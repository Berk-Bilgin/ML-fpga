//Numpy array shape [4]
//Min -0.047851562500
//Max 0.073730468750
//Number of zeros 0

#ifndef B8_H_
#define B8_H_

#ifndef __SYNTHESIS__
bias8_t b8[4];
#else
bias8_t b8[4] = {-0.04785156250, -0.01220703125, -0.00488281250, 0.07373046875};
#endif

#endif
