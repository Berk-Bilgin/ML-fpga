//Numpy array shape [8]
//Min -0.180175781250
//Max 0.260253906250
//Number of zeros 0

#ifndef B5_H_
#define B5_H_

#ifndef __SYNTHESIS__
bias5_t b5[8];
#else
bias5_t b5[8] = {0.06054687500, -0.06933593750, -0.18017578125, -0.02636718750, 0.05615234375, -0.04248046875, 0.26025390625, 0.06250000000};
#endif

#endif
