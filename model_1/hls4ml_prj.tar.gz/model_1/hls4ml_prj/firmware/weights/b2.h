//Numpy array shape [8]
//Min -0.149902343750
//Max 0.034667968750
//Number of zeros 0

#ifndef B2_H_
#define B2_H_

#ifndef __SYNTHESIS__
bias2_t b2[8];
#else
bias2_t b2[8] = {-0.03662109375, -0.14990234375, -0.14648437500, -0.03759765625, -0.13574218750, 0.03466796875, -0.11718750000, -0.00830078125};
#endif

#endif
