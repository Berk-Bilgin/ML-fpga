#include "conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s.h"
#include "AESL_pkg.h"

using namespace std;

namespace ap_rtl {

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_ap_clk_no_reset_() {
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_CS_fsm = ap_ST_fsm_state1;
    } else {
        ap_CS_fsm = ap_NS_fsm.read();
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_done_reg = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, ap_continue.read())) {
            ap_done_reg = ap_const_logic_0;
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state8.read()) && 
                    !(esl_seteq<1,1,1>(and_ln360_reg_24080.read(), ap_const_lv1_1) && esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op3666.read())) && 
                    esl_seteq<1,1,1>(ap_const_lv1_1, icmp_ln64_fu_23162_p2.read()))) {
            ap_done_reg = ap_const_logic_1;
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_enable_reg_pp1_iter0 = ap_const_logic_0;
    } else {
        if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
             esl_seteq<1,1,1>(ap_block_pp1_stage0_subdone.read(), ap_const_boolean_0) && 
             esl_seteq<1,1,1>(ap_const_lv1_1, ap_phi_mux_in_index13_phi_fu_860_p4.read()))) {
            ap_enable_reg_pp1_iter0 = ap_const_logic_0;
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state4.read()) && 
                    esl_seteq<1,1,1>(ap_const_lv1_1, and_ln360_fu_1390_p2.read()))) {
            ap_enable_reg_pp1_iter0 = ap_const_logic_1;
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_enable_reg_pp1_iter1 = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_block_pp1_stage0_subdone.read(), ap_const_boolean_0)) {
            ap_enable_reg_pp1_iter1 = ap_enable_reg_pp1_iter0.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_enable_reg_pp1_iter2 = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_block_pp1_stage0_subdone.read(), ap_const_boolean_0)) {
            ap_enable_reg_pp1_iter2 = ap_enable_reg_pp1_iter1.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state4.read()) && 
                    esl_seteq<1,1,1>(ap_const_lv1_1, and_ln360_fu_1390_p2.read()))) {
            ap_enable_reg_pp1_iter2 = ap_const_logic_0;
        }
    }
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state8.read()) && 
         !(esl_seteq<1,1,1>(and_ln360_reg_24080.read(), ap_const_lv1_1) && esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op3666.read())) && 
         esl_seteq<1,1,1>(icmp_ln64_fu_23162_p2.read(), ap_const_lv1_0))) {
        i_iw_0_i14_reg_729 = i_iw_reg_24048.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
                !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1)))) {
        i_iw_0_i14_reg_729 = ap_const_lv7_0;
    }
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state3.read()) && 
         esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln166_fu_1112_p2.read()))) {
        i_iw_0_i_i_i_reg_741 = i_iw_3_fu_1118_p2.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read()) && 
                esl_seteq<1,1,1>(io_acc_block_signal_op26.read(), ap_const_logic_1))) {
        i_iw_0_i_i_i_reg_741 = ap_const_lv3_0;
    }
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
         esl_seteq<1,1,1>(in_index13_reg_856.read(), ap_const_lv1_0))) {
        in_index13_reg_856 = in_index_reg_24089.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state4.read()) && 
                esl_seteq<1,1,1>(ap_const_lv1_1, and_ln360_fu_1390_p2.read()))) {
        in_index13_reg_856 = ap_const_lv1_0;
    }
    if (esl_seteq<1,1,1>(ap_condition_451.read(), ap_const_boolean_1)) {
        if (esl_seteq<1,1,1>(ap_const_lv1_1, icmp_ln384_fu_23121_p2.read())) {
            pX_2 = ap_const_lv32_0;
        } else if (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln384_fu_23121_p2.read())) {
            pX_2 = add_ln389_fu_23126_p2.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        start_once_reg = ap_const_logic_0;
    } else {
        if ((esl_seteq<1,1,1>(ap_const_logic_1, real_start.read()) && 
             esl_seteq<1,1,1>(ap_const_logic_0, internal_ap_ready.read()))) {
            start_once_reg = ap_const_logic_1;
        } else if (esl_seteq<1,1,1>(ap_const_logic_1, internal_ap_ready.read())) {
            start_once_reg = ap_const_logic_0;
        }
    }
    if ((esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
         esl_seteq<1,1,1>(in_index13_reg_856_pp1_iter1_reg.read(), ap_const_lv1_0))) {
        tmp_data_0_V_1611_reg_868 = tmp_data_0_V_fu_17320_p3.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state4.read()) && 
                esl_seteq<1,1,1>(ap_const_lv1_1, and_ln360_fu_1390_p2.read()))) {
        tmp_data_0_V_1611_reg_868 = ap_const_lv24_FFFFF4;
    }
    if ((esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
         esl_seteq<1,1,1>(in_index13_reg_856_pp1_iter1_reg.read(), ap_const_lv1_0))) {
        tmp_data_1_V_139_reg_879 = tmp_data_1_V_fu_19251_p3.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state4.read()) && 
                esl_seteq<1,1,1>(ap_const_lv1_1, and_ln360_fu_1390_p2.read()))) {
        tmp_data_1_V_139_reg_879 = ap_const_lv24_FFFFFC;
    }
    if ((esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
         esl_seteq<1,1,1>(in_index13_reg_856_pp1_iter1_reg.read(), ap_const_lv1_0))) {
        tmp_data_2_V_137_reg_890 = tmp_data_2_V_fu_21182_p3.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state4.read()) && 
                esl_seteq<1,1,1>(ap_const_lv1_1, and_ln360_fu_1390_p2.read()))) {
        tmp_data_2_V_137_reg_890 = ap_const_lv24_FFFFFE;
    }
    if ((esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
         esl_seteq<1,1,1>(in_index13_reg_856_pp1_iter1_reg.read(), ap_const_lv1_0))) {
        tmp_data_3_V_135_reg_901 = tmp_data_3_V_fu_23113_p3.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state4.read()) && 
                esl_seteq<1,1,1>(ap_const_lv1_1, and_ln360_fu_1390_p2.read()))) {
        tmp_data_3_V_135_reg_901 = ap_const_lv24_12;
    }
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state4.read())) {
        and_ln360_reg_24080 = and_ln360_fu_1390_p2.read();
        icmp_ln360_reg_24069 = icmp_ln360_fu_1364_p2.read();
        kernel_data_V_1_32 = tmp_data_V_17_0_reg_23968.read();
        kernel_data_V_1_33 = tmp_data_V_17_1_reg_23973.read();
        kernel_data_V_1_34 = tmp_data_V_17_2_reg_23978.read();
        kernel_data_V_1_35 = tmp_data_V_17_3_reg_23983.read();
        kernel_data_V_1_36 = tmp_data_V_17_4_reg_23988.read();
        kernel_data_V_1_37 = tmp_data_V_17_5_reg_23993.read();
        kernel_data_V_1_38 = tmp_data_V_17_6_reg_23998.read();
        kernel_data_V_1_39 = tmp_data_V_17_7_reg_24003.read();
        pX_2_load_reg_24074 = pX_2.read();
        sX_2_load_reg_24064 = sX_2.read();
    }
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read()) && esl_seteq<1,1,1>(io_acc_block_signal_op26.read(), ap_const_logic_1))) {
        i_iw_reg_24048 = i_iw_fu_1106_p2.read();
        kernel_data_V_1_32_load_reg_24008 = kernel_data_V_1_32.read();
        kernel_data_V_1_33_load_reg_24013 = kernel_data_V_1_33.read();
        kernel_data_V_1_34_load_reg_24018 = kernel_data_V_1_34.read();
        kernel_data_V_1_35_load_reg_24023 = kernel_data_V_1_35.read();
        kernel_data_V_1_36_load_reg_24028 = kernel_data_V_1_36.read();
        kernel_data_V_1_37_load_reg_24033 = kernel_data_V_1_37.read();
        kernel_data_V_1_38_load_reg_24038 = kernel_data_V_1_38.read();
        kernel_data_V_1_39_load_reg_24043 = kernel_data_V_1_39.read();
        tmp_data_V_17_0_reg_23968 = data_V_data_0_V_dout.read();
        tmp_data_V_17_1_reg_23973 = data_V_data_1_V_dout.read();
        tmp_data_V_17_2_reg_23978 = data_V_data_2_V_dout.read();
        tmp_data_V_17_3_reg_23983 = data_V_data_3_V_dout.read();
        tmp_data_V_17_4_reg_23988 = data_V_data_4_V_dout.read();
        tmp_data_V_17_5_reg_23993 = data_V_data_5_V_dout.read();
        tmp_data_V_17_6_reg_23998 = data_V_data_6_V_dout.read();
        tmp_data_V_17_7_reg_24003 = data_V_data_7_V_dout.read();
    }
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0))) {
        in_index13_reg_856_pp1_iter1_reg = in_index13_reg_856.read();
        select_ln340_2416_reg_24094 = select_ln340_2416_fu_1593_p3.read();
        select_ln340_2418_reg_24100 = select_ln340_2418_fu_1793_p3.read();
        select_ln340_2420_reg_24106 = select_ln340_2420_fu_1993_p3.read();
        select_ln340_2422_reg_24112 = select_ln340_2422_fu_2193_p3.read();
        select_ln340_2424_reg_24118 = select_ln340_2424_fu_2385_p3.read();
        select_ln340_2426_reg_24124 = select_ln340_2426_fu_2577_p3.read();
        select_ln340_2428_reg_24130 = select_ln340_2428_fu_2769_p3.read();
        select_ln340_2430_reg_24136 = select_ln340_2430_fu_2961_p3.read();
        select_ln340_2432_reg_24142 = select_ln340_2432_fu_3153_p3.read();
        select_ln340_2434_reg_24148 = select_ln340_2434_fu_3345_p3.read();
        select_ln340_2436_reg_24154 = select_ln340_2436_fu_3537_p3.read();
        select_ln340_2438_reg_24160 = select_ln340_2438_fu_3729_p3.read();
        select_ln340_2440_reg_24166 = select_ln340_2440_fu_3921_p3.read();
        select_ln340_2442_reg_24172 = select_ln340_2442_fu_4113_p3.read();
        select_ln340_2444_reg_24178 = select_ln340_2444_fu_4305_p3.read();
        select_ln340_2446_reg_24184 = select_ln340_2446_fu_4497_p3.read();
        select_ln340_2448_reg_24190 = select_ln340_2448_fu_4689_p3.read();
        select_ln340_2450_reg_24196 = select_ln340_2450_fu_4881_p3.read();
        select_ln340_2452_reg_24202 = select_ln340_2452_fu_5073_p3.read();
        select_ln340_2456_reg_24213 = select_ln340_2456_fu_5263_p3.read();
        select_ln340_2458_reg_24219 = select_ln340_2458_fu_5443_p3.read();
        select_ln340_2460_reg_24225 = select_ln340_2460_fu_5623_p3.read();
        select_ln340_2462_reg_24231 = select_ln340_2462_fu_5803_p3.read();
        select_ln340_2464_reg_24237 = select_ln340_2464_fu_5983_p3.read();
        select_ln340_2466_reg_24243 = select_ln340_2466_fu_6163_p3.read();
        select_ln340_2468_reg_24249 = select_ln340_2468_fu_6343_p3.read();
        select_ln340_2470_reg_24255 = select_ln340_2470_fu_6523_p3.read();
        select_ln340_2472_reg_24261 = select_ln340_2472_fu_6703_p3.read();
        select_ln340_2474_reg_24267 = select_ln340_2474_fu_6883_p3.read();
        select_ln340_2476_reg_24273 = select_ln340_2476_fu_7063_p3.read();
        select_ln340_2478_reg_24279 = select_ln340_2478_fu_7243_p3.read();
        select_ln340_2480_reg_24285 = select_ln340_2480_fu_7423_p3.read();
        select_ln340_2482_reg_24291 = select_ln340_2482_fu_7603_p3.read();
        select_ln340_2484_reg_24297 = select_ln340_2484_fu_7783_p3.read();
        select_ln340_2486_reg_24303 = select_ln340_2486_fu_7963_p3.read();
        select_ln340_2488_reg_24309 = select_ln340_2488_fu_8143_p3.read();
        select_ln340_2490_reg_24315 = select_ln340_2490_fu_8323_p3.read();
        select_ln340_2492_reg_24321 = select_ln340_2492_fu_8503_p3.read();
        select_ln340_2496_reg_24332 = select_ln340_2496_fu_8693_p3.read();
        select_ln340_2498_reg_24338 = select_ln340_2498_fu_8873_p3.read();
        select_ln340_2500_reg_24344 = select_ln340_2500_fu_9053_p3.read();
        select_ln340_2502_reg_24350 = select_ln340_2502_fu_9233_p3.read();
        select_ln340_2504_reg_24356 = select_ln340_2504_fu_9413_p3.read();
        select_ln340_2506_reg_24362 = select_ln340_2506_fu_9593_p3.read();
        select_ln340_2508_reg_24368 = select_ln340_2508_fu_9773_p3.read();
        select_ln340_2510_reg_24374 = select_ln340_2510_fu_9953_p3.read();
        select_ln340_2512_reg_24380 = select_ln340_2512_fu_10133_p3.read();
        select_ln340_2514_reg_24386 = select_ln340_2514_fu_10313_p3.read();
        select_ln340_2516_reg_24392 = select_ln340_2516_fu_10493_p3.read();
        select_ln340_2518_reg_24398 = select_ln340_2518_fu_10673_p3.read();
        select_ln340_2520_reg_24404 = select_ln340_2520_fu_10853_p3.read();
        select_ln340_2522_reg_24410 = select_ln340_2522_fu_11033_p3.read();
        select_ln340_2524_reg_24416 = select_ln340_2524_fu_11213_p3.read();
        select_ln340_2526_reg_24422 = select_ln340_2526_fu_11393_p3.read();
        select_ln340_2528_reg_24428 = select_ln340_2528_fu_11573_p3.read();
        select_ln340_2530_reg_24434 = select_ln340_2530_fu_11753_p3.read();
        select_ln340_2532_reg_24440 = select_ln340_2532_fu_11933_p3.read();
        select_ln340_2536_reg_24451 = select_ln340_2536_fu_12123_p3.read();
        select_ln340_2538_reg_24457 = select_ln340_2538_fu_12303_p3.read();
        select_ln340_2540_reg_24463 = select_ln340_2540_fu_12483_p3.read();
        select_ln340_2542_reg_24469 = select_ln340_2542_fu_12663_p3.read();
        select_ln340_2544_reg_24475 = select_ln340_2544_fu_12843_p3.read();
        select_ln340_2546_reg_24481 = select_ln340_2546_fu_13023_p3.read();
        select_ln340_2548_reg_24487 = select_ln340_2548_fu_13203_p3.read();
        select_ln340_2550_reg_24493 = select_ln340_2550_fu_13383_p3.read();
        select_ln340_2552_reg_24499 = select_ln340_2552_fu_13563_p3.read();
        select_ln340_2554_reg_24505 = select_ln340_2554_fu_13743_p3.read();
        select_ln340_2556_reg_24511 = select_ln340_2556_fu_13923_p3.read();
        select_ln340_2558_reg_24517 = select_ln340_2558_fu_14103_p3.read();
        select_ln340_2560_reg_24523 = select_ln340_2560_fu_14283_p3.read();
        select_ln340_2562_reg_24529 = select_ln340_2562_fu_14463_p3.read();
        select_ln340_2564_reg_24535 = select_ln340_2564_fu_14643_p3.read();
        select_ln340_2566_reg_24541 = select_ln340_2566_fu_14823_p3.read();
        select_ln340_2568_reg_24547 = select_ln340_2568_fu_15003_p3.read();
        select_ln340_2570_reg_24553 = select_ln340_2570_fu_15183_p3.read();
        select_ln340_2572_reg_24559 = select_ln340_2572_fu_15363_p3.read();
        tmp_692_reg_24208 = w8_V_q0.read().range(159, 152);
        tmp_712_reg_24327 = w8_V_q0.read().range(319, 312);
        tmp_732_reg_24446 = w8_V_q0.read().range(479, 472);
        tmp_752_reg_24565 = w8_V_q0.read().range(638, 632);
    }
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        in_index_reg_24089 = in_index_fu_1401_p2.read();
    }
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state3.read()) && esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln166_fu_1112_p2.read()) && esl_seteq<1,2,2>(trunc_ln203_fu_1124_p1.read(), ap_const_lv2_0))) {
        kernel_data_V_1_0 = ap_phi_mux_phi_ln203_phi_fu_755_p8.read();
    }
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state3.read()) && esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln166_fu_1112_p2.read()) && esl_seteq<1,3,3>(ap_const_lv3_0, ap_phi_mux_i_iw_0_i_i_i_phi_fu_745_p4.read()))) {
        kernel_data_V_1_1 = ap_phi_mux_phi_ln203_8_phi_fu_768_p8.read();
        kernel_data_V_1_2 = ap_phi_mux_phi_ln203_9_phi_fu_781_p8.read();
        kernel_data_V_1_3 = ap_phi_mux_phi_ln203_10_phi_fu_794_p8.read();
        kernel_data_V_1_4 = ap_phi_mux_phi_ln203_11_phi_fu_807_p8.read();
        kernel_data_V_1_5 = ap_phi_mux_phi_ln203_12_phi_fu_820_p8.read();
        kernel_data_V_1_6 = ap_phi_mux_phi_ln203_13_phi_fu_833_p8.read();
        kernel_data_V_1_7 = ap_phi_mux_phi_ln203_14_phi_fu_846_p8.read();
    }
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state3.read()) && esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln166_fu_1112_p2.read()) && esl_seteq<1,3,3>(ap_phi_mux_i_iw_0_i_i_i_phi_fu_745_p4.read(), ap_const_lv3_1))) {
        kernel_data_V_1_10 = ap_phi_mux_phi_ln203_9_phi_fu_781_p8.read();
        kernel_data_V_1_11 = ap_phi_mux_phi_ln203_10_phi_fu_794_p8.read();
        kernel_data_V_1_12 = ap_phi_mux_phi_ln203_11_phi_fu_807_p8.read();
        kernel_data_V_1_13 = ap_phi_mux_phi_ln203_12_phi_fu_820_p8.read();
        kernel_data_V_1_14 = ap_phi_mux_phi_ln203_13_phi_fu_833_p8.read();
        kernel_data_V_1_15 = ap_phi_mux_phi_ln203_14_phi_fu_846_p8.read();
        kernel_data_V_1_9 = ap_phi_mux_phi_ln203_8_phi_fu_768_p8.read();
    }
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state3.read()) && esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln166_fu_1112_p2.read()) && esl_seteq<1,2,2>(trunc_ln203_fu_1124_p1.read(), ap_const_lv2_2))) {
        kernel_data_V_1_16 = ap_phi_mux_phi_ln203_phi_fu_755_p8.read();
    }
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state3.read()) && esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln166_fu_1112_p2.read()) && esl_seteq<1,3,3>(ap_phi_mux_i_iw_0_i_i_i_phi_fu_745_p4.read(), ap_const_lv3_2))) {
        kernel_data_V_1_17 = ap_phi_mux_phi_ln203_8_phi_fu_768_p8.read();
        kernel_data_V_1_18 = ap_phi_mux_phi_ln203_9_phi_fu_781_p8.read();
        kernel_data_V_1_19 = ap_phi_mux_phi_ln203_10_phi_fu_794_p8.read();
        kernel_data_V_1_20 = ap_phi_mux_phi_ln203_11_phi_fu_807_p8.read();
        kernel_data_V_1_21 = ap_phi_mux_phi_ln203_12_phi_fu_820_p8.read();
        kernel_data_V_1_22 = ap_phi_mux_phi_ln203_13_phi_fu_833_p8.read();
        kernel_data_V_1_23 = ap_phi_mux_phi_ln203_14_phi_fu_846_p8.read();
    }
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state3.read()) && esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln166_fu_1112_p2.read()) && esl_seteq<1,2,2>(trunc_ln203_fu_1124_p1.read(), ap_const_lv2_3))) {
        kernel_data_V_1_24 = ap_phi_mux_phi_ln203_phi_fu_755_p8.read();
    }
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state3.read()) && esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln166_fu_1112_p2.read()) && !esl_seteq<1,3,3>(ap_const_lv3_0, ap_phi_mux_i_iw_0_i_i_i_phi_fu_745_p4.read()) && !esl_seteq<1,3,3>(ap_phi_mux_i_iw_0_i_i_i_phi_fu_745_p4.read(), ap_const_lv3_1) && !esl_seteq<1,3,3>(ap_phi_mux_i_iw_0_i_i_i_phi_fu_745_p4.read(), ap_const_lv3_2))) {
        kernel_data_V_1_25 = ap_phi_mux_phi_ln203_8_phi_fu_768_p8.read();
        kernel_data_V_1_26 = ap_phi_mux_phi_ln203_9_phi_fu_781_p8.read();
        kernel_data_V_1_27 = ap_phi_mux_phi_ln203_10_phi_fu_794_p8.read();
        kernel_data_V_1_28 = ap_phi_mux_phi_ln203_11_phi_fu_807_p8.read();
        kernel_data_V_1_29 = ap_phi_mux_phi_ln203_12_phi_fu_820_p8.read();
        kernel_data_V_1_30 = ap_phi_mux_phi_ln203_13_phi_fu_833_p8.read();
        kernel_data_V_1_31 = ap_phi_mux_phi_ln203_14_phi_fu_846_p8.read();
    }
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state3.read()) && esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln166_fu_1112_p2.read()) && esl_seteq<1,2,2>(trunc_ln203_fu_1124_p1.read(), ap_const_lv2_1))) {
        kernel_data_V_1_8 = ap_phi_mux_phi_ln203_phi_fu_755_p8.read();
    }
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state8.read()) && !(esl_seteq<1,1,1>(and_ln360_reg_24080.read(), ap_const_lv1_1) && esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op3666.read())))) {
        sX_2 = ap_phi_mux_storemerge_i_i_phi_fu_915_p4.read();
    }
    if ((esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()))) {
        tmp_data_0_V_reg_24570 = tmp_data_0_V_fu_17320_p3.read();
        tmp_data_1_V_reg_24576 = tmp_data_1_V_fu_19251_p3.read();
        tmp_data_2_V_reg_24582 = tmp_data_2_V_fu_21182_p3.read();
        tmp_data_3_V_reg_24588 = tmp_data_3_V_fu_23113_p3.read();
    }
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_ap_NS_fsm() {
    switch (ap_CS_fsm.read().to_uint64()) {
        case 1 : 
            if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1)))) {
                ap_NS_fsm = ap_ST_fsm_state2;
            } else {
                ap_NS_fsm = ap_ST_fsm_state1;
            }
            break;
        case 2 : 
            if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read()) && esl_seteq<1,1,1>(io_acc_block_signal_op26.read(), ap_const_logic_1))) {
                ap_NS_fsm = ap_ST_fsm_state3;
            } else {
                ap_NS_fsm = ap_ST_fsm_state2;
            }
            break;
        case 4 : 
            if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state3.read()) && esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln166_fu_1112_p2.read()))) {
                ap_NS_fsm = ap_ST_fsm_state3;
            } else {
                ap_NS_fsm = ap_ST_fsm_state4;
            }
            break;
        case 8 : 
            if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state4.read()) && esl_seteq<1,1,1>(ap_const_lv1_1, and_ln360_fu_1390_p2.read()))) {
                ap_NS_fsm = ap_ST_fsm_pp1_stage0;
            } else {
                ap_NS_fsm = ap_ST_fsm_state8;
            }
            break;
        case 16 : 
            if (!(esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && esl_seteq<1,1,1>(ap_block_pp1_stage0_subdone.read(), ap_const_boolean_0) && esl_seteq<1,1,1>(ap_enable_reg_pp1_iter1.read(), ap_const_logic_0))) {
                ap_NS_fsm = ap_ST_fsm_pp1_stage0;
            } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && esl_seteq<1,1,1>(ap_block_pp1_stage0_subdone.read(), ap_const_boolean_0) && esl_seteq<1,1,1>(ap_enable_reg_pp1_iter1.read(), ap_const_logic_0))) {
                ap_NS_fsm = ap_ST_fsm_state8;
            } else {
                ap_NS_fsm = ap_ST_fsm_pp1_stage0;
            }
            break;
        case 32 : 
            if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state8.read()) && !(esl_seteq<1,1,1>(and_ln360_reg_24080.read(), ap_const_lv1_1) && esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op3666.read())) && esl_seteq<1,1,1>(ap_const_lv1_1, icmp_ln64_fu_23162_p2.read()))) {
                ap_NS_fsm = ap_ST_fsm_state1;
            } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state8.read()) && !(esl_seteq<1,1,1>(and_ln360_reg_24080.read(), ap_const_lv1_1) && esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op3666.read())) && esl_seteq<1,1,1>(icmp_ln64_fu_23162_p2.read(), ap_const_lv1_0))) {
                ap_NS_fsm = ap_ST_fsm_state2;
            } else {
                ap_NS_fsm = ap_ST_fsm_state8;
            }
            break;
        default : 
            ap_NS_fsm =  (sc_lv<6>) ("XXXXXX");
            break;
    }
}

}

