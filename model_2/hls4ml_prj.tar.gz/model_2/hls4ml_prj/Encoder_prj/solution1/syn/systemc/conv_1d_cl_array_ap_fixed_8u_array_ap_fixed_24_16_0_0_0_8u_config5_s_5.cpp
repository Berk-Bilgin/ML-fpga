#include "conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s.h"
#include "AESL_pkg.h"

using namespace std;

namespace ap_rtl {

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_2382_fu_37957_p2() {
    or_ln340_2382_fu_37957_p2 = (tmp_4833_fu_37925_p3.read() | xor_ln340_645_fu_37951_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_2383_fu_17407_p2() {
    or_ln340_2383_fu_17407_p2 = (and_ln786_88_fu_17377_p2.read() | xor_ln779_88_fu_17345_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_2384_fu_17413_p2() {
    or_ln340_2384_fu_17413_p2 = (or_ln340_2383_fu_17407_p2.read() | and_ln416_599_fu_17331_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_2385_fu_38045_p2() {
    or_ln340_2385_fu_38045_p2 = (tmp_4840_fu_38013_p3.read() | xor_ln340_646_fu_38039_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_2386_fu_17587_p2() {
    or_ln340_2386_fu_17587_p2 = (and_ln786_89_fu_17557_p2.read() | xor_ln779_89_fu_17525_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_2387_fu_17593_p2() {
    or_ln340_2387_fu_17593_p2 = (or_ln340_2386_fu_17587_p2.read() | and_ln416_600_fu_17511_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_2388_fu_38133_p2() {
    or_ln340_2388_fu_38133_p2 = (tmp_4847_fu_38101_p3.read() | xor_ln340_647_fu_38127_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_2389_fu_17767_p2() {
    or_ln340_2389_fu_17767_p2 = (and_ln786_90_fu_17737_p2.read() | xor_ln779_90_fu_17705_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_2390_fu_17773_p2() {
    or_ln340_2390_fu_17773_p2 = (or_ln340_2389_fu_17767_p2.read() | and_ln416_601_fu_17691_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_2391_fu_38221_p2() {
    or_ln340_2391_fu_38221_p2 = (tmp_4854_fu_38189_p3.read() | xor_ln340_648_fu_38215_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_2392_fu_17947_p2() {
    or_ln340_2392_fu_17947_p2 = (and_ln786_91_fu_17917_p2.read() | xor_ln779_91_fu_17885_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_2393_fu_17953_p2() {
    or_ln340_2393_fu_17953_p2 = (or_ln340_2392_fu_17947_p2.read() | and_ln416_602_fu_17871_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_2394_fu_38309_p2() {
    or_ln340_2394_fu_38309_p2 = (tmp_4861_fu_38277_p3.read() | xor_ln340_649_fu_38303_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_2395_fu_18127_p2() {
    or_ln340_2395_fu_18127_p2 = (and_ln786_92_fu_18097_p2.read() | xor_ln779_92_fu_18065_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_2396_fu_18133_p2() {
    or_ln340_2396_fu_18133_p2 = (or_ln340_2395_fu_18127_p2.read() | and_ln416_603_fu_18051_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_2397_fu_38397_p2() {
    or_ln340_2397_fu_38397_p2 = (tmp_4868_fu_38365_p3.read() | xor_ln340_650_fu_38391_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_2398_fu_18307_p2() {
    or_ln340_2398_fu_18307_p2 = (and_ln786_93_fu_18277_p2.read() | xor_ln779_93_fu_18245_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_2399_fu_18313_p2() {
    or_ln340_2399_fu_18313_p2 = (or_ln340_2398_fu_18307_p2.read() | and_ln416_604_fu_18231_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_23_fu_6211_p2() {
    or_ln340_23_fu_6211_p2 = (and_ln786_1653_fu_6205_p2.read() | and_ln785_534_fu_6181_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_2400_fu_38485_p2() {
    or_ln340_2400_fu_38485_p2 = (tmp_4875_fu_38453_p3.read() | xor_ln340_651_fu_38479_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_2401_fu_18487_p2() {
    or_ln340_2401_fu_18487_p2 = (and_ln786_94_fu_18457_p2.read() | xor_ln779_94_fu_18425_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_2402_fu_18493_p2() {
    or_ln340_2402_fu_18493_p2 = (or_ln340_2401_fu_18487_p2.read() | and_ln416_605_fu_18411_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_2403_fu_38573_p2() {
    or_ln340_2403_fu_38573_p2 = (tmp_4882_fu_38541_p3.read() | xor_ln340_652_fu_38567_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_2404_fu_18667_p2() {
    or_ln340_2404_fu_18667_p2 = (and_ln786_95_fu_18637_p2.read() | xor_ln779_95_fu_18605_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_2405_fu_18673_p2() {
    or_ln340_2405_fu_18673_p2 = (or_ln340_2404_fu_18667_p2.read() | and_ln416_606_fu_18591_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_2406_fu_38661_p2() {
    or_ln340_2406_fu_38661_p2 = (tmp_4889_fu_38629_p3.read() | xor_ln340_653_fu_38655_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_2407_fu_18847_p2() {
    or_ln340_2407_fu_18847_p2 = (and_ln786_96_fu_18817_p2.read() | xor_ln779_96_fu_18785_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_2408_fu_18853_p2() {
    or_ln340_2408_fu_18853_p2 = (or_ln340_2407_fu_18847_p2.read() | and_ln416_607_fu_18771_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_2409_fu_38749_p2() {
    or_ln340_2409_fu_38749_p2 = (tmp_4896_fu_38717_p3.read() | xor_ln340_654_fu_38743_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_2410_fu_19027_p2() {
    or_ln340_2410_fu_19027_p2 = (and_ln786_97_fu_18997_p2.read() | xor_ln779_97_fu_18965_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_2411_fu_19033_p2() {
    or_ln340_2411_fu_19033_p2 = (or_ln340_2410_fu_19027_p2.read() | and_ln416_608_fu_18951_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_2412_fu_38837_p2() {
    or_ln340_2412_fu_38837_p2 = (tmp_4903_fu_38805_p3.read() | xor_ln340_655_fu_38831_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_2413_fu_19207_p2() {
    or_ln340_2413_fu_19207_p2 = (and_ln786_98_fu_19177_p2.read() | xor_ln779_98_fu_19145_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_2414_fu_19213_p2() {
    or_ln340_2414_fu_19213_p2 = (or_ln340_2413_fu_19207_p2.read() | and_ln416_609_fu_19131_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_2415_fu_38925_p2() {
    or_ln340_2415_fu_38925_p2 = (tmp_4910_fu_38893_p3.read() | xor_ln340_656_fu_38919_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_2416_fu_39088_p2() {
    or_ln340_2416_fu_39088_p2 = (and_ln786_99_fu_39058_p2.read() | xor_ln779_99_fu_39026_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_2417_fu_39094_p2() {
    or_ln340_2417_fu_39094_p2 = (or_ln340_2416_fu_39088_p2.read() | and_ln416_610_fu_39012_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_2418_fu_39184_p2() {
    or_ln340_2418_fu_39184_p2 = (tmp_4917_fu_39152_p3.read() | xor_ln340_657_fu_39178_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_2419_fu_19397_p2() {
    or_ln340_2419_fu_19397_p2 = (and_ln786_100_fu_19367_p2.read() | xor_ln779_100_fu_19335_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_2420_fu_19403_p2() {
    or_ln340_2420_fu_19403_p2 = (or_ln340_2419_fu_19397_p2.read() | and_ln416_611_fu_19321_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_2421_fu_39272_p2() {
    or_ln340_2421_fu_39272_p2 = (tmp_4924_fu_39240_p3.read() | xor_ln340_658_fu_39266_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_2422_fu_19577_p2() {
    or_ln340_2422_fu_19577_p2 = (and_ln786_101_fu_19547_p2.read() | xor_ln779_101_fu_19515_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_2423_fu_19583_p2() {
    or_ln340_2423_fu_19583_p2 = (or_ln340_2422_fu_19577_p2.read() | and_ln416_612_fu_19501_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_2424_fu_39360_p2() {
    or_ln340_2424_fu_39360_p2 = (tmp_4931_fu_39328_p3.read() | xor_ln340_659_fu_39354_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_2425_fu_19757_p2() {
    or_ln340_2425_fu_19757_p2 = (and_ln786_102_fu_19727_p2.read() | xor_ln779_102_fu_19695_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_2426_fu_19763_p2() {
    or_ln340_2426_fu_19763_p2 = (or_ln340_2425_fu_19757_p2.read() | and_ln416_613_fu_19681_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_2427_fu_39448_p2() {
    or_ln340_2427_fu_39448_p2 = (tmp_4938_fu_39416_p3.read() | xor_ln340_660_fu_39442_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_2428_fu_19937_p2() {
    or_ln340_2428_fu_19937_p2 = (and_ln786_103_fu_19907_p2.read() | xor_ln779_103_fu_19875_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_2429_fu_19943_p2() {
    or_ln340_2429_fu_19943_p2 = (or_ln340_2428_fu_19937_p2.read() | and_ln416_614_fu_19861_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_2430_fu_39536_p2() {
    or_ln340_2430_fu_39536_p2 = (tmp_4945_fu_39504_p3.read() | xor_ln340_661_fu_39530_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_2431_fu_20117_p2() {
    or_ln340_2431_fu_20117_p2 = (and_ln786_104_fu_20087_p2.read() | xor_ln779_104_fu_20055_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_2432_fu_20123_p2() {
    or_ln340_2432_fu_20123_p2 = (or_ln340_2431_fu_20117_p2.read() | and_ln416_615_fu_20041_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_2433_fu_39624_p2() {
    or_ln340_2433_fu_39624_p2 = (tmp_4952_fu_39592_p3.read() | xor_ln340_662_fu_39618_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_2434_fu_20297_p2() {
    or_ln340_2434_fu_20297_p2 = (and_ln786_105_fu_20267_p2.read() | xor_ln779_105_fu_20235_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_2435_fu_20303_p2() {
    or_ln340_2435_fu_20303_p2 = (or_ln340_2434_fu_20297_p2.read() | and_ln416_616_fu_20221_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_2436_fu_39712_p2() {
    or_ln340_2436_fu_39712_p2 = (tmp_4959_fu_39680_p3.read() | xor_ln340_663_fu_39706_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_2437_fu_20477_p2() {
    or_ln340_2437_fu_20477_p2 = (and_ln786_106_fu_20447_p2.read() | xor_ln779_106_fu_20415_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_2438_fu_20483_p2() {
    or_ln340_2438_fu_20483_p2 = (or_ln340_2437_fu_20477_p2.read() | and_ln416_617_fu_20401_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_2439_fu_39800_p2() {
    or_ln340_2439_fu_39800_p2 = (tmp_4966_fu_39768_p3.read() | xor_ln340_664_fu_39794_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_2440_fu_20657_p2() {
    or_ln340_2440_fu_20657_p2 = (and_ln786_107_fu_20627_p2.read() | xor_ln779_107_fu_20595_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_2441_fu_20663_p2() {
    or_ln340_2441_fu_20663_p2 = (or_ln340_2440_fu_20657_p2.read() | and_ln416_618_fu_20581_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_2442_fu_39888_p2() {
    or_ln340_2442_fu_39888_p2 = (tmp_4973_fu_39856_p3.read() | xor_ln340_665_fu_39882_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_2443_fu_20837_p2() {
    or_ln340_2443_fu_20837_p2 = (and_ln786_108_fu_20807_p2.read() | xor_ln779_108_fu_20775_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_2444_fu_20843_p2() {
    or_ln340_2444_fu_20843_p2 = (or_ln340_2443_fu_20837_p2.read() | and_ln416_619_fu_20761_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_2445_fu_39976_p2() {
    or_ln340_2445_fu_39976_p2 = (tmp_4980_fu_39944_p3.read() | xor_ln340_666_fu_39970_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_2446_fu_21017_p2() {
    or_ln340_2446_fu_21017_p2 = (and_ln786_109_fu_20987_p2.read() | xor_ln779_109_fu_20955_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_2447_fu_21023_p2() {
    or_ln340_2447_fu_21023_p2 = (or_ln340_2446_fu_21017_p2.read() | and_ln416_620_fu_20941_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_2448_fu_40064_p2() {
    or_ln340_2448_fu_40064_p2 = (tmp_4987_fu_40032_p3.read() | xor_ln340_667_fu_40058_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_2449_fu_21197_p2() {
    or_ln340_2449_fu_21197_p2 = (and_ln786_110_fu_21167_p2.read() | xor_ln779_110_fu_21135_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_2450_fu_21203_p2() {
    or_ln340_2450_fu_21203_p2 = (or_ln340_2449_fu_21197_p2.read() | and_ln416_621_fu_21121_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_2451_fu_40152_p2() {
    or_ln340_2451_fu_40152_p2 = (tmp_4994_fu_40120_p3.read() | xor_ln340_668_fu_40146_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_2452_fu_21377_p2() {
    or_ln340_2452_fu_21377_p2 = (and_ln786_111_fu_21347_p2.read() | xor_ln779_111_fu_21315_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_2453_fu_21383_p2() {
    or_ln340_2453_fu_21383_p2 = (or_ln340_2452_fu_21377_p2.read() | and_ln416_622_fu_21301_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_2454_fu_40240_p2() {
    or_ln340_2454_fu_40240_p2 = (tmp_5001_fu_40208_p3.read() | xor_ln340_669_fu_40234_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_2455_fu_21557_p2() {
    or_ln340_2455_fu_21557_p2 = (and_ln786_112_fu_21527_p2.read() | xor_ln779_112_fu_21495_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_2456_fu_21563_p2() {
    or_ln340_2456_fu_21563_p2 = (or_ln340_2455_fu_21557_p2.read() | and_ln416_623_fu_21481_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_2457_fu_40328_p2() {
    or_ln340_2457_fu_40328_p2 = (tmp_5008_fu_40296_p3.read() | xor_ln340_670_fu_40322_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_2458_fu_21737_p2() {
    or_ln340_2458_fu_21737_p2 = (and_ln786_113_fu_21707_p2.read() | xor_ln779_113_fu_21675_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_2459_fu_21743_p2() {
    or_ln340_2459_fu_21743_p2 = (or_ln340_2458_fu_21737_p2.read() | and_ln416_624_fu_21661_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_2460_fu_40416_p2() {
    or_ln340_2460_fu_40416_p2 = (tmp_5015_fu_40384_p3.read() | xor_ln340_671_fu_40410_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_2461_fu_21917_p2() {
    or_ln340_2461_fu_21917_p2 = (and_ln786_114_fu_21887_p2.read() | xor_ln779_114_fu_21855_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_2462_fu_21923_p2() {
    or_ln340_2462_fu_21923_p2 = (or_ln340_2461_fu_21917_p2.read() | and_ln416_625_fu_21841_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_2463_fu_40504_p2() {
    or_ln340_2463_fu_40504_p2 = (tmp_5022_fu_40472_p3.read() | xor_ln340_672_fu_40498_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_2464_fu_22097_p2() {
    or_ln340_2464_fu_22097_p2 = (and_ln786_115_fu_22067_p2.read() | xor_ln779_115_fu_22035_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_2465_fu_22103_p2() {
    or_ln340_2465_fu_22103_p2 = (or_ln340_2464_fu_22097_p2.read() | and_ln416_626_fu_22021_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_2466_fu_40592_p2() {
    or_ln340_2466_fu_40592_p2 = (tmp_5029_fu_40560_p3.read() | xor_ln340_673_fu_40586_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_2467_fu_22277_p2() {
    or_ln340_2467_fu_22277_p2 = (and_ln786_116_fu_22247_p2.read() | xor_ln779_116_fu_22215_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_2468_fu_22283_p2() {
    or_ln340_2468_fu_22283_p2 = (or_ln340_2467_fu_22277_p2.read() | and_ln416_627_fu_22201_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_2469_fu_40680_p2() {
    or_ln340_2469_fu_40680_p2 = (tmp_5036_fu_40648_p3.read() | xor_ln340_674_fu_40674_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_2470_fu_22457_p2() {
    or_ln340_2470_fu_22457_p2 = (and_ln786_117_fu_22427_p2.read() | xor_ln779_117_fu_22395_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_2471_fu_22463_p2() {
    or_ln340_2471_fu_22463_p2 = (or_ln340_2470_fu_22457_p2.read() | and_ln416_628_fu_22381_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_2472_fu_40768_p2() {
    or_ln340_2472_fu_40768_p2 = (tmp_5043_fu_40736_p3.read() | xor_ln340_675_fu_40762_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_2473_fu_22637_p2() {
    or_ln340_2473_fu_22637_p2 = (and_ln786_118_fu_22607_p2.read() | xor_ln779_118_fu_22575_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_2474_fu_22643_p2() {
    or_ln340_2474_fu_22643_p2 = (or_ln340_2473_fu_22637_p2.read() | and_ln416_629_fu_22561_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_2475_fu_40856_p2() {
    or_ln340_2475_fu_40856_p2 = (tmp_5050_fu_40824_p3.read() | xor_ln340_676_fu_40850_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_2476_fu_41019_p2() {
    or_ln340_2476_fu_41019_p2 = (and_ln786_119_fu_40989_p2.read() | xor_ln779_119_fu_40957_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_2477_fu_41025_p2() {
    or_ln340_2477_fu_41025_p2 = (or_ln340_2476_fu_41019_p2.read() | and_ln416_630_fu_40943_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_2478_fu_41115_p2() {
    or_ln340_2478_fu_41115_p2 = (tmp_5057_fu_41083_p3.read() | xor_ln340_677_fu_41109_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_2479_fu_22827_p2() {
    or_ln340_2479_fu_22827_p2 = (and_ln786_120_fu_22797_p2.read() | xor_ln779_120_fu_22765_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_2480_fu_22833_p2() {
    or_ln340_2480_fu_22833_p2 = (or_ln340_2479_fu_22827_p2.read() | and_ln416_631_fu_22751_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_2481_fu_41203_p2() {
    or_ln340_2481_fu_41203_p2 = (tmp_5064_fu_41171_p3.read() | xor_ln340_678_fu_41197_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_2482_fu_23007_p2() {
    or_ln340_2482_fu_23007_p2 = (and_ln786_121_fu_22977_p2.read() | xor_ln779_121_fu_22945_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_2483_fu_23013_p2() {
    or_ln340_2483_fu_23013_p2 = (or_ln340_2482_fu_23007_p2.read() | and_ln416_632_fu_22931_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_2484_fu_41291_p2() {
    or_ln340_2484_fu_41291_p2 = (tmp_5071_fu_41259_p3.read() | xor_ln340_679_fu_41285_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_2485_fu_23187_p2() {
    or_ln340_2485_fu_23187_p2 = (and_ln786_122_fu_23157_p2.read() | xor_ln779_122_fu_23125_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_2486_fu_23193_p2() {
    or_ln340_2486_fu_23193_p2 = (or_ln340_2485_fu_23187_p2.read() | and_ln416_633_fu_23111_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_2487_fu_41379_p2() {
    or_ln340_2487_fu_41379_p2 = (tmp_5078_fu_41347_p3.read() | xor_ln340_680_fu_41373_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_2488_fu_23367_p2() {
    or_ln340_2488_fu_23367_p2 = (and_ln786_123_fu_23337_p2.read() | xor_ln779_123_fu_23305_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_2489_fu_23373_p2() {
    or_ln340_2489_fu_23373_p2 = (or_ln340_2488_fu_23367_p2.read() | and_ln416_634_fu_23291_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_2490_fu_41467_p2() {
    or_ln340_2490_fu_41467_p2 = (tmp_5085_fu_41435_p3.read() | xor_ln340_681_fu_41461_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_2491_fu_23547_p2() {
    or_ln340_2491_fu_23547_p2 = (and_ln786_124_fu_23517_p2.read() | xor_ln779_124_fu_23485_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_2492_fu_23553_p2() {
    or_ln340_2492_fu_23553_p2 = (or_ln340_2491_fu_23547_p2.read() | and_ln416_635_fu_23471_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_2493_fu_41555_p2() {
    or_ln340_2493_fu_41555_p2 = (tmp_5092_fu_41523_p3.read() | xor_ln340_682_fu_41549_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_2494_fu_23727_p2() {
    or_ln340_2494_fu_23727_p2 = (and_ln786_125_fu_23697_p2.read() | xor_ln779_125_fu_23665_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_2495_fu_23733_p2() {
    or_ln340_2495_fu_23733_p2 = (or_ln340_2494_fu_23727_p2.read() | and_ln416_636_fu_23651_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_2496_fu_41643_p2() {
    or_ln340_2496_fu_41643_p2 = (tmp_5099_fu_41611_p3.read() | xor_ln340_683_fu_41637_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_2497_fu_23907_p2() {
    or_ln340_2497_fu_23907_p2 = (and_ln786_126_fu_23877_p2.read() | xor_ln779_126_fu_23845_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_2498_fu_23913_p2() {
    or_ln340_2498_fu_23913_p2 = (or_ln340_2497_fu_23907_p2.read() | and_ln416_637_fu_23831_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_2499_fu_41731_p2() {
    or_ln340_2499_fu_41731_p2 = (tmp_5106_fu_41699_p3.read() | xor_ln340_684_fu_41725_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_24_fu_6391_p2() {
    or_ln340_24_fu_6391_p2 = (and_ln786_1655_fu_6385_p2.read() | and_ln785_535_fu_6361_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_2500_fu_24087_p2() {
    or_ln340_2500_fu_24087_p2 = (and_ln786_127_fu_24057_p2.read() | xor_ln779_127_fu_24025_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_2501_fu_24093_p2() {
    or_ln340_2501_fu_24093_p2 = (or_ln340_2500_fu_24087_p2.read() | and_ln416_638_fu_24011_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_2502_fu_41819_p2() {
    or_ln340_2502_fu_41819_p2 = (tmp_5113_fu_41787_p3.read() | xor_ln340_685_fu_41813_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_2503_fu_24267_p2() {
    or_ln340_2503_fu_24267_p2 = (and_ln786_128_fu_24237_p2.read() | xor_ln779_128_fu_24205_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_2504_fu_24273_p2() {
    or_ln340_2504_fu_24273_p2 = (or_ln340_2503_fu_24267_p2.read() | and_ln416_639_fu_24191_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_2505_fu_41907_p2() {
    or_ln340_2505_fu_41907_p2 = (tmp_5120_fu_41875_p3.read() | xor_ln340_686_fu_41901_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_2506_fu_24447_p2() {
    or_ln340_2506_fu_24447_p2 = (and_ln786_129_fu_24417_p2.read() | xor_ln779_129_fu_24385_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_2507_fu_24453_p2() {
    or_ln340_2507_fu_24453_p2 = (or_ln340_2506_fu_24447_p2.read() | and_ln416_640_fu_24371_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_2508_fu_41995_p2() {
    or_ln340_2508_fu_41995_p2 = (tmp_5127_fu_41963_p3.read() | xor_ln340_687_fu_41989_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_2509_fu_24627_p2() {
    or_ln340_2509_fu_24627_p2 = (and_ln786_130_fu_24597_p2.read() | xor_ln779_130_fu_24565_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_2510_fu_24633_p2() {
    or_ln340_2510_fu_24633_p2 = (or_ln340_2509_fu_24627_p2.read() | and_ln416_641_fu_24551_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_2511_fu_42083_p2() {
    or_ln340_2511_fu_42083_p2 = (tmp_5134_fu_42051_p3.read() | xor_ln340_688_fu_42077_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_2512_fu_24807_p2() {
    or_ln340_2512_fu_24807_p2 = (and_ln786_131_fu_24777_p2.read() | xor_ln779_131_fu_24745_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_2513_fu_24813_p2() {
    or_ln340_2513_fu_24813_p2 = (or_ln340_2512_fu_24807_p2.read() | and_ln416_642_fu_24731_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_2514_fu_42171_p2() {
    or_ln340_2514_fu_42171_p2 = (tmp_5141_fu_42139_p3.read() | xor_ln340_689_fu_42165_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_2515_fu_24987_p2() {
    or_ln340_2515_fu_24987_p2 = (and_ln786_132_fu_24957_p2.read() | xor_ln779_132_fu_24925_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_2516_fu_24993_p2() {
    or_ln340_2516_fu_24993_p2 = (or_ln340_2515_fu_24987_p2.read() | and_ln416_643_fu_24911_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_2517_fu_42259_p2() {
    or_ln340_2517_fu_42259_p2 = (tmp_5148_fu_42227_p3.read() | xor_ln340_690_fu_42253_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_2518_fu_25167_p2() {
    or_ln340_2518_fu_25167_p2 = (and_ln786_133_fu_25137_p2.read() | xor_ln779_133_fu_25105_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_2519_fu_25173_p2() {
    or_ln340_2519_fu_25173_p2 = (or_ln340_2518_fu_25167_p2.read() | and_ln416_644_fu_25091_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_2520_fu_42347_p2() {
    or_ln340_2520_fu_42347_p2 = (tmp_5155_fu_42315_p3.read() | xor_ln340_691_fu_42341_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_2521_fu_25347_p2() {
    or_ln340_2521_fu_25347_p2 = (and_ln786_134_fu_25317_p2.read() | xor_ln779_134_fu_25285_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_2522_fu_25353_p2() {
    or_ln340_2522_fu_25353_p2 = (or_ln340_2521_fu_25347_p2.read() | and_ln416_645_fu_25271_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_2523_fu_42435_p2() {
    or_ln340_2523_fu_42435_p2 = (tmp_5162_fu_42403_p3.read() | xor_ln340_692_fu_42429_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_2524_fu_25527_p2() {
    or_ln340_2524_fu_25527_p2 = (and_ln786_135_fu_25497_p2.read() | xor_ln779_135_fu_25465_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_2525_fu_25533_p2() {
    or_ln340_2525_fu_25533_p2 = (or_ln340_2524_fu_25527_p2.read() | and_ln416_646_fu_25451_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_2526_fu_42523_p2() {
    or_ln340_2526_fu_42523_p2 = (tmp_5169_fu_42491_p3.read() | xor_ln340_693_fu_42517_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_2527_fu_25707_p2() {
    or_ln340_2527_fu_25707_p2 = (and_ln786_136_fu_25677_p2.read() | xor_ln779_136_fu_25645_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_2528_fu_25713_p2() {
    or_ln340_2528_fu_25713_p2 = (or_ln340_2527_fu_25707_p2.read() | and_ln416_647_fu_25631_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_2529_fu_42611_p2() {
    or_ln340_2529_fu_42611_p2 = (tmp_5176_fu_42579_p3.read() | xor_ln340_694_fu_42605_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_2530_fu_25887_p2() {
    or_ln340_2530_fu_25887_p2 = (and_ln786_137_fu_25857_p2.read() | xor_ln779_137_fu_25825_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_2531_fu_25893_p2() {
    or_ln340_2531_fu_25893_p2 = (or_ln340_2530_fu_25887_p2.read() | and_ln416_648_fu_25811_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_2532_fu_42699_p2() {
    or_ln340_2532_fu_42699_p2 = (tmp_5183_fu_42667_p3.read() | xor_ln340_695_fu_42693_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_2533_fu_26067_p2() {
    or_ln340_2533_fu_26067_p2 = (and_ln786_138_fu_26037_p2.read() | xor_ln779_138_fu_26005_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_2534_fu_26073_p2() {
    or_ln340_2534_fu_26073_p2 = (or_ln340_2533_fu_26067_p2.read() | and_ln416_649_fu_25991_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_2535_fu_42787_p2() {
    or_ln340_2535_fu_42787_p2 = (tmp_5190_fu_42755_p3.read() | xor_ln340_696_fu_42781_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_2536_fu_42950_p2() {
    or_ln340_2536_fu_42950_p2 = (and_ln786_139_fu_42920_p2.read() | xor_ln779_139_fu_42888_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_2537_fu_42956_p2() {
    or_ln340_2537_fu_42956_p2 = (or_ln340_2536_fu_42950_p2.read() | and_ln416_650_fu_42874_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_2538_fu_43046_p2() {
    or_ln340_2538_fu_43046_p2 = (tmp_5197_fu_43014_p3.read() | xor_ln340_697_fu_43040_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_2539_fu_26257_p2() {
    or_ln340_2539_fu_26257_p2 = (and_ln786_140_fu_26227_p2.read() | xor_ln779_140_fu_26195_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_2540_fu_26263_p2() {
    or_ln340_2540_fu_26263_p2 = (or_ln340_2539_fu_26257_p2.read() | and_ln416_651_fu_26181_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_2541_fu_43134_p2() {
    or_ln340_2541_fu_43134_p2 = (tmp_5204_fu_43102_p3.read() | xor_ln340_698_fu_43128_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_2542_fu_26437_p2() {
    or_ln340_2542_fu_26437_p2 = (and_ln786_141_fu_26407_p2.read() | xor_ln779_141_fu_26375_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_2543_fu_26443_p2() {
    or_ln340_2543_fu_26443_p2 = (or_ln340_2542_fu_26437_p2.read() | and_ln416_652_fu_26361_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_2544_fu_43222_p2() {
    or_ln340_2544_fu_43222_p2 = (tmp_5211_fu_43190_p3.read() | xor_ln340_699_fu_43216_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_2545_fu_26617_p2() {
    or_ln340_2545_fu_26617_p2 = (and_ln786_142_fu_26587_p2.read() | xor_ln779_142_fu_26555_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_2546_fu_26623_p2() {
    or_ln340_2546_fu_26623_p2 = (or_ln340_2545_fu_26617_p2.read() | and_ln416_653_fu_26541_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_2547_fu_43310_p2() {
    or_ln340_2547_fu_43310_p2 = (tmp_5218_fu_43278_p3.read() | xor_ln340_700_fu_43304_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_2548_fu_26797_p2() {
    or_ln340_2548_fu_26797_p2 = (and_ln786_143_fu_26767_p2.read() | xor_ln779_143_fu_26735_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_2549_fu_26803_p2() {
    or_ln340_2549_fu_26803_p2 = (or_ln340_2548_fu_26797_p2.read() | and_ln416_654_fu_26721_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_2550_fu_43398_p2() {
    or_ln340_2550_fu_43398_p2 = (tmp_5225_fu_43366_p3.read() | xor_ln340_701_fu_43392_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_2551_fu_26977_p2() {
    or_ln340_2551_fu_26977_p2 = (and_ln786_144_fu_26947_p2.read() | xor_ln779_144_fu_26915_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_2552_fu_26983_p2() {
    or_ln340_2552_fu_26983_p2 = (or_ln340_2551_fu_26977_p2.read() | and_ln416_655_fu_26901_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_2553_fu_43486_p2() {
    or_ln340_2553_fu_43486_p2 = (tmp_5232_fu_43454_p3.read() | xor_ln340_702_fu_43480_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_2554_fu_27157_p2() {
    or_ln340_2554_fu_27157_p2 = (and_ln786_145_fu_27127_p2.read() | xor_ln779_145_fu_27095_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_2555_fu_27163_p2() {
    or_ln340_2555_fu_27163_p2 = (or_ln340_2554_fu_27157_p2.read() | and_ln416_656_fu_27081_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_2556_fu_43574_p2() {
    or_ln340_2556_fu_43574_p2 = (tmp_5239_fu_43542_p3.read() | xor_ln340_703_fu_43568_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_2557_fu_27337_p2() {
    or_ln340_2557_fu_27337_p2 = (and_ln786_146_fu_27307_p2.read() | xor_ln779_146_fu_27275_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_2558_fu_27343_p2() {
    or_ln340_2558_fu_27343_p2 = (or_ln340_2557_fu_27337_p2.read() | and_ln416_657_fu_27261_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_2559_fu_43662_p2() {
    or_ln340_2559_fu_43662_p2 = (tmp_5246_fu_43630_p3.read() | xor_ln340_704_fu_43656_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_2560_fu_27517_p2() {
    or_ln340_2560_fu_27517_p2 = (and_ln786_147_fu_27487_p2.read() | xor_ln779_147_fu_27455_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_2561_fu_27523_p2() {
    or_ln340_2561_fu_27523_p2 = (or_ln340_2560_fu_27517_p2.read() | and_ln416_658_fu_27441_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_2562_fu_43750_p2() {
    or_ln340_2562_fu_43750_p2 = (tmp_5253_fu_43718_p3.read() | xor_ln340_705_fu_43744_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_2563_fu_27697_p2() {
    or_ln340_2563_fu_27697_p2 = (and_ln786_148_fu_27667_p2.read() | xor_ln779_148_fu_27635_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_2564_fu_27703_p2() {
    or_ln340_2564_fu_27703_p2 = (or_ln340_2563_fu_27697_p2.read() | and_ln416_659_fu_27621_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_2565_fu_43838_p2() {
    or_ln340_2565_fu_43838_p2 = (tmp_5260_fu_43806_p3.read() | xor_ln340_706_fu_43832_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_2566_fu_27877_p2() {
    or_ln340_2566_fu_27877_p2 = (and_ln786_149_fu_27847_p2.read() | xor_ln779_149_fu_27815_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_2567_fu_27883_p2() {
    or_ln340_2567_fu_27883_p2 = (or_ln340_2566_fu_27877_p2.read() | and_ln416_660_fu_27801_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_2568_fu_43926_p2() {
    or_ln340_2568_fu_43926_p2 = (tmp_5267_fu_43894_p3.read() | xor_ln340_707_fu_43920_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_2569_fu_28057_p2() {
    or_ln340_2569_fu_28057_p2 = (and_ln786_150_fu_28027_p2.read() | xor_ln779_150_fu_27995_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_2570_fu_28063_p2() {
    or_ln340_2570_fu_28063_p2 = (or_ln340_2569_fu_28057_p2.read() | and_ln416_661_fu_27981_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_2571_fu_44014_p2() {
    or_ln340_2571_fu_44014_p2 = (tmp_5274_fu_43982_p3.read() | xor_ln340_708_fu_44008_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_2572_fu_28237_p2() {
    or_ln340_2572_fu_28237_p2 = (and_ln786_151_fu_28207_p2.read() | xor_ln779_151_fu_28175_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_2573_fu_28243_p2() {
    or_ln340_2573_fu_28243_p2 = (or_ln340_2572_fu_28237_p2.read() | and_ln416_662_fu_28161_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_2574_fu_44102_p2() {
    or_ln340_2574_fu_44102_p2 = (tmp_5281_fu_44070_p3.read() | xor_ln340_709_fu_44096_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_2575_fu_28417_p2() {
    or_ln340_2575_fu_28417_p2 = (and_ln786_152_fu_28387_p2.read() | xor_ln779_152_fu_28355_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_2576_fu_28423_p2() {
    or_ln340_2576_fu_28423_p2 = (or_ln340_2575_fu_28417_p2.read() | and_ln416_663_fu_28341_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_2577_fu_44190_p2() {
    or_ln340_2577_fu_44190_p2 = (tmp_5288_fu_44158_p3.read() | xor_ln340_710_fu_44184_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_2578_fu_28597_p2() {
    or_ln340_2578_fu_28597_p2 = (and_ln786_153_fu_28567_p2.read() | xor_ln779_153_fu_28535_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_2579_fu_28603_p2() {
    or_ln340_2579_fu_28603_p2 = (or_ln340_2578_fu_28597_p2.read() | and_ln416_664_fu_28521_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_2580_fu_44278_p2() {
    or_ln340_2580_fu_44278_p2 = (tmp_5295_fu_44246_p3.read() | xor_ln340_711_fu_44272_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_2581_fu_28777_p2() {
    or_ln340_2581_fu_28777_p2 = (and_ln786_154_fu_28747_p2.read() | xor_ln779_154_fu_28715_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_2582_fu_28783_p2() {
    or_ln340_2582_fu_28783_p2 = (or_ln340_2581_fu_28777_p2.read() | and_ln416_665_fu_28701_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_2583_fu_44366_p2() {
    or_ln340_2583_fu_44366_p2 = (tmp_5302_fu_44334_p3.read() | xor_ln340_712_fu_44360_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_2584_fu_28957_p2() {
    or_ln340_2584_fu_28957_p2 = (and_ln786_155_fu_28927_p2.read() | xor_ln779_155_fu_28895_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_2585_fu_28963_p2() {
    or_ln340_2585_fu_28963_p2 = (or_ln340_2584_fu_28957_p2.read() | and_ln416_666_fu_28881_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_2586_fu_44454_p2() {
    or_ln340_2586_fu_44454_p2 = (tmp_5309_fu_44422_p3.read() | xor_ln340_713_fu_44448_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_2587_fu_29137_p2() {
    or_ln340_2587_fu_29137_p2 = (and_ln786_156_fu_29107_p2.read() | xor_ln779_156_fu_29075_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_2588_fu_29143_p2() {
    or_ln340_2588_fu_29143_p2 = (or_ln340_2587_fu_29137_p2.read() | and_ln416_667_fu_29061_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_2589_fu_44542_p2() {
    or_ln340_2589_fu_44542_p2 = (tmp_5316_fu_44510_p3.read() | xor_ln340_714_fu_44536_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_2590_fu_29317_p2() {
    or_ln340_2590_fu_29317_p2 = (and_ln786_157_fu_29287_p2.read() | xor_ln779_157_fu_29255_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_2591_fu_29323_p2() {
    or_ln340_2591_fu_29323_p2 = (or_ln340_2590_fu_29317_p2.read() | and_ln416_668_fu_29241_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_2592_fu_44630_p2() {
    or_ln340_2592_fu_44630_p2 = (tmp_5323_fu_44598_p3.read() | xor_ln340_715_fu_44624_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_2593_fu_29497_p2() {
    or_ln340_2593_fu_29497_p2 = (and_ln786_158_fu_29467_p2.read() | xor_ln779_158_fu_29435_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_2594_fu_29503_p2() {
    or_ln340_2594_fu_29503_p2 = (or_ln340_2593_fu_29497_p2.read() | and_ln416_669_fu_29421_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_2595_fu_44718_p2() {
    or_ln340_2595_fu_44718_p2 = (tmp_5330_fu_44686_p3.read() | xor_ln340_716_fu_44712_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_2596_fu_44899_p2() {
    or_ln340_2596_fu_44899_p2 = (and_ln786_159_fu_44869_p2.read() | xor_ln779_159_fu_44837_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_2597_fu_44905_p2() {
    or_ln340_2597_fu_44905_p2 = (or_ln340_2596_fu_44899_p2.read() | and_ln416_670_fu_44823_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_2598_fu_44995_p2() {
    or_ln340_2598_fu_44995_p2 = (tmp_5337_fu_44963_p3.read() | xor_ln340_717_fu_44989_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_25_fu_6571_p2() {
    or_ln340_25_fu_6571_p2 = (and_ln786_1657_fu_6565_p2.read() | and_ln785_536_fu_6541_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_26_fu_6751_p2() {
    or_ln340_26_fu_6751_p2 = (and_ln786_1659_fu_6745_p2.read() | and_ln785_537_fu_6721_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_27_fu_6931_p2() {
    or_ln340_27_fu_6931_p2 = (and_ln786_1661_fu_6925_p2.read() | and_ln785_538_fu_6901_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_28_fu_7111_p2() {
    or_ln340_28_fu_7111_p2 = (and_ln786_1663_fu_7105_p2.read() | and_ln785_539_fu_7081_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_29_fu_7291_p2() {
    or_ln340_29_fu_7291_p2 = (and_ln786_1665_fu_7285_p2.read() | and_ln785_540_fu_7261_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_2_fu_2401_p2() {
    or_ln340_2_fu_2401_p2 = (and_ln786_1611_fu_2395_p2.read() | and_ln785_513_fu_2371_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_30_fu_7471_p2() {
    or_ln340_30_fu_7471_p2 = (and_ln786_1667_fu_7465_p2.read() | and_ln785_541_fu_7441_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_31_fu_7651_p2() {
    or_ln340_31_fu_7651_p2 = (and_ln786_1669_fu_7645_p2.read() | and_ln785_542_fu_7621_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_32_fu_7831_p2() {
    or_ln340_32_fu_7831_p2 = (and_ln786_1671_fu_7825_p2.read() | and_ln785_543_fu_7801_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_33_fu_8011_p2() {
    or_ln340_33_fu_8011_p2 = (and_ln786_1673_fu_8005_p2.read() | and_ln785_544_fu_7981_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_34_fu_8191_p2() {
    or_ln340_34_fu_8191_p2 = (and_ln786_1675_fu_8185_p2.read() | and_ln785_545_fu_8161_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_35_fu_8371_p2() {
    or_ln340_35_fu_8371_p2 = (and_ln786_1677_fu_8365_p2.read() | and_ln785_546_fu_8341_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_36_fu_8551_p2() {
    or_ln340_36_fu_8551_p2 = (and_ln786_1679_fu_8545_p2.read() | and_ln785_547_fu_8521_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_37_fu_8731_p2() {
    or_ln340_37_fu_8731_p2 = (and_ln786_1681_fu_8725_p2.read() | and_ln785_548_fu_8701_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_38_fu_8911_p2() {
    or_ln340_38_fu_8911_p2 = (and_ln786_1683_fu_8905_p2.read() | and_ln785_549_fu_8881_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_39_fu_33289_p2() {
    or_ln340_39_fu_33289_p2 = (and_ln786_1685_fu_33283_p2.read() | and_ln785_550_fu_33259_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_3_fu_2601_p2() {
    or_ln340_3_fu_2601_p2 = (and_ln786_1613_fu_2595_p2.read() | and_ln785_514_fu_2571_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_40_fu_9101_p2() {
    or_ln340_40_fu_9101_p2 = (and_ln786_1687_fu_9095_p2.read() | and_ln785_551_fu_9071_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_41_fu_9281_p2() {
    or_ln340_41_fu_9281_p2 = (and_ln786_1689_fu_9275_p2.read() | and_ln785_552_fu_9251_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_42_fu_9461_p2() {
    or_ln340_42_fu_9461_p2 = (and_ln786_1691_fu_9455_p2.read() | and_ln785_553_fu_9431_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_43_fu_9641_p2() {
    or_ln340_43_fu_9641_p2 = (and_ln786_1693_fu_9635_p2.read() | and_ln785_554_fu_9611_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_44_fu_9821_p2() {
    or_ln340_44_fu_9821_p2 = (and_ln786_1695_fu_9815_p2.read() | and_ln785_555_fu_9791_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_45_fu_10001_p2() {
    or_ln340_45_fu_10001_p2 = (and_ln786_1697_fu_9995_p2.read() | and_ln785_556_fu_9971_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_46_fu_10181_p2() {
    or_ln340_46_fu_10181_p2 = (and_ln786_1699_fu_10175_p2.read() | and_ln785_557_fu_10151_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_47_fu_10361_p2() {
    or_ln340_47_fu_10361_p2 = (and_ln786_1701_fu_10355_p2.read() | and_ln785_558_fu_10331_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_48_fu_10541_p2() {
    or_ln340_48_fu_10541_p2 = (and_ln786_1703_fu_10535_p2.read() | and_ln785_559_fu_10511_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_49_fu_10721_p2() {
    or_ln340_49_fu_10721_p2 = (and_ln786_1705_fu_10715_p2.read() | and_ln785_560_fu_10691_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_4_fu_2793_p2() {
    or_ln340_4_fu_2793_p2 = (and_ln786_1615_fu_2787_p2.read() | and_ln785_515_fu_2763_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_50_fu_10901_p2() {
    or_ln340_50_fu_10901_p2 = (and_ln786_1707_fu_10895_p2.read() | and_ln785_561_fu_10871_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_51_fu_11081_p2() {
    or_ln340_51_fu_11081_p2 = (and_ln786_1709_fu_11075_p2.read() | and_ln785_562_fu_11051_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_52_fu_11261_p2() {
    or_ln340_52_fu_11261_p2 = (and_ln786_1711_fu_11255_p2.read() | and_ln785_563_fu_11231_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_53_fu_11441_p2() {
    or_ln340_53_fu_11441_p2 = (and_ln786_1713_fu_11435_p2.read() | and_ln785_564_fu_11411_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_54_fu_11621_p2() {
    or_ln340_54_fu_11621_p2 = (and_ln786_1715_fu_11615_p2.read() | and_ln785_565_fu_11591_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_55_fu_11801_p2() {
    or_ln340_55_fu_11801_p2 = (and_ln786_1717_fu_11795_p2.read() | and_ln785_566_fu_11771_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_56_fu_11981_p2() {
    or_ln340_56_fu_11981_p2 = (and_ln786_1719_fu_11975_p2.read() | and_ln785_567_fu_11951_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_57_fu_12161_p2() {
    or_ln340_57_fu_12161_p2 = (and_ln786_1721_fu_12155_p2.read() | and_ln785_568_fu_12131_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_58_fu_12341_p2() {
    or_ln340_58_fu_12341_p2 = (and_ln786_1723_fu_12335_p2.read() | and_ln785_569_fu_12311_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_59_fu_35220_p2() {
    or_ln340_59_fu_35220_p2 = (and_ln786_1725_fu_35214_p2.read() | and_ln785_570_fu_35190_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_5_fu_2985_p2() {
    or_ln340_5_fu_2985_p2 = (and_ln786_1617_fu_2979_p2.read() | and_ln785_516_fu_2955_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_60_fu_12531_p2() {
    or_ln340_60_fu_12531_p2 = (and_ln786_1727_fu_12525_p2.read() | and_ln785_571_fu_12501_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_61_fu_12711_p2() {
    or_ln340_61_fu_12711_p2 = (and_ln786_1729_fu_12705_p2.read() | and_ln785_572_fu_12681_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_629_fu_3177_p2() {
    or_ln340_629_fu_3177_p2 = (and_ln786_1619_fu_3171_p2.read() | and_ln785_517_fu_3147_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_62_fu_12891_p2() {
    or_ln340_62_fu_12891_p2 = (and_ln786_1731_fu_12885_p2.read() | and_ln785_573_fu_12861_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_63_fu_13071_p2() {
    or_ln340_63_fu_13071_p2 = (and_ln786_1733_fu_13065_p2.read() | and_ln785_574_fu_13041_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_64_fu_13251_p2() {
    or_ln340_64_fu_13251_p2 = (and_ln786_1735_fu_13245_p2.read() | and_ln785_575_fu_13221_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_65_fu_13431_p2() {
    or_ln340_65_fu_13431_p2 = (and_ln786_1737_fu_13425_p2.read() | and_ln785_576_fu_13401_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_66_fu_13611_p2() {
    or_ln340_66_fu_13611_p2 = (and_ln786_1739_fu_13605_p2.read() | and_ln785_577_fu_13581_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_67_fu_13791_p2() {
    or_ln340_67_fu_13791_p2 = (and_ln786_1741_fu_13785_p2.read() | and_ln785_578_fu_13761_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_68_fu_13971_p2() {
    or_ln340_68_fu_13971_p2 = (and_ln786_1743_fu_13965_p2.read() | and_ln785_579_fu_13941_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_69_fu_14151_p2() {
    or_ln340_69_fu_14151_p2 = (and_ln786_1745_fu_14145_p2.read() | and_ln785_580_fu_14121_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_70_fu_14331_p2() {
    or_ln340_70_fu_14331_p2 = (and_ln786_1747_fu_14325_p2.read() | and_ln785_581_fu_14301_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_71_fu_14511_p2() {
    or_ln340_71_fu_14511_p2 = (and_ln786_1749_fu_14505_p2.read() | and_ln785_582_fu_14481_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_72_fu_14691_p2() {
    or_ln340_72_fu_14691_p2 = (and_ln786_1751_fu_14685_p2.read() | and_ln785_583_fu_14661_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_73_fu_14871_p2() {
    or_ln340_73_fu_14871_p2 = (and_ln786_1753_fu_14865_p2.read() | and_ln785_584_fu_14841_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_74_fu_15051_p2() {
    or_ln340_74_fu_15051_p2 = (and_ln786_1755_fu_15045_p2.read() | and_ln785_585_fu_15021_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_75_fu_15231_p2() {
    or_ln340_75_fu_15231_p2 = (and_ln786_1757_fu_15225_p2.read() | and_ln785_586_fu_15201_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_76_fu_15411_p2() {
    or_ln340_76_fu_15411_p2 = (and_ln786_1759_fu_15405_p2.read() | and_ln785_587_fu_15381_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_77_fu_15591_p2() {
    or_ln340_77_fu_15591_p2 = (and_ln786_1761_fu_15585_p2.read() | and_ln785_588_fu_15561_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_78_fu_15771_p2() {
    or_ln340_78_fu_15771_p2 = (and_ln786_1763_fu_15765_p2.read() | and_ln785_589_fu_15741_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_79_fu_37151_p2() {
    or_ln340_79_fu_37151_p2 = (and_ln786_1765_fu_37145_p2.read() | and_ln785_590_fu_37121_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_7_fu_3369_p2() {
    or_ln340_7_fu_3369_p2 = (and_ln786_1621_fu_3363_p2.read() | and_ln785_518_fu_3339_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_80_fu_15961_p2() {
    or_ln340_80_fu_15961_p2 = (and_ln786_1767_fu_15955_p2.read() | and_ln785_591_fu_15931_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_81_fu_16141_p2() {
    or_ln340_81_fu_16141_p2 = (and_ln786_1769_fu_16135_p2.read() | and_ln785_592_fu_16111_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_82_fu_16321_p2() {
    or_ln340_82_fu_16321_p2 = (and_ln786_1771_fu_16315_p2.read() | and_ln785_593_fu_16291_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_831_fu_3561_p2() {
    or_ln340_831_fu_3561_p2 = (and_ln786_1623_fu_3555_p2.read() | and_ln785_519_fu_3531_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_83_fu_16501_p2() {
    or_ln340_83_fu_16501_p2 = (and_ln786_1773_fu_16495_p2.read() | and_ln785_594_fu_16471_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_84_fu_16681_p2() {
    or_ln340_84_fu_16681_p2 = (and_ln786_1775_fu_16675_p2.read() | and_ln785_595_fu_16651_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_85_fu_16861_p2() {
    or_ln340_85_fu_16861_p2 = (and_ln786_1777_fu_16855_p2.read() | and_ln785_596_fu_16831_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_86_fu_17041_p2() {
    or_ln340_86_fu_17041_p2 = (and_ln786_1779_fu_17035_p2.read() | and_ln785_597_fu_17011_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_87_fu_17221_p2() {
    or_ln340_87_fu_17221_p2 = (and_ln786_1781_fu_17215_p2.read() | and_ln785_598_fu_17191_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_88_fu_17401_p2() {
    or_ln340_88_fu_17401_p2 = (and_ln786_1783_fu_17395_p2.read() | and_ln785_599_fu_17371_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_89_fu_17581_p2() {
    or_ln340_89_fu_17581_p2 = (and_ln786_1785_fu_17575_p2.read() | and_ln785_600_fu_17551_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_90_fu_17761_p2() {
    or_ln340_90_fu_17761_p2 = (and_ln786_1787_fu_17755_p2.read() | and_ln785_601_fu_17731_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_91_fu_17941_p2() {
    or_ln340_91_fu_17941_p2 = (and_ln786_1789_fu_17935_p2.read() | and_ln785_602_fu_17911_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_92_fu_18121_p2() {
    or_ln340_92_fu_18121_p2 = (and_ln786_1791_fu_18115_p2.read() | and_ln785_603_fu_18091_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_93_fu_18301_p2() {
    or_ln340_93_fu_18301_p2 = (and_ln786_1793_fu_18295_p2.read() | and_ln785_604_fu_18271_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_94_fu_18481_p2() {
    or_ln340_94_fu_18481_p2 = (and_ln786_1795_fu_18475_p2.read() | and_ln785_605_fu_18451_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_95_fu_18661_p2() {
    or_ln340_95_fu_18661_p2 = (and_ln786_1797_fu_18655_p2.read() | and_ln785_606_fu_18631_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_96_fu_18841_p2() {
    or_ln340_96_fu_18841_p2 = (and_ln786_1799_fu_18835_p2.read() | and_ln785_607_fu_18811_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_97_fu_19021_p2() {
    or_ln340_97_fu_19021_p2 = (and_ln786_1801_fu_19015_p2.read() | and_ln785_608_fu_18991_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_98_fu_19201_p2() {
    or_ln340_98_fu_19201_p2 = (and_ln786_1803_fu_19195_p2.read() | and_ln785_609_fu_19171_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_99_fu_39082_p2() {
    or_ln340_99_fu_39082_p2 = (and_ln786_1805_fu_39076_p2.read() | and_ln785_610_fu_39052_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_9_fu_3753_p2() {
    or_ln340_9_fu_3753_p2 = (and_ln786_1625_fu_3747_p2.read() | and_ln785_520_fu_3723_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln340_fu_2001_p2() {
    or_ln340_fu_2001_p2 = (and_ln786_1607_fu_1995_p2.read() | and_ln785_fu_1971_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln785_100_fu_19355_p2() {
    or_ln785_100_fu_19355_p2 = (tmp_4922_fu_19327_p3.read() | xor_ln785_100_fu_19349_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln785_101_fu_19535_p2() {
    or_ln785_101_fu_19535_p2 = (tmp_4929_fu_19507_p3.read() | xor_ln785_101_fu_19529_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln785_102_fu_19715_p2() {
    or_ln785_102_fu_19715_p2 = (tmp_4936_fu_19687_p3.read() | xor_ln785_102_fu_19709_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln785_103_fu_19895_p2() {
    or_ln785_103_fu_19895_p2 = (tmp_4943_fu_19867_p3.read() | xor_ln785_103_fu_19889_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln785_104_fu_20075_p2() {
    or_ln785_104_fu_20075_p2 = (tmp_4950_fu_20047_p3.read() | xor_ln785_104_fu_20069_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln785_105_fu_20255_p2() {
    or_ln785_105_fu_20255_p2 = (tmp_4957_fu_20227_p3.read() | xor_ln785_105_fu_20249_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln785_106_fu_20435_p2() {
    or_ln785_106_fu_20435_p2 = (tmp_4964_fu_20407_p3.read() | xor_ln785_106_fu_20429_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln785_107_fu_20615_p2() {
    or_ln785_107_fu_20615_p2 = (tmp_4971_fu_20587_p3.read() | xor_ln785_107_fu_20609_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln785_108_fu_20795_p2() {
    or_ln785_108_fu_20795_p2 = (tmp_4978_fu_20767_p3.read() | xor_ln785_108_fu_20789_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln785_109_fu_20975_p2() {
    or_ln785_109_fu_20975_p2 = (tmp_4985_fu_20947_p3.read() | xor_ln785_109_fu_20969_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln785_10_fu_3909_p2() {
    or_ln785_10_fu_3909_p2 = (tmp_4292_fu_3881_p3.read() | xor_ln785_10_fu_3903_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln785_110_fu_21155_p2() {
    or_ln785_110_fu_21155_p2 = (tmp_4992_fu_21127_p3.read() | xor_ln785_110_fu_21149_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln785_111_fu_21335_p2() {
    or_ln785_111_fu_21335_p2 = (tmp_4999_fu_21307_p3.read() | xor_ln785_111_fu_21329_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln785_112_fu_21515_p2() {
    or_ln785_112_fu_21515_p2 = (tmp_5006_fu_21487_p3.read() | xor_ln785_112_fu_21509_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln785_113_fu_21695_p2() {
    or_ln785_113_fu_21695_p2 = (tmp_5013_fu_21667_p3.read() | xor_ln785_113_fu_21689_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln785_114_fu_21875_p2() {
    or_ln785_114_fu_21875_p2 = (tmp_5020_fu_21847_p3.read() | xor_ln785_114_fu_21869_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln785_115_fu_22055_p2() {
    or_ln785_115_fu_22055_p2 = (tmp_5027_fu_22027_p3.read() | xor_ln785_115_fu_22049_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln785_116_fu_22235_p2() {
    or_ln785_116_fu_22235_p2 = (tmp_5034_fu_22207_p3.read() | xor_ln785_116_fu_22229_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln785_117_fu_22415_p2() {
    or_ln785_117_fu_22415_p2 = (tmp_5041_fu_22387_p3.read() | xor_ln785_117_fu_22409_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln785_118_fu_22595_p2() {
    or_ln785_118_fu_22595_p2 = (tmp_5048_fu_22567_p3.read() | xor_ln785_118_fu_22589_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln785_119_fu_40977_p2() {
    or_ln785_119_fu_40977_p2 = (tmp_5055_fu_40949_p3.read() | xor_ln785_119_fu_40971_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln785_11_fu_4101_p2() {
    or_ln785_11_fu_4101_p2 = (tmp_4299_fu_4073_p3.read() | xor_ln785_11_fu_4095_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln785_120_fu_22785_p2() {
    or_ln785_120_fu_22785_p2 = (tmp_5062_fu_22757_p3.read() | xor_ln785_120_fu_22779_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln785_121_fu_22965_p2() {
    or_ln785_121_fu_22965_p2 = (tmp_5069_fu_22937_p3.read() | xor_ln785_121_fu_22959_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln785_122_fu_23145_p2() {
    or_ln785_122_fu_23145_p2 = (tmp_5076_fu_23117_p3.read() | xor_ln785_122_fu_23139_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln785_123_fu_23325_p2() {
    or_ln785_123_fu_23325_p2 = (tmp_5083_fu_23297_p3.read() | xor_ln785_123_fu_23319_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln785_124_fu_23505_p2() {
    or_ln785_124_fu_23505_p2 = (tmp_5090_fu_23477_p3.read() | xor_ln785_124_fu_23499_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln785_125_fu_23685_p2() {
    or_ln785_125_fu_23685_p2 = (tmp_5097_fu_23657_p3.read() | xor_ln785_125_fu_23679_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln785_126_fu_23865_p2() {
    or_ln785_126_fu_23865_p2 = (tmp_5104_fu_23837_p3.read() | xor_ln785_126_fu_23859_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln785_127_fu_24045_p2() {
    or_ln785_127_fu_24045_p2 = (tmp_5111_fu_24017_p3.read() | xor_ln785_127_fu_24039_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln785_128_fu_24225_p2() {
    or_ln785_128_fu_24225_p2 = (tmp_5118_fu_24197_p3.read() | xor_ln785_128_fu_24219_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln785_129_fu_24405_p2() {
    or_ln785_129_fu_24405_p2 = (tmp_5125_fu_24377_p3.read() | xor_ln785_129_fu_24399_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln785_12_fu_4293_p2() {
    or_ln785_12_fu_4293_p2 = (tmp_4306_fu_4265_p3.read() | xor_ln785_12_fu_4287_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln785_130_fu_24585_p2() {
    or_ln785_130_fu_24585_p2 = (tmp_5132_fu_24557_p3.read() | xor_ln785_130_fu_24579_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln785_131_fu_24765_p2() {
    or_ln785_131_fu_24765_p2 = (tmp_5139_fu_24737_p3.read() | xor_ln785_131_fu_24759_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln785_132_fu_24945_p2() {
    or_ln785_132_fu_24945_p2 = (tmp_5146_fu_24917_p3.read() | xor_ln785_132_fu_24939_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln785_133_fu_25125_p2() {
    or_ln785_133_fu_25125_p2 = (tmp_5153_fu_25097_p3.read() | xor_ln785_133_fu_25119_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln785_134_fu_25305_p2() {
    or_ln785_134_fu_25305_p2 = (tmp_5160_fu_25277_p3.read() | xor_ln785_134_fu_25299_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln785_135_fu_25485_p2() {
    or_ln785_135_fu_25485_p2 = (tmp_5167_fu_25457_p3.read() | xor_ln785_135_fu_25479_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln785_136_fu_25665_p2() {
    or_ln785_136_fu_25665_p2 = (tmp_5174_fu_25637_p3.read() | xor_ln785_136_fu_25659_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln785_137_fu_25845_p2() {
    or_ln785_137_fu_25845_p2 = (tmp_5181_fu_25817_p3.read() | xor_ln785_137_fu_25839_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln785_138_fu_26025_p2() {
    or_ln785_138_fu_26025_p2 = (tmp_5188_fu_25997_p3.read() | xor_ln785_138_fu_26019_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln785_139_fu_42908_p2() {
    or_ln785_139_fu_42908_p2 = (tmp_5195_fu_42880_p3.read() | xor_ln785_139_fu_42902_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln785_13_fu_4485_p2() {
    or_ln785_13_fu_4485_p2 = (tmp_4313_fu_4457_p3.read() | xor_ln785_13_fu_4479_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln785_140_fu_26215_p2() {
    or_ln785_140_fu_26215_p2 = (tmp_5202_fu_26187_p3.read() | xor_ln785_140_fu_26209_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln785_141_fu_26395_p2() {
    or_ln785_141_fu_26395_p2 = (tmp_5209_fu_26367_p3.read() | xor_ln785_141_fu_26389_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln785_142_fu_26575_p2() {
    or_ln785_142_fu_26575_p2 = (tmp_5216_fu_26547_p3.read() | xor_ln785_142_fu_26569_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln785_143_fu_26755_p2() {
    or_ln785_143_fu_26755_p2 = (tmp_5223_fu_26727_p3.read() | xor_ln785_143_fu_26749_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln785_144_fu_26935_p2() {
    or_ln785_144_fu_26935_p2 = (tmp_5230_fu_26907_p3.read() | xor_ln785_144_fu_26929_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln785_145_fu_27115_p2() {
    or_ln785_145_fu_27115_p2 = (tmp_5237_fu_27087_p3.read() | xor_ln785_145_fu_27109_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln785_146_fu_27295_p2() {
    or_ln785_146_fu_27295_p2 = (tmp_5244_fu_27267_p3.read() | xor_ln785_146_fu_27289_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln785_147_fu_27475_p2() {
    or_ln785_147_fu_27475_p2 = (tmp_5251_fu_27447_p3.read() | xor_ln785_147_fu_27469_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln785_148_fu_27655_p2() {
    or_ln785_148_fu_27655_p2 = (tmp_5258_fu_27627_p3.read() | xor_ln785_148_fu_27649_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln785_149_fu_27835_p2() {
    or_ln785_149_fu_27835_p2 = (tmp_5265_fu_27807_p3.read() | xor_ln785_149_fu_27829_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln785_14_fu_4677_p2() {
    or_ln785_14_fu_4677_p2 = (tmp_4320_fu_4649_p3.read() | xor_ln785_14_fu_4671_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln785_150_fu_28015_p2() {
    or_ln785_150_fu_28015_p2 = (tmp_5272_fu_27987_p3.read() | xor_ln785_150_fu_28009_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln785_151_fu_28195_p2() {
    or_ln785_151_fu_28195_p2 = (tmp_5279_fu_28167_p3.read() | xor_ln785_151_fu_28189_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln785_152_fu_28375_p2() {
    or_ln785_152_fu_28375_p2 = (tmp_5286_fu_28347_p3.read() | xor_ln785_152_fu_28369_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln785_153_fu_28555_p2() {
    or_ln785_153_fu_28555_p2 = (tmp_5293_fu_28527_p3.read() | xor_ln785_153_fu_28549_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln785_154_fu_28735_p2() {
    or_ln785_154_fu_28735_p2 = (tmp_5300_fu_28707_p3.read() | xor_ln785_154_fu_28729_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln785_155_fu_28915_p2() {
    or_ln785_155_fu_28915_p2 = (tmp_5307_fu_28887_p3.read() | xor_ln785_155_fu_28909_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln785_156_fu_29095_p2() {
    or_ln785_156_fu_29095_p2 = (tmp_5314_fu_29067_p3.read() | xor_ln785_156_fu_29089_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln785_157_fu_29275_p2() {
    or_ln785_157_fu_29275_p2 = (tmp_5321_fu_29247_p3.read() | xor_ln785_157_fu_29269_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln785_158_fu_29455_p2() {
    or_ln785_158_fu_29455_p2 = (tmp_5328_fu_29427_p3.read() | xor_ln785_158_fu_29449_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln785_159_fu_44857_p2() {
    or_ln785_159_fu_44857_p2 = (tmp_5335_fu_44829_p3.read() | xor_ln785_159_fu_44851_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln785_15_fu_4869_p2() {
    or_ln785_15_fu_4869_p2 = (tmp_4327_fu_4841_p3.read() | xor_ln785_15_fu_4863_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln785_16_fu_5061_p2() {
    or_ln785_16_fu_5061_p2 = (tmp_4334_fu_5033_p3.read() | xor_ln785_16_fu_5055_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln785_17_fu_5253_p2() {
    or_ln785_17_fu_5253_p2 = (tmp_4341_fu_5225_p3.read() | xor_ln785_17_fu_5247_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln785_18_fu_5445_p2() {
    or_ln785_18_fu_5445_p2 = (tmp_4348_fu_5417_p3.read() | xor_ln785_18_fu_5439_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln785_19_fu_31322_p2() {
    or_ln785_19_fu_31322_p2 = (tmp_4355_fu_31294_p3.read() | xor_ln785_19_fu_31316_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln785_1_fu_2165_p2() {
    or_ln785_1_fu_2165_p2 = (tmp_4229_fu_2137_p3.read() | xor_ln785_1_fu_2159_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln785_20_fu_5635_p2() {
    or_ln785_20_fu_5635_p2 = (tmp_4362_fu_5607_p3.read() | xor_ln785_20_fu_5629_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln785_21_fu_5815_p2() {
    or_ln785_21_fu_5815_p2 = (tmp_4369_fu_5787_p3.read() | xor_ln785_21_fu_5809_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln785_22_fu_5995_p2() {
    or_ln785_22_fu_5995_p2 = (tmp_4376_fu_5967_p3.read() | xor_ln785_22_fu_5989_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln785_23_fu_6175_p2() {
    or_ln785_23_fu_6175_p2 = (tmp_4383_fu_6147_p3.read() | xor_ln785_23_fu_6169_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln785_24_fu_6355_p2() {
    or_ln785_24_fu_6355_p2 = (tmp_4390_fu_6327_p3.read() | xor_ln785_24_fu_6349_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln785_25_fu_6535_p2() {
    or_ln785_25_fu_6535_p2 = (tmp_4397_fu_6507_p3.read() | xor_ln785_25_fu_6529_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln785_26_fu_6715_p2() {
    or_ln785_26_fu_6715_p2 = (tmp_4404_fu_6687_p3.read() | xor_ln785_26_fu_6709_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln785_27_fu_6895_p2() {
    or_ln785_27_fu_6895_p2 = (tmp_4411_fu_6867_p3.read() | xor_ln785_27_fu_6889_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln785_28_fu_7075_p2() {
    or_ln785_28_fu_7075_p2 = (tmp_4418_fu_7047_p3.read() | xor_ln785_28_fu_7069_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln785_29_fu_7255_p2() {
    or_ln785_29_fu_7255_p2 = (tmp_4425_fu_7227_p3.read() | xor_ln785_29_fu_7249_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln785_2_fu_2365_p2() {
    or_ln785_2_fu_2365_p2 = (tmp_4236_fu_2337_p3.read() | xor_ln785_2_fu_2359_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln785_30_fu_7435_p2() {
    or_ln785_30_fu_7435_p2 = (tmp_4432_fu_7407_p3.read() | xor_ln785_30_fu_7429_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln785_31_fu_7615_p2() {
    or_ln785_31_fu_7615_p2 = (tmp_4439_fu_7587_p3.read() | xor_ln785_31_fu_7609_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln785_323_fu_2565_p2() {
    or_ln785_323_fu_2565_p2 = (tmp_4243_fu_2537_p3.read() | xor_ln785_3_fu_2559_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln785_32_fu_7795_p2() {
    or_ln785_32_fu_7795_p2 = (tmp_4446_fu_7767_p3.read() | xor_ln785_32_fu_7789_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln785_33_fu_7975_p2() {
    or_ln785_33_fu_7975_p2 = (tmp_4453_fu_7947_p3.read() | xor_ln785_33_fu_7969_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln785_34_fu_8155_p2() {
    or_ln785_34_fu_8155_p2 = (tmp_4460_fu_8127_p3.read() | xor_ln785_34_fu_8149_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln785_35_fu_8335_p2() {
    or_ln785_35_fu_8335_p2 = (tmp_4467_fu_8307_p3.read() | xor_ln785_35_fu_8329_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln785_36_fu_8515_p2() {
    or_ln785_36_fu_8515_p2 = (tmp_4474_fu_8487_p3.read() | xor_ln785_36_fu_8509_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln785_37_fu_8695_p2() {
    or_ln785_37_fu_8695_p2 = (tmp_4481_fu_8667_p3.read() | xor_ln785_37_fu_8689_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln785_38_fu_8875_p2() {
    or_ln785_38_fu_8875_p2 = (tmp_4488_fu_8847_p3.read() | xor_ln785_38_fu_8869_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln785_39_fu_33253_p2() {
    or_ln785_39_fu_33253_p2 = (tmp_4495_fu_33225_p3.read() | xor_ln785_39_fu_33247_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln785_40_fu_9065_p2() {
    or_ln785_40_fu_9065_p2 = (tmp_4502_fu_9037_p3.read() | xor_ln785_40_fu_9059_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln785_41_fu_9245_p2() {
    or_ln785_41_fu_9245_p2 = (tmp_4509_fu_9217_p3.read() | xor_ln785_41_fu_9239_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln785_42_fu_9425_p2() {
    or_ln785_42_fu_9425_p2 = (tmp_4516_fu_9397_p3.read() | xor_ln785_42_fu_9419_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln785_43_fu_9605_p2() {
    or_ln785_43_fu_9605_p2 = (tmp_4523_fu_9577_p3.read() | xor_ln785_43_fu_9599_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln785_44_fu_9785_p2() {
    or_ln785_44_fu_9785_p2 = (tmp_4530_fu_9757_p3.read() | xor_ln785_44_fu_9779_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln785_45_fu_9965_p2() {
    or_ln785_45_fu_9965_p2 = (tmp_4537_fu_9937_p3.read() | xor_ln785_45_fu_9959_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln785_46_fu_10145_p2() {
    or_ln785_46_fu_10145_p2 = (tmp_4544_fu_10117_p3.read() | xor_ln785_46_fu_10139_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln785_47_fu_10325_p2() {
    or_ln785_47_fu_10325_p2 = (tmp_4551_fu_10297_p3.read() | xor_ln785_47_fu_10319_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln785_48_fu_10505_p2() {
    or_ln785_48_fu_10505_p2 = (tmp_4558_fu_10477_p3.read() | xor_ln785_48_fu_10499_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln785_49_fu_10685_p2() {
    or_ln785_49_fu_10685_p2 = (tmp_4565_fu_10657_p3.read() | xor_ln785_49_fu_10679_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln785_4_fu_2757_p2() {
    or_ln785_4_fu_2757_p2 = (tmp_4250_fu_2729_p3.read() | xor_ln785_427_fu_2751_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln785_50_fu_10865_p2() {
    or_ln785_50_fu_10865_p2 = (tmp_4572_fu_10837_p3.read() | xor_ln785_50_fu_10859_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln785_51_fu_11045_p2() {
    or_ln785_51_fu_11045_p2 = (tmp_4579_fu_11017_p3.read() | xor_ln785_51_fu_11039_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln785_52_fu_11225_p2() {
    or_ln785_52_fu_11225_p2 = (tmp_4586_fu_11197_p3.read() | xor_ln785_52_fu_11219_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln785_53_fu_11405_p2() {
    or_ln785_53_fu_11405_p2 = (tmp_4593_fu_11377_p3.read() | xor_ln785_53_fu_11399_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln785_54_fu_11585_p2() {
    or_ln785_54_fu_11585_p2 = (tmp_4600_fu_11557_p3.read() | xor_ln785_54_fu_11579_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln785_55_fu_11765_p2() {
    or_ln785_55_fu_11765_p2 = (tmp_4607_fu_11737_p3.read() | xor_ln785_55_fu_11759_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln785_56_fu_11945_p2() {
    or_ln785_56_fu_11945_p2 = (tmp_4614_fu_11917_p3.read() | xor_ln785_56_fu_11939_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln785_57_fu_12125_p2() {
    or_ln785_57_fu_12125_p2 = (tmp_4621_fu_12097_p3.read() | xor_ln785_57_fu_12119_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln785_58_fu_12305_p2() {
    or_ln785_58_fu_12305_p2 = (tmp_4628_fu_12277_p3.read() | xor_ln785_58_fu_12299_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln785_59_fu_35184_p2() {
    or_ln785_59_fu_35184_p2 = (tmp_4635_fu_35156_p3.read() | xor_ln785_59_fu_35178_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln785_5_fu_2949_p2() {
    or_ln785_5_fu_2949_p2 = (tmp_4257_fu_2921_p3.read() | xor_ln785_528_fu_2943_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln785_60_fu_12495_p2() {
    or_ln785_60_fu_12495_p2 = (tmp_4642_fu_12467_p3.read() | xor_ln785_60_fu_12489_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln785_61_fu_12675_p2() {
    or_ln785_61_fu_12675_p2 = (tmp_4649_fu_12647_p3.read() | xor_ln785_61_fu_12669_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln785_62_fu_12855_p2() {
    or_ln785_62_fu_12855_p2 = (tmp_4656_fu_12827_p3.read() | xor_ln785_62_fu_12849_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln785_63_fu_13035_p2() {
    or_ln785_63_fu_13035_p2 = (tmp_4663_fu_13007_p3.read() | xor_ln785_63_fu_13029_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln785_64_fu_13215_p2() {
    or_ln785_64_fu_13215_p2 = (tmp_4670_fu_13187_p3.read() | xor_ln785_64_fu_13209_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln785_65_fu_13395_p2() {
    or_ln785_65_fu_13395_p2 = (tmp_4677_fu_13367_p3.read() | xor_ln785_65_fu_13389_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln785_66_fu_13575_p2() {
    or_ln785_66_fu_13575_p2 = (tmp_4684_fu_13547_p3.read() | xor_ln785_66_fu_13569_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln785_67_fu_13755_p2() {
    or_ln785_67_fu_13755_p2 = (tmp_4691_fu_13727_p3.read() | xor_ln785_67_fu_13749_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln785_68_fu_13935_p2() {
    or_ln785_68_fu_13935_p2 = (tmp_4698_fu_13907_p3.read() | xor_ln785_68_fu_13929_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln785_69_fu_14115_p2() {
    or_ln785_69_fu_14115_p2 = (tmp_4705_fu_14087_p3.read() | xor_ln785_69_fu_14109_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln785_6_fu_3141_p2() {
    or_ln785_6_fu_3141_p2 = (tmp_4264_fu_3113_p3.read() | xor_ln785_6_fu_3135_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln785_70_fu_14295_p2() {
    or_ln785_70_fu_14295_p2 = (tmp_4712_fu_14267_p3.read() | xor_ln785_70_fu_14289_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln785_71_fu_14475_p2() {
    or_ln785_71_fu_14475_p2 = (tmp_4719_fu_14447_p3.read() | xor_ln785_71_fu_14469_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln785_72_fu_14655_p2() {
    or_ln785_72_fu_14655_p2 = (tmp_4726_fu_14627_p3.read() | xor_ln785_72_fu_14649_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln785_73_fu_14835_p2() {
    or_ln785_73_fu_14835_p2 = (tmp_4733_fu_14807_p3.read() | xor_ln785_73_fu_14829_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln785_74_fu_15015_p2() {
    or_ln785_74_fu_15015_p2 = (tmp_4740_fu_14987_p3.read() | xor_ln785_74_fu_15009_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln785_75_fu_15195_p2() {
    or_ln785_75_fu_15195_p2 = (tmp_4747_fu_15167_p3.read() | xor_ln785_75_fu_15189_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln785_76_fu_15375_p2() {
    or_ln785_76_fu_15375_p2 = (tmp_4754_fu_15347_p3.read() | xor_ln785_76_fu_15369_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln785_77_fu_15555_p2() {
    or_ln785_77_fu_15555_p2 = (tmp_4761_fu_15527_p3.read() | xor_ln785_77_fu_15549_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln785_78_fu_15735_p2() {
    or_ln785_78_fu_15735_p2 = (tmp_4768_fu_15707_p3.read() | xor_ln785_78_fu_15729_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln785_79_fu_37115_p2() {
    or_ln785_79_fu_37115_p2 = (tmp_4775_fu_37087_p3.read() | xor_ln785_79_fu_37109_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln785_7_fu_3333_p2() {
    or_ln785_7_fu_3333_p2 = (tmp_4271_fu_3305_p3.read() | xor_ln785_7_fu_3327_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln785_80_fu_15925_p2() {
    or_ln785_80_fu_15925_p2 = (tmp_4782_fu_15897_p3.read() | xor_ln785_80_fu_15919_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln785_81_fu_16105_p2() {
    or_ln785_81_fu_16105_p2 = (tmp_4789_fu_16077_p3.read() | xor_ln785_81_fu_16099_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln785_82_fu_16285_p2() {
    or_ln785_82_fu_16285_p2 = (tmp_4796_fu_16257_p3.read() | xor_ln785_82_fu_16279_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln785_83_fu_16465_p2() {
    or_ln785_83_fu_16465_p2 = (tmp_4803_fu_16437_p3.read() | xor_ln785_83_fu_16459_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln785_84_fu_16645_p2() {
    or_ln785_84_fu_16645_p2 = (tmp_4810_fu_16617_p3.read() | xor_ln785_84_fu_16639_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln785_85_fu_16825_p2() {
    or_ln785_85_fu_16825_p2 = (tmp_4817_fu_16797_p3.read() | xor_ln785_85_fu_16819_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln785_86_fu_17005_p2() {
    or_ln785_86_fu_17005_p2 = (tmp_4824_fu_16977_p3.read() | xor_ln785_86_fu_16999_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln785_87_fu_17185_p2() {
    or_ln785_87_fu_17185_p2 = (tmp_4831_fu_17157_p3.read() | xor_ln785_87_fu_17179_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln785_88_fu_17365_p2() {
    or_ln785_88_fu_17365_p2 = (tmp_4838_fu_17337_p3.read() | xor_ln785_88_fu_17359_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln785_89_fu_17545_p2() {
    or_ln785_89_fu_17545_p2 = (tmp_4845_fu_17517_p3.read() | xor_ln785_89_fu_17539_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln785_8_fu_3525_p2() {
    or_ln785_8_fu_3525_p2 = (tmp_4278_fu_3497_p3.read() | xor_ln785_8_fu_3519_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln785_90_fu_17725_p2() {
    or_ln785_90_fu_17725_p2 = (tmp_4852_fu_17697_p3.read() | xor_ln785_90_fu_17719_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln785_91_fu_17905_p2() {
    or_ln785_91_fu_17905_p2 = (tmp_4859_fu_17877_p3.read() | xor_ln785_91_fu_17899_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln785_92_fu_18085_p2() {
    or_ln785_92_fu_18085_p2 = (tmp_4866_fu_18057_p3.read() | xor_ln785_92_fu_18079_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln785_93_fu_18265_p2() {
    or_ln785_93_fu_18265_p2 = (tmp_4873_fu_18237_p3.read() | xor_ln785_93_fu_18259_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln785_94_fu_18445_p2() {
    or_ln785_94_fu_18445_p2 = (tmp_4880_fu_18417_p3.read() | xor_ln785_94_fu_18439_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln785_95_fu_18625_p2() {
    or_ln785_95_fu_18625_p2 = (tmp_4887_fu_18597_p3.read() | xor_ln785_95_fu_18619_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln785_96_fu_18805_p2() {
    or_ln785_96_fu_18805_p2 = (tmp_4894_fu_18777_p3.read() | xor_ln785_96_fu_18799_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln785_97_fu_18985_p2() {
    or_ln785_97_fu_18985_p2 = (tmp_4901_fu_18957_p3.read() | xor_ln785_97_fu_18979_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln785_98_fu_19165_p2() {
    or_ln785_98_fu_19165_p2 = (tmp_4908_fu_19137_p3.read() | xor_ln785_98_fu_19159_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln785_99_fu_39046_p2() {
    or_ln785_99_fu_39046_p2 = (tmp_4915_fu_39018_p3.read() | xor_ln785_99_fu_39040_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln785_9_fu_3717_p2() {
    or_ln785_9_fu_3717_p2 = (tmp_4285_fu_3689_p3.read() | xor_ln785_9_fu_3711_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln785_fu_1965_p2() {
    or_ln785_fu_1965_p2 = (tmp_4222_fu_1937_p3.read() | xor_ln785_fu_1959_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln786_512_fu_2183_p2() {
    or_ln786_512_fu_2183_p2 = (and_ln416_512_fu_2131_p2.read() | and_ln786_1_fu_2177_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln786_513_fu_2383_p2() {
    or_ln786_513_fu_2383_p2 = (and_ln416_513_fu_2331_p2.read() | and_ln786_2_fu_2377_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln786_514_fu_2583_p2() {
    or_ln786_514_fu_2583_p2 = (and_ln416_514_fu_2531_p2.read() | and_ln786_3_fu_2577_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln786_515_fu_2775_p2() {
    or_ln786_515_fu_2775_p2 = (and_ln416_515_fu_2723_p2.read() | and_ln786_4_fu_2769_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln786_516_fu_2967_p2() {
    or_ln786_516_fu_2967_p2 = (and_ln416_516_fu_2915_p2.read() | and_ln786_5_fu_2961_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln786_517_fu_3159_p2() {
    or_ln786_517_fu_3159_p2 = (and_ln416_517_fu_3107_p2.read() | and_ln786_6_fu_3153_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln786_518_fu_3351_p2() {
    or_ln786_518_fu_3351_p2 = (and_ln416_518_fu_3299_p2.read() | and_ln786_7_fu_3345_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln786_519_fu_3543_p2() {
    or_ln786_519_fu_3543_p2 = (and_ln416_519_fu_3491_p2.read() | and_ln786_8_fu_3537_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln786_520_fu_3735_p2() {
    or_ln786_520_fu_3735_p2 = (and_ln416_520_fu_3683_p2.read() | and_ln786_9_fu_3729_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln786_521_fu_3927_p2() {
    or_ln786_521_fu_3927_p2 = (and_ln416_521_fu_3875_p2.read() | and_ln786_10_fu_3921_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln786_522_fu_4119_p2() {
    or_ln786_522_fu_4119_p2 = (and_ln416_522_fu_4067_p2.read() | and_ln786_11_fu_4113_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln786_523_fu_4311_p2() {
    or_ln786_523_fu_4311_p2 = (and_ln416_523_fu_4259_p2.read() | and_ln786_12_fu_4305_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln786_524_fu_4503_p2() {
    or_ln786_524_fu_4503_p2 = (and_ln416_524_fu_4451_p2.read() | and_ln786_13_fu_4497_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln786_525_fu_4695_p2() {
    or_ln786_525_fu_4695_p2 = (and_ln416_525_fu_4643_p2.read() | and_ln786_14_fu_4689_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln786_526_fu_4887_p2() {
    or_ln786_526_fu_4887_p2 = (and_ln416_526_fu_4835_p2.read() | and_ln786_15_fu_4881_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln786_527_fu_5079_p2() {
    or_ln786_527_fu_5079_p2 = (and_ln416_527_fu_5027_p2.read() | and_ln786_16_fu_5073_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln786_528_fu_5271_p2() {
    or_ln786_528_fu_5271_p2 = (and_ln416_528_fu_5219_p2.read() | and_ln786_17_fu_5265_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln786_529_fu_5463_p2() {
    or_ln786_529_fu_5463_p2 = (and_ln416_529_fu_5411_p2.read() | and_ln786_18_fu_5457_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln786_530_fu_31340_p2() {
    or_ln786_530_fu_31340_p2 = (and_ln416_530_fu_31288_p2.read() | and_ln786_19_fu_31334_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln786_531_fu_5653_p2() {
    or_ln786_531_fu_5653_p2 = (and_ln416_531_fu_5601_p2.read() | and_ln786_20_fu_5647_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln786_532_fu_5833_p2() {
    or_ln786_532_fu_5833_p2 = (and_ln416_532_fu_5781_p2.read() | and_ln786_21_fu_5827_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln786_533_fu_6013_p2() {
    or_ln786_533_fu_6013_p2 = (and_ln416_533_fu_5961_p2.read() | and_ln786_22_fu_6007_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln786_534_fu_6193_p2() {
    or_ln786_534_fu_6193_p2 = (and_ln416_534_fu_6141_p2.read() | and_ln786_23_fu_6187_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln786_535_fu_6373_p2() {
    or_ln786_535_fu_6373_p2 = (and_ln416_535_fu_6321_p2.read() | and_ln786_24_fu_6367_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln786_536_fu_6553_p2() {
    or_ln786_536_fu_6553_p2 = (and_ln416_536_fu_6501_p2.read() | and_ln786_25_fu_6547_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln786_537_fu_6733_p2() {
    or_ln786_537_fu_6733_p2 = (and_ln416_537_fu_6681_p2.read() | and_ln786_26_fu_6727_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln786_538_fu_6913_p2() {
    or_ln786_538_fu_6913_p2 = (and_ln416_538_fu_6861_p2.read() | and_ln786_27_fu_6907_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln786_539_fu_7093_p2() {
    or_ln786_539_fu_7093_p2 = (and_ln416_539_fu_7041_p2.read() | and_ln786_28_fu_7087_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln786_540_fu_7273_p2() {
    or_ln786_540_fu_7273_p2 = (and_ln416_540_fu_7221_p2.read() | and_ln786_29_fu_7267_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln786_541_fu_7453_p2() {
    or_ln786_541_fu_7453_p2 = (and_ln416_541_fu_7401_p2.read() | and_ln786_30_fu_7447_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln786_542_fu_7633_p2() {
    or_ln786_542_fu_7633_p2 = (and_ln416_542_fu_7581_p2.read() | and_ln786_31_fu_7627_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln786_543_fu_7813_p2() {
    or_ln786_543_fu_7813_p2 = (and_ln416_543_fu_7761_p2.read() | and_ln786_32_fu_7807_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln786_544_fu_7993_p2() {
    or_ln786_544_fu_7993_p2 = (and_ln416_544_fu_7941_p2.read() | and_ln786_33_fu_7987_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln786_545_fu_8173_p2() {
    or_ln786_545_fu_8173_p2 = (and_ln416_545_fu_8121_p2.read() | and_ln786_34_fu_8167_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln786_546_fu_8353_p2() {
    or_ln786_546_fu_8353_p2 = (and_ln416_546_fu_8301_p2.read() | and_ln786_35_fu_8347_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln786_547_fu_8533_p2() {
    or_ln786_547_fu_8533_p2 = (and_ln416_547_fu_8481_p2.read() | and_ln786_36_fu_8527_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln786_548_fu_8713_p2() {
    or_ln786_548_fu_8713_p2 = (and_ln416_548_fu_8661_p2.read() | and_ln786_37_fu_8707_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln786_549_fu_8893_p2() {
    or_ln786_549_fu_8893_p2 = (and_ln416_549_fu_8841_p2.read() | and_ln786_38_fu_8887_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln786_550_fu_33271_p2() {
    or_ln786_550_fu_33271_p2 = (and_ln416_550_fu_33219_p2.read() | and_ln786_39_fu_33265_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln786_551_fu_9083_p2() {
    or_ln786_551_fu_9083_p2 = (and_ln416_551_fu_9031_p2.read() | and_ln786_40_fu_9077_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln786_552_fu_9263_p2() {
    or_ln786_552_fu_9263_p2 = (and_ln416_552_fu_9211_p2.read() | and_ln786_41_fu_9257_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln786_553_fu_9443_p2() {
    or_ln786_553_fu_9443_p2 = (and_ln416_553_fu_9391_p2.read() | and_ln786_42_fu_9437_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln786_554_fu_9623_p2() {
    or_ln786_554_fu_9623_p2 = (and_ln416_554_fu_9571_p2.read() | and_ln786_43_fu_9617_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln786_555_fu_9803_p2() {
    or_ln786_555_fu_9803_p2 = (and_ln416_555_fu_9751_p2.read() | and_ln786_44_fu_9797_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln786_556_fu_9983_p2() {
    or_ln786_556_fu_9983_p2 = (and_ln416_556_fu_9931_p2.read() | and_ln786_45_fu_9977_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln786_557_fu_10163_p2() {
    or_ln786_557_fu_10163_p2 = (and_ln416_557_fu_10111_p2.read() | and_ln786_46_fu_10157_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln786_558_fu_10343_p2() {
    or_ln786_558_fu_10343_p2 = (and_ln416_558_fu_10291_p2.read() | and_ln786_47_fu_10337_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln786_559_fu_10523_p2() {
    or_ln786_559_fu_10523_p2 = (and_ln416_559_fu_10471_p2.read() | and_ln786_48_fu_10517_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln786_560_fu_10703_p2() {
    or_ln786_560_fu_10703_p2 = (and_ln416_560_fu_10651_p2.read() | and_ln786_49_fu_10697_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln786_561_fu_10883_p2() {
    or_ln786_561_fu_10883_p2 = (and_ln416_561_fu_10831_p2.read() | and_ln786_50_fu_10877_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln786_562_fu_11063_p2() {
    or_ln786_562_fu_11063_p2 = (and_ln416_562_fu_11011_p2.read() | and_ln786_51_fu_11057_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln786_563_fu_11243_p2() {
    or_ln786_563_fu_11243_p2 = (and_ln416_563_fu_11191_p2.read() | and_ln786_52_fu_11237_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln786_564_fu_11423_p2() {
    or_ln786_564_fu_11423_p2 = (and_ln416_564_fu_11371_p2.read() | and_ln786_53_fu_11417_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln786_565_fu_11603_p2() {
    or_ln786_565_fu_11603_p2 = (and_ln416_565_fu_11551_p2.read() | and_ln786_54_fu_11597_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln786_566_fu_11783_p2() {
    or_ln786_566_fu_11783_p2 = (and_ln416_566_fu_11731_p2.read() | and_ln786_55_fu_11777_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln786_567_fu_11963_p2() {
    or_ln786_567_fu_11963_p2 = (and_ln416_567_fu_11911_p2.read() | and_ln786_56_fu_11957_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln786_568_fu_12143_p2() {
    or_ln786_568_fu_12143_p2 = (and_ln416_568_fu_12091_p2.read() | and_ln786_57_fu_12137_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln786_569_fu_12323_p2() {
    or_ln786_569_fu_12323_p2 = (and_ln416_569_fu_12271_p2.read() | and_ln786_58_fu_12317_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln786_570_fu_35202_p2() {
    or_ln786_570_fu_35202_p2 = (and_ln416_570_fu_35150_p2.read() | and_ln786_59_fu_35196_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln786_571_fu_12513_p2() {
    or_ln786_571_fu_12513_p2 = (and_ln416_571_fu_12461_p2.read() | and_ln786_60_fu_12507_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln786_572_fu_12693_p2() {
    or_ln786_572_fu_12693_p2 = (and_ln416_572_fu_12641_p2.read() | and_ln786_61_fu_12687_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln786_573_fu_12873_p2() {
    or_ln786_573_fu_12873_p2 = (and_ln416_573_fu_12821_p2.read() | and_ln786_62_fu_12867_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln786_574_fu_13053_p2() {
    or_ln786_574_fu_13053_p2 = (and_ln416_574_fu_13001_p2.read() | and_ln786_63_fu_13047_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln786_575_fu_13233_p2() {
    or_ln786_575_fu_13233_p2 = (and_ln416_575_fu_13181_p2.read() | and_ln786_64_fu_13227_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln786_576_fu_13413_p2() {
    or_ln786_576_fu_13413_p2 = (and_ln416_576_fu_13361_p2.read() | and_ln786_65_fu_13407_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln786_577_fu_13593_p2() {
    or_ln786_577_fu_13593_p2 = (and_ln416_577_fu_13541_p2.read() | and_ln786_66_fu_13587_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln786_578_fu_13773_p2() {
    or_ln786_578_fu_13773_p2 = (and_ln416_578_fu_13721_p2.read() | and_ln786_67_fu_13767_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln786_579_fu_13953_p2() {
    or_ln786_579_fu_13953_p2 = (and_ln416_579_fu_13901_p2.read() | and_ln786_68_fu_13947_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln786_580_fu_14133_p2() {
    or_ln786_580_fu_14133_p2 = (and_ln416_580_fu_14081_p2.read() | and_ln786_69_fu_14127_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln786_581_fu_14313_p2() {
    or_ln786_581_fu_14313_p2 = (and_ln416_581_fu_14261_p2.read() | and_ln786_70_fu_14307_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln786_582_fu_14493_p2() {
    or_ln786_582_fu_14493_p2 = (and_ln416_582_fu_14441_p2.read() | and_ln786_71_fu_14487_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln786_583_fu_14673_p2() {
    or_ln786_583_fu_14673_p2 = (and_ln416_583_fu_14621_p2.read() | and_ln786_72_fu_14667_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln786_584_fu_14853_p2() {
    or_ln786_584_fu_14853_p2 = (and_ln416_584_fu_14801_p2.read() | and_ln786_73_fu_14847_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln786_585_fu_15033_p2() {
    or_ln786_585_fu_15033_p2 = (and_ln416_585_fu_14981_p2.read() | and_ln786_74_fu_15027_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln786_586_fu_15213_p2() {
    or_ln786_586_fu_15213_p2 = (and_ln416_586_fu_15161_p2.read() | and_ln786_75_fu_15207_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln786_587_fu_15393_p2() {
    or_ln786_587_fu_15393_p2 = (and_ln416_587_fu_15341_p2.read() | and_ln786_76_fu_15387_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln786_588_fu_15573_p2() {
    or_ln786_588_fu_15573_p2 = (and_ln416_588_fu_15521_p2.read() | and_ln786_77_fu_15567_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln786_589_fu_15753_p2() {
    or_ln786_589_fu_15753_p2 = (and_ln416_589_fu_15701_p2.read() | and_ln786_78_fu_15747_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln786_590_fu_37133_p2() {
    or_ln786_590_fu_37133_p2 = (and_ln416_590_fu_37081_p2.read() | and_ln786_79_fu_37127_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln786_591_fu_15943_p2() {
    or_ln786_591_fu_15943_p2 = (and_ln416_591_fu_15891_p2.read() | and_ln786_80_fu_15937_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln786_592_fu_16123_p2() {
    or_ln786_592_fu_16123_p2 = (and_ln416_592_fu_16071_p2.read() | and_ln786_81_fu_16117_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln786_593_fu_16303_p2() {
    or_ln786_593_fu_16303_p2 = (and_ln416_593_fu_16251_p2.read() | and_ln786_82_fu_16297_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln786_594_fu_16483_p2() {
    or_ln786_594_fu_16483_p2 = (and_ln416_594_fu_16431_p2.read() | and_ln786_83_fu_16477_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln786_595_fu_16663_p2() {
    or_ln786_595_fu_16663_p2 = (and_ln416_595_fu_16611_p2.read() | and_ln786_84_fu_16657_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln786_596_fu_16843_p2() {
    or_ln786_596_fu_16843_p2 = (and_ln416_596_fu_16791_p2.read() | and_ln786_85_fu_16837_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln786_597_fu_17023_p2() {
    or_ln786_597_fu_17023_p2 = (and_ln416_597_fu_16971_p2.read() | and_ln786_86_fu_17017_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln786_598_fu_17203_p2() {
    or_ln786_598_fu_17203_p2 = (and_ln416_598_fu_17151_p2.read() | and_ln786_87_fu_17197_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln786_599_fu_17383_p2() {
    or_ln786_599_fu_17383_p2 = (and_ln416_599_fu_17331_p2.read() | and_ln786_88_fu_17377_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln786_600_fu_17563_p2() {
    or_ln786_600_fu_17563_p2 = (and_ln416_600_fu_17511_p2.read() | and_ln786_89_fu_17557_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln786_601_fu_17743_p2() {
    or_ln786_601_fu_17743_p2 = (and_ln416_601_fu_17691_p2.read() | and_ln786_90_fu_17737_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln786_602_fu_17923_p2() {
    or_ln786_602_fu_17923_p2 = (and_ln416_602_fu_17871_p2.read() | and_ln786_91_fu_17917_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln786_603_fu_18103_p2() {
    or_ln786_603_fu_18103_p2 = (and_ln416_603_fu_18051_p2.read() | and_ln786_92_fu_18097_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln786_604_fu_18283_p2() {
    or_ln786_604_fu_18283_p2 = (and_ln416_604_fu_18231_p2.read() | and_ln786_93_fu_18277_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln786_605_fu_18463_p2() {
    or_ln786_605_fu_18463_p2 = (and_ln416_605_fu_18411_p2.read() | and_ln786_94_fu_18457_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln786_606_fu_18643_p2() {
    or_ln786_606_fu_18643_p2 = (and_ln416_606_fu_18591_p2.read() | and_ln786_95_fu_18637_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln786_607_fu_18823_p2() {
    or_ln786_607_fu_18823_p2 = (and_ln416_607_fu_18771_p2.read() | and_ln786_96_fu_18817_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln786_608_fu_19003_p2() {
    or_ln786_608_fu_19003_p2 = (and_ln416_608_fu_18951_p2.read() | and_ln786_97_fu_18997_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln786_609_fu_19183_p2() {
    or_ln786_609_fu_19183_p2 = (and_ln416_609_fu_19131_p2.read() | and_ln786_98_fu_19177_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln786_610_fu_39064_p2() {
    or_ln786_610_fu_39064_p2 = (and_ln416_610_fu_39012_p2.read() | and_ln786_99_fu_39058_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln786_611_fu_19373_p2() {
    or_ln786_611_fu_19373_p2 = (and_ln416_611_fu_19321_p2.read() | and_ln786_100_fu_19367_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln786_612_fu_19553_p2() {
    or_ln786_612_fu_19553_p2 = (and_ln416_612_fu_19501_p2.read() | and_ln786_101_fu_19547_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln786_613_fu_19733_p2() {
    or_ln786_613_fu_19733_p2 = (and_ln416_613_fu_19681_p2.read() | and_ln786_102_fu_19727_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln786_614_fu_19913_p2() {
    or_ln786_614_fu_19913_p2 = (and_ln416_614_fu_19861_p2.read() | and_ln786_103_fu_19907_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln786_615_fu_20093_p2() {
    or_ln786_615_fu_20093_p2 = (and_ln416_615_fu_20041_p2.read() | and_ln786_104_fu_20087_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln786_616_fu_20273_p2() {
    or_ln786_616_fu_20273_p2 = (and_ln416_616_fu_20221_p2.read() | and_ln786_105_fu_20267_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln786_617_fu_20453_p2() {
    or_ln786_617_fu_20453_p2 = (and_ln416_617_fu_20401_p2.read() | and_ln786_106_fu_20447_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln786_618_fu_20633_p2() {
    or_ln786_618_fu_20633_p2 = (and_ln416_618_fu_20581_p2.read() | and_ln786_107_fu_20627_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln786_619_fu_20813_p2() {
    or_ln786_619_fu_20813_p2 = (and_ln416_619_fu_20761_p2.read() | and_ln786_108_fu_20807_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln786_620_fu_20993_p2() {
    or_ln786_620_fu_20993_p2 = (and_ln416_620_fu_20941_p2.read() | and_ln786_109_fu_20987_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln786_621_fu_21173_p2() {
    or_ln786_621_fu_21173_p2 = (and_ln416_621_fu_21121_p2.read() | and_ln786_110_fu_21167_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln786_622_fu_21353_p2() {
    or_ln786_622_fu_21353_p2 = (and_ln416_622_fu_21301_p2.read() | and_ln786_111_fu_21347_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln786_623_fu_21533_p2() {
    or_ln786_623_fu_21533_p2 = (and_ln416_623_fu_21481_p2.read() | and_ln786_112_fu_21527_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln786_624_fu_21713_p2() {
    or_ln786_624_fu_21713_p2 = (and_ln416_624_fu_21661_p2.read() | and_ln786_113_fu_21707_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln786_625_fu_21893_p2() {
    or_ln786_625_fu_21893_p2 = (and_ln416_625_fu_21841_p2.read() | and_ln786_114_fu_21887_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln786_626_fu_22073_p2() {
    or_ln786_626_fu_22073_p2 = (and_ln416_626_fu_22021_p2.read() | and_ln786_115_fu_22067_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln786_627_fu_22253_p2() {
    or_ln786_627_fu_22253_p2 = (and_ln416_627_fu_22201_p2.read() | and_ln786_116_fu_22247_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln786_628_fu_22433_p2() {
    or_ln786_628_fu_22433_p2 = (and_ln416_628_fu_22381_p2.read() | and_ln786_117_fu_22427_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln786_629_fu_22613_p2() {
    or_ln786_629_fu_22613_p2 = (and_ln416_629_fu_22561_p2.read() | and_ln786_118_fu_22607_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln786_630_fu_40995_p2() {
    or_ln786_630_fu_40995_p2 = (and_ln416_630_fu_40943_p2.read() | and_ln786_119_fu_40989_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln786_631_fu_22803_p2() {
    or_ln786_631_fu_22803_p2 = (and_ln416_631_fu_22751_p2.read() | and_ln786_120_fu_22797_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln786_632_fu_22983_p2() {
    or_ln786_632_fu_22983_p2 = (and_ln416_632_fu_22931_p2.read() | and_ln786_121_fu_22977_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln786_633_fu_23163_p2() {
    or_ln786_633_fu_23163_p2 = (and_ln416_633_fu_23111_p2.read() | and_ln786_122_fu_23157_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln786_634_fu_23343_p2() {
    or_ln786_634_fu_23343_p2 = (and_ln416_634_fu_23291_p2.read() | and_ln786_123_fu_23337_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln786_635_fu_23523_p2() {
    or_ln786_635_fu_23523_p2 = (and_ln416_635_fu_23471_p2.read() | and_ln786_124_fu_23517_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln786_636_fu_23703_p2() {
    or_ln786_636_fu_23703_p2 = (and_ln416_636_fu_23651_p2.read() | and_ln786_125_fu_23697_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln786_637_fu_23883_p2() {
    or_ln786_637_fu_23883_p2 = (and_ln416_637_fu_23831_p2.read() | and_ln786_126_fu_23877_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln786_638_fu_24063_p2() {
    or_ln786_638_fu_24063_p2 = (and_ln416_638_fu_24011_p2.read() | and_ln786_127_fu_24057_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln786_639_fu_24243_p2() {
    or_ln786_639_fu_24243_p2 = (and_ln416_639_fu_24191_p2.read() | and_ln786_128_fu_24237_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln786_640_fu_24423_p2() {
    or_ln786_640_fu_24423_p2 = (and_ln416_640_fu_24371_p2.read() | and_ln786_129_fu_24417_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln786_641_fu_24603_p2() {
    or_ln786_641_fu_24603_p2 = (and_ln416_641_fu_24551_p2.read() | and_ln786_130_fu_24597_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln786_642_fu_24783_p2() {
    or_ln786_642_fu_24783_p2 = (and_ln416_642_fu_24731_p2.read() | and_ln786_131_fu_24777_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln786_643_fu_24963_p2() {
    or_ln786_643_fu_24963_p2 = (and_ln416_643_fu_24911_p2.read() | and_ln786_132_fu_24957_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln786_644_fu_25143_p2() {
    or_ln786_644_fu_25143_p2 = (and_ln416_644_fu_25091_p2.read() | and_ln786_133_fu_25137_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln786_645_fu_25323_p2() {
    or_ln786_645_fu_25323_p2 = (and_ln416_645_fu_25271_p2.read() | and_ln786_134_fu_25317_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln786_646_fu_25503_p2() {
    or_ln786_646_fu_25503_p2 = (and_ln416_646_fu_25451_p2.read() | and_ln786_135_fu_25497_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln786_647_fu_25683_p2() {
    or_ln786_647_fu_25683_p2 = (and_ln416_647_fu_25631_p2.read() | and_ln786_136_fu_25677_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln786_648_fu_25863_p2() {
    or_ln786_648_fu_25863_p2 = (and_ln416_648_fu_25811_p2.read() | and_ln786_137_fu_25857_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln786_649_fu_26043_p2() {
    or_ln786_649_fu_26043_p2 = (and_ln416_649_fu_25991_p2.read() | and_ln786_138_fu_26037_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln786_650_fu_42926_p2() {
    or_ln786_650_fu_42926_p2 = (and_ln416_650_fu_42874_p2.read() | and_ln786_139_fu_42920_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln786_651_fu_26233_p2() {
    or_ln786_651_fu_26233_p2 = (and_ln416_651_fu_26181_p2.read() | and_ln786_140_fu_26227_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln786_652_fu_26413_p2() {
    or_ln786_652_fu_26413_p2 = (and_ln416_652_fu_26361_p2.read() | and_ln786_141_fu_26407_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln786_653_fu_26593_p2() {
    or_ln786_653_fu_26593_p2 = (and_ln416_653_fu_26541_p2.read() | and_ln786_142_fu_26587_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln786_654_fu_26773_p2() {
    or_ln786_654_fu_26773_p2 = (and_ln416_654_fu_26721_p2.read() | and_ln786_143_fu_26767_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln786_655_fu_26953_p2() {
    or_ln786_655_fu_26953_p2 = (and_ln416_655_fu_26901_p2.read() | and_ln786_144_fu_26947_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln786_656_fu_27133_p2() {
    or_ln786_656_fu_27133_p2 = (and_ln416_656_fu_27081_p2.read() | and_ln786_145_fu_27127_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln786_657_fu_27313_p2() {
    or_ln786_657_fu_27313_p2 = (and_ln416_657_fu_27261_p2.read() | and_ln786_146_fu_27307_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln786_658_fu_27493_p2() {
    or_ln786_658_fu_27493_p2 = (and_ln416_658_fu_27441_p2.read() | and_ln786_147_fu_27487_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln786_659_fu_27673_p2() {
    or_ln786_659_fu_27673_p2 = (and_ln416_659_fu_27621_p2.read() | and_ln786_148_fu_27667_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln786_660_fu_27853_p2() {
    or_ln786_660_fu_27853_p2 = (and_ln416_660_fu_27801_p2.read() | and_ln786_149_fu_27847_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln786_661_fu_28033_p2() {
    or_ln786_661_fu_28033_p2 = (and_ln416_661_fu_27981_p2.read() | and_ln786_150_fu_28027_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln786_662_fu_28213_p2() {
    or_ln786_662_fu_28213_p2 = (and_ln416_662_fu_28161_p2.read() | and_ln786_151_fu_28207_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln786_663_fu_28393_p2() {
    or_ln786_663_fu_28393_p2 = (and_ln416_663_fu_28341_p2.read() | and_ln786_152_fu_28387_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln786_664_fu_28573_p2() {
    or_ln786_664_fu_28573_p2 = (and_ln416_664_fu_28521_p2.read() | and_ln786_153_fu_28567_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln786_665_fu_28753_p2() {
    or_ln786_665_fu_28753_p2 = (and_ln416_665_fu_28701_p2.read() | and_ln786_154_fu_28747_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln786_666_fu_28933_p2() {
    or_ln786_666_fu_28933_p2 = (and_ln416_666_fu_28881_p2.read() | and_ln786_155_fu_28927_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln786_667_fu_29113_p2() {
    or_ln786_667_fu_29113_p2 = (and_ln416_667_fu_29061_p2.read() | and_ln786_156_fu_29107_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln786_668_fu_29293_p2() {
    or_ln786_668_fu_29293_p2 = (and_ln416_668_fu_29241_p2.read() | and_ln786_157_fu_29287_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln786_669_fu_29473_p2() {
    or_ln786_669_fu_29473_p2 = (and_ln416_669_fu_29421_p2.read() | and_ln786_158_fu_29467_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln786_670_fu_44875_p2() {
    or_ln786_670_fu_44875_p2 = (and_ln416_670_fu_44823_p2.read() | and_ln786_159_fu_44869_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_or_ln786_fu_1983_p2() {
    or_ln786_fu_1983_p2 = (and_ln416_fu_1931_p2.read() | and_ln786_fu_1977_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_real_start() {
    if ((esl_seteq<1,1,1>(ap_const_logic_0, start_full_n.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_0, start_once_reg.read()))) {
        real_start = ap_const_logic_0;
    } else {
        real_start = ap_start.read();
    }
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_res_V_data_0_V_blk_n() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state8.read()) && 
         esl_seteq<1,1,1>(and_ln360_reg_46774.read(), ap_const_lv1_1))) {
        res_V_data_0_V_blk_n = res_V_data_0_V_full_n.read();
    } else {
        res_V_data_0_V_blk_n = ap_const_logic_1;
    }
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_res_V_data_0_V_din() {
    res_V_data_0_V_din = tmp_data_0_V_reg_47740.read();
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_res_V_data_0_V_write() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state8.read()) && 
         esl_seteq<1,1,1>(and_ln360_reg_46774.read(), ap_const_lv1_1) && 
         !(esl_seteq<1,1,1>(and_ln360_reg_46774.read(), ap_const_lv1_1) && esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op7036.read())))) {
        res_V_data_0_V_write = ap_const_logic_1;
    } else {
        res_V_data_0_V_write = ap_const_logic_0;
    }
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_res_V_data_1_V_blk_n() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state8.read()) && 
         esl_seteq<1,1,1>(and_ln360_reg_46774.read(), ap_const_lv1_1))) {
        res_V_data_1_V_blk_n = res_V_data_1_V_full_n.read();
    } else {
        res_V_data_1_V_blk_n = ap_const_logic_1;
    }
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_res_V_data_1_V_din() {
    res_V_data_1_V_din = tmp_data_1_V_reg_47746.read();
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_res_V_data_1_V_write() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state8.read()) && 
         esl_seteq<1,1,1>(and_ln360_reg_46774.read(), ap_const_lv1_1) && 
         !(esl_seteq<1,1,1>(and_ln360_reg_46774.read(), ap_const_lv1_1) && esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op7036.read())))) {
        res_V_data_1_V_write = ap_const_logic_1;
    } else {
        res_V_data_1_V_write = ap_const_logic_0;
    }
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_res_V_data_2_V_blk_n() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state8.read()) && 
         esl_seteq<1,1,1>(and_ln360_reg_46774.read(), ap_const_lv1_1))) {
        res_V_data_2_V_blk_n = res_V_data_2_V_full_n.read();
    } else {
        res_V_data_2_V_blk_n = ap_const_logic_1;
    }
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_res_V_data_2_V_din() {
    res_V_data_2_V_din = tmp_data_2_V_reg_47752.read();
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_res_V_data_2_V_write() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state8.read()) && 
         esl_seteq<1,1,1>(and_ln360_reg_46774.read(), ap_const_lv1_1) && 
         !(esl_seteq<1,1,1>(and_ln360_reg_46774.read(), ap_const_lv1_1) && esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op7036.read())))) {
        res_V_data_2_V_write = ap_const_logic_1;
    } else {
        res_V_data_2_V_write = ap_const_logic_0;
    }
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_res_V_data_3_V_blk_n() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state8.read()) && 
         esl_seteq<1,1,1>(and_ln360_reg_46774.read(), ap_const_lv1_1))) {
        res_V_data_3_V_blk_n = res_V_data_3_V_full_n.read();
    } else {
        res_V_data_3_V_blk_n = ap_const_logic_1;
    }
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_res_V_data_3_V_din() {
    res_V_data_3_V_din = tmp_data_3_V_reg_47758.read();
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_res_V_data_3_V_write() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state8.read()) && 
         esl_seteq<1,1,1>(and_ln360_reg_46774.read(), ap_const_lv1_1) && 
         !(esl_seteq<1,1,1>(and_ln360_reg_46774.read(), ap_const_lv1_1) && esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op7036.read())))) {
        res_V_data_3_V_write = ap_const_logic_1;
    } else {
        res_V_data_3_V_write = ap_const_logic_0;
    }
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_res_V_data_4_V_blk_n() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state8.read()) && 
         esl_seteq<1,1,1>(and_ln360_reg_46774.read(), ap_const_lv1_1))) {
        res_V_data_4_V_blk_n = res_V_data_4_V_full_n.read();
    } else {
        res_V_data_4_V_blk_n = ap_const_logic_1;
    }
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_res_V_data_4_V_din() {
    res_V_data_4_V_din = tmp_data_4_V_reg_47764.read();
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_res_V_data_4_V_write() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state8.read()) && 
         esl_seteq<1,1,1>(and_ln360_reg_46774.read(), ap_const_lv1_1) && 
         !(esl_seteq<1,1,1>(and_ln360_reg_46774.read(), ap_const_lv1_1) && esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op7036.read())))) {
        res_V_data_4_V_write = ap_const_logic_1;
    } else {
        res_V_data_4_V_write = ap_const_logic_0;
    }
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_res_V_data_5_V_blk_n() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state8.read()) && 
         esl_seteq<1,1,1>(and_ln360_reg_46774.read(), ap_const_lv1_1))) {
        res_V_data_5_V_blk_n = res_V_data_5_V_full_n.read();
    } else {
        res_V_data_5_V_blk_n = ap_const_logic_1;
    }
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_res_V_data_5_V_din() {
    res_V_data_5_V_din = tmp_data_5_V_reg_47770.read();
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_res_V_data_5_V_write() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state8.read()) && 
         esl_seteq<1,1,1>(and_ln360_reg_46774.read(), ap_const_lv1_1) && 
         !(esl_seteq<1,1,1>(and_ln360_reg_46774.read(), ap_const_lv1_1) && esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op7036.read())))) {
        res_V_data_5_V_write = ap_const_logic_1;
    } else {
        res_V_data_5_V_write = ap_const_logic_0;
    }
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_res_V_data_6_V_blk_n() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state8.read()) && 
         esl_seteq<1,1,1>(and_ln360_reg_46774.read(), ap_const_lv1_1))) {
        res_V_data_6_V_blk_n = res_V_data_6_V_full_n.read();
    } else {
        res_V_data_6_V_blk_n = ap_const_logic_1;
    }
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_res_V_data_6_V_din() {
    res_V_data_6_V_din = tmp_data_6_V_reg_47776.read();
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_res_V_data_6_V_write() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state8.read()) && 
         esl_seteq<1,1,1>(and_ln360_reg_46774.read(), ap_const_lv1_1) && 
         !(esl_seteq<1,1,1>(and_ln360_reg_46774.read(), ap_const_lv1_1) && esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op7036.read())))) {
        res_V_data_6_V_write = ap_const_logic_1;
    } else {
        res_V_data_6_V_write = ap_const_logic_0;
    }
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_res_V_data_7_V_blk_n() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state8.read()) && 
         esl_seteq<1,1,1>(and_ln360_reg_46774.read(), ap_const_lv1_1))) {
        res_V_data_7_V_blk_n = res_V_data_7_V_full_n.read();
    } else {
        res_V_data_7_V_blk_n = ap_const_logic_1;
    }
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_res_V_data_7_V_din() {
    res_V_data_7_V_din = tmp_data_7_V_reg_47782.read();
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_res_V_data_7_V_write() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state8.read()) && 
         esl_seteq<1,1,1>(and_ln360_reg_46774.read(), ap_const_lv1_1) && 
         !(esl_seteq<1,1,1>(and_ln360_reg_46774.read(), ap_const_lv1_1) && esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op7036.read())))) {
        res_V_data_7_V_write = ap_const_logic_1;
    } else {
        res_V_data_7_V_write = ap_const_logic_0;
    }
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_100_fu_19409_p3() {
    select_ln340_100_fu_19409_p3 = (!or_ln340_100_fu_19391_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_100_fu_19391_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: add_ln415_626_fu_19301_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_101_fu_19589_p3() {
    select_ln340_101_fu_19589_p3 = (!or_ln340_101_fu_19571_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_101_fu_19571_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: add_ln415_627_fu_19481_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_102_fu_19769_p3() {
    select_ln340_102_fu_19769_p3 = (!or_ln340_102_fu_19751_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_102_fu_19751_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: add_ln415_628_fu_19661_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_103_fu_19949_p3() {
    select_ln340_103_fu_19949_p3 = (!or_ln340_103_fu_19931_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_103_fu_19931_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: add_ln415_629_fu_19841_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_104_fu_20129_p3() {
    select_ln340_104_fu_20129_p3 = (!or_ln340_104_fu_20111_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_104_fu_20111_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: add_ln415_630_fu_20021_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_105_fu_20309_p3() {
    select_ln340_105_fu_20309_p3 = (!or_ln340_105_fu_20291_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_105_fu_20291_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: add_ln415_631_fu_20201_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_106_fu_20489_p3() {
    select_ln340_106_fu_20489_p3 = (!or_ln340_106_fu_20471_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_106_fu_20471_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: add_ln415_632_fu_20381_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_1071_fu_29607_p3() {
    select_ln340_1071_fu_29607_p3 = (!xor_ln340_1048_fu_29589_p2.read()[0].is_01())? sc_lv<24>(): ((xor_ln340_1048_fu_29589_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: acc_0_V_fu_29564_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_1072_fu_29695_p3() {
    select_ln340_1072_fu_29695_p3 = (!xor_ln340_1049_fu_29677_p2.read()[0].is_01())? sc_lv<24>(): ((xor_ln340_1049_fu_29677_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: acc_0_V_69_fu_29652_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_1073_fu_29783_p3() {
    select_ln340_1073_fu_29783_p3 = (!xor_ln340_1050_fu_29765_p2.read()[0].is_01())? sc_lv<24>(): ((xor_ln340_1050_fu_29765_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: acc_0_V_71_fu_29740_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_1074_fu_29871_p3() {
    select_ln340_1074_fu_29871_p3 = (!xor_ln340_1051_fu_29853_p2.read()[0].is_01())? sc_lv<24>(): ((xor_ln340_1051_fu_29853_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: acc_0_V_73_fu_29828_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_1075_fu_29959_p3() {
    select_ln340_1075_fu_29959_p3 = (!xor_ln340_1052_fu_29941_p2.read()[0].is_01())? sc_lv<24>(): ((xor_ln340_1052_fu_29941_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: acc_0_V_75_fu_29916_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_1076_fu_30047_p3() {
    select_ln340_1076_fu_30047_p3 = (!xor_ln340_1053_fu_30029_p2.read()[0].is_01())? sc_lv<24>(): ((xor_ln340_1053_fu_30029_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: acc_0_V_77_fu_30004_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_1077_fu_30135_p3() {
    select_ln340_1077_fu_30135_p3 = (!xor_ln340_1054_fu_30117_p2.read()[0].is_01())? sc_lv<24>(): ((xor_ln340_1054_fu_30117_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: acc_0_V_79_fu_30092_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_1078_fu_30223_p3() {
    select_ln340_1078_fu_30223_p3 = (!xor_ln340_1055_fu_30205_p2.read()[0].is_01())? sc_lv<24>(): ((xor_ln340_1055_fu_30205_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: acc_0_V_81_fu_30180_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_1079_fu_30311_p3() {
    select_ln340_1079_fu_30311_p3 = (!xor_ln340_1056_fu_30293_p2.read()[0].is_01())? sc_lv<24>(): ((xor_ln340_1056_fu_30293_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: acc_0_V_83_fu_30268_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_107_fu_20669_p3() {
    select_ln340_107_fu_20669_p3 = (!or_ln340_107_fu_20651_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_107_fu_20651_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: add_ln415_633_fu_20561_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_1080_fu_30399_p3() {
    select_ln340_1080_fu_30399_p3 = (!xor_ln340_1057_fu_30381_p2.read()[0].is_01())? sc_lv<24>(): ((xor_ln340_1057_fu_30381_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: acc_0_V_85_fu_30356_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_1081_fu_30487_p3() {
    select_ln340_1081_fu_30487_p3 = (!xor_ln340_1058_fu_30469_p2.read()[0].is_01())? sc_lv<24>(): ((xor_ln340_1058_fu_30469_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: acc_0_V_87_fu_30444_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_1082_fu_30575_p3() {
    select_ln340_1082_fu_30575_p3 = (!xor_ln340_1059_fu_30557_p2.read()[0].is_01())? sc_lv<24>(): ((xor_ln340_1059_fu_30557_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: acc_0_V_89_fu_30532_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_1083_fu_30663_p3() {
    select_ln340_1083_fu_30663_p3 = (!xor_ln340_1060_fu_30645_p2.read()[0].is_01())? sc_lv<24>(): ((xor_ln340_1060_fu_30645_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: acc_0_V_91_fu_30620_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_1084_fu_30751_p3() {
    select_ln340_1084_fu_30751_p3 = (!xor_ln340_1061_fu_30733_p2.read()[0].is_01())? sc_lv<24>(): ((xor_ln340_1061_fu_30733_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: acc_0_V_93_fu_30708_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_1085_fu_30839_p3() {
    select_ln340_1085_fu_30839_p3 = (!xor_ln340_1062_fu_30821_p2.read()[0].is_01())? sc_lv<24>(): ((xor_ln340_1062_fu_30821_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: acc_0_V_95_fu_30796_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_1086_fu_30927_p3() {
    select_ln340_1086_fu_30927_p3 = (!xor_ln340_1063_fu_30909_p2.read()[0].is_01())? sc_lv<24>(): ((xor_ln340_1063_fu_30909_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: acc_0_V_97_fu_30884_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_1087_fu_31015_p3() {
    select_ln340_1087_fu_31015_p3 = (!xor_ln340_1064_fu_30997_p2.read()[0].is_01())? sc_lv<24>(): ((xor_ln340_1064_fu_30997_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: acc_0_V_99_fu_30972_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_1088_fu_31103_p3() {
    select_ln340_1088_fu_31103_p3 = (!xor_ln340_1065_fu_31085_p2.read()[0].is_01())? sc_lv<24>(): ((xor_ln340_1065_fu_31085_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: acc_0_V_101_fu_31060_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_1089_fu_31191_p3() {
    select_ln340_1089_fu_31191_p3 = (!xor_ln340_1066_fu_31173_p2.read()[0].is_01())? sc_lv<24>(): ((xor_ln340_1066_fu_31173_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: acc_0_V_103_fu_31148_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_108_fu_20849_p3() {
    select_ln340_108_fu_20849_p3 = (!or_ln340_108_fu_20831_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_108_fu_20831_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: add_ln415_634_fu_20741_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_1090_fu_31466_p3() {
    select_ln340_1090_fu_31466_p3 = (!xor_ln340_1067_fu_31448_p2.read()[0].is_01())? sc_lv<24>(): ((xor_ln340_1067_fu_31448_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: acc_0_V_105_fu_31422_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_1091_fu_31554_p3() {
    select_ln340_1091_fu_31554_p3 = (!xor_ln340_1068_fu_31536_p2.read()[0].is_01())? sc_lv<24>(): ((xor_ln340_1068_fu_31536_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: acc_1_V_fu_31511_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_1092_fu_31642_p3() {
    select_ln340_1092_fu_31642_p3 = (!xor_ln340_1069_fu_31624_p2.read()[0].is_01())? sc_lv<24>(): ((xor_ln340_1069_fu_31624_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: acc_1_V_69_fu_31599_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_1093_fu_31730_p3() {
    select_ln340_1093_fu_31730_p3 = (!xor_ln340_1070_fu_31712_p2.read()[0].is_01())? sc_lv<24>(): ((xor_ln340_1070_fu_31712_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: acc_1_V_71_fu_31687_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_1094_fu_31818_p3() {
    select_ln340_1094_fu_31818_p3 = (!xor_ln340_1071_fu_31800_p2.read()[0].is_01())? sc_lv<24>(): ((xor_ln340_1071_fu_31800_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: acc_1_V_73_fu_31775_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_1095_fu_31906_p3() {
    select_ln340_1095_fu_31906_p3 = (!xor_ln340_1072_fu_31888_p2.read()[0].is_01())? sc_lv<24>(): ((xor_ln340_1072_fu_31888_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: acc_1_V_75_fu_31863_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_1096_fu_31994_p3() {
    select_ln340_1096_fu_31994_p3 = (!xor_ln340_1073_fu_31976_p2.read()[0].is_01())? sc_lv<24>(): ((xor_ln340_1073_fu_31976_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: acc_1_V_77_fu_31951_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_1097_fu_32082_p3() {
    select_ln340_1097_fu_32082_p3 = (!xor_ln340_1074_fu_32064_p2.read()[0].is_01())? sc_lv<24>(): ((xor_ln340_1074_fu_32064_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: acc_1_V_79_fu_32039_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_1098_fu_32170_p3() {
    select_ln340_1098_fu_32170_p3 = (!xor_ln340_1075_fu_32152_p2.read()[0].is_01())? sc_lv<24>(): ((xor_ln340_1075_fu_32152_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: acc_1_V_81_fu_32127_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_1099_fu_32258_p3() {
    select_ln340_1099_fu_32258_p3 = (!xor_ln340_1076_fu_32240_p2.read()[0].is_01())? sc_lv<24>(): ((xor_ln340_1076_fu_32240_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: acc_1_V_83_fu_32215_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_109_fu_21029_p3() {
    select_ln340_109_fu_21029_p3 = (!or_ln340_109_fu_21011_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_109_fu_21011_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: add_ln415_635_fu_20921_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_10_fu_3963_p3() {
    select_ln340_10_fu_3963_p3 = (!or_ln340_10_fu_3945_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_10_fu_3945_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: add_ln415_536_fu_3855_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_1100_fu_32346_p3() {
    select_ln340_1100_fu_32346_p3 = (!xor_ln340_1077_fu_32328_p2.read()[0].is_01())? sc_lv<24>(): ((xor_ln340_1077_fu_32328_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: acc_1_V_85_fu_32303_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_1101_fu_32434_p3() {
    select_ln340_1101_fu_32434_p3 = (!xor_ln340_1078_fu_32416_p2.read()[0].is_01())? sc_lv<24>(): ((xor_ln340_1078_fu_32416_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: acc_1_V_87_fu_32391_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_1102_fu_32522_p3() {
    select_ln340_1102_fu_32522_p3 = (!xor_ln340_1079_fu_32504_p2.read()[0].is_01())? sc_lv<24>(): ((xor_ln340_1079_fu_32504_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: acc_1_V_89_fu_32479_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_1103_fu_32610_p3() {
    select_ln340_1103_fu_32610_p3 = (!xor_ln340_1080_fu_32592_p2.read()[0].is_01())? sc_lv<24>(): ((xor_ln340_1080_fu_32592_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: acc_1_V_91_fu_32567_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_1104_fu_32698_p3() {
    select_ln340_1104_fu_32698_p3 = (!xor_ln340_1081_fu_32680_p2.read()[0].is_01())? sc_lv<24>(): ((xor_ln340_1081_fu_32680_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: acc_1_V_93_fu_32655_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_1105_fu_32786_p3() {
    select_ln340_1105_fu_32786_p3 = (!xor_ln340_1082_fu_32768_p2.read()[0].is_01())? sc_lv<24>(): ((xor_ln340_1082_fu_32768_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: acc_1_V_95_fu_32743_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_1106_fu_32874_p3() {
    select_ln340_1106_fu_32874_p3 = (!xor_ln340_1083_fu_32856_p2.read()[0].is_01())? sc_lv<24>(): ((xor_ln340_1083_fu_32856_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: acc_1_V_97_fu_32831_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_1107_fu_32962_p3() {
    select_ln340_1107_fu_32962_p3 = (!xor_ln340_1084_fu_32944_p2.read()[0].is_01())? sc_lv<24>(): ((xor_ln340_1084_fu_32944_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: acc_1_V_99_fu_32919_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_1108_fu_33050_p3() {
    select_ln340_1108_fu_33050_p3 = (!xor_ln340_1085_fu_33032_p2.read()[0].is_01())? sc_lv<24>(): ((xor_ln340_1085_fu_33032_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: acc_1_V_101_fu_33007_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_1109_fu_33138_p3() {
    select_ln340_1109_fu_33138_p3 = (!xor_ln340_1086_fu_33120_p2.read()[0].is_01())? sc_lv<24>(): ((xor_ln340_1086_fu_33120_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: acc_1_V_103_fu_33095_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_110_fu_21209_p3() {
    select_ln340_110_fu_21209_p3 = (!or_ln340_110_fu_21191_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_110_fu_21191_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: add_ln415_636_fu_21101_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_1110_fu_33397_p3() {
    select_ln340_1110_fu_33397_p3 = (!xor_ln340_1087_fu_33379_p2.read()[0].is_01())? sc_lv<24>(): ((xor_ln340_1087_fu_33379_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: acc_1_V_105_fu_33353_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_1111_fu_33485_p3() {
    select_ln340_1111_fu_33485_p3 = (!xor_ln340_1088_fu_33467_p2.read()[0].is_01())? sc_lv<24>(): ((xor_ln340_1088_fu_33467_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: acc_2_V_fu_33442_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_1112_fu_33573_p3() {
    select_ln340_1112_fu_33573_p3 = (!xor_ln340_1089_fu_33555_p2.read()[0].is_01())? sc_lv<24>(): ((xor_ln340_1089_fu_33555_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: acc_2_V_69_fu_33530_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_1113_fu_33661_p3() {
    select_ln340_1113_fu_33661_p3 = (!xor_ln340_1090_fu_33643_p2.read()[0].is_01())? sc_lv<24>(): ((xor_ln340_1090_fu_33643_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: acc_2_V_71_fu_33618_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_1114_fu_33749_p3() {
    select_ln340_1114_fu_33749_p3 = (!xor_ln340_1091_fu_33731_p2.read()[0].is_01())? sc_lv<24>(): ((xor_ln340_1091_fu_33731_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: acc_2_V_73_fu_33706_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_1115_fu_33837_p3() {
    select_ln340_1115_fu_33837_p3 = (!xor_ln340_1092_fu_33819_p2.read()[0].is_01())? sc_lv<24>(): ((xor_ln340_1092_fu_33819_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: acc_2_V_75_fu_33794_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_1116_fu_33925_p3() {
    select_ln340_1116_fu_33925_p3 = (!xor_ln340_1093_fu_33907_p2.read()[0].is_01())? sc_lv<24>(): ((xor_ln340_1093_fu_33907_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: acc_2_V_77_fu_33882_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_1117_fu_34013_p3() {
    select_ln340_1117_fu_34013_p3 = (!xor_ln340_1094_fu_33995_p2.read()[0].is_01())? sc_lv<24>(): ((xor_ln340_1094_fu_33995_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: acc_2_V_79_fu_33970_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_1118_fu_34101_p3() {
    select_ln340_1118_fu_34101_p3 = (!xor_ln340_1095_fu_34083_p2.read()[0].is_01())? sc_lv<24>(): ((xor_ln340_1095_fu_34083_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: acc_2_V_81_fu_34058_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_1119_fu_34189_p3() {
    select_ln340_1119_fu_34189_p3 = (!xor_ln340_1096_fu_34171_p2.read()[0].is_01())? sc_lv<24>(): ((xor_ln340_1096_fu_34171_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: acc_2_V_83_fu_34146_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_111_fu_21389_p3() {
    select_ln340_111_fu_21389_p3 = (!or_ln340_111_fu_21371_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_111_fu_21371_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: add_ln415_637_fu_21281_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_1120_fu_34277_p3() {
    select_ln340_1120_fu_34277_p3 = (!xor_ln340_1097_fu_34259_p2.read()[0].is_01())? sc_lv<24>(): ((xor_ln340_1097_fu_34259_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: acc_2_V_85_fu_34234_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_1121_fu_34365_p3() {
    select_ln340_1121_fu_34365_p3 = (!xor_ln340_1098_fu_34347_p2.read()[0].is_01())? sc_lv<24>(): ((xor_ln340_1098_fu_34347_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: acc_2_V_87_fu_34322_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_1122_fu_34453_p3() {
    select_ln340_1122_fu_34453_p3 = (!xor_ln340_1099_fu_34435_p2.read()[0].is_01())? sc_lv<24>(): ((xor_ln340_1099_fu_34435_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: acc_2_V_89_fu_34410_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_1123_fu_34541_p3() {
    select_ln340_1123_fu_34541_p3 = (!xor_ln340_1100_fu_34523_p2.read()[0].is_01())? sc_lv<24>(): ((xor_ln340_1100_fu_34523_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: acc_2_V_91_fu_34498_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_1124_fu_34629_p3() {
    select_ln340_1124_fu_34629_p3 = (!xor_ln340_1101_fu_34611_p2.read()[0].is_01())? sc_lv<24>(): ((xor_ln340_1101_fu_34611_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: acc_2_V_93_fu_34586_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_1125_fu_34717_p3() {
    select_ln340_1125_fu_34717_p3 = (!xor_ln340_1102_fu_34699_p2.read()[0].is_01())? sc_lv<24>(): ((xor_ln340_1102_fu_34699_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: acc_2_V_95_fu_34674_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_1126_fu_34805_p3() {
    select_ln340_1126_fu_34805_p3 = (!xor_ln340_1103_fu_34787_p2.read()[0].is_01())? sc_lv<24>(): ((xor_ln340_1103_fu_34787_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: acc_2_V_97_fu_34762_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_1127_fu_34893_p3() {
    select_ln340_1127_fu_34893_p3 = (!xor_ln340_1104_fu_34875_p2.read()[0].is_01())? sc_lv<24>(): ((xor_ln340_1104_fu_34875_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: acc_2_V_99_fu_34850_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_1128_fu_34981_p3() {
    select_ln340_1128_fu_34981_p3 = (!xor_ln340_1105_fu_34963_p2.read()[0].is_01())? sc_lv<24>(): ((xor_ln340_1105_fu_34963_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: acc_2_V_101_fu_34938_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_1129_fu_35069_p3() {
    select_ln340_1129_fu_35069_p3 = (!xor_ln340_1106_fu_35051_p2.read()[0].is_01())? sc_lv<24>(): ((xor_ln340_1106_fu_35051_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: acc_2_V_103_fu_35026_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_112_fu_21569_p3() {
    select_ln340_112_fu_21569_p3 = (!or_ln340_112_fu_21551_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_112_fu_21551_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: add_ln415_638_fu_21461_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_1130_fu_35328_p3() {
    select_ln340_1130_fu_35328_p3 = (!xor_ln340_1107_fu_35310_p2.read()[0].is_01())? sc_lv<24>(): ((xor_ln340_1107_fu_35310_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: acc_2_V_105_fu_35284_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_1131_fu_35416_p3() {
    select_ln340_1131_fu_35416_p3 = (!xor_ln340_1108_fu_35398_p2.read()[0].is_01())? sc_lv<24>(): ((xor_ln340_1108_fu_35398_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: acc_3_V_fu_35373_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_1132_fu_35504_p3() {
    select_ln340_1132_fu_35504_p3 = (!xor_ln340_1109_fu_35486_p2.read()[0].is_01())? sc_lv<24>(): ((xor_ln340_1109_fu_35486_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: acc_3_V_69_fu_35461_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_1133_fu_35592_p3() {
    select_ln340_1133_fu_35592_p3 = (!xor_ln340_1110_fu_35574_p2.read()[0].is_01())? sc_lv<24>(): ((xor_ln340_1110_fu_35574_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: acc_3_V_71_fu_35549_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_1134_fu_35680_p3() {
    select_ln340_1134_fu_35680_p3 = (!xor_ln340_1111_fu_35662_p2.read()[0].is_01())? sc_lv<24>(): ((xor_ln340_1111_fu_35662_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: acc_3_V_73_fu_35637_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_1135_fu_35768_p3() {
    select_ln340_1135_fu_35768_p3 = (!xor_ln340_1112_fu_35750_p2.read()[0].is_01())? sc_lv<24>(): ((xor_ln340_1112_fu_35750_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: acc_3_V_75_fu_35725_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_1136_fu_35856_p3() {
    select_ln340_1136_fu_35856_p3 = (!xor_ln340_1113_fu_35838_p2.read()[0].is_01())? sc_lv<24>(): ((xor_ln340_1113_fu_35838_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: acc_3_V_77_fu_35813_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_1137_fu_35944_p3() {
    select_ln340_1137_fu_35944_p3 = (!xor_ln340_1114_fu_35926_p2.read()[0].is_01())? sc_lv<24>(): ((xor_ln340_1114_fu_35926_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: acc_3_V_79_fu_35901_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_1138_fu_36032_p3() {
    select_ln340_1138_fu_36032_p3 = (!xor_ln340_1115_fu_36014_p2.read()[0].is_01())? sc_lv<24>(): ((xor_ln340_1115_fu_36014_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: acc_3_V_81_fu_35989_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_1139_fu_36120_p3() {
    select_ln340_1139_fu_36120_p3 = (!xor_ln340_1116_fu_36102_p2.read()[0].is_01())? sc_lv<24>(): ((xor_ln340_1116_fu_36102_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: acc_3_V_83_fu_36077_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_113_fu_21749_p3() {
    select_ln340_113_fu_21749_p3 = (!or_ln340_113_fu_21731_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_113_fu_21731_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: add_ln415_639_fu_21641_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_1140_fu_36208_p3() {
    select_ln340_1140_fu_36208_p3 = (!xor_ln340_1117_fu_36190_p2.read()[0].is_01())? sc_lv<24>(): ((xor_ln340_1117_fu_36190_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: acc_3_V_85_fu_36165_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_1141_fu_36296_p3() {
    select_ln340_1141_fu_36296_p3 = (!xor_ln340_1118_fu_36278_p2.read()[0].is_01())? sc_lv<24>(): ((xor_ln340_1118_fu_36278_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: acc_3_V_87_fu_36253_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_1142_fu_36384_p3() {
    select_ln340_1142_fu_36384_p3 = (!xor_ln340_1119_fu_36366_p2.read()[0].is_01())? sc_lv<24>(): ((xor_ln340_1119_fu_36366_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: acc_3_V_89_fu_36341_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_1143_fu_36472_p3() {
    select_ln340_1143_fu_36472_p3 = (!xor_ln340_1120_fu_36454_p2.read()[0].is_01())? sc_lv<24>(): ((xor_ln340_1120_fu_36454_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: acc_3_V_91_fu_36429_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_1144_fu_36560_p3() {
    select_ln340_1144_fu_36560_p3 = (!xor_ln340_1121_fu_36542_p2.read()[0].is_01())? sc_lv<24>(): ((xor_ln340_1121_fu_36542_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: acc_3_V_93_fu_36517_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_1145_fu_36648_p3() {
    select_ln340_1145_fu_36648_p3 = (!xor_ln340_1122_fu_36630_p2.read()[0].is_01())? sc_lv<24>(): ((xor_ln340_1122_fu_36630_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: acc_3_V_95_fu_36605_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_1146_fu_36736_p3() {
    select_ln340_1146_fu_36736_p3 = (!xor_ln340_1123_fu_36718_p2.read()[0].is_01())? sc_lv<24>(): ((xor_ln340_1123_fu_36718_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: acc_3_V_97_fu_36693_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_1147_fu_36824_p3() {
    select_ln340_1147_fu_36824_p3 = (!xor_ln340_1124_fu_36806_p2.read()[0].is_01())? sc_lv<24>(): ((xor_ln340_1124_fu_36806_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: acc_3_V_99_fu_36781_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_1148_fu_36912_p3() {
    select_ln340_1148_fu_36912_p3 = (!xor_ln340_1125_fu_36894_p2.read()[0].is_01())? sc_lv<24>(): ((xor_ln340_1125_fu_36894_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: acc_3_V_101_fu_36869_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_1149_fu_37000_p3() {
    select_ln340_1149_fu_37000_p3 = (!xor_ln340_1126_fu_36982_p2.read()[0].is_01())? sc_lv<24>(): ((xor_ln340_1126_fu_36982_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: acc_3_V_103_fu_36957_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_114_fu_21929_p3() {
    select_ln340_114_fu_21929_p3 = (!or_ln340_114_fu_21911_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_114_fu_21911_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: add_ln415_640_fu_21821_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_1150_fu_37259_p3() {
    select_ln340_1150_fu_37259_p3 = (!xor_ln340_1127_fu_37241_p2.read()[0].is_01())? sc_lv<24>(): ((xor_ln340_1127_fu_37241_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: acc_3_V_105_fu_37215_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_1151_fu_37347_p3() {
    select_ln340_1151_fu_37347_p3 = (!xor_ln340_1128_fu_37329_p2.read()[0].is_01())? sc_lv<24>(): ((xor_ln340_1128_fu_37329_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: acc_4_V_fu_37304_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_1152_fu_37435_p3() {
    select_ln340_1152_fu_37435_p3 = (!xor_ln340_1129_fu_37417_p2.read()[0].is_01())? sc_lv<24>(): ((xor_ln340_1129_fu_37417_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: acc_4_V_69_fu_37392_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_1153_fu_37523_p3() {
    select_ln340_1153_fu_37523_p3 = (!xor_ln340_1130_fu_37505_p2.read()[0].is_01())? sc_lv<24>(): ((xor_ln340_1130_fu_37505_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: acc_4_V_71_fu_37480_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_1154_fu_37611_p3() {
    select_ln340_1154_fu_37611_p3 = (!xor_ln340_1131_fu_37593_p2.read()[0].is_01())? sc_lv<24>(): ((xor_ln340_1131_fu_37593_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: acc_4_V_73_fu_37568_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_1155_fu_37699_p3() {
    select_ln340_1155_fu_37699_p3 = (!xor_ln340_1132_fu_37681_p2.read()[0].is_01())? sc_lv<24>(): ((xor_ln340_1132_fu_37681_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: acc_4_V_75_fu_37656_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_1156_fu_37787_p3() {
    select_ln340_1156_fu_37787_p3 = (!xor_ln340_1133_fu_37769_p2.read()[0].is_01())? sc_lv<24>(): ((xor_ln340_1133_fu_37769_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: acc_4_V_77_fu_37744_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_1157_fu_37875_p3() {
    select_ln340_1157_fu_37875_p3 = (!xor_ln340_1134_fu_37857_p2.read()[0].is_01())? sc_lv<24>(): ((xor_ln340_1134_fu_37857_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: acc_4_V_79_fu_37832_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_1158_fu_37963_p3() {
    select_ln340_1158_fu_37963_p3 = (!xor_ln340_1135_fu_37945_p2.read()[0].is_01())? sc_lv<24>(): ((xor_ln340_1135_fu_37945_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: acc_4_V_81_fu_37920_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_1159_fu_38051_p3() {
    select_ln340_1159_fu_38051_p3 = (!xor_ln340_1136_fu_38033_p2.read()[0].is_01())? sc_lv<24>(): ((xor_ln340_1136_fu_38033_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: acc_4_V_83_fu_38008_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_115_fu_22109_p3() {
    select_ln340_115_fu_22109_p3 = (!or_ln340_115_fu_22091_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_115_fu_22091_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: add_ln415_641_fu_22001_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_1160_fu_38139_p3() {
    select_ln340_1160_fu_38139_p3 = (!xor_ln340_1137_fu_38121_p2.read()[0].is_01())? sc_lv<24>(): ((xor_ln340_1137_fu_38121_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: acc_4_V_85_fu_38096_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_1161_fu_38227_p3() {
    select_ln340_1161_fu_38227_p3 = (!xor_ln340_1138_fu_38209_p2.read()[0].is_01())? sc_lv<24>(): ((xor_ln340_1138_fu_38209_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: acc_4_V_87_fu_38184_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_1162_fu_38315_p3() {
    select_ln340_1162_fu_38315_p3 = (!xor_ln340_1139_fu_38297_p2.read()[0].is_01())? sc_lv<24>(): ((xor_ln340_1139_fu_38297_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: acc_4_V_89_fu_38272_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_1163_fu_38403_p3() {
    select_ln340_1163_fu_38403_p3 = (!xor_ln340_1140_fu_38385_p2.read()[0].is_01())? sc_lv<24>(): ((xor_ln340_1140_fu_38385_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: acc_4_V_91_fu_38360_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_1164_fu_38491_p3() {
    select_ln340_1164_fu_38491_p3 = (!xor_ln340_1141_fu_38473_p2.read()[0].is_01())? sc_lv<24>(): ((xor_ln340_1141_fu_38473_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: acc_4_V_93_fu_38448_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_1165_fu_38579_p3() {
    select_ln340_1165_fu_38579_p3 = (!xor_ln340_1142_fu_38561_p2.read()[0].is_01())? sc_lv<24>(): ((xor_ln340_1142_fu_38561_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: acc_4_V_95_fu_38536_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_1166_fu_38667_p3() {
    select_ln340_1166_fu_38667_p3 = (!xor_ln340_1143_fu_38649_p2.read()[0].is_01())? sc_lv<24>(): ((xor_ln340_1143_fu_38649_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: acc_4_V_97_fu_38624_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_1167_fu_38755_p3() {
    select_ln340_1167_fu_38755_p3 = (!xor_ln340_1144_fu_38737_p2.read()[0].is_01())? sc_lv<24>(): ((xor_ln340_1144_fu_38737_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: acc_4_V_99_fu_38712_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_1168_fu_38843_p3() {
    select_ln340_1168_fu_38843_p3 = (!xor_ln340_1145_fu_38825_p2.read()[0].is_01())? sc_lv<24>(): ((xor_ln340_1145_fu_38825_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: acc_4_V_101_fu_38800_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_1169_fu_38931_p3() {
    select_ln340_1169_fu_38931_p3 = (!xor_ln340_1146_fu_38913_p2.read()[0].is_01())? sc_lv<24>(): ((xor_ln340_1146_fu_38913_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: acc_4_V_103_fu_38888_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_116_fu_22289_p3() {
    select_ln340_116_fu_22289_p3 = (!or_ln340_116_fu_22271_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_116_fu_22271_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: add_ln415_642_fu_22181_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_1170_fu_39190_p3() {
    select_ln340_1170_fu_39190_p3 = (!xor_ln340_1147_fu_39172_p2.read()[0].is_01())? sc_lv<24>(): ((xor_ln340_1147_fu_39172_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: acc_4_V_105_fu_39146_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_1171_fu_39278_p3() {
    select_ln340_1171_fu_39278_p3 = (!xor_ln340_1148_fu_39260_p2.read()[0].is_01())? sc_lv<24>(): ((xor_ln340_1148_fu_39260_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: acc_5_V_fu_39235_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_1172_fu_39366_p3() {
    select_ln340_1172_fu_39366_p3 = (!xor_ln340_1149_fu_39348_p2.read()[0].is_01())? sc_lv<24>(): ((xor_ln340_1149_fu_39348_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: acc_5_V_69_fu_39323_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_1173_fu_39454_p3() {
    select_ln340_1173_fu_39454_p3 = (!xor_ln340_1150_fu_39436_p2.read()[0].is_01())? sc_lv<24>(): ((xor_ln340_1150_fu_39436_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: acc_5_V_71_fu_39411_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_1174_fu_39542_p3() {
    select_ln340_1174_fu_39542_p3 = (!xor_ln340_1151_fu_39524_p2.read()[0].is_01())? sc_lv<24>(): ((xor_ln340_1151_fu_39524_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: acc_5_V_73_fu_39499_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_1175_fu_39630_p3() {
    select_ln340_1175_fu_39630_p3 = (!xor_ln340_1152_fu_39612_p2.read()[0].is_01())? sc_lv<24>(): ((xor_ln340_1152_fu_39612_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: acc_5_V_75_fu_39587_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_1176_fu_39718_p3() {
    select_ln340_1176_fu_39718_p3 = (!xor_ln340_1153_fu_39700_p2.read()[0].is_01())? sc_lv<24>(): ((xor_ln340_1153_fu_39700_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: acc_5_V_77_fu_39675_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_1177_fu_39806_p3() {
    select_ln340_1177_fu_39806_p3 = (!xor_ln340_1154_fu_39788_p2.read()[0].is_01())? sc_lv<24>(): ((xor_ln340_1154_fu_39788_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: acc_5_V_79_fu_39763_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_1178_fu_39894_p3() {
    select_ln340_1178_fu_39894_p3 = (!xor_ln340_1155_fu_39876_p2.read()[0].is_01())? sc_lv<24>(): ((xor_ln340_1155_fu_39876_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: acc_5_V_81_fu_39851_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_1179_fu_39982_p3() {
    select_ln340_1179_fu_39982_p3 = (!xor_ln340_1156_fu_39964_p2.read()[0].is_01())? sc_lv<24>(): ((xor_ln340_1156_fu_39964_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: acc_5_V_83_fu_39939_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_117_fu_22469_p3() {
    select_ln340_117_fu_22469_p3 = (!or_ln340_117_fu_22451_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_117_fu_22451_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: add_ln415_643_fu_22361_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_1180_fu_40070_p3() {
    select_ln340_1180_fu_40070_p3 = (!xor_ln340_1157_fu_40052_p2.read()[0].is_01())? sc_lv<24>(): ((xor_ln340_1157_fu_40052_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: acc_5_V_85_fu_40027_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_1181_fu_40158_p3() {
    select_ln340_1181_fu_40158_p3 = (!xor_ln340_1158_fu_40140_p2.read()[0].is_01())? sc_lv<24>(): ((xor_ln340_1158_fu_40140_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: acc_5_V_87_fu_40115_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_1182_fu_40246_p3() {
    select_ln340_1182_fu_40246_p3 = (!xor_ln340_1159_fu_40228_p2.read()[0].is_01())? sc_lv<24>(): ((xor_ln340_1159_fu_40228_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: acc_5_V_89_fu_40203_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_1183_fu_40334_p3() {
    select_ln340_1183_fu_40334_p3 = (!xor_ln340_1160_fu_40316_p2.read()[0].is_01())? sc_lv<24>(): ((xor_ln340_1160_fu_40316_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: acc_5_V_91_fu_40291_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_1184_fu_40422_p3() {
    select_ln340_1184_fu_40422_p3 = (!xor_ln340_1161_fu_40404_p2.read()[0].is_01())? sc_lv<24>(): ((xor_ln340_1161_fu_40404_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: acc_5_V_93_fu_40379_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_1185_fu_40510_p3() {
    select_ln340_1185_fu_40510_p3 = (!xor_ln340_1162_fu_40492_p2.read()[0].is_01())? sc_lv<24>(): ((xor_ln340_1162_fu_40492_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: acc_5_V_95_fu_40467_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_1186_fu_40598_p3() {
    select_ln340_1186_fu_40598_p3 = (!xor_ln340_1163_fu_40580_p2.read()[0].is_01())? sc_lv<24>(): ((xor_ln340_1163_fu_40580_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: acc_5_V_97_fu_40555_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_1187_fu_40686_p3() {
    select_ln340_1187_fu_40686_p3 = (!xor_ln340_1164_fu_40668_p2.read()[0].is_01())? sc_lv<24>(): ((xor_ln340_1164_fu_40668_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: acc_5_V_99_fu_40643_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_1188_fu_40774_p3() {
    select_ln340_1188_fu_40774_p3 = (!xor_ln340_1165_fu_40756_p2.read()[0].is_01())? sc_lv<24>(): ((xor_ln340_1165_fu_40756_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: acc_5_V_101_fu_40731_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_1189_fu_40862_p3() {
    select_ln340_1189_fu_40862_p3 = (!xor_ln340_1166_fu_40844_p2.read()[0].is_01())? sc_lv<24>(): ((xor_ln340_1166_fu_40844_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: acc_5_V_103_fu_40819_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_118_fu_22649_p3() {
    select_ln340_118_fu_22649_p3 = (!or_ln340_118_fu_22631_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_118_fu_22631_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: add_ln415_644_fu_22541_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_1190_fu_41121_p3() {
    select_ln340_1190_fu_41121_p3 = (!xor_ln340_1167_fu_41103_p2.read()[0].is_01())? sc_lv<24>(): ((xor_ln340_1167_fu_41103_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: acc_5_V_105_fu_41077_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_1191_fu_41209_p3() {
    select_ln340_1191_fu_41209_p3 = (!xor_ln340_1168_fu_41191_p2.read()[0].is_01())? sc_lv<24>(): ((xor_ln340_1168_fu_41191_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: acc_6_V_fu_41166_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_1192_fu_41297_p3() {
    select_ln340_1192_fu_41297_p3 = (!xor_ln340_1169_fu_41279_p2.read()[0].is_01())? sc_lv<24>(): ((xor_ln340_1169_fu_41279_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: acc_6_V_69_fu_41254_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_1193_fu_41385_p3() {
    select_ln340_1193_fu_41385_p3 = (!xor_ln340_1170_fu_41367_p2.read()[0].is_01())? sc_lv<24>(): ((xor_ln340_1170_fu_41367_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: acc_6_V_71_fu_41342_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_1194_fu_41473_p3() {
    select_ln340_1194_fu_41473_p3 = (!xor_ln340_1171_fu_41455_p2.read()[0].is_01())? sc_lv<24>(): ((xor_ln340_1171_fu_41455_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: acc_6_V_73_fu_41430_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_1195_fu_41561_p3() {
    select_ln340_1195_fu_41561_p3 = (!xor_ln340_1172_fu_41543_p2.read()[0].is_01())? sc_lv<24>(): ((xor_ln340_1172_fu_41543_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: acc_6_V_75_fu_41518_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_1196_fu_41649_p3() {
    select_ln340_1196_fu_41649_p3 = (!xor_ln340_1173_fu_41631_p2.read()[0].is_01())? sc_lv<24>(): ((xor_ln340_1173_fu_41631_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: acc_6_V_77_fu_41606_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_1197_fu_41737_p3() {
    select_ln340_1197_fu_41737_p3 = (!xor_ln340_1174_fu_41719_p2.read()[0].is_01())? sc_lv<24>(): ((xor_ln340_1174_fu_41719_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: acc_6_V_79_fu_41694_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_1198_fu_41825_p3() {
    select_ln340_1198_fu_41825_p3 = (!xor_ln340_1175_fu_41807_p2.read()[0].is_01())? sc_lv<24>(): ((xor_ln340_1175_fu_41807_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: acc_6_V_81_fu_41782_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_1199_fu_41913_p3() {
    select_ln340_1199_fu_41913_p3 = (!xor_ln340_1176_fu_41895_p2.read()[0].is_01())? sc_lv<24>(): ((xor_ln340_1176_fu_41895_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: acc_6_V_83_fu_41870_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_119_fu_41031_p3() {
    select_ln340_119_fu_41031_p3 = (!or_ln340_119_fu_41013_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_119_fu_41013_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: add_ln415_645_fu_40923_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_11_fu_4155_p3() {
    select_ln340_11_fu_4155_p3 = (!or_ln340_11_fu_4137_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_11_fu_4137_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: add_ln415_537_fu_4047_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_1200_fu_42001_p3() {
    select_ln340_1200_fu_42001_p3 = (!xor_ln340_1177_fu_41983_p2.read()[0].is_01())? sc_lv<24>(): ((xor_ln340_1177_fu_41983_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: acc_6_V_85_fu_41958_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_1201_fu_42089_p3() {
    select_ln340_1201_fu_42089_p3 = (!xor_ln340_1178_fu_42071_p2.read()[0].is_01())? sc_lv<24>(): ((xor_ln340_1178_fu_42071_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: acc_6_V_87_fu_42046_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_1202_fu_42177_p3() {
    select_ln340_1202_fu_42177_p3 = (!xor_ln340_1179_fu_42159_p2.read()[0].is_01())? sc_lv<24>(): ((xor_ln340_1179_fu_42159_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: acc_6_V_89_fu_42134_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_1203_fu_42265_p3() {
    select_ln340_1203_fu_42265_p3 = (!xor_ln340_1180_fu_42247_p2.read()[0].is_01())? sc_lv<24>(): ((xor_ln340_1180_fu_42247_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: acc_6_V_91_fu_42222_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_1204_fu_42353_p3() {
    select_ln340_1204_fu_42353_p3 = (!xor_ln340_1181_fu_42335_p2.read()[0].is_01())? sc_lv<24>(): ((xor_ln340_1181_fu_42335_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: acc_6_V_93_fu_42310_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_1205_fu_42441_p3() {
    select_ln340_1205_fu_42441_p3 = (!xor_ln340_1182_fu_42423_p2.read()[0].is_01())? sc_lv<24>(): ((xor_ln340_1182_fu_42423_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: acc_6_V_95_fu_42398_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_1206_fu_42529_p3() {
    select_ln340_1206_fu_42529_p3 = (!xor_ln340_1183_fu_42511_p2.read()[0].is_01())? sc_lv<24>(): ((xor_ln340_1183_fu_42511_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: acc_6_V_97_fu_42486_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_1207_fu_42617_p3() {
    select_ln340_1207_fu_42617_p3 = (!xor_ln340_1184_fu_42599_p2.read()[0].is_01())? sc_lv<24>(): ((xor_ln340_1184_fu_42599_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: acc_6_V_99_fu_42574_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_1208_fu_42705_p3() {
    select_ln340_1208_fu_42705_p3 = (!xor_ln340_1185_fu_42687_p2.read()[0].is_01())? sc_lv<24>(): ((xor_ln340_1185_fu_42687_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: acc_6_V_101_fu_42662_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_1209_fu_42793_p3() {
    select_ln340_1209_fu_42793_p3 = (!xor_ln340_1186_fu_42775_p2.read()[0].is_01())? sc_lv<24>(): ((xor_ln340_1186_fu_42775_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: acc_6_V_103_fu_42750_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_120_fu_22839_p3() {
    select_ln340_120_fu_22839_p3 = (!or_ln340_120_fu_22821_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_120_fu_22821_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: add_ln415_646_fu_22731_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_1210_fu_43052_p3() {
    select_ln340_1210_fu_43052_p3 = (!xor_ln340_1187_fu_43034_p2.read()[0].is_01())? sc_lv<24>(): ((xor_ln340_1187_fu_43034_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: acc_6_V_105_fu_43008_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_1211_fu_43140_p3() {
    select_ln340_1211_fu_43140_p3 = (!xor_ln340_1188_fu_43122_p2.read()[0].is_01())? sc_lv<24>(): ((xor_ln340_1188_fu_43122_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: acc_7_V_fu_43097_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_1212_fu_43228_p3() {
    select_ln340_1212_fu_43228_p3 = (!xor_ln340_1189_fu_43210_p2.read()[0].is_01())? sc_lv<24>(): ((xor_ln340_1189_fu_43210_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: acc_7_V_69_fu_43185_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_1213_fu_43316_p3() {
    select_ln340_1213_fu_43316_p3 = (!xor_ln340_1190_fu_43298_p2.read()[0].is_01())? sc_lv<24>(): ((xor_ln340_1190_fu_43298_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: acc_7_V_71_fu_43273_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_1214_fu_43404_p3() {
    select_ln340_1214_fu_43404_p3 = (!xor_ln340_1191_fu_43386_p2.read()[0].is_01())? sc_lv<24>(): ((xor_ln340_1191_fu_43386_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: acc_7_V_73_fu_43361_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_1215_fu_43492_p3() {
    select_ln340_1215_fu_43492_p3 = (!xor_ln340_1192_fu_43474_p2.read()[0].is_01())? sc_lv<24>(): ((xor_ln340_1192_fu_43474_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: acc_7_V_75_fu_43449_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_1216_fu_43580_p3() {
    select_ln340_1216_fu_43580_p3 = (!xor_ln340_1193_fu_43562_p2.read()[0].is_01())? sc_lv<24>(): ((xor_ln340_1193_fu_43562_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: acc_7_V_77_fu_43537_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_1217_fu_43668_p3() {
    select_ln340_1217_fu_43668_p3 = (!xor_ln340_1194_fu_43650_p2.read()[0].is_01())? sc_lv<24>(): ((xor_ln340_1194_fu_43650_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: acc_7_V_79_fu_43625_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_1218_fu_43756_p3() {
    select_ln340_1218_fu_43756_p3 = (!xor_ln340_1195_fu_43738_p2.read()[0].is_01())? sc_lv<24>(): ((xor_ln340_1195_fu_43738_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: acc_7_V_81_fu_43713_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_1219_fu_43844_p3() {
    select_ln340_1219_fu_43844_p3 = (!xor_ln340_1196_fu_43826_p2.read()[0].is_01())? sc_lv<24>(): ((xor_ln340_1196_fu_43826_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: acc_7_V_83_fu_43801_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_121_fu_23019_p3() {
    select_ln340_121_fu_23019_p3 = (!or_ln340_121_fu_23001_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_121_fu_23001_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: add_ln415_647_fu_22911_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_1220_fu_43932_p3() {
    select_ln340_1220_fu_43932_p3 = (!xor_ln340_1197_fu_43914_p2.read()[0].is_01())? sc_lv<24>(): ((xor_ln340_1197_fu_43914_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: acc_7_V_85_fu_43889_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_1221_fu_44020_p3() {
    select_ln340_1221_fu_44020_p3 = (!xor_ln340_1198_fu_44002_p2.read()[0].is_01())? sc_lv<24>(): ((xor_ln340_1198_fu_44002_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: acc_7_V_87_fu_43977_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_1222_fu_44108_p3() {
    select_ln340_1222_fu_44108_p3 = (!xor_ln340_1199_fu_44090_p2.read()[0].is_01())? sc_lv<24>(): ((xor_ln340_1199_fu_44090_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: acc_7_V_89_fu_44065_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_1223_fu_44196_p3() {
    select_ln340_1223_fu_44196_p3 = (!xor_ln340_1200_fu_44178_p2.read()[0].is_01())? sc_lv<24>(): ((xor_ln340_1200_fu_44178_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: acc_7_V_91_fu_44153_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_1224_fu_44284_p3() {
    select_ln340_1224_fu_44284_p3 = (!xor_ln340_1201_fu_44266_p2.read()[0].is_01())? sc_lv<24>(): ((xor_ln340_1201_fu_44266_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: acc_7_V_93_fu_44241_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_1225_fu_44372_p3() {
    select_ln340_1225_fu_44372_p3 = (!xor_ln340_1202_fu_44354_p2.read()[0].is_01())? sc_lv<24>(): ((xor_ln340_1202_fu_44354_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: acc_7_V_95_fu_44329_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_1226_fu_44460_p3() {
    select_ln340_1226_fu_44460_p3 = (!xor_ln340_1203_fu_44442_p2.read()[0].is_01())? sc_lv<24>(): ((xor_ln340_1203_fu_44442_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: acc_7_V_97_fu_44417_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_1227_fu_44548_p3() {
    select_ln340_1227_fu_44548_p3 = (!xor_ln340_1204_fu_44530_p2.read()[0].is_01())? sc_lv<24>(): ((xor_ln340_1204_fu_44530_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: acc_7_V_99_fu_44505_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_1228_fu_44636_p3() {
    select_ln340_1228_fu_44636_p3 = (!xor_ln340_1205_fu_44618_p2.read()[0].is_01())? sc_lv<24>(): ((xor_ln340_1205_fu_44618_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: acc_7_V_101_fu_44593_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_1229_fu_44724_p3() {
    select_ln340_1229_fu_44724_p3 = (!xor_ln340_1206_fu_44706_p2.read()[0].is_01())? sc_lv<24>(): ((xor_ln340_1206_fu_44706_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: acc_7_V_103_fu_44681_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_122_fu_23199_p3() {
    select_ln340_122_fu_23199_p3 = (!or_ln340_122_fu_23181_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_122_fu_23181_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: add_ln415_648_fu_23091_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_1230_fu_45001_p3() {
    select_ln340_1230_fu_45001_p3 = (!xor_ln340_1207_fu_44983_p2.read()[0].is_01())? sc_lv<24>(): ((xor_ln340_1207_fu_44983_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: acc_7_V_105_fu_44957_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_123_fu_23379_p3() {
    select_ln340_123_fu_23379_p3 = (!or_ln340_123_fu_23361_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_123_fu_23361_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: add_ln415_649_fu_23271_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_124_fu_23559_p3() {
    select_ln340_124_fu_23559_p3 = (!or_ln340_124_fu_23541_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_124_fu_23541_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: add_ln415_650_fu_23451_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_125_fu_23739_p3() {
    select_ln340_125_fu_23739_p3 = (!or_ln340_125_fu_23721_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_125_fu_23721_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: add_ln415_651_fu_23631_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_126_fu_23919_p3() {
    select_ln340_126_fu_23919_p3 = (!or_ln340_126_fu_23901_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_126_fu_23901_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: add_ln415_652_fu_23811_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_127_fu_24099_p3() {
    select_ln340_127_fu_24099_p3 = (!or_ln340_127_fu_24081_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_127_fu_24081_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: add_ln415_653_fu_23991_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_128_fu_24279_p3() {
    select_ln340_128_fu_24279_p3 = (!or_ln340_128_fu_24261_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_128_fu_24261_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: add_ln415_654_fu_24171_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_129_fu_24459_p3() {
    select_ln340_129_fu_24459_p3 = (!or_ln340_129_fu_24441_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_129_fu_24441_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: add_ln415_655_fu_24351_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_12_fu_4347_p3() {
    select_ln340_12_fu_4347_p3 = (!or_ln340_12_fu_4329_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_12_fu_4329_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: add_ln415_538_fu_4239_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_130_fu_24639_p3() {
    select_ln340_130_fu_24639_p3 = (!or_ln340_130_fu_24621_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_130_fu_24621_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: add_ln415_656_fu_24531_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_131_fu_24819_p3() {
    select_ln340_131_fu_24819_p3 = (!or_ln340_131_fu_24801_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_131_fu_24801_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: add_ln415_657_fu_24711_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_132_fu_24999_p3() {
    select_ln340_132_fu_24999_p3 = (!or_ln340_132_fu_24981_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_132_fu_24981_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: add_ln415_658_fu_24891_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_133_fu_25179_p3() {
    select_ln340_133_fu_25179_p3 = (!or_ln340_133_fu_25161_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_133_fu_25161_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: add_ln415_659_fu_25071_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_134_fu_25359_p3() {
    select_ln340_134_fu_25359_p3 = (!or_ln340_134_fu_25341_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_134_fu_25341_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: add_ln415_660_fu_25251_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_135_fu_25539_p3() {
    select_ln340_135_fu_25539_p3 = (!or_ln340_135_fu_25521_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_135_fu_25521_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: add_ln415_661_fu_25431_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_136_fu_25719_p3() {
    select_ln340_136_fu_25719_p3 = (!or_ln340_136_fu_25701_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_136_fu_25701_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: add_ln415_662_fu_25611_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_137_fu_25899_p3() {
    select_ln340_137_fu_25899_p3 = (!or_ln340_137_fu_25881_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_137_fu_25881_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: add_ln415_663_fu_25791_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_138_fu_26079_p3() {
    select_ln340_138_fu_26079_p3 = (!or_ln340_138_fu_26061_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_138_fu_26061_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: add_ln415_664_fu_25971_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_139_fu_42962_p3() {
    select_ln340_139_fu_42962_p3 = (!or_ln340_139_fu_42944_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_139_fu_42944_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: add_ln415_665_fu_42854_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_13_fu_4539_p3() {
    select_ln340_13_fu_4539_p3 = (!or_ln340_13_fu_4521_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_13_fu_4521_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: add_ln415_539_fu_4431_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_140_fu_26269_p3() {
    select_ln340_140_fu_26269_p3 = (!or_ln340_140_fu_26251_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_140_fu_26251_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: add_ln415_666_fu_26161_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_141_fu_26449_p3() {
    select_ln340_141_fu_26449_p3 = (!or_ln340_141_fu_26431_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_141_fu_26431_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: add_ln415_667_fu_26341_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_142_fu_26629_p3() {
    select_ln340_142_fu_26629_p3 = (!or_ln340_142_fu_26611_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_142_fu_26611_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: add_ln415_668_fu_26521_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_143_fu_26809_p3() {
    select_ln340_143_fu_26809_p3 = (!or_ln340_143_fu_26791_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_143_fu_26791_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: add_ln415_669_fu_26701_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_144_fu_26989_p3() {
    select_ln340_144_fu_26989_p3 = (!or_ln340_144_fu_26971_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_144_fu_26971_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: add_ln415_670_fu_26881_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_145_fu_27169_p3() {
    select_ln340_145_fu_27169_p3 = (!or_ln340_145_fu_27151_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_145_fu_27151_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: add_ln415_671_fu_27061_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_146_fu_27349_p3() {
    select_ln340_146_fu_27349_p3 = (!or_ln340_146_fu_27331_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_146_fu_27331_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: add_ln415_672_fu_27241_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_147_fu_27529_p3() {
    select_ln340_147_fu_27529_p3 = (!or_ln340_147_fu_27511_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_147_fu_27511_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: add_ln415_673_fu_27421_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_148_fu_27709_p3() {
    select_ln340_148_fu_27709_p3 = (!or_ln340_148_fu_27691_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_148_fu_27691_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: add_ln415_674_fu_27601_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_149_fu_27889_p3() {
    select_ln340_149_fu_27889_p3 = (!or_ln340_149_fu_27871_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_149_fu_27871_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: add_ln415_675_fu_27781_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_14_fu_4731_p3() {
    select_ln340_14_fu_4731_p3 = (!or_ln340_14_fu_4713_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_14_fu_4713_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: add_ln415_540_fu_4623_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_150_fu_28069_p3() {
    select_ln340_150_fu_28069_p3 = (!or_ln340_150_fu_28051_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_150_fu_28051_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: add_ln415_676_fu_27961_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_151_fu_28249_p3() {
    select_ln340_151_fu_28249_p3 = (!or_ln340_151_fu_28231_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_151_fu_28231_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: add_ln415_677_fu_28141_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_152_fu_28429_p3() {
    select_ln340_152_fu_28429_p3 = (!or_ln340_152_fu_28411_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_152_fu_28411_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: add_ln415_678_fu_28321_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_153_fu_28609_p3() {
    select_ln340_153_fu_28609_p3 = (!or_ln340_153_fu_28591_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_153_fu_28591_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: add_ln415_679_fu_28501_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_154_fu_28789_p3() {
    select_ln340_154_fu_28789_p3 = (!or_ln340_154_fu_28771_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_154_fu_28771_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: add_ln415_680_fu_28681_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_155_fu_28969_p3() {
    select_ln340_155_fu_28969_p3 = (!or_ln340_155_fu_28951_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_155_fu_28951_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: add_ln415_681_fu_28861_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_156_fu_29149_p3() {
    select_ln340_156_fu_29149_p3 = (!or_ln340_156_fu_29131_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_156_fu_29131_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: add_ln415_682_fu_29041_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_157_fu_29329_p3() {
    select_ln340_157_fu_29329_p3 = (!or_ln340_157_fu_29311_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_157_fu_29311_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: add_ln415_683_fu_29221_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_158_fu_29509_p3() {
    select_ln340_158_fu_29509_p3 = (!or_ln340_158_fu_29491_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_158_fu_29491_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: add_ln415_684_fu_29401_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_159_fu_44911_p3() {
    select_ln340_159_fu_44911_p3 = (!or_ln340_159_fu_44893_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_159_fu_44893_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: sext_ln415_fu_44805_p1.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_15_fu_4923_p3() {
    select_ln340_15_fu_4923_p3 = (!or_ln340_15_fu_4905_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_15_fu_4905_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: add_ln415_541_fu_4815_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_16_fu_5115_p3() {
    select_ln340_16_fu_5115_p3 = (!or_ln340_16_fu_5097_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_16_fu_5097_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: add_ln415_542_fu_5007_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_17_fu_5307_p3() {
    select_ln340_17_fu_5307_p3 = (!or_ln340_17_fu_5289_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_17_fu_5289_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: add_ln415_543_fu_5199_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_18_fu_5499_p3() {
    select_ln340_18_fu_5499_p3 = (!or_ln340_18_fu_5481_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_18_fu_5481_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: add_ln415_544_fu_5391_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_19_fu_31376_p3() {
    select_ln340_19_fu_31376_p3 = (!or_ln340_19_fu_31358_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_19_fu_31358_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: add_ln415_545_fu_31268_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_1_fu_2219_p3() {
    select_ln340_1_fu_2219_p3 = (!or_ln340_1_fu_2201_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_1_fu_2201_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: add_ln415_527_fu_2111_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_2096_fu_2035_p3() {
    select_ln340_2096_fu_2035_p3 = (!or_ln340_2120_fu_2013_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2120_fu_2013_p2.read()[0].to_bool())? select_ln340_fu_2019_p3.read(): select_ln388_fu_2027_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_2097_fu_29623_p3() {
    select_ln340_2097_fu_29623_p3 = (!or_ln340_2121_fu_29601_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2121_fu_29601_p2.read()[0].to_bool())? select_ln340_1071_fu_29607_p3.read(): acc_0_V_68_fu_29615_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_2098_fu_2235_p3() {
    select_ln340_2098_fu_2235_p3 = (!or_ln340_2123_fu_2213_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2123_fu_2213_p2.read()[0].to_bool())? select_ln340_1_fu_2219_p3.read(): select_ln388_1_fu_2227_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_2099_fu_29711_p3() {
    select_ln340_2099_fu_29711_p3 = (!or_ln340_2124_fu_29689_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2124_fu_29689_p2.read()[0].to_bool())? select_ln340_1072_fu_29695_p3.read(): acc_0_V_70_fu_29703_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_20_fu_5689_p3() {
    select_ln340_20_fu_5689_p3 = (!or_ln340_20_fu_5671_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_20_fu_5671_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: add_ln415_546_fu_5581_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_2100_fu_2435_p3() {
    select_ln340_2100_fu_2435_p3 = (!or_ln340_2126_fu_2413_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2126_fu_2413_p2.read()[0].to_bool())? select_ln340_2_fu_2419_p3.read(): select_ln388_2_fu_2427_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_2101_fu_29799_p3() {
    select_ln340_2101_fu_29799_p3 = (!or_ln340_2127_fu_29777_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2127_fu_29777_p2.read()[0].to_bool())? select_ln340_1073_fu_29783_p3.read(): acc_0_V_72_fu_29791_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_2102_fu_2635_p3() {
    select_ln340_2102_fu_2635_p3 = (!or_ln340_2129_fu_2613_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2129_fu_2613_p2.read()[0].to_bool())? select_ln340_3_fu_2619_p3.read(): select_ln388_3_fu_2627_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_2103_fu_29887_p3() {
    select_ln340_2103_fu_29887_p3 = (!or_ln340_2130_fu_29865_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2130_fu_29865_p2.read()[0].to_bool())? select_ln340_1074_fu_29871_p3.read(): acc_0_V_74_fu_29879_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_2104_fu_2827_p3() {
    select_ln340_2104_fu_2827_p3 = (!or_ln340_2132_fu_2805_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2132_fu_2805_p2.read()[0].to_bool())? select_ln340_4_fu_2811_p3.read(): select_ln388_4_fu_2819_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_2105_fu_29975_p3() {
    select_ln340_2105_fu_29975_p3 = (!or_ln340_2133_fu_29953_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2133_fu_29953_p2.read()[0].to_bool())? select_ln340_1075_fu_29959_p3.read(): acc_0_V_76_fu_29967_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_2106_fu_3019_p3() {
    select_ln340_2106_fu_3019_p3 = (!or_ln340_2135_fu_2997_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2135_fu_2997_p2.read()[0].to_bool())? select_ln340_5_fu_3003_p3.read(): select_ln388_5_fu_3011_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_2107_fu_30063_p3() {
    select_ln340_2107_fu_30063_p3 = (!or_ln340_2136_fu_30041_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2136_fu_30041_p2.read()[0].to_bool())? select_ln340_1076_fu_30047_p3.read(): acc_0_V_78_fu_30055_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_2108_fu_3211_p3() {
    select_ln340_2108_fu_3211_p3 = (!or_ln340_2138_fu_3189_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2138_fu_3189_p2.read()[0].to_bool())? select_ln340_6_fu_3195_p3.read(): select_ln388_6_fu_3203_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_2109_fu_30151_p3() {
    select_ln340_2109_fu_30151_p3 = (!or_ln340_2139_fu_30129_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2139_fu_30129_p2.read()[0].to_bool())? select_ln340_1077_fu_30135_p3.read(): acc_0_V_80_fu_30143_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_2110_fu_3403_p3() {
    select_ln340_2110_fu_3403_p3 = (!or_ln340_2141_fu_3381_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2141_fu_3381_p2.read()[0].to_bool())? select_ln340_7_fu_3387_p3.read(): select_ln388_7_fu_3395_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_2111_fu_30239_p3() {
    select_ln340_2111_fu_30239_p3 = (!or_ln340_2142_fu_30217_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2142_fu_30217_p2.read()[0].to_bool())? select_ln340_1078_fu_30223_p3.read(): acc_0_V_82_fu_30231_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_2112_fu_3595_p3() {
    select_ln340_2112_fu_3595_p3 = (!or_ln340_2144_fu_3573_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2144_fu_3573_p2.read()[0].to_bool())? select_ln340_8_fu_3579_p3.read(): select_ln388_8_fu_3587_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_2113_fu_30327_p3() {
    select_ln340_2113_fu_30327_p3 = (!or_ln340_2145_fu_30305_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2145_fu_30305_p2.read()[0].to_bool())? select_ln340_1079_fu_30311_p3.read(): acc_0_V_84_fu_30319_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_2114_fu_3787_p3() {
    select_ln340_2114_fu_3787_p3 = (!or_ln340_2147_fu_3765_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2147_fu_3765_p2.read()[0].to_bool())? select_ln340_9_fu_3771_p3.read(): select_ln388_9_fu_3779_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_2115_fu_30415_p3() {
    select_ln340_2115_fu_30415_p3 = (!or_ln340_2148_fu_30393_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2148_fu_30393_p2.read()[0].to_bool())? select_ln340_1080_fu_30399_p3.read(): acc_0_V_86_fu_30407_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_2116_fu_3979_p3() {
    select_ln340_2116_fu_3979_p3 = (!or_ln340_2150_fu_3957_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2150_fu_3957_p2.read()[0].to_bool())? select_ln340_10_fu_3963_p3.read(): select_ln388_10_fu_3971_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_2117_fu_30503_p3() {
    select_ln340_2117_fu_30503_p3 = (!or_ln340_2151_fu_30481_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2151_fu_30481_p2.read()[0].to_bool())? select_ln340_1081_fu_30487_p3.read(): acc_0_V_88_fu_30495_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_2118_fu_4171_p3() {
    select_ln340_2118_fu_4171_p3 = (!or_ln340_2153_fu_4149_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2153_fu_4149_p2.read()[0].to_bool())? select_ln340_11_fu_4155_p3.read(): select_ln388_11_fu_4163_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_2119_fu_30591_p3() {
    select_ln340_2119_fu_30591_p3 = (!or_ln340_2154_fu_30569_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2154_fu_30569_p2.read()[0].to_bool())? select_ln340_1082_fu_30575_p3.read(): acc_0_V_90_fu_30583_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_2120_fu_4363_p3() {
    select_ln340_2120_fu_4363_p3 = (!or_ln340_2156_fu_4341_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2156_fu_4341_p2.read()[0].to_bool())? select_ln340_12_fu_4347_p3.read(): select_ln388_12_fu_4355_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_2121_fu_30679_p3() {
    select_ln340_2121_fu_30679_p3 = (!or_ln340_2157_fu_30657_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2157_fu_30657_p2.read()[0].to_bool())? select_ln340_1083_fu_30663_p3.read(): acc_0_V_92_fu_30671_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_2122_fu_4555_p3() {
    select_ln340_2122_fu_4555_p3 = (!or_ln340_2159_fu_4533_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2159_fu_4533_p2.read()[0].to_bool())? select_ln340_13_fu_4539_p3.read(): select_ln388_13_fu_4547_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_2123_fu_30767_p3() {
    select_ln340_2123_fu_30767_p3 = (!or_ln340_2160_fu_30745_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2160_fu_30745_p2.read()[0].to_bool())? select_ln340_1084_fu_30751_p3.read(): acc_0_V_94_fu_30759_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_2124_fu_4747_p3() {
    select_ln340_2124_fu_4747_p3 = (!or_ln340_2162_fu_4725_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2162_fu_4725_p2.read()[0].to_bool())? select_ln340_14_fu_4731_p3.read(): select_ln388_14_fu_4739_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_2125_fu_30855_p3() {
    select_ln340_2125_fu_30855_p3 = (!or_ln340_2163_fu_30833_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2163_fu_30833_p2.read()[0].to_bool())? select_ln340_1085_fu_30839_p3.read(): acc_0_V_96_fu_30847_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_2126_fu_4939_p3() {
    select_ln340_2126_fu_4939_p3 = (!or_ln340_2165_fu_4917_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2165_fu_4917_p2.read()[0].to_bool())? select_ln340_15_fu_4923_p3.read(): select_ln388_15_fu_4931_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_2127_fu_30943_p3() {
    select_ln340_2127_fu_30943_p3 = (!or_ln340_2166_fu_30921_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2166_fu_30921_p2.read()[0].to_bool())? select_ln340_1086_fu_30927_p3.read(): acc_0_V_98_fu_30935_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_2128_fu_5131_p3() {
    select_ln340_2128_fu_5131_p3 = (!or_ln340_2168_fu_5109_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2168_fu_5109_p2.read()[0].to_bool())? select_ln340_16_fu_5115_p3.read(): select_ln388_16_fu_5123_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_2129_fu_31031_p3() {
    select_ln340_2129_fu_31031_p3 = (!or_ln340_2169_fu_31009_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2169_fu_31009_p2.read()[0].to_bool())? select_ln340_1087_fu_31015_p3.read(): acc_0_V_100_fu_31023_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_2130_fu_5323_p3() {
    select_ln340_2130_fu_5323_p3 = (!or_ln340_2171_fu_5301_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2171_fu_5301_p2.read()[0].to_bool())? select_ln340_17_fu_5307_p3.read(): select_ln388_17_fu_5315_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_2131_fu_31119_p3() {
    select_ln340_2131_fu_31119_p3 = (!or_ln340_2172_fu_31097_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2172_fu_31097_p2.read()[0].to_bool())? select_ln340_1088_fu_31103_p3.read(): acc_0_V_102_fu_31111_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_2132_fu_5515_p3() {
    select_ln340_2132_fu_5515_p3 = (!or_ln340_2174_fu_5493_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2174_fu_5493_p2.read()[0].to_bool())? select_ln340_18_fu_5499_p3.read(): select_ln388_18_fu_5507_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_2133_fu_31207_p3() {
    select_ln340_2133_fu_31207_p3 = (!or_ln340_2175_fu_31185_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2175_fu_31185_p2.read()[0].to_bool())? select_ln340_1089_fu_31191_p3.read(): acc_0_V_104_fu_31199_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_2134_fu_31392_p3() {
    select_ln340_2134_fu_31392_p3 = (!or_ln340_2177_fu_31370_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2177_fu_31370_p2.read()[0].to_bool())? select_ln340_19_fu_31376_p3.read(): select_ln388_19_fu_31384_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_2136_fu_5705_p3() {
    select_ln340_2136_fu_5705_p3 = (!or_ln340_2180_fu_5683_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2180_fu_5683_p2.read()[0].to_bool())? select_ln340_20_fu_5689_p3.read(): select_ln388_20_fu_5697_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_2137_fu_31570_p3() {
    select_ln340_2137_fu_31570_p3 = (!or_ln340_2181_fu_31548_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2181_fu_31548_p2.read()[0].to_bool())? select_ln340_1091_fu_31554_p3.read(): acc_1_V_68_fu_31562_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_2138_fu_5885_p3() {
    select_ln340_2138_fu_5885_p3 = (!or_ln340_2183_fu_5863_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2183_fu_5863_p2.read()[0].to_bool())? select_ln340_21_fu_5869_p3.read(): select_ln388_21_fu_5877_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_2139_fu_31658_p3() {
    select_ln340_2139_fu_31658_p3 = (!or_ln340_2184_fu_31636_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2184_fu_31636_p2.read()[0].to_bool())? select_ln340_1092_fu_31642_p3.read(): acc_1_V_70_fu_31650_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_2140_fu_6065_p3() {
    select_ln340_2140_fu_6065_p3 = (!or_ln340_2186_fu_6043_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2186_fu_6043_p2.read()[0].to_bool())? select_ln340_22_fu_6049_p3.read(): select_ln388_22_fu_6057_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_2141_fu_31746_p3() {
    select_ln340_2141_fu_31746_p3 = (!or_ln340_2187_fu_31724_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2187_fu_31724_p2.read()[0].to_bool())? select_ln340_1093_fu_31730_p3.read(): acc_1_V_72_fu_31738_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_2142_fu_6245_p3() {
    select_ln340_2142_fu_6245_p3 = (!or_ln340_2189_fu_6223_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2189_fu_6223_p2.read()[0].to_bool())? select_ln340_23_fu_6229_p3.read(): select_ln388_23_fu_6237_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_2143_fu_31834_p3() {
    select_ln340_2143_fu_31834_p3 = (!or_ln340_2190_fu_31812_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2190_fu_31812_p2.read()[0].to_bool())? select_ln340_1094_fu_31818_p3.read(): acc_1_V_74_fu_31826_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_2144_fu_6425_p3() {
    select_ln340_2144_fu_6425_p3 = (!or_ln340_2192_fu_6403_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2192_fu_6403_p2.read()[0].to_bool())? select_ln340_24_fu_6409_p3.read(): select_ln388_24_fu_6417_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_2145_fu_31922_p3() {
    select_ln340_2145_fu_31922_p3 = (!or_ln340_2193_fu_31900_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2193_fu_31900_p2.read()[0].to_bool())? select_ln340_1095_fu_31906_p3.read(): acc_1_V_76_fu_31914_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_2146_fu_6605_p3() {
    select_ln340_2146_fu_6605_p3 = (!or_ln340_2195_fu_6583_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2195_fu_6583_p2.read()[0].to_bool())? select_ln340_25_fu_6589_p3.read(): select_ln388_25_fu_6597_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_2147_fu_32010_p3() {
    select_ln340_2147_fu_32010_p3 = (!or_ln340_2196_fu_31988_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2196_fu_31988_p2.read()[0].to_bool())? select_ln340_1096_fu_31994_p3.read(): acc_1_V_78_fu_32002_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_2148_fu_6785_p3() {
    select_ln340_2148_fu_6785_p3 = (!or_ln340_2198_fu_6763_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2198_fu_6763_p2.read()[0].to_bool())? select_ln340_26_fu_6769_p3.read(): select_ln388_26_fu_6777_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_2149_fu_32098_p3() {
    select_ln340_2149_fu_32098_p3 = (!or_ln340_2199_fu_32076_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2199_fu_32076_p2.read()[0].to_bool())? select_ln340_1097_fu_32082_p3.read(): acc_1_V_80_fu_32090_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_2150_fu_6965_p3() {
    select_ln340_2150_fu_6965_p3 = (!or_ln340_2201_fu_6943_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2201_fu_6943_p2.read()[0].to_bool())? select_ln340_27_fu_6949_p3.read(): select_ln388_27_fu_6957_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_2151_fu_32186_p3() {
    select_ln340_2151_fu_32186_p3 = (!or_ln340_2202_fu_32164_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2202_fu_32164_p2.read()[0].to_bool())? select_ln340_1098_fu_32170_p3.read(): acc_1_V_82_fu_32178_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_2152_fu_7145_p3() {
    select_ln340_2152_fu_7145_p3 = (!or_ln340_2204_fu_7123_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2204_fu_7123_p2.read()[0].to_bool())? select_ln340_28_fu_7129_p3.read(): select_ln388_28_fu_7137_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_2153_fu_32274_p3() {
    select_ln340_2153_fu_32274_p3 = (!or_ln340_2205_fu_32252_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2205_fu_32252_p2.read()[0].to_bool())? select_ln340_1099_fu_32258_p3.read(): acc_1_V_84_fu_32266_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_2154_fu_7325_p3() {
    select_ln340_2154_fu_7325_p3 = (!or_ln340_2207_fu_7303_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2207_fu_7303_p2.read()[0].to_bool())? select_ln340_29_fu_7309_p3.read(): select_ln388_29_fu_7317_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_2155_fu_32362_p3() {
    select_ln340_2155_fu_32362_p3 = (!or_ln340_2208_fu_32340_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2208_fu_32340_p2.read()[0].to_bool())? select_ln340_1100_fu_32346_p3.read(): acc_1_V_86_fu_32354_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_2156_fu_7505_p3() {
    select_ln340_2156_fu_7505_p3 = (!or_ln340_2210_fu_7483_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2210_fu_7483_p2.read()[0].to_bool())? select_ln340_30_fu_7489_p3.read(): select_ln388_30_fu_7497_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_2157_fu_32450_p3() {
    select_ln340_2157_fu_32450_p3 = (!or_ln340_2211_fu_32428_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2211_fu_32428_p2.read()[0].to_bool())? select_ln340_1101_fu_32434_p3.read(): acc_1_V_88_fu_32442_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_2158_fu_7685_p3() {
    select_ln340_2158_fu_7685_p3 = (!or_ln340_2213_fu_7663_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2213_fu_7663_p2.read()[0].to_bool())? select_ln340_31_fu_7669_p3.read(): select_ln388_31_fu_7677_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_2159_fu_32538_p3() {
    select_ln340_2159_fu_32538_p3 = (!or_ln340_2214_fu_32516_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2214_fu_32516_p2.read()[0].to_bool())? select_ln340_1102_fu_32522_p3.read(): acc_1_V_90_fu_32530_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_2160_fu_7865_p3() {
    select_ln340_2160_fu_7865_p3 = (!or_ln340_2216_fu_7843_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2216_fu_7843_p2.read()[0].to_bool())? select_ln340_32_fu_7849_p3.read(): select_ln388_32_fu_7857_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_2161_fu_32626_p3() {
    select_ln340_2161_fu_32626_p3 = (!or_ln340_2217_fu_32604_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2217_fu_32604_p2.read()[0].to_bool())? select_ln340_1103_fu_32610_p3.read(): acc_1_V_92_fu_32618_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_2162_fu_8045_p3() {
    select_ln340_2162_fu_8045_p3 = (!or_ln340_2219_fu_8023_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2219_fu_8023_p2.read()[0].to_bool())? select_ln340_33_fu_8029_p3.read(): select_ln388_33_fu_8037_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_2163_fu_32714_p3() {
    select_ln340_2163_fu_32714_p3 = (!or_ln340_2220_fu_32692_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2220_fu_32692_p2.read()[0].to_bool())? select_ln340_1104_fu_32698_p3.read(): acc_1_V_94_fu_32706_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_2164_fu_8225_p3() {
    select_ln340_2164_fu_8225_p3 = (!or_ln340_2222_fu_8203_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2222_fu_8203_p2.read()[0].to_bool())? select_ln340_34_fu_8209_p3.read(): select_ln388_34_fu_8217_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_2165_fu_32802_p3() {
    select_ln340_2165_fu_32802_p3 = (!or_ln340_2223_fu_32780_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2223_fu_32780_p2.read()[0].to_bool())? select_ln340_1105_fu_32786_p3.read(): acc_1_V_96_fu_32794_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_2166_fu_8405_p3() {
    select_ln340_2166_fu_8405_p3 = (!or_ln340_2225_fu_8383_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2225_fu_8383_p2.read()[0].to_bool())? select_ln340_35_fu_8389_p3.read(): select_ln388_35_fu_8397_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_2167_fu_32890_p3() {
    select_ln340_2167_fu_32890_p3 = (!or_ln340_2226_fu_32868_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2226_fu_32868_p2.read()[0].to_bool())? select_ln340_1106_fu_32874_p3.read(): acc_1_V_98_fu_32882_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_2168_fu_8585_p3() {
    select_ln340_2168_fu_8585_p3 = (!or_ln340_2228_fu_8563_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2228_fu_8563_p2.read()[0].to_bool())? select_ln340_36_fu_8569_p3.read(): select_ln388_36_fu_8577_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_2169_fu_32978_p3() {
    select_ln340_2169_fu_32978_p3 = (!or_ln340_2229_fu_32956_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2229_fu_32956_p2.read()[0].to_bool())? select_ln340_1107_fu_32962_p3.read(): acc_1_V_100_fu_32970_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_2170_fu_8765_p3() {
    select_ln340_2170_fu_8765_p3 = (!or_ln340_2231_fu_8743_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2231_fu_8743_p2.read()[0].to_bool())? select_ln340_37_fu_8749_p3.read(): select_ln388_37_fu_8757_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_2171_fu_33066_p3() {
    select_ln340_2171_fu_33066_p3 = (!or_ln340_2232_fu_33044_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2232_fu_33044_p2.read()[0].to_bool())? select_ln340_1108_fu_33050_p3.read(): acc_1_V_102_fu_33058_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_2172_fu_8945_p3() {
    select_ln340_2172_fu_8945_p3 = (!or_ln340_2234_fu_8923_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2234_fu_8923_p2.read()[0].to_bool())? select_ln340_38_fu_8929_p3.read(): select_ln388_38_fu_8937_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_2173_fu_33154_p3() {
    select_ln340_2173_fu_33154_p3 = (!or_ln340_2235_fu_33132_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2235_fu_33132_p2.read()[0].to_bool())? select_ln340_1109_fu_33138_p3.read(): acc_1_V_104_fu_33146_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_2174_fu_33323_p3() {
    select_ln340_2174_fu_33323_p3 = (!or_ln340_2237_fu_33301_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2237_fu_33301_p2.read()[0].to_bool())? select_ln340_39_fu_33307_p3.read(): select_ln388_39_fu_33315_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_2176_fu_9135_p3() {
    select_ln340_2176_fu_9135_p3 = (!or_ln340_2240_fu_9113_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2240_fu_9113_p2.read()[0].to_bool())? select_ln340_40_fu_9119_p3.read(): select_ln388_40_fu_9127_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_2177_fu_33501_p3() {
    select_ln340_2177_fu_33501_p3 = (!or_ln340_2241_fu_33479_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2241_fu_33479_p2.read()[0].to_bool())? select_ln340_1111_fu_33485_p3.read(): acc_2_V_68_fu_33493_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_2178_fu_9315_p3() {
    select_ln340_2178_fu_9315_p3 = (!or_ln340_2243_fu_9293_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2243_fu_9293_p2.read()[0].to_bool())? select_ln340_41_fu_9299_p3.read(): select_ln388_41_fu_9307_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_2179_fu_33589_p3() {
    select_ln340_2179_fu_33589_p3 = (!or_ln340_2244_fu_33567_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2244_fu_33567_p2.read()[0].to_bool())? select_ln340_1112_fu_33573_p3.read(): acc_2_V_70_fu_33581_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_2180_fu_9495_p3() {
    select_ln340_2180_fu_9495_p3 = (!or_ln340_2246_fu_9473_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2246_fu_9473_p2.read()[0].to_bool())? select_ln340_42_fu_9479_p3.read(): select_ln388_42_fu_9487_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_2181_fu_33677_p3() {
    select_ln340_2181_fu_33677_p3 = (!or_ln340_2247_fu_33655_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2247_fu_33655_p2.read()[0].to_bool())? select_ln340_1113_fu_33661_p3.read(): acc_2_V_72_fu_33669_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_2182_fu_9675_p3() {
    select_ln340_2182_fu_9675_p3 = (!or_ln340_2249_fu_9653_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2249_fu_9653_p2.read()[0].to_bool())? select_ln340_43_fu_9659_p3.read(): select_ln388_43_fu_9667_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_2183_fu_33765_p3() {
    select_ln340_2183_fu_33765_p3 = (!or_ln340_2250_fu_33743_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2250_fu_33743_p2.read()[0].to_bool())? select_ln340_1114_fu_33749_p3.read(): acc_2_V_74_fu_33757_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_2184_fu_9855_p3() {
    select_ln340_2184_fu_9855_p3 = (!or_ln340_2252_fu_9833_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2252_fu_9833_p2.read()[0].to_bool())? select_ln340_44_fu_9839_p3.read(): select_ln388_44_fu_9847_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_2185_fu_33853_p3() {
    select_ln340_2185_fu_33853_p3 = (!or_ln340_2253_fu_33831_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2253_fu_33831_p2.read()[0].to_bool())? select_ln340_1115_fu_33837_p3.read(): acc_2_V_76_fu_33845_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_2186_fu_10035_p3() {
    select_ln340_2186_fu_10035_p3 = (!or_ln340_2255_fu_10013_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2255_fu_10013_p2.read()[0].to_bool())? select_ln340_45_fu_10019_p3.read(): select_ln388_45_fu_10027_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_2187_fu_33941_p3() {
    select_ln340_2187_fu_33941_p3 = (!or_ln340_2256_fu_33919_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2256_fu_33919_p2.read()[0].to_bool())? select_ln340_1116_fu_33925_p3.read(): acc_2_V_78_fu_33933_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_2188_fu_10215_p3() {
    select_ln340_2188_fu_10215_p3 = (!or_ln340_2258_fu_10193_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2258_fu_10193_p2.read()[0].to_bool())? select_ln340_46_fu_10199_p3.read(): select_ln388_46_fu_10207_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_2189_fu_34029_p3() {
    select_ln340_2189_fu_34029_p3 = (!or_ln340_2259_fu_34007_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2259_fu_34007_p2.read()[0].to_bool())? select_ln340_1117_fu_34013_p3.read(): acc_2_V_80_fu_34021_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_2190_fu_10395_p3() {
    select_ln340_2190_fu_10395_p3 = (!or_ln340_2261_fu_10373_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2261_fu_10373_p2.read()[0].to_bool())? select_ln340_47_fu_10379_p3.read(): select_ln388_47_fu_10387_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_2191_fu_34117_p3() {
    select_ln340_2191_fu_34117_p3 = (!or_ln340_2262_fu_34095_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2262_fu_34095_p2.read()[0].to_bool())? select_ln340_1118_fu_34101_p3.read(): acc_2_V_82_fu_34109_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_2192_fu_10575_p3() {
    select_ln340_2192_fu_10575_p3 = (!or_ln340_2264_fu_10553_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2264_fu_10553_p2.read()[0].to_bool())? select_ln340_48_fu_10559_p3.read(): select_ln388_48_fu_10567_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_2193_fu_34205_p3() {
    select_ln340_2193_fu_34205_p3 = (!or_ln340_2265_fu_34183_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2265_fu_34183_p2.read()[0].to_bool())? select_ln340_1119_fu_34189_p3.read(): acc_2_V_84_fu_34197_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_2194_fu_10755_p3() {
    select_ln340_2194_fu_10755_p3 = (!or_ln340_2267_fu_10733_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2267_fu_10733_p2.read()[0].to_bool())? select_ln340_49_fu_10739_p3.read(): select_ln388_49_fu_10747_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_2195_fu_34293_p3() {
    select_ln340_2195_fu_34293_p3 = (!or_ln340_2268_fu_34271_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2268_fu_34271_p2.read()[0].to_bool())? select_ln340_1120_fu_34277_p3.read(): acc_2_V_86_fu_34285_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_2196_fu_10935_p3() {
    select_ln340_2196_fu_10935_p3 = (!or_ln340_2270_fu_10913_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2270_fu_10913_p2.read()[0].to_bool())? select_ln340_50_fu_10919_p3.read(): select_ln388_50_fu_10927_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_2197_fu_34381_p3() {
    select_ln340_2197_fu_34381_p3 = (!or_ln340_2271_fu_34359_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2271_fu_34359_p2.read()[0].to_bool())? select_ln340_1121_fu_34365_p3.read(): acc_2_V_88_fu_34373_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_2198_fu_11115_p3() {
    select_ln340_2198_fu_11115_p3 = (!or_ln340_2273_fu_11093_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2273_fu_11093_p2.read()[0].to_bool())? select_ln340_51_fu_11099_p3.read(): select_ln388_51_fu_11107_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_2199_fu_34469_p3() {
    select_ln340_2199_fu_34469_p3 = (!or_ln340_2274_fu_34447_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2274_fu_34447_p2.read()[0].to_bool())? select_ln340_1122_fu_34453_p3.read(): acc_2_V_90_fu_34461_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_21_fu_5869_p3() {
    select_ln340_21_fu_5869_p3 = (!or_ln340_21_fu_5851_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_21_fu_5851_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: add_ln415_547_fu_5761_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_2200_fu_11295_p3() {
    select_ln340_2200_fu_11295_p3 = (!or_ln340_2276_fu_11273_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2276_fu_11273_p2.read()[0].to_bool())? select_ln340_52_fu_11279_p3.read(): select_ln388_52_fu_11287_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_2201_fu_34557_p3() {
    select_ln340_2201_fu_34557_p3 = (!or_ln340_2277_fu_34535_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2277_fu_34535_p2.read()[0].to_bool())? select_ln340_1123_fu_34541_p3.read(): acc_2_V_92_fu_34549_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_2202_fu_11475_p3() {
    select_ln340_2202_fu_11475_p3 = (!or_ln340_2279_fu_11453_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2279_fu_11453_p2.read()[0].to_bool())? select_ln340_53_fu_11459_p3.read(): select_ln388_53_fu_11467_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_2203_fu_34645_p3() {
    select_ln340_2203_fu_34645_p3 = (!or_ln340_2280_fu_34623_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2280_fu_34623_p2.read()[0].to_bool())? select_ln340_1124_fu_34629_p3.read(): acc_2_V_94_fu_34637_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_2204_fu_11655_p3() {
    select_ln340_2204_fu_11655_p3 = (!or_ln340_2282_fu_11633_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2282_fu_11633_p2.read()[0].to_bool())? select_ln340_54_fu_11639_p3.read(): select_ln388_54_fu_11647_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_2205_fu_34733_p3() {
    select_ln340_2205_fu_34733_p3 = (!or_ln340_2283_fu_34711_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2283_fu_34711_p2.read()[0].to_bool())? select_ln340_1125_fu_34717_p3.read(): acc_2_V_96_fu_34725_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_2206_fu_11835_p3() {
    select_ln340_2206_fu_11835_p3 = (!or_ln340_2285_fu_11813_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2285_fu_11813_p2.read()[0].to_bool())? select_ln340_55_fu_11819_p3.read(): select_ln388_55_fu_11827_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_2207_fu_34821_p3() {
    select_ln340_2207_fu_34821_p3 = (!or_ln340_2286_fu_34799_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2286_fu_34799_p2.read()[0].to_bool())? select_ln340_1126_fu_34805_p3.read(): acc_2_V_98_fu_34813_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_2208_fu_12015_p3() {
    select_ln340_2208_fu_12015_p3 = (!or_ln340_2288_fu_11993_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2288_fu_11993_p2.read()[0].to_bool())? select_ln340_56_fu_11999_p3.read(): select_ln388_56_fu_12007_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_2209_fu_34909_p3() {
    select_ln340_2209_fu_34909_p3 = (!or_ln340_2289_fu_34887_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2289_fu_34887_p2.read()[0].to_bool())? select_ln340_1127_fu_34893_p3.read(): acc_2_V_100_fu_34901_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_2210_fu_12195_p3() {
    select_ln340_2210_fu_12195_p3 = (!or_ln340_2291_fu_12173_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2291_fu_12173_p2.read()[0].to_bool())? select_ln340_57_fu_12179_p3.read(): select_ln388_57_fu_12187_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_2211_fu_34997_p3() {
    select_ln340_2211_fu_34997_p3 = (!or_ln340_2292_fu_34975_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2292_fu_34975_p2.read()[0].to_bool())? select_ln340_1128_fu_34981_p3.read(): acc_2_V_102_fu_34989_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_2212_fu_12375_p3() {
    select_ln340_2212_fu_12375_p3 = (!or_ln340_2294_fu_12353_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2294_fu_12353_p2.read()[0].to_bool())? select_ln340_58_fu_12359_p3.read(): select_ln388_58_fu_12367_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_2213_fu_35085_p3() {
    select_ln340_2213_fu_35085_p3 = (!or_ln340_2295_fu_35063_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2295_fu_35063_p2.read()[0].to_bool())? select_ln340_1129_fu_35069_p3.read(): acc_2_V_104_fu_35077_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_2214_fu_35254_p3() {
    select_ln340_2214_fu_35254_p3 = (!or_ln340_2297_fu_35232_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2297_fu_35232_p2.read()[0].to_bool())? select_ln340_59_fu_35238_p3.read(): select_ln388_59_fu_35246_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_2216_fu_12565_p3() {
    select_ln340_2216_fu_12565_p3 = (!or_ln340_2300_fu_12543_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2300_fu_12543_p2.read()[0].to_bool())? select_ln340_60_fu_12549_p3.read(): select_ln388_60_fu_12557_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_select_ln340_2217_fu_35432_p3() {
    select_ln340_2217_fu_35432_p3 = (!or_ln340_2301_fu_35410_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2301_fu_35410_p2.read()[0].to_bool())? select_ln340_1131_fu_35416_p3.read(): acc_3_V_68_fu_35424_p3.read());
}

}

