#include "conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s.h"
#include "AESL_pkg.h"

using namespace std;

namespace ap_rtl {

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln779_14_fu_4215_p2() {
    xor_ln779_14_fu_4215_p2 = (tmp_5437_fu_4147_p3.read() ^ ap_const_lv1_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln779_15_fu_4407_p2() {
    xor_ln779_15_fu_4407_p2 = (tmp_5444_fu_4339_p3.read() ^ ap_const_lv1_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln779_16_fu_4599_p2() {
    xor_ln779_16_fu_4599_p2 = (tmp_5451_fu_4531_p3.read() ^ ap_const_lv1_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln779_17_fu_4791_p2() {
    xor_ln779_17_fu_4791_p2 = (tmp_5458_fu_4723_p3.read() ^ ap_const_lv1_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln779_18_fu_4983_p2() {
    xor_ln779_18_fu_4983_p2 = (tmp_5465_fu_4915_p3.read() ^ ap_const_lv1_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln779_19_fu_17140_p2() {
    xor_ln779_19_fu_17140_p2 = (tmp_5472_fu_17072_p3.read() ^ ap_const_lv1_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln779_1_fu_1703_p2() {
    xor_ln779_1_fu_1703_p2 = (tmp_5346_fu_1635_p3.read() ^ ap_const_lv1_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln779_20_fu_5173_p2() {
    xor_ln779_20_fu_5173_p2 = (tmp_5479_fu_5105_p3.read() ^ ap_const_lv1_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln779_21_fu_5353_p2() {
    xor_ln779_21_fu_5353_p2 = (tmp_5486_fu_5285_p3.read() ^ ap_const_lv1_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln779_22_fu_5533_p2() {
    xor_ln779_22_fu_5533_p2 = (tmp_5493_fu_5465_p3.read() ^ ap_const_lv1_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln779_23_fu_5713_p2() {
    xor_ln779_23_fu_5713_p2 = (tmp_5500_fu_5645_p3.read() ^ ap_const_lv1_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln779_24_fu_5893_p2() {
    xor_ln779_24_fu_5893_p2 = (tmp_5507_fu_5825_p3.read() ^ ap_const_lv1_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln779_25_fu_6073_p2() {
    xor_ln779_25_fu_6073_p2 = (tmp_5514_fu_6005_p3.read() ^ ap_const_lv1_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln779_26_fu_6253_p2() {
    xor_ln779_26_fu_6253_p2 = (tmp_5521_fu_6185_p3.read() ^ ap_const_lv1_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln779_27_fu_6433_p2() {
    xor_ln779_27_fu_6433_p2 = (tmp_5528_fu_6365_p3.read() ^ ap_const_lv1_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln779_28_fu_6613_p2() {
    xor_ln779_28_fu_6613_p2 = (tmp_5535_fu_6545_p3.read() ^ ap_const_lv1_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln779_29_fu_6793_p2() {
    xor_ln779_29_fu_6793_p2 = (tmp_5542_fu_6725_p3.read() ^ ap_const_lv1_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln779_2_fu_1903_p2() {
    xor_ln779_2_fu_1903_p2 = (tmp_5353_fu_1835_p3.read() ^ ap_const_lv1_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln779_30_fu_6973_p2() {
    xor_ln779_30_fu_6973_p2 = (tmp_5549_fu_6905_p3.read() ^ ap_const_lv1_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln779_31_fu_7153_p2() {
    xor_ln779_31_fu_7153_p2 = (tmp_5556_fu_7085_p3.read() ^ ap_const_lv1_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln779_32_fu_7333_p2() {
    xor_ln779_32_fu_7333_p2 = (tmp_5563_fu_7265_p3.read() ^ ap_const_lv1_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln779_33_fu_7513_p2() {
    xor_ln779_33_fu_7513_p2 = (tmp_5570_fu_7445_p3.read() ^ ap_const_lv1_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln779_34_fu_7693_p2() {
    xor_ln779_34_fu_7693_p2 = (tmp_5577_fu_7625_p3.read() ^ ap_const_lv1_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln779_35_fu_7873_p2() {
    xor_ln779_35_fu_7873_p2 = (tmp_5584_fu_7805_p3.read() ^ ap_const_lv1_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln779_36_fu_8053_p2() {
    xor_ln779_36_fu_8053_p2 = (tmp_5591_fu_7985_p3.read() ^ ap_const_lv1_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln779_37_fu_8233_p2() {
    xor_ln779_37_fu_8233_p2 = (tmp_5598_fu_8165_p3.read() ^ ap_const_lv1_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln779_38_fu_8413_p2() {
    xor_ln779_38_fu_8413_p2 = (tmp_5605_fu_8345_p3.read() ^ ap_const_lv1_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln779_39_fu_19071_p2() {
    xor_ln779_39_fu_19071_p2 = (tmp_5612_fu_19003_p3.read() ^ ap_const_lv1_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln779_3_fu_2103_p2() {
    xor_ln779_3_fu_2103_p2 = (tmp_5360_fu_2035_p3.read() ^ ap_const_lv1_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln779_40_fu_8603_p2() {
    xor_ln779_40_fu_8603_p2 = (tmp_5619_fu_8535_p3.read() ^ ap_const_lv1_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln779_41_fu_8783_p2() {
    xor_ln779_41_fu_8783_p2 = (tmp_5626_fu_8715_p3.read() ^ ap_const_lv1_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln779_42_fu_8963_p2() {
    xor_ln779_42_fu_8963_p2 = (tmp_5633_fu_8895_p3.read() ^ ap_const_lv1_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln779_43_fu_9143_p2() {
    xor_ln779_43_fu_9143_p2 = (tmp_5640_fu_9075_p3.read() ^ ap_const_lv1_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln779_44_fu_9323_p2() {
    xor_ln779_44_fu_9323_p2 = (tmp_5647_fu_9255_p3.read() ^ ap_const_lv1_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln779_45_fu_9503_p2() {
    xor_ln779_45_fu_9503_p2 = (tmp_5654_fu_9435_p3.read() ^ ap_const_lv1_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln779_46_fu_9683_p2() {
    xor_ln779_46_fu_9683_p2 = (tmp_5661_fu_9615_p3.read() ^ ap_const_lv1_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln779_47_fu_9863_p2() {
    xor_ln779_47_fu_9863_p2 = (tmp_5668_fu_9795_p3.read() ^ ap_const_lv1_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln779_48_fu_10043_p2() {
    xor_ln779_48_fu_10043_p2 = (tmp_5675_fu_9975_p3.read() ^ ap_const_lv1_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln779_49_fu_10223_p2() {
    xor_ln779_49_fu_10223_p2 = (tmp_5682_fu_10155_p3.read() ^ ap_const_lv1_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln779_4_fu_2295_p2() {
    xor_ln779_4_fu_2295_p2 = (tmp_5367_fu_2227_p3.read() ^ ap_const_lv1_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln779_50_fu_10403_p2() {
    xor_ln779_50_fu_10403_p2 = (tmp_5689_fu_10335_p3.read() ^ ap_const_lv1_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln779_51_fu_10583_p2() {
    xor_ln779_51_fu_10583_p2 = (tmp_5696_fu_10515_p3.read() ^ ap_const_lv1_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln779_52_fu_10763_p2() {
    xor_ln779_52_fu_10763_p2 = (tmp_5703_fu_10695_p3.read() ^ ap_const_lv1_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln779_53_fu_10943_p2() {
    xor_ln779_53_fu_10943_p2 = (tmp_5710_fu_10875_p3.read() ^ ap_const_lv1_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln779_54_fu_11123_p2() {
    xor_ln779_54_fu_11123_p2 = (tmp_5717_fu_11055_p3.read() ^ ap_const_lv1_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln779_55_fu_11303_p2() {
    xor_ln779_55_fu_11303_p2 = (tmp_5724_fu_11235_p3.read() ^ ap_const_lv1_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln779_56_fu_11483_p2() {
    xor_ln779_56_fu_11483_p2 = (tmp_5731_fu_11415_p3.read() ^ ap_const_lv1_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln779_57_fu_11663_p2() {
    xor_ln779_57_fu_11663_p2 = (tmp_5738_fu_11595_p3.read() ^ ap_const_lv1_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln779_58_fu_11843_p2() {
    xor_ln779_58_fu_11843_p2 = (tmp_5745_fu_11775_p3.read() ^ ap_const_lv1_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln779_59_fu_21002_p2() {
    xor_ln779_59_fu_21002_p2 = (tmp_5752_fu_20934_p3.read() ^ ap_const_lv1_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln779_5_fu_2487_p2() {
    xor_ln779_5_fu_2487_p2 = (tmp_5374_fu_2419_p3.read() ^ ap_const_lv1_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln779_60_fu_12033_p2() {
    xor_ln779_60_fu_12033_p2 = (tmp_5759_fu_11965_p3.read() ^ ap_const_lv1_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln779_61_fu_12213_p2() {
    xor_ln779_61_fu_12213_p2 = (tmp_5766_fu_12145_p3.read() ^ ap_const_lv1_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln779_62_fu_12393_p2() {
    xor_ln779_62_fu_12393_p2 = (tmp_5773_fu_12325_p3.read() ^ ap_const_lv1_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln779_63_fu_12573_p2() {
    xor_ln779_63_fu_12573_p2 = (tmp_5780_fu_12505_p3.read() ^ ap_const_lv1_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln779_64_fu_12753_p2() {
    xor_ln779_64_fu_12753_p2 = (tmp_5787_fu_12685_p3.read() ^ ap_const_lv1_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln779_65_fu_12933_p2() {
    xor_ln779_65_fu_12933_p2 = (tmp_5794_fu_12865_p3.read() ^ ap_const_lv1_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln779_66_fu_13113_p2() {
    xor_ln779_66_fu_13113_p2 = (tmp_5801_fu_13045_p3.read() ^ ap_const_lv1_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln779_67_fu_13293_p2() {
    xor_ln779_67_fu_13293_p2 = (tmp_5808_fu_13225_p3.read() ^ ap_const_lv1_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln779_68_fu_13473_p2() {
    xor_ln779_68_fu_13473_p2 = (tmp_5815_fu_13405_p3.read() ^ ap_const_lv1_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln779_69_fu_13653_p2() {
    xor_ln779_69_fu_13653_p2 = (tmp_5822_fu_13585_p3.read() ^ ap_const_lv1_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln779_6_fu_2679_p2() {
    xor_ln779_6_fu_2679_p2 = (tmp_5381_fu_2611_p3.read() ^ ap_const_lv1_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln779_70_fu_13833_p2() {
    xor_ln779_70_fu_13833_p2 = (tmp_5829_fu_13765_p3.read() ^ ap_const_lv1_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln779_71_fu_14013_p2() {
    xor_ln779_71_fu_14013_p2 = (tmp_5836_fu_13945_p3.read() ^ ap_const_lv1_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln779_72_fu_14193_p2() {
    xor_ln779_72_fu_14193_p2 = (tmp_5843_fu_14125_p3.read() ^ ap_const_lv1_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln779_73_fu_14373_p2() {
    xor_ln779_73_fu_14373_p2 = (tmp_5850_fu_14305_p3.read() ^ ap_const_lv1_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln779_74_fu_14553_p2() {
    xor_ln779_74_fu_14553_p2 = (tmp_5857_fu_14485_p3.read() ^ ap_const_lv1_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln779_75_fu_14733_p2() {
    xor_ln779_75_fu_14733_p2 = (tmp_5864_fu_14665_p3.read() ^ ap_const_lv1_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln779_76_fu_14913_p2() {
    xor_ln779_76_fu_14913_p2 = (tmp_5871_fu_14845_p3.read() ^ ap_const_lv1_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln779_77_fu_15093_p2() {
    xor_ln779_77_fu_15093_p2 = (tmp_5878_fu_15025_p3.read() ^ ap_const_lv1_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln779_78_fu_15273_p2() {
    xor_ln779_78_fu_15273_p2 = (tmp_5885_fu_15205_p3.read() ^ ap_const_lv1_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln779_79_fu_22933_p2() {
    xor_ln779_79_fu_22933_p2 = (tmp_5892_fu_22865_p3.read() ^ ap_const_lv1_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln779_7_fu_2871_p2() {
    xor_ln779_7_fu_2871_p2 = (tmp_5388_fu_2803_p3.read() ^ ap_const_lv1_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln779_8_fu_3063_p2() {
    xor_ln779_8_fu_3063_p2 = (tmp_5395_fu_2995_p3.read() ^ ap_const_lv1_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln779_9_fu_3255_p2() {
    xor_ln779_9_fu_3255_p2 = (tmp_5402_fu_3187_p3.read() ^ ap_const_lv1_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln779_fu_1503_p2() {
    xor_ln779_fu_1503_p2 = (tmp_5339_fu_1435_p3.read() ^ ap_const_lv1_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln785_10_fu_3461_p2() {
    xor_ln785_10_fu_3461_p2 = (tmp_5409_fu_3379_p3.read() ^ and_ln416_680_fu_3433_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln785_11_fu_3653_p2() {
    xor_ln785_11_fu_3653_p2 = (tmp_5416_fu_3571_p3.read() ^ and_ln416_681_fu_3625_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln785_12_fu_3845_p2() {
    xor_ln785_12_fu_3845_p2 = (tmp_5423_fu_3763_p3.read() ^ and_ln416_682_fu_3817_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln785_13_fu_4037_p2() {
    xor_ln785_13_fu_4037_p2 = (tmp_5430_fu_3955_p3.read() ^ and_ln416_683_fu_4009_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln785_14_fu_4229_p2() {
    xor_ln785_14_fu_4229_p2 = (tmp_5437_fu_4147_p3.read() ^ and_ln416_684_fu_4201_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln785_15_fu_4421_p2() {
    xor_ln785_15_fu_4421_p2 = (tmp_5444_fu_4339_p3.read() ^ and_ln416_685_fu_4393_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln785_16_fu_4613_p2() {
    xor_ln785_16_fu_4613_p2 = (tmp_5451_fu_4531_p3.read() ^ and_ln416_686_fu_4585_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln785_17_fu_4805_p2() {
    xor_ln785_17_fu_4805_p2 = (tmp_5458_fu_4723_p3.read() ^ and_ln416_687_fu_4777_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln785_18_fu_4997_p2() {
    xor_ln785_18_fu_4997_p2 = (tmp_5465_fu_4915_p3.read() ^ and_ln416_688_fu_4969_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln785_19_fu_17154_p2() {
    xor_ln785_19_fu_17154_p2 = (tmp_5472_fu_17072_p3.read() ^ and_ln416_689_fu_17126_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln785_1_fu_1717_p2() {
    xor_ln785_1_fu_1717_p2 = (tmp_5346_fu_1635_p3.read() ^ and_ln416_671_fu_1689_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln785_20_fu_5187_p2() {
    xor_ln785_20_fu_5187_p2 = (tmp_5479_fu_5105_p3.read() ^ and_ln416_690_fu_5159_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln785_21_fu_5367_p2() {
    xor_ln785_21_fu_5367_p2 = (tmp_5486_fu_5285_p3.read() ^ and_ln416_691_fu_5339_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln785_22_fu_5547_p2() {
    xor_ln785_22_fu_5547_p2 = (tmp_5493_fu_5465_p3.read() ^ and_ln416_692_fu_5519_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln785_23_fu_5727_p2() {
    xor_ln785_23_fu_5727_p2 = (tmp_5500_fu_5645_p3.read() ^ and_ln416_693_fu_5699_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln785_24_fu_5907_p2() {
    xor_ln785_24_fu_5907_p2 = (tmp_5507_fu_5825_p3.read() ^ and_ln416_694_fu_5879_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln785_25_fu_6087_p2() {
    xor_ln785_25_fu_6087_p2 = (tmp_5514_fu_6005_p3.read() ^ and_ln416_695_fu_6059_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln785_26_fu_6267_p2() {
    xor_ln785_26_fu_6267_p2 = (tmp_5521_fu_6185_p3.read() ^ and_ln416_696_fu_6239_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln785_27_fu_6447_p2() {
    xor_ln785_27_fu_6447_p2 = (tmp_5528_fu_6365_p3.read() ^ and_ln416_697_fu_6419_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln785_28_fu_6627_p2() {
    xor_ln785_28_fu_6627_p2 = (tmp_5535_fu_6545_p3.read() ^ and_ln416_698_fu_6599_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln785_29_fu_6807_p2() {
    xor_ln785_29_fu_6807_p2 = (tmp_5542_fu_6725_p3.read() ^ and_ln416_699_fu_6779_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln785_2_fu_1917_p2() {
    xor_ln785_2_fu_1917_p2 = (tmp_5353_fu_1835_p3.read() ^ and_ln416_672_fu_1889_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln785_30_fu_6987_p2() {
    xor_ln785_30_fu_6987_p2 = (tmp_5549_fu_6905_p3.read() ^ and_ln416_700_fu_6959_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln785_31_fu_7167_p2() {
    xor_ln785_31_fu_7167_p2 = (tmp_5556_fu_7085_p3.read() ^ and_ln416_701_fu_7139_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln785_32_fu_7347_p2() {
    xor_ln785_32_fu_7347_p2 = (tmp_5563_fu_7265_p3.read() ^ and_ln416_702_fu_7319_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln785_33_fu_7527_p2() {
    xor_ln785_33_fu_7527_p2 = (tmp_5570_fu_7445_p3.read() ^ and_ln416_703_fu_7499_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln785_34_fu_7707_p2() {
    xor_ln785_34_fu_7707_p2 = (tmp_5577_fu_7625_p3.read() ^ and_ln416_704_fu_7679_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln785_35_fu_7887_p2() {
    xor_ln785_35_fu_7887_p2 = (tmp_5584_fu_7805_p3.read() ^ and_ln416_705_fu_7859_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln785_36_fu_8067_p2() {
    xor_ln785_36_fu_8067_p2 = (tmp_5591_fu_7985_p3.read() ^ and_ln416_706_fu_8039_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln785_37_fu_8247_p2() {
    xor_ln785_37_fu_8247_p2 = (tmp_5598_fu_8165_p3.read() ^ and_ln416_707_fu_8219_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln785_38_fu_8427_p2() {
    xor_ln785_38_fu_8427_p2 = (tmp_5605_fu_8345_p3.read() ^ and_ln416_708_fu_8399_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln785_39_fu_19085_p2() {
    xor_ln785_39_fu_19085_p2 = (tmp_5612_fu_19003_p3.read() ^ and_ln416_709_fu_19057_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln785_3_fu_2117_p2() {
    xor_ln785_3_fu_2117_p2 = (tmp_5360_fu_2035_p3.read() ^ and_ln416_673_fu_2089_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln785_40_fu_8617_p2() {
    xor_ln785_40_fu_8617_p2 = (tmp_5619_fu_8535_p3.read() ^ and_ln416_710_fu_8589_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln785_41_fu_8797_p2() {
    xor_ln785_41_fu_8797_p2 = (tmp_5626_fu_8715_p3.read() ^ and_ln416_711_fu_8769_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln785_42_fu_8977_p2() {
    xor_ln785_42_fu_8977_p2 = (tmp_5633_fu_8895_p3.read() ^ and_ln416_712_fu_8949_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln785_43_fu_9157_p2() {
    xor_ln785_43_fu_9157_p2 = (tmp_5640_fu_9075_p3.read() ^ and_ln416_713_fu_9129_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln785_44_fu_9337_p2() {
    xor_ln785_44_fu_9337_p2 = (tmp_5647_fu_9255_p3.read() ^ and_ln416_714_fu_9309_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln785_45_fu_9517_p2() {
    xor_ln785_45_fu_9517_p2 = (tmp_5654_fu_9435_p3.read() ^ and_ln416_715_fu_9489_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln785_46_fu_9697_p2() {
    xor_ln785_46_fu_9697_p2 = (tmp_5661_fu_9615_p3.read() ^ and_ln416_716_fu_9669_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln785_47_fu_9877_p2() {
    xor_ln785_47_fu_9877_p2 = (tmp_5668_fu_9795_p3.read() ^ and_ln416_717_fu_9849_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln785_48_fu_10057_p2() {
    xor_ln785_48_fu_10057_p2 = (tmp_5675_fu_9975_p3.read() ^ and_ln416_718_fu_10029_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln785_49_fu_10237_p2() {
    xor_ln785_49_fu_10237_p2 = (tmp_5682_fu_10155_p3.read() ^ and_ln416_719_fu_10209_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln785_4_fu_2309_p2() {
    xor_ln785_4_fu_2309_p2 = (tmp_5367_fu_2227_p3.read() ^ and_ln416_674_fu_2281_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln785_50_fu_10417_p2() {
    xor_ln785_50_fu_10417_p2 = (tmp_5689_fu_10335_p3.read() ^ and_ln416_720_fu_10389_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln785_51_fu_10597_p2() {
    xor_ln785_51_fu_10597_p2 = (tmp_5696_fu_10515_p3.read() ^ and_ln416_721_fu_10569_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln785_52_fu_10777_p2() {
    xor_ln785_52_fu_10777_p2 = (tmp_5703_fu_10695_p3.read() ^ and_ln416_722_fu_10749_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln785_535_fu_2693_p2() {
    xor_ln785_535_fu_2693_p2 = (tmp_5381_fu_2611_p3.read() ^ and_ln416_676_fu_2665_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln785_536_fu_2885_p2() {
    xor_ln785_536_fu_2885_p2 = (tmp_5388_fu_2803_p3.read() ^ and_ln416_677_fu_2857_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln785_53_fu_10957_p2() {
    xor_ln785_53_fu_10957_p2 = (tmp_5710_fu_10875_p3.read() ^ and_ln416_723_fu_10929_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln785_54_fu_11137_p2() {
    xor_ln785_54_fu_11137_p2 = (tmp_5717_fu_11055_p3.read() ^ and_ln416_724_fu_11109_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln785_55_fu_11317_p2() {
    xor_ln785_55_fu_11317_p2 = (tmp_5724_fu_11235_p3.read() ^ and_ln416_725_fu_11289_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln785_56_fu_11497_p2() {
    xor_ln785_56_fu_11497_p2 = (tmp_5731_fu_11415_p3.read() ^ and_ln416_726_fu_11469_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln785_57_fu_11677_p2() {
    xor_ln785_57_fu_11677_p2 = (tmp_5738_fu_11595_p3.read() ^ and_ln416_727_fu_11649_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln785_58_fu_11857_p2() {
    xor_ln785_58_fu_11857_p2 = (tmp_5745_fu_11775_p3.read() ^ and_ln416_728_fu_11829_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln785_59_fu_21016_p2() {
    xor_ln785_59_fu_21016_p2 = (tmp_5752_fu_20934_p3.read() ^ and_ln416_729_fu_20988_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln785_5_fu_2501_p2() {
    xor_ln785_5_fu_2501_p2 = (tmp_5374_fu_2419_p3.read() ^ and_ln416_675_fu_2473_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln785_60_fu_12047_p2() {
    xor_ln785_60_fu_12047_p2 = (tmp_5759_fu_11965_p3.read() ^ and_ln416_730_fu_12019_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln785_61_fu_12227_p2() {
    xor_ln785_61_fu_12227_p2 = (tmp_5766_fu_12145_p3.read() ^ and_ln416_731_fu_12199_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln785_62_fu_12407_p2() {
    xor_ln785_62_fu_12407_p2 = (tmp_5773_fu_12325_p3.read() ^ and_ln416_732_fu_12379_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln785_63_fu_12587_p2() {
    xor_ln785_63_fu_12587_p2 = (tmp_5780_fu_12505_p3.read() ^ and_ln416_733_fu_12559_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln785_64_fu_12767_p2() {
    xor_ln785_64_fu_12767_p2 = (tmp_5787_fu_12685_p3.read() ^ and_ln416_734_fu_12739_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln785_65_fu_12947_p2() {
    xor_ln785_65_fu_12947_p2 = (tmp_5794_fu_12865_p3.read() ^ and_ln416_735_fu_12919_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln785_66_fu_13127_p2() {
    xor_ln785_66_fu_13127_p2 = (tmp_5801_fu_13045_p3.read() ^ and_ln416_736_fu_13099_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln785_67_fu_13307_p2() {
    xor_ln785_67_fu_13307_p2 = (tmp_5808_fu_13225_p3.read() ^ and_ln416_737_fu_13279_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln785_68_fu_13487_p2() {
    xor_ln785_68_fu_13487_p2 = (tmp_5815_fu_13405_p3.read() ^ and_ln416_738_fu_13459_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln785_69_fu_13667_p2() {
    xor_ln785_69_fu_13667_p2 = (tmp_5822_fu_13585_p3.read() ^ and_ln416_739_fu_13639_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln785_70_fu_13847_p2() {
    xor_ln785_70_fu_13847_p2 = (tmp_5829_fu_13765_p3.read() ^ and_ln416_740_fu_13819_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln785_71_fu_14027_p2() {
    xor_ln785_71_fu_14027_p2 = (tmp_5836_fu_13945_p3.read() ^ and_ln416_741_fu_13999_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln785_72_fu_14207_p2() {
    xor_ln785_72_fu_14207_p2 = (tmp_5843_fu_14125_p3.read() ^ and_ln416_742_fu_14179_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln785_73_fu_14387_p2() {
    xor_ln785_73_fu_14387_p2 = (tmp_5850_fu_14305_p3.read() ^ and_ln416_743_fu_14359_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln785_74_fu_14567_p2() {
    xor_ln785_74_fu_14567_p2 = (tmp_5857_fu_14485_p3.read() ^ and_ln416_744_fu_14539_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln785_75_fu_14747_p2() {
    xor_ln785_75_fu_14747_p2 = (tmp_5864_fu_14665_p3.read() ^ and_ln416_745_fu_14719_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln785_76_fu_14927_p2() {
    xor_ln785_76_fu_14927_p2 = (tmp_5871_fu_14845_p3.read() ^ and_ln416_746_fu_14899_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln785_77_fu_15107_p2() {
    xor_ln785_77_fu_15107_p2 = (tmp_5878_fu_15025_p3.read() ^ and_ln416_747_fu_15079_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln785_78_fu_15287_p2() {
    xor_ln785_78_fu_15287_p2 = (tmp_5885_fu_15205_p3.read() ^ and_ln416_748_fu_15259_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln785_79_fu_22947_p2() {
    xor_ln785_79_fu_22947_p2 = (tmp_5892_fu_22865_p3.read() ^ and_ln416_749_fu_22919_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln785_8_fu_3077_p2() {
    xor_ln785_8_fu_3077_p2 = (tmp_5395_fu_2995_p3.read() ^ and_ln416_678_fu_3049_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln785_9_fu_3269_p2() {
    xor_ln785_9_fu_3269_p2 = (tmp_5402_fu_3187_p3.read() ^ and_ln416_679_fu_3241_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln785_fu_1517_p2() {
    xor_ln785_fu_1517_p2 = (tmp_5339_fu_1435_p3.read() ^ and_ln416_fu_1489_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln786_1207_fu_15415_p2() {
    xor_ln786_1207_fu_15415_p2 = (tmp_5345_fu_15407_p3.read() ^ ap_const_lv1_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln786_1208_fu_15503_p2() {
    xor_ln786_1208_fu_15503_p2 = (tmp_5352_fu_15495_p3.read() ^ ap_const_lv1_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln786_1209_fu_15591_p2() {
    xor_ln786_1209_fu_15591_p2 = (tmp_5359_fu_15583_p3.read() ^ ap_const_lv1_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln786_1210_fu_15679_p2() {
    xor_ln786_1210_fu_15679_p2 = (tmp_5366_fu_15671_p3.read() ^ ap_const_lv1_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln786_1211_fu_15767_p2() {
    xor_ln786_1211_fu_15767_p2 = (tmp_5373_fu_15759_p3.read() ^ ap_const_lv1_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln786_1212_fu_15855_p2() {
    xor_ln786_1212_fu_15855_p2 = (tmp_5380_fu_15847_p3.read() ^ ap_const_lv1_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln786_1213_fu_15943_p2() {
    xor_ln786_1213_fu_15943_p2 = (tmp_5387_fu_15935_p3.read() ^ ap_const_lv1_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln786_1214_fu_16031_p2() {
    xor_ln786_1214_fu_16031_p2 = (tmp_5394_fu_16023_p3.read() ^ ap_const_lv1_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln786_1215_fu_16119_p2() {
    xor_ln786_1215_fu_16119_p2 = (tmp_5401_fu_16111_p3.read() ^ ap_const_lv1_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln786_1216_fu_16207_p2() {
    xor_ln786_1216_fu_16207_p2 = (tmp_5408_fu_16199_p3.read() ^ ap_const_lv1_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln786_1217_fu_16295_p2() {
    xor_ln786_1217_fu_16295_p2 = (tmp_5415_fu_16287_p3.read() ^ ap_const_lv1_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln786_1218_fu_16383_p2() {
    xor_ln786_1218_fu_16383_p2 = (tmp_5422_fu_16375_p3.read() ^ ap_const_lv1_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln786_1219_fu_16471_p2() {
    xor_ln786_1219_fu_16471_p2 = (tmp_5429_fu_16463_p3.read() ^ ap_const_lv1_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln786_1220_fu_16559_p2() {
    xor_ln786_1220_fu_16559_p2 = (tmp_5436_fu_16551_p3.read() ^ ap_const_lv1_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln786_1221_fu_16647_p2() {
    xor_ln786_1221_fu_16647_p2 = (tmp_5443_fu_16639_p3.read() ^ ap_const_lv1_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln786_1222_fu_16735_p2() {
    xor_ln786_1222_fu_16735_p2 = (tmp_5450_fu_16727_p3.read() ^ ap_const_lv1_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln786_1223_fu_16823_p2() {
    xor_ln786_1223_fu_16823_p2 = (tmp_5457_fu_16815_p3.read() ^ ap_const_lv1_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln786_1224_fu_16911_p2() {
    xor_ln786_1224_fu_16911_p2 = (tmp_5464_fu_16903_p3.read() ^ ap_const_lv1_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln786_1225_fu_16999_p2() {
    xor_ln786_1225_fu_16999_p2 = (tmp_5471_fu_16991_p3.read() ^ ap_const_lv1_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln786_1226_fu_17274_p2() {
    xor_ln786_1226_fu_17274_p2 = (tmp_5478_fu_17266_p3.read() ^ ap_const_lv1_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln786_1227_fu_17362_p2() {
    xor_ln786_1227_fu_17362_p2 = (tmp_5485_fu_17354_p3.read() ^ ap_const_lv1_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln786_1228_fu_17450_p2() {
    xor_ln786_1228_fu_17450_p2 = (tmp_5492_fu_17442_p3.read() ^ ap_const_lv1_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln786_1229_fu_17538_p2() {
    xor_ln786_1229_fu_17538_p2 = (tmp_5499_fu_17530_p3.read() ^ ap_const_lv1_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln786_1230_fu_17626_p2() {
    xor_ln786_1230_fu_17626_p2 = (tmp_5506_fu_17618_p3.read() ^ ap_const_lv1_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln786_1231_fu_17714_p2() {
    xor_ln786_1231_fu_17714_p2 = (tmp_5513_fu_17706_p3.read() ^ ap_const_lv1_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln786_1232_fu_17802_p2() {
    xor_ln786_1232_fu_17802_p2 = (tmp_5520_fu_17794_p3.read() ^ ap_const_lv1_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln786_1233_fu_17890_p2() {
    xor_ln786_1233_fu_17890_p2 = (tmp_5527_fu_17882_p3.read() ^ ap_const_lv1_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln786_1234_fu_17978_p2() {
    xor_ln786_1234_fu_17978_p2 = (tmp_5534_fu_17970_p3.read() ^ ap_const_lv1_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln786_1235_fu_18066_p2() {
    xor_ln786_1235_fu_18066_p2 = (tmp_5541_fu_18058_p3.read() ^ ap_const_lv1_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln786_1236_fu_18154_p2() {
    xor_ln786_1236_fu_18154_p2 = (tmp_5548_fu_18146_p3.read() ^ ap_const_lv1_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln786_1237_fu_18242_p2() {
    xor_ln786_1237_fu_18242_p2 = (tmp_5555_fu_18234_p3.read() ^ ap_const_lv1_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln786_1238_fu_18330_p2() {
    xor_ln786_1238_fu_18330_p2 = (tmp_5562_fu_18322_p3.read() ^ ap_const_lv1_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln786_1239_fu_18418_p2() {
    xor_ln786_1239_fu_18418_p2 = (tmp_5569_fu_18410_p3.read() ^ ap_const_lv1_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln786_1240_fu_18506_p2() {
    xor_ln786_1240_fu_18506_p2 = (tmp_5576_fu_18498_p3.read() ^ ap_const_lv1_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln786_1241_fu_18594_p2() {
    xor_ln786_1241_fu_18594_p2 = (tmp_5583_fu_18586_p3.read() ^ ap_const_lv1_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln786_1242_fu_18682_p2() {
    xor_ln786_1242_fu_18682_p2 = (tmp_5590_fu_18674_p3.read() ^ ap_const_lv1_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln786_1243_fu_18770_p2() {
    xor_ln786_1243_fu_18770_p2 = (tmp_5597_fu_18762_p3.read() ^ ap_const_lv1_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln786_1244_fu_18858_p2() {
    xor_ln786_1244_fu_18858_p2 = (tmp_5604_fu_18850_p3.read() ^ ap_const_lv1_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln786_1245_fu_18946_p2() {
    xor_ln786_1245_fu_18946_p2 = (tmp_5611_fu_18938_p3.read() ^ ap_const_lv1_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln786_1246_fu_19205_p2() {
    xor_ln786_1246_fu_19205_p2 = (tmp_5618_fu_19197_p3.read() ^ ap_const_lv1_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln786_1247_fu_19293_p2() {
    xor_ln786_1247_fu_19293_p2 = (tmp_5625_fu_19285_p3.read() ^ ap_const_lv1_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln786_1248_fu_19381_p2() {
    xor_ln786_1248_fu_19381_p2 = (tmp_5632_fu_19373_p3.read() ^ ap_const_lv1_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln786_1249_fu_19469_p2() {
    xor_ln786_1249_fu_19469_p2 = (tmp_5639_fu_19461_p3.read() ^ ap_const_lv1_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln786_1250_fu_19557_p2() {
    xor_ln786_1250_fu_19557_p2 = (tmp_5646_fu_19549_p3.read() ^ ap_const_lv1_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln786_1251_fu_19645_p2() {
    xor_ln786_1251_fu_19645_p2 = (tmp_5653_fu_19637_p3.read() ^ ap_const_lv1_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln786_1252_fu_19733_p2() {
    xor_ln786_1252_fu_19733_p2 = (tmp_5660_fu_19725_p3.read() ^ ap_const_lv1_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln786_1253_fu_19821_p2() {
    xor_ln786_1253_fu_19821_p2 = (tmp_5667_fu_19813_p3.read() ^ ap_const_lv1_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln786_1254_fu_19909_p2() {
    xor_ln786_1254_fu_19909_p2 = (tmp_5674_fu_19901_p3.read() ^ ap_const_lv1_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln786_1255_fu_19997_p2() {
    xor_ln786_1255_fu_19997_p2 = (tmp_5681_fu_19989_p3.read() ^ ap_const_lv1_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln786_1256_fu_20085_p2() {
    xor_ln786_1256_fu_20085_p2 = (tmp_5688_fu_20077_p3.read() ^ ap_const_lv1_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln786_1257_fu_20173_p2() {
    xor_ln786_1257_fu_20173_p2 = (tmp_5695_fu_20165_p3.read() ^ ap_const_lv1_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln786_1258_fu_20261_p2() {
    xor_ln786_1258_fu_20261_p2 = (tmp_5702_fu_20253_p3.read() ^ ap_const_lv1_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln786_1259_fu_20349_p2() {
    xor_ln786_1259_fu_20349_p2 = (tmp_5709_fu_20341_p3.read() ^ ap_const_lv1_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln786_1260_fu_20437_p2() {
    xor_ln786_1260_fu_20437_p2 = (tmp_5716_fu_20429_p3.read() ^ ap_const_lv1_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln786_1261_fu_20525_p2() {
    xor_ln786_1261_fu_20525_p2 = (tmp_5723_fu_20517_p3.read() ^ ap_const_lv1_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln786_1262_fu_20613_p2() {
    xor_ln786_1262_fu_20613_p2 = (tmp_5730_fu_20605_p3.read() ^ ap_const_lv1_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln786_1263_fu_20701_p2() {
    xor_ln786_1263_fu_20701_p2 = (tmp_5737_fu_20693_p3.read() ^ ap_const_lv1_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln786_1264_fu_20789_p2() {
    xor_ln786_1264_fu_20789_p2 = (tmp_5744_fu_20781_p3.read() ^ ap_const_lv1_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln786_1265_fu_20877_p2() {
    xor_ln786_1265_fu_20877_p2 = (tmp_5751_fu_20869_p3.read() ^ ap_const_lv1_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln786_1266_fu_21136_p2() {
    xor_ln786_1266_fu_21136_p2 = (tmp_5758_fu_21128_p3.read() ^ ap_const_lv1_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln786_1267_fu_21224_p2() {
    xor_ln786_1267_fu_21224_p2 = (tmp_5765_fu_21216_p3.read() ^ ap_const_lv1_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln786_1268_fu_21312_p2() {
    xor_ln786_1268_fu_21312_p2 = (tmp_5772_fu_21304_p3.read() ^ ap_const_lv1_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln786_1269_fu_21400_p2() {
    xor_ln786_1269_fu_21400_p2 = (tmp_5779_fu_21392_p3.read() ^ ap_const_lv1_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln786_1270_fu_21488_p2() {
    xor_ln786_1270_fu_21488_p2 = (tmp_5786_fu_21480_p3.read() ^ ap_const_lv1_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln786_1271_fu_21576_p2() {
    xor_ln786_1271_fu_21576_p2 = (tmp_5793_fu_21568_p3.read() ^ ap_const_lv1_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln786_1272_fu_21664_p2() {
    xor_ln786_1272_fu_21664_p2 = (tmp_5800_fu_21656_p3.read() ^ ap_const_lv1_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln786_1273_fu_21752_p2() {
    xor_ln786_1273_fu_21752_p2 = (tmp_5807_fu_21744_p3.read() ^ ap_const_lv1_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln786_1274_fu_21840_p2() {
    xor_ln786_1274_fu_21840_p2 = (tmp_5814_fu_21832_p3.read() ^ ap_const_lv1_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln786_1275_fu_21928_p2() {
    xor_ln786_1275_fu_21928_p2 = (tmp_5821_fu_21920_p3.read() ^ ap_const_lv1_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln786_1276_fu_22016_p2() {
    xor_ln786_1276_fu_22016_p2 = (tmp_5828_fu_22008_p3.read() ^ ap_const_lv1_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln786_1277_fu_22104_p2() {
    xor_ln786_1277_fu_22104_p2 = (tmp_5835_fu_22096_p3.read() ^ ap_const_lv1_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln786_1278_fu_22192_p2() {
    xor_ln786_1278_fu_22192_p2 = (tmp_5842_fu_22184_p3.read() ^ ap_const_lv1_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln786_1279_fu_22280_p2() {
    xor_ln786_1279_fu_22280_p2 = (tmp_5849_fu_22272_p3.read() ^ ap_const_lv1_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln786_1280_fu_22368_p2() {
    xor_ln786_1280_fu_22368_p2 = (tmp_5856_fu_22360_p3.read() ^ ap_const_lv1_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln786_1281_fu_22456_p2() {
    xor_ln786_1281_fu_22456_p2 = (tmp_5863_fu_22448_p3.read() ^ ap_const_lv1_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln786_1282_fu_22544_p2() {
    xor_ln786_1282_fu_22544_p2 = (tmp_5870_fu_22536_p3.read() ^ ap_const_lv1_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln786_1283_fu_22632_p2() {
    xor_ln786_1283_fu_22632_p2 = (tmp_5877_fu_22624_p3.read() ^ ap_const_lv1_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln786_1284_fu_22720_p2() {
    xor_ln786_1284_fu_22720_p2 = (tmp_5884_fu_22712_p3.read() ^ ap_const_lv1_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln786_1285_fu_22808_p2() {
    xor_ln786_1285_fu_22808_p2 = (tmp_5891_fu_22800_p3.read() ^ ap_const_lv1_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln786_1286_fu_23067_p2() {
    xor_ln786_1286_fu_23067_p2 = (tmp_5898_fu_23059_p3.read() ^ ap_const_lv1_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln786_1366_fu_1747_p2() {
    xor_ln786_1366_fu_1747_p2 = (or_ln786_671_fu_1741_p2.read() ^ ap_const_lv1_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln786_1367_fu_1947_p2() {
    xor_ln786_1367_fu_1947_p2 = (or_ln786_672_fu_1941_p2.read() ^ ap_const_lv1_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln786_1368_fu_2147_p2() {
    xor_ln786_1368_fu_2147_p2 = (or_ln786_673_fu_2141_p2.read() ^ ap_const_lv1_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln786_1369_fu_2339_p2() {
    xor_ln786_1369_fu_2339_p2 = (or_ln786_674_fu_2333_p2.read() ^ ap_const_lv1_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln786_1370_fu_2531_p2() {
    xor_ln786_1370_fu_2531_p2 = (or_ln786_675_fu_2525_p2.read() ^ ap_const_lv1_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln786_1371_fu_2723_p2() {
    xor_ln786_1371_fu_2723_p2 = (or_ln786_676_fu_2717_p2.read() ^ ap_const_lv1_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln786_1372_fu_2915_p2() {
    xor_ln786_1372_fu_2915_p2 = (or_ln786_677_fu_2909_p2.read() ^ ap_const_lv1_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln786_1373_fu_3107_p2() {
    xor_ln786_1373_fu_3107_p2 = (or_ln786_678_fu_3101_p2.read() ^ ap_const_lv1_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln786_1374_fu_3299_p2() {
    xor_ln786_1374_fu_3299_p2 = (or_ln786_679_fu_3293_p2.read() ^ ap_const_lv1_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln786_1375_fu_3491_p2() {
    xor_ln786_1375_fu_3491_p2 = (or_ln786_680_fu_3485_p2.read() ^ ap_const_lv1_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln786_1376_fu_3683_p2() {
    xor_ln786_1376_fu_3683_p2 = (or_ln786_681_fu_3677_p2.read() ^ ap_const_lv1_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln786_1377_fu_3875_p2() {
    xor_ln786_1377_fu_3875_p2 = (or_ln786_682_fu_3869_p2.read() ^ ap_const_lv1_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln786_1378_fu_4067_p2() {
    xor_ln786_1378_fu_4067_p2 = (or_ln786_683_fu_4061_p2.read() ^ ap_const_lv1_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln786_1379_fu_4259_p2() {
    xor_ln786_1379_fu_4259_p2 = (or_ln786_684_fu_4253_p2.read() ^ ap_const_lv1_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln786_1380_fu_4451_p2() {
    xor_ln786_1380_fu_4451_p2 = (or_ln786_685_fu_4445_p2.read() ^ ap_const_lv1_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln786_1381_fu_4643_p2() {
    xor_ln786_1381_fu_4643_p2 = (or_ln786_686_fu_4637_p2.read() ^ ap_const_lv1_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln786_1382_fu_4835_p2() {
    xor_ln786_1382_fu_4835_p2 = (or_ln786_687_fu_4829_p2.read() ^ ap_const_lv1_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln786_1383_fu_5027_p2() {
    xor_ln786_1383_fu_5027_p2 = (or_ln786_688_fu_5021_p2.read() ^ ap_const_lv1_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln786_1384_fu_17184_p2() {
    xor_ln786_1384_fu_17184_p2 = (or_ln786_689_fu_17178_p2.read() ^ ap_const_lv1_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln786_1385_fu_5217_p2() {
    xor_ln786_1385_fu_5217_p2 = (or_ln786_690_fu_5211_p2.read() ^ ap_const_lv1_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln786_1386_fu_5397_p2() {
    xor_ln786_1386_fu_5397_p2 = (or_ln786_691_fu_5391_p2.read() ^ ap_const_lv1_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln786_1387_fu_5577_p2() {
    xor_ln786_1387_fu_5577_p2 = (or_ln786_692_fu_5571_p2.read() ^ ap_const_lv1_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln786_1388_fu_5757_p2() {
    xor_ln786_1388_fu_5757_p2 = (or_ln786_693_fu_5751_p2.read() ^ ap_const_lv1_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln786_1389_fu_5937_p2() {
    xor_ln786_1389_fu_5937_p2 = (or_ln786_694_fu_5931_p2.read() ^ ap_const_lv1_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln786_1390_fu_6117_p2() {
    xor_ln786_1390_fu_6117_p2 = (or_ln786_695_fu_6111_p2.read() ^ ap_const_lv1_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln786_1391_fu_6297_p2() {
    xor_ln786_1391_fu_6297_p2 = (or_ln786_696_fu_6291_p2.read() ^ ap_const_lv1_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln786_1392_fu_6477_p2() {
    xor_ln786_1392_fu_6477_p2 = (or_ln786_697_fu_6471_p2.read() ^ ap_const_lv1_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln786_1393_fu_6657_p2() {
    xor_ln786_1393_fu_6657_p2 = (or_ln786_698_fu_6651_p2.read() ^ ap_const_lv1_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln786_1394_fu_6837_p2() {
    xor_ln786_1394_fu_6837_p2 = (or_ln786_699_fu_6831_p2.read() ^ ap_const_lv1_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln786_1395_fu_7017_p2() {
    xor_ln786_1395_fu_7017_p2 = (or_ln786_700_fu_7011_p2.read() ^ ap_const_lv1_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln786_1396_fu_7197_p2() {
    xor_ln786_1396_fu_7197_p2 = (or_ln786_701_fu_7191_p2.read() ^ ap_const_lv1_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln786_1397_fu_7377_p2() {
    xor_ln786_1397_fu_7377_p2 = (or_ln786_702_fu_7371_p2.read() ^ ap_const_lv1_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln786_1398_fu_7557_p2() {
    xor_ln786_1398_fu_7557_p2 = (or_ln786_703_fu_7551_p2.read() ^ ap_const_lv1_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln786_1399_fu_7737_p2() {
    xor_ln786_1399_fu_7737_p2 = (or_ln786_704_fu_7731_p2.read() ^ ap_const_lv1_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln786_1400_fu_7917_p2() {
    xor_ln786_1400_fu_7917_p2 = (or_ln786_705_fu_7911_p2.read() ^ ap_const_lv1_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln786_1401_fu_8097_p2() {
    xor_ln786_1401_fu_8097_p2 = (or_ln786_706_fu_8091_p2.read() ^ ap_const_lv1_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln786_1402_fu_8277_p2() {
    xor_ln786_1402_fu_8277_p2 = (or_ln786_707_fu_8271_p2.read() ^ ap_const_lv1_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln786_1403_fu_8457_p2() {
    xor_ln786_1403_fu_8457_p2 = (or_ln786_708_fu_8451_p2.read() ^ ap_const_lv1_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln786_1404_fu_19115_p2() {
    xor_ln786_1404_fu_19115_p2 = (or_ln786_709_fu_19109_p2.read() ^ ap_const_lv1_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln786_1405_fu_8647_p2() {
    xor_ln786_1405_fu_8647_p2 = (or_ln786_710_fu_8641_p2.read() ^ ap_const_lv1_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln786_1406_fu_8827_p2() {
    xor_ln786_1406_fu_8827_p2 = (or_ln786_711_fu_8821_p2.read() ^ ap_const_lv1_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln786_1407_fu_9007_p2() {
    xor_ln786_1407_fu_9007_p2 = (or_ln786_712_fu_9001_p2.read() ^ ap_const_lv1_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln786_1408_fu_9187_p2() {
    xor_ln786_1408_fu_9187_p2 = (or_ln786_713_fu_9181_p2.read() ^ ap_const_lv1_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln786_1409_fu_9367_p2() {
    xor_ln786_1409_fu_9367_p2 = (or_ln786_714_fu_9361_p2.read() ^ ap_const_lv1_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln786_1410_fu_9547_p2() {
    xor_ln786_1410_fu_9547_p2 = (or_ln786_715_fu_9541_p2.read() ^ ap_const_lv1_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln786_1411_fu_9727_p2() {
    xor_ln786_1411_fu_9727_p2 = (or_ln786_716_fu_9721_p2.read() ^ ap_const_lv1_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln786_1412_fu_9907_p2() {
    xor_ln786_1412_fu_9907_p2 = (or_ln786_717_fu_9901_p2.read() ^ ap_const_lv1_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln786_1413_fu_10087_p2() {
    xor_ln786_1413_fu_10087_p2 = (or_ln786_718_fu_10081_p2.read() ^ ap_const_lv1_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln786_1414_fu_10267_p2() {
    xor_ln786_1414_fu_10267_p2 = (or_ln786_719_fu_10261_p2.read() ^ ap_const_lv1_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln786_1415_fu_10447_p2() {
    xor_ln786_1415_fu_10447_p2 = (or_ln786_720_fu_10441_p2.read() ^ ap_const_lv1_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln786_1416_fu_10627_p2() {
    xor_ln786_1416_fu_10627_p2 = (or_ln786_721_fu_10621_p2.read() ^ ap_const_lv1_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln786_1417_fu_10807_p2() {
    xor_ln786_1417_fu_10807_p2 = (or_ln786_722_fu_10801_p2.read() ^ ap_const_lv1_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln786_1418_fu_10987_p2() {
    xor_ln786_1418_fu_10987_p2 = (or_ln786_723_fu_10981_p2.read() ^ ap_const_lv1_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln786_1419_fu_11167_p2() {
    xor_ln786_1419_fu_11167_p2 = (or_ln786_724_fu_11161_p2.read() ^ ap_const_lv1_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln786_1420_fu_11347_p2() {
    xor_ln786_1420_fu_11347_p2 = (or_ln786_725_fu_11341_p2.read() ^ ap_const_lv1_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln786_1421_fu_11527_p2() {
    xor_ln786_1421_fu_11527_p2 = (or_ln786_726_fu_11521_p2.read() ^ ap_const_lv1_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln786_1422_fu_11707_p2() {
    xor_ln786_1422_fu_11707_p2 = (or_ln786_727_fu_11701_p2.read() ^ ap_const_lv1_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln786_1423_fu_11887_p2() {
    xor_ln786_1423_fu_11887_p2 = (or_ln786_728_fu_11881_p2.read() ^ ap_const_lv1_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln786_1424_fu_21046_p2() {
    xor_ln786_1424_fu_21046_p2 = (or_ln786_729_fu_21040_p2.read() ^ ap_const_lv1_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln786_1425_fu_12077_p2() {
    xor_ln786_1425_fu_12077_p2 = (or_ln786_730_fu_12071_p2.read() ^ ap_const_lv1_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln786_1426_fu_12257_p2() {
    xor_ln786_1426_fu_12257_p2 = (or_ln786_731_fu_12251_p2.read() ^ ap_const_lv1_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln786_1427_fu_12437_p2() {
    xor_ln786_1427_fu_12437_p2 = (or_ln786_732_fu_12431_p2.read() ^ ap_const_lv1_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln786_1428_fu_12617_p2() {
    xor_ln786_1428_fu_12617_p2 = (or_ln786_733_fu_12611_p2.read() ^ ap_const_lv1_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln786_1429_fu_12797_p2() {
    xor_ln786_1429_fu_12797_p2 = (or_ln786_734_fu_12791_p2.read() ^ ap_const_lv1_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln786_1430_fu_12977_p2() {
    xor_ln786_1430_fu_12977_p2 = (or_ln786_735_fu_12971_p2.read() ^ ap_const_lv1_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln786_1431_fu_13157_p2() {
    xor_ln786_1431_fu_13157_p2 = (or_ln786_736_fu_13151_p2.read() ^ ap_const_lv1_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln786_1432_fu_13337_p2() {
    xor_ln786_1432_fu_13337_p2 = (or_ln786_737_fu_13331_p2.read() ^ ap_const_lv1_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln786_1433_fu_13517_p2() {
    xor_ln786_1433_fu_13517_p2 = (or_ln786_738_fu_13511_p2.read() ^ ap_const_lv1_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln786_1434_fu_13697_p2() {
    xor_ln786_1434_fu_13697_p2 = (or_ln786_739_fu_13691_p2.read() ^ ap_const_lv1_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln786_1435_fu_13877_p2() {
    xor_ln786_1435_fu_13877_p2 = (or_ln786_740_fu_13871_p2.read() ^ ap_const_lv1_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln786_1436_fu_14057_p2() {
    xor_ln786_1436_fu_14057_p2 = (or_ln786_741_fu_14051_p2.read() ^ ap_const_lv1_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln786_1437_fu_14237_p2() {
    xor_ln786_1437_fu_14237_p2 = (or_ln786_742_fu_14231_p2.read() ^ ap_const_lv1_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln786_1438_fu_14417_p2() {
    xor_ln786_1438_fu_14417_p2 = (or_ln786_743_fu_14411_p2.read() ^ ap_const_lv1_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln786_1439_fu_14597_p2() {
    xor_ln786_1439_fu_14597_p2 = (or_ln786_744_fu_14591_p2.read() ^ ap_const_lv1_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln786_1440_fu_14777_p2() {
    xor_ln786_1440_fu_14777_p2 = (or_ln786_745_fu_14771_p2.read() ^ ap_const_lv1_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln786_1441_fu_14957_p2() {
    xor_ln786_1441_fu_14957_p2 = (or_ln786_746_fu_14951_p2.read() ^ ap_const_lv1_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln786_1442_fu_15137_p2() {
    xor_ln786_1442_fu_15137_p2 = (or_ln786_747_fu_15131_p2.read() ^ ap_const_lv1_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln786_1443_fu_15317_p2() {
    xor_ln786_1443_fu_15317_p2 = (or_ln786_748_fu_15311_p2.read() ^ ap_const_lv1_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln786_1444_fu_22977_p2() {
    xor_ln786_1444_fu_22977_p2 = (or_ln786_749_fu_22971_p2.read() ^ ap_const_lv1_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_xor_ln786_fu_1547_p2() {
    xor_ln786_fu_1547_p2 = (or_ln786_fu_1541_p2.read() ^ ap_const_lv1_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_zext_ln415_686_fu_1665_p1() {
    zext_ln415_686_fu_1665_p1 = esl_zext<24,1>(tmp_5348_fu_1658_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_zext_ln415_687_fu_1865_p1() {
    zext_ln415_687_fu_1865_p1 = esl_zext<24,1>(tmp_5355_fu_1858_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_zext_ln415_688_fu_2065_p1() {
    zext_ln415_688_fu_2065_p1 = esl_zext<24,1>(tmp_5362_fu_2058_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_zext_ln415_689_fu_2257_p1() {
    zext_ln415_689_fu_2257_p1 = esl_zext<24,1>(tmp_5369_fu_2250_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_zext_ln415_690_fu_2449_p1() {
    zext_ln415_690_fu_2449_p1 = esl_zext<24,1>(tmp_5376_fu_2442_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_zext_ln415_691_fu_2641_p1() {
    zext_ln415_691_fu_2641_p1 = esl_zext<24,1>(tmp_5383_fu_2634_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_zext_ln415_692_fu_2833_p1() {
    zext_ln415_692_fu_2833_p1 = esl_zext<24,1>(tmp_5390_fu_2826_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_zext_ln415_693_fu_3025_p1() {
    zext_ln415_693_fu_3025_p1 = esl_zext<24,1>(tmp_5397_fu_3018_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_zext_ln415_694_fu_3217_p1() {
    zext_ln415_694_fu_3217_p1 = esl_zext<24,1>(tmp_5404_fu_3210_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_zext_ln415_695_fu_3409_p1() {
    zext_ln415_695_fu_3409_p1 = esl_zext<24,1>(tmp_5411_fu_3402_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_zext_ln415_696_fu_3601_p1() {
    zext_ln415_696_fu_3601_p1 = esl_zext<24,1>(tmp_5418_fu_3594_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_zext_ln415_697_fu_3793_p1() {
    zext_ln415_697_fu_3793_p1 = esl_zext<24,1>(tmp_5425_fu_3786_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_zext_ln415_698_fu_3985_p1() {
    zext_ln415_698_fu_3985_p1 = esl_zext<24,1>(tmp_5432_fu_3978_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_zext_ln415_699_fu_4177_p1() {
    zext_ln415_699_fu_4177_p1 = esl_zext<24,1>(tmp_5439_fu_4170_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_zext_ln415_700_fu_4369_p1() {
    zext_ln415_700_fu_4369_p1 = esl_zext<24,1>(tmp_5446_fu_4362_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_zext_ln415_701_fu_4561_p1() {
    zext_ln415_701_fu_4561_p1 = esl_zext<24,1>(tmp_5453_fu_4554_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_zext_ln415_702_fu_4753_p1() {
    zext_ln415_702_fu_4753_p1 = esl_zext<24,1>(tmp_5460_fu_4746_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_zext_ln415_703_fu_4945_p1() {
    zext_ln415_703_fu_4945_p1 = esl_zext<24,1>(tmp_5467_fu_4938_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_zext_ln415_704_fu_17102_p1() {
    zext_ln415_704_fu_17102_p1 = esl_zext<24,1>(tmp_5474_fu_17095_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_zext_ln415_705_fu_5135_p1() {
    zext_ln415_705_fu_5135_p1 = esl_zext<24,1>(tmp_5481_fu_5128_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_zext_ln415_706_fu_5315_p1() {
    zext_ln415_706_fu_5315_p1 = esl_zext<24,1>(tmp_5488_fu_5308_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_zext_ln415_707_fu_5495_p1() {
    zext_ln415_707_fu_5495_p1 = esl_zext<24,1>(tmp_5495_fu_5488_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_zext_ln415_708_fu_5675_p1() {
    zext_ln415_708_fu_5675_p1 = esl_zext<24,1>(tmp_5502_fu_5668_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_zext_ln415_709_fu_5855_p1() {
    zext_ln415_709_fu_5855_p1 = esl_zext<24,1>(tmp_5509_fu_5848_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_zext_ln415_710_fu_6035_p1() {
    zext_ln415_710_fu_6035_p1 = esl_zext<24,1>(tmp_5516_fu_6028_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_zext_ln415_711_fu_6215_p1() {
    zext_ln415_711_fu_6215_p1 = esl_zext<24,1>(tmp_5523_fu_6208_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_zext_ln415_712_fu_6395_p1() {
    zext_ln415_712_fu_6395_p1 = esl_zext<24,1>(tmp_5530_fu_6388_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_zext_ln415_713_fu_6575_p1() {
    zext_ln415_713_fu_6575_p1 = esl_zext<24,1>(tmp_5537_fu_6568_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_zext_ln415_714_fu_6755_p1() {
    zext_ln415_714_fu_6755_p1 = esl_zext<24,1>(tmp_5544_fu_6748_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_zext_ln415_715_fu_6935_p1() {
    zext_ln415_715_fu_6935_p1 = esl_zext<24,1>(tmp_5551_fu_6928_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_zext_ln415_716_fu_7115_p1() {
    zext_ln415_716_fu_7115_p1 = esl_zext<24,1>(tmp_5558_fu_7108_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_zext_ln415_717_fu_7295_p1() {
    zext_ln415_717_fu_7295_p1 = esl_zext<24,1>(tmp_5565_fu_7288_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_zext_ln415_718_fu_7475_p1() {
    zext_ln415_718_fu_7475_p1 = esl_zext<24,1>(tmp_5572_fu_7468_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_zext_ln415_719_fu_7655_p1() {
    zext_ln415_719_fu_7655_p1 = esl_zext<24,1>(tmp_5579_fu_7648_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_zext_ln415_720_fu_7835_p1() {
    zext_ln415_720_fu_7835_p1 = esl_zext<24,1>(tmp_5586_fu_7828_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_zext_ln415_721_fu_8015_p1() {
    zext_ln415_721_fu_8015_p1 = esl_zext<24,1>(tmp_5593_fu_8008_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_zext_ln415_722_fu_8195_p1() {
    zext_ln415_722_fu_8195_p1 = esl_zext<24,1>(tmp_5600_fu_8188_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_zext_ln415_723_fu_8375_p1() {
    zext_ln415_723_fu_8375_p1 = esl_zext<24,1>(tmp_5607_fu_8368_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_zext_ln415_724_fu_19033_p1() {
    zext_ln415_724_fu_19033_p1 = esl_zext<24,1>(tmp_5614_fu_19026_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_zext_ln415_725_fu_8565_p1() {
    zext_ln415_725_fu_8565_p1 = esl_zext<24,1>(tmp_5621_fu_8558_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_zext_ln415_726_fu_8745_p1() {
    zext_ln415_726_fu_8745_p1 = esl_zext<24,1>(tmp_5628_fu_8738_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_zext_ln415_727_fu_8925_p1() {
    zext_ln415_727_fu_8925_p1 = esl_zext<24,1>(tmp_5635_fu_8918_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_zext_ln415_728_fu_9105_p1() {
    zext_ln415_728_fu_9105_p1 = esl_zext<24,1>(tmp_5642_fu_9098_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_zext_ln415_729_fu_9285_p1() {
    zext_ln415_729_fu_9285_p1 = esl_zext<24,1>(tmp_5649_fu_9278_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_zext_ln415_730_fu_9465_p1() {
    zext_ln415_730_fu_9465_p1 = esl_zext<24,1>(tmp_5656_fu_9458_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_zext_ln415_731_fu_9645_p1() {
    zext_ln415_731_fu_9645_p1 = esl_zext<24,1>(tmp_5663_fu_9638_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_zext_ln415_732_fu_9825_p1() {
    zext_ln415_732_fu_9825_p1 = esl_zext<24,1>(tmp_5670_fu_9818_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_zext_ln415_733_fu_10005_p1() {
    zext_ln415_733_fu_10005_p1 = esl_zext<24,1>(tmp_5677_fu_9998_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_zext_ln415_734_fu_10185_p1() {
    zext_ln415_734_fu_10185_p1 = esl_zext<24,1>(tmp_5684_fu_10178_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_zext_ln415_735_fu_10365_p1() {
    zext_ln415_735_fu_10365_p1 = esl_zext<24,1>(tmp_5691_fu_10358_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_zext_ln415_736_fu_10545_p1() {
    zext_ln415_736_fu_10545_p1 = esl_zext<24,1>(tmp_5698_fu_10538_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_zext_ln415_737_fu_10725_p1() {
    zext_ln415_737_fu_10725_p1 = esl_zext<24,1>(tmp_5705_fu_10718_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_zext_ln415_738_fu_10905_p1() {
    zext_ln415_738_fu_10905_p1 = esl_zext<24,1>(tmp_5712_fu_10898_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_zext_ln415_739_fu_11085_p1() {
    zext_ln415_739_fu_11085_p1 = esl_zext<24,1>(tmp_5719_fu_11078_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_zext_ln415_740_fu_11265_p1() {
    zext_ln415_740_fu_11265_p1 = esl_zext<24,1>(tmp_5726_fu_11258_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_zext_ln415_741_fu_11445_p1() {
    zext_ln415_741_fu_11445_p1 = esl_zext<24,1>(tmp_5733_fu_11438_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_zext_ln415_742_fu_11625_p1() {
    zext_ln415_742_fu_11625_p1 = esl_zext<24,1>(tmp_5740_fu_11618_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_zext_ln415_743_fu_11805_p1() {
    zext_ln415_743_fu_11805_p1 = esl_zext<24,1>(tmp_5747_fu_11798_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_zext_ln415_744_fu_20964_p1() {
    zext_ln415_744_fu_20964_p1 = esl_zext<24,1>(tmp_5754_fu_20957_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_zext_ln415_745_fu_11995_p1() {
    zext_ln415_745_fu_11995_p1 = esl_zext<24,1>(tmp_5761_fu_11988_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_zext_ln415_746_fu_12175_p1() {
    zext_ln415_746_fu_12175_p1 = esl_zext<24,1>(tmp_5768_fu_12168_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_zext_ln415_747_fu_12355_p1() {
    zext_ln415_747_fu_12355_p1 = esl_zext<24,1>(tmp_5775_fu_12348_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_zext_ln415_748_fu_12535_p1() {
    zext_ln415_748_fu_12535_p1 = esl_zext<24,1>(tmp_5782_fu_12528_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_zext_ln415_749_fu_12715_p1() {
    zext_ln415_749_fu_12715_p1 = esl_zext<24,1>(tmp_5789_fu_12708_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_zext_ln415_750_fu_12895_p1() {
    zext_ln415_750_fu_12895_p1 = esl_zext<24,1>(tmp_5796_fu_12888_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_zext_ln415_751_fu_13075_p1() {
    zext_ln415_751_fu_13075_p1 = esl_zext<24,1>(tmp_5803_fu_13068_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_zext_ln415_752_fu_13255_p1() {
    zext_ln415_752_fu_13255_p1 = esl_zext<24,1>(tmp_5810_fu_13248_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_zext_ln415_753_fu_13435_p1() {
    zext_ln415_753_fu_13435_p1 = esl_zext<24,1>(tmp_5817_fu_13428_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_zext_ln415_754_fu_13615_p1() {
    zext_ln415_754_fu_13615_p1 = esl_zext<24,1>(tmp_5824_fu_13608_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_zext_ln415_755_fu_13795_p1() {
    zext_ln415_755_fu_13795_p1 = esl_zext<24,1>(tmp_5831_fu_13788_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_zext_ln415_756_fu_13975_p1() {
    zext_ln415_756_fu_13975_p1 = esl_zext<24,1>(tmp_5838_fu_13968_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_zext_ln415_757_fu_14155_p1() {
    zext_ln415_757_fu_14155_p1 = esl_zext<24,1>(tmp_5845_fu_14148_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_zext_ln415_758_fu_14335_p1() {
    zext_ln415_758_fu_14335_p1 = esl_zext<24,1>(tmp_5852_fu_14328_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_zext_ln415_759_fu_14515_p1() {
    zext_ln415_759_fu_14515_p1 = esl_zext<24,1>(tmp_5859_fu_14508_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_zext_ln415_760_fu_14695_p1() {
    zext_ln415_760_fu_14695_p1 = esl_zext<24,1>(tmp_5866_fu_14688_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_zext_ln415_761_fu_14875_p1() {
    zext_ln415_761_fu_14875_p1 = esl_zext<24,1>(tmp_5873_fu_14868_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_zext_ln415_762_fu_15055_p1() {
    zext_ln415_762_fu_15055_p1 = esl_zext<24,1>(tmp_5880_fu_15048_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_zext_ln415_763_fu_15235_p1() {
    zext_ln415_763_fu_15235_p1 = esl_zext<24,1>(tmp_5887_fu_15228_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_zext_ln415_764_fu_22895_p1() {
    zext_ln415_764_fu_22895_p1 = esl_zext<24,1>(tmp_5894_fu_22888_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_zext_ln415_fu_1465_p1() {
    zext_ln415_fu_1465_p1 = esl_zext<24,1>(tmp_5341_fu_1458_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_zext_ln56_fu_1396_p1() {
    zext_ln56_fu_1396_p1 = esl_zext<64,1>(ap_phi_mux_in_index13_phi_fu_860_p4.read());
}

}

