#include "dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s.h"
#include "AESL_pkg.h"

using namespace std;

namespace ap_rtl {

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln340_818_fu_122924_p2() {
    xor_ln340_818_fu_122924_p2 = (tmp_2659_fu_122891_p3.read() ^ tmp_2660_fu_122904_p3.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln340_819_fu_123012_p2() {
    xor_ln340_819_fu_123012_p2 = (tmp_2666_fu_122979_p3.read() ^ tmp_2667_fu_122992_p3.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln340_81_fu_101933_p2() {
    xor_ln340_81_fu_101933_p2 = (tmp_1084_fu_101894_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln340_820_fu_123100_p2() {
    xor_ln340_820_fu_123100_p2 = (tmp_2673_fu_123067_p3.read() ^ tmp_2674_fu_123080_p3.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln340_821_fu_123188_p2() {
    xor_ln340_821_fu_123188_p2 = (tmp_2680_fu_123155_p3.read() ^ tmp_2681_fu_123168_p3.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln340_822_fu_123276_p2() {
    xor_ln340_822_fu_123276_p2 = (tmp_2687_fu_123243_p3.read() ^ tmp_2688_fu_123256_p3.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln340_823_fu_123364_p2() {
    xor_ln340_823_fu_123364_p2 = (tmp_2694_fu_123331_p3.read() ^ tmp_2695_fu_123344_p3.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln340_824_fu_123452_p2() {
    xor_ln340_824_fu_123452_p2 = (tmp_2701_fu_123419_p3.read() ^ tmp_2702_fu_123432_p3.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln340_825_fu_123540_p2() {
    xor_ln340_825_fu_123540_p2 = (tmp_2708_fu_123507_p3.read() ^ tmp_2709_fu_123520_p3.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln340_826_fu_123628_p2() {
    xor_ln340_826_fu_123628_p2 = (tmp_2715_fu_123595_p3.read() ^ tmp_2716_fu_123608_p3.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln340_827_fu_123716_p2() {
    xor_ln340_827_fu_123716_p2 = (tmp_2722_fu_123683_p3.read() ^ tmp_2723_fu_123696_p3.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln340_828_fu_123804_p2() {
    xor_ln340_828_fu_123804_p2 = (tmp_2729_fu_123771_p3.read() ^ tmp_2730_fu_123784_p3.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln340_829_fu_123892_p2() {
    xor_ln340_829_fu_123892_p2 = (tmp_2736_fu_123859_p3.read() ^ tmp_2737_fu_123872_p3.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln340_82_fu_102021_p2() {
    xor_ln340_82_fu_102021_p2 = (tmp_1091_fu_101982_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln340_830_fu_123980_p2() {
    xor_ln340_830_fu_123980_p2 = (tmp_2743_fu_123947_p3.read() ^ tmp_2744_fu_123960_p3.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln340_831_fu_124239_p2() {
    xor_ln340_831_fu_124239_p2 = (tmp_2750_fu_124205_p3.read() ^ tmp_2751_fu_124219_p3.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln340_832_fu_124327_p2() {
    xor_ln340_832_fu_124327_p2 = (tmp_2757_fu_124294_p3.read() ^ tmp_2758_fu_124307_p3.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln340_833_fu_124415_p2() {
    xor_ln340_833_fu_124415_p2 = (tmp_2764_fu_124382_p3.read() ^ tmp_2765_fu_124395_p3.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln340_834_fu_124503_p2() {
    xor_ln340_834_fu_124503_p2 = (tmp_2771_fu_124470_p3.read() ^ tmp_2772_fu_124483_p3.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln340_835_fu_124591_p2() {
    xor_ln340_835_fu_124591_p2 = (tmp_2778_fu_124558_p3.read() ^ tmp_2779_fu_124571_p3.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln340_836_fu_124679_p2() {
    xor_ln340_836_fu_124679_p2 = (tmp_2785_fu_124646_p3.read() ^ tmp_2786_fu_124659_p3.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln340_837_fu_124767_p2() {
    xor_ln340_837_fu_124767_p2 = (tmp_2792_fu_124734_p3.read() ^ tmp_2793_fu_124747_p3.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln340_838_fu_124855_p2() {
    xor_ln340_838_fu_124855_p2 = (tmp_2799_fu_124822_p3.read() ^ tmp_2800_fu_124835_p3.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln340_839_fu_124943_p2() {
    xor_ln340_839_fu_124943_p2 = (tmp_2806_fu_124910_p3.read() ^ tmp_2807_fu_124923_p3.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln340_83_fu_102109_p2() {
    xor_ln340_83_fu_102109_p2 = (tmp_1098_fu_102070_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln340_840_fu_125031_p2() {
    xor_ln340_840_fu_125031_p2 = (tmp_2813_fu_124998_p3.read() ^ tmp_2814_fu_125011_p3.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln340_841_fu_125119_p2() {
    xor_ln340_841_fu_125119_p2 = (tmp_2820_fu_125086_p3.read() ^ tmp_2821_fu_125099_p3.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln340_842_fu_125207_p2() {
    xor_ln340_842_fu_125207_p2 = (tmp_2827_fu_125174_p3.read() ^ tmp_2828_fu_125187_p3.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln340_843_fu_125295_p2() {
    xor_ln340_843_fu_125295_p2 = (tmp_2834_fu_125262_p3.read() ^ tmp_2835_fu_125275_p3.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln340_844_fu_125383_p2() {
    xor_ln340_844_fu_125383_p2 = (tmp_2841_fu_125350_p3.read() ^ tmp_2842_fu_125363_p3.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln340_845_fu_125471_p2() {
    xor_ln340_845_fu_125471_p2 = (tmp_2848_fu_125438_p3.read() ^ tmp_2849_fu_125451_p3.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln340_846_fu_125559_p2() {
    xor_ln340_846_fu_125559_p2 = (tmp_2855_fu_125526_p3.read() ^ tmp_2856_fu_125539_p3.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln340_847_fu_125647_p2() {
    xor_ln340_847_fu_125647_p2 = (tmp_2862_fu_125614_p3.read() ^ tmp_2863_fu_125627_p3.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln340_848_fu_125735_p2() {
    xor_ln340_848_fu_125735_p2 = (tmp_2869_fu_125702_p3.read() ^ tmp_2870_fu_125715_p3.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln340_849_fu_125823_p2() {
    xor_ln340_849_fu_125823_p2 = (tmp_2876_fu_125790_p3.read() ^ tmp_2877_fu_125803_p3.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln340_84_fu_102197_p2() {
    xor_ln340_84_fu_102197_p2 = (tmp_1105_fu_102158_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln340_850_fu_125911_p2() {
    xor_ln340_850_fu_125911_p2 = (tmp_2883_fu_125878_p3.read() ^ tmp_2884_fu_125891_p3.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln340_851_fu_125999_p2() {
    xor_ln340_851_fu_125999_p2 = (tmp_2890_fu_125966_p3.read() ^ tmp_2891_fu_125979_p3.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln340_852_fu_126087_p2() {
    xor_ln340_852_fu_126087_p2 = (tmp_2897_fu_126054_p3.read() ^ tmp_2898_fu_126067_p3.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln340_853_fu_126175_p2() {
    xor_ln340_853_fu_126175_p2 = (tmp_2904_fu_126142_p3.read() ^ tmp_2905_fu_126155_p3.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln340_854_fu_126263_p2() {
    xor_ln340_854_fu_126263_p2 = (tmp_2911_fu_126230_p3.read() ^ tmp_2912_fu_126243_p3.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln340_855_fu_126351_p2() {
    xor_ln340_855_fu_126351_p2 = (tmp_2918_fu_126318_p3.read() ^ tmp_2919_fu_126331_p3.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln340_856_fu_126439_p2() {
    xor_ln340_856_fu_126439_p2 = (tmp_2925_fu_126406_p3.read() ^ tmp_2926_fu_126419_p3.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln340_857_fu_126527_p2() {
    xor_ln340_857_fu_126527_p2 = (tmp_2932_fu_126494_p3.read() ^ tmp_2933_fu_126507_p3.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln340_858_fu_126615_p2() {
    xor_ln340_858_fu_126615_p2 = (tmp_2939_fu_126582_p3.read() ^ tmp_2940_fu_126595_p3.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln340_859_fu_126703_p2() {
    xor_ln340_859_fu_126703_p2 = (tmp_2946_fu_126670_p3.read() ^ tmp_2947_fu_126683_p3.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln340_85_fu_102285_p2() {
    xor_ln340_85_fu_102285_p2 = (tmp_1112_fu_102246_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln340_860_fu_126791_p2() {
    xor_ln340_860_fu_126791_p2 = (tmp_2953_fu_126758_p3.read() ^ tmp_2954_fu_126771_p3.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln340_861_fu_126879_p2() {
    xor_ln340_861_fu_126879_p2 = (tmp_2960_fu_126846_p3.read() ^ tmp_2961_fu_126859_p3.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln340_862_fu_126967_p2() {
    xor_ln340_862_fu_126967_p2 = (tmp_2967_fu_126934_p3.read() ^ tmp_2968_fu_126947_p3.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln340_863_fu_127226_p2() {
    xor_ln340_863_fu_127226_p2 = (tmp_2974_fu_127192_p3.read() ^ tmp_2975_fu_127206_p3.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln340_864_fu_127314_p2() {
    xor_ln340_864_fu_127314_p2 = (tmp_2981_fu_127281_p3.read() ^ tmp_2982_fu_127294_p3.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln340_865_fu_127402_p2() {
    xor_ln340_865_fu_127402_p2 = (tmp_2988_fu_127369_p3.read() ^ tmp_2989_fu_127382_p3.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln340_866_fu_127490_p2() {
    xor_ln340_866_fu_127490_p2 = (tmp_2995_fu_127457_p3.read() ^ tmp_2996_fu_127470_p3.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln340_867_fu_127578_p2() {
    xor_ln340_867_fu_127578_p2 = (tmp_3002_fu_127545_p3.read() ^ tmp_3003_fu_127558_p3.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln340_868_fu_127666_p2() {
    xor_ln340_868_fu_127666_p2 = (tmp_3009_fu_127633_p3.read() ^ tmp_3010_fu_127646_p3.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln340_869_fu_127754_p2() {
    xor_ln340_869_fu_127754_p2 = (tmp_3016_fu_127721_p3.read() ^ tmp_3017_fu_127734_p3.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln340_86_fu_102373_p2() {
    xor_ln340_86_fu_102373_p2 = (tmp_1119_fu_102334_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln340_870_fu_127842_p2() {
    xor_ln340_870_fu_127842_p2 = (tmp_3023_fu_127809_p3.read() ^ tmp_3024_fu_127822_p3.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln340_871_fu_127930_p2() {
    xor_ln340_871_fu_127930_p2 = (tmp_3030_fu_127897_p3.read() ^ tmp_3031_fu_127910_p3.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln340_872_fu_128018_p2() {
    xor_ln340_872_fu_128018_p2 = (tmp_3037_fu_127985_p3.read() ^ tmp_3038_fu_127998_p3.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln340_873_fu_128106_p2() {
    xor_ln340_873_fu_128106_p2 = (tmp_3044_fu_128073_p3.read() ^ tmp_3045_fu_128086_p3.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln340_874_fu_128194_p2() {
    xor_ln340_874_fu_128194_p2 = (tmp_3051_fu_128161_p3.read() ^ tmp_3052_fu_128174_p3.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln340_875_fu_128282_p2() {
    xor_ln340_875_fu_128282_p2 = (tmp_3058_fu_128249_p3.read() ^ tmp_3059_fu_128262_p3.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln340_876_fu_128370_p2() {
    xor_ln340_876_fu_128370_p2 = (tmp_3065_fu_128337_p3.read() ^ tmp_3066_fu_128350_p3.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln340_877_fu_128458_p2() {
    xor_ln340_877_fu_128458_p2 = (tmp_3072_fu_128425_p3.read() ^ tmp_3073_fu_128438_p3.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln340_878_fu_128546_p2() {
    xor_ln340_878_fu_128546_p2 = (tmp_3079_fu_128513_p3.read() ^ tmp_3080_fu_128526_p3.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln340_879_fu_128634_p2() {
    xor_ln340_879_fu_128634_p2 = (tmp_3086_fu_128601_p3.read() ^ tmp_3087_fu_128614_p3.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln340_87_fu_102461_p2() {
    xor_ln340_87_fu_102461_p2 = (tmp_1126_fu_102422_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln340_880_fu_128722_p2() {
    xor_ln340_880_fu_128722_p2 = (tmp_3093_fu_128689_p3.read() ^ tmp_3094_fu_128702_p3.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln340_881_fu_128810_p2() {
    xor_ln340_881_fu_128810_p2 = (tmp_3100_fu_128777_p3.read() ^ tmp_3101_fu_128790_p3.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln340_882_fu_128898_p2() {
    xor_ln340_882_fu_128898_p2 = (tmp_3107_fu_128865_p3.read() ^ tmp_3108_fu_128878_p3.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln340_883_fu_128986_p2() {
    xor_ln340_883_fu_128986_p2 = (tmp_3114_fu_128953_p3.read() ^ tmp_3115_fu_128966_p3.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln340_884_fu_129074_p2() {
    xor_ln340_884_fu_129074_p2 = (tmp_3121_fu_129041_p3.read() ^ tmp_3122_fu_129054_p3.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln340_885_fu_129162_p2() {
    xor_ln340_885_fu_129162_p2 = (tmp_3128_fu_129129_p3.read() ^ tmp_3129_fu_129142_p3.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln340_886_fu_129250_p2() {
    xor_ln340_886_fu_129250_p2 = (tmp_3135_fu_129217_p3.read() ^ tmp_3136_fu_129230_p3.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln340_887_fu_129338_p2() {
    xor_ln340_887_fu_129338_p2 = (tmp_3142_fu_129305_p3.read() ^ tmp_3143_fu_129318_p3.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln340_888_fu_129426_p2() {
    xor_ln340_888_fu_129426_p2 = (tmp_3149_fu_129393_p3.read() ^ tmp_3150_fu_129406_p3.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln340_889_fu_129514_p2() {
    xor_ln340_889_fu_129514_p2 = (tmp_3156_fu_129481_p3.read() ^ tmp_3157_fu_129494_p3.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln340_88_fu_102549_p2() {
    xor_ln340_88_fu_102549_p2 = (tmp_1133_fu_102510_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln340_890_fu_129602_p2() {
    xor_ln340_890_fu_129602_p2 = (tmp_3163_fu_129569_p3.read() ^ tmp_3164_fu_129582_p3.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln340_891_fu_129690_p2() {
    xor_ln340_891_fu_129690_p2 = (tmp_3170_fu_129657_p3.read() ^ tmp_3171_fu_129670_p3.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln340_892_fu_129778_p2() {
    xor_ln340_892_fu_129778_p2 = (tmp_3177_fu_129745_p3.read() ^ tmp_3178_fu_129758_p3.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln340_893_fu_129866_p2() {
    xor_ln340_893_fu_129866_p2 = (tmp_3184_fu_129833_p3.read() ^ tmp_3185_fu_129846_p3.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln340_894_fu_129954_p2() {
    xor_ln340_894_fu_129954_p2 = (tmp_3191_fu_129921_p3.read() ^ tmp_3192_fu_129934_p3.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln340_895_fu_130213_p2() {
    xor_ln340_895_fu_130213_p2 = (tmp_3198_fu_130179_p3.read() ^ tmp_3199_fu_130193_p3.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln340_896_fu_130301_p2() {
    xor_ln340_896_fu_130301_p2 = (tmp_3205_fu_130268_p3.read() ^ tmp_3206_fu_130281_p3.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln340_897_fu_130389_p2() {
    xor_ln340_897_fu_130389_p2 = (tmp_3212_fu_130356_p3.read() ^ tmp_3213_fu_130369_p3.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln340_898_fu_130477_p2() {
    xor_ln340_898_fu_130477_p2 = (tmp_3219_fu_130444_p3.read() ^ tmp_3220_fu_130457_p3.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln340_899_fu_130565_p2() {
    xor_ln340_899_fu_130565_p2 = (tmp_3226_fu_130532_p3.read() ^ tmp_3227_fu_130545_p3.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln340_89_fu_102637_p2() {
    xor_ln340_89_fu_102637_p2 = (tmp_1140_fu_102598_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln340_8_fu_95161_p2() {
    xor_ln340_8_fu_95161_p2 = (tmp_573_fu_95122_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln340_900_fu_130653_p2() {
    xor_ln340_900_fu_130653_p2 = (tmp_3233_fu_130620_p3.read() ^ tmp_3234_fu_130633_p3.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln340_901_fu_130741_p2() {
    xor_ln340_901_fu_130741_p2 = (tmp_3240_fu_130708_p3.read() ^ tmp_3241_fu_130721_p3.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln340_902_fu_130829_p2() {
    xor_ln340_902_fu_130829_p2 = (tmp_3247_fu_130796_p3.read() ^ tmp_3248_fu_130809_p3.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln340_903_fu_130917_p2() {
    xor_ln340_903_fu_130917_p2 = (tmp_3254_fu_130884_p3.read() ^ tmp_3255_fu_130897_p3.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln340_904_fu_131005_p2() {
    xor_ln340_904_fu_131005_p2 = (tmp_3261_fu_130972_p3.read() ^ tmp_3262_fu_130985_p3.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln340_905_fu_131093_p2() {
    xor_ln340_905_fu_131093_p2 = (tmp_3268_fu_131060_p3.read() ^ tmp_3269_fu_131073_p3.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln340_906_fu_131181_p2() {
    xor_ln340_906_fu_131181_p2 = (tmp_3275_fu_131148_p3.read() ^ tmp_3276_fu_131161_p3.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln340_907_fu_131269_p2() {
    xor_ln340_907_fu_131269_p2 = (tmp_3282_fu_131236_p3.read() ^ tmp_3283_fu_131249_p3.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln340_908_fu_131357_p2() {
    xor_ln340_908_fu_131357_p2 = (tmp_3289_fu_131324_p3.read() ^ tmp_3290_fu_131337_p3.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln340_909_fu_131445_p2() {
    xor_ln340_909_fu_131445_p2 = (tmp_3296_fu_131412_p3.read() ^ tmp_3297_fu_131425_p3.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln340_90_fu_102725_p2() {
    xor_ln340_90_fu_102725_p2 = (tmp_1147_fu_102686_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln340_910_fu_131533_p2() {
    xor_ln340_910_fu_131533_p2 = (tmp_3303_fu_131500_p3.read() ^ tmp_3304_fu_131513_p3.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln340_911_fu_131621_p2() {
    xor_ln340_911_fu_131621_p2 = (tmp_3310_fu_131588_p3.read() ^ tmp_3311_fu_131601_p3.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln340_912_fu_131709_p2() {
    xor_ln340_912_fu_131709_p2 = (tmp_3317_fu_131676_p3.read() ^ tmp_3318_fu_131689_p3.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln340_913_fu_131797_p2() {
    xor_ln340_913_fu_131797_p2 = (tmp_3324_fu_131764_p3.read() ^ tmp_3325_fu_131777_p3.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln340_914_fu_131885_p2() {
    xor_ln340_914_fu_131885_p2 = (tmp_3331_fu_131852_p3.read() ^ tmp_3332_fu_131865_p3.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln340_915_fu_131973_p2() {
    xor_ln340_915_fu_131973_p2 = (tmp_3338_fu_131940_p3.read() ^ tmp_3339_fu_131953_p3.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln340_916_fu_132061_p2() {
    xor_ln340_916_fu_132061_p2 = (tmp_3345_fu_132028_p3.read() ^ tmp_3346_fu_132041_p3.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln340_917_fu_132149_p2() {
    xor_ln340_917_fu_132149_p2 = (tmp_3352_fu_132116_p3.read() ^ tmp_3353_fu_132129_p3.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln340_918_fu_132237_p2() {
    xor_ln340_918_fu_132237_p2 = (tmp_3359_fu_132204_p3.read() ^ tmp_3360_fu_132217_p3.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln340_919_fu_132325_p2() {
    xor_ln340_919_fu_132325_p2 = (tmp_3366_fu_132292_p3.read() ^ tmp_3367_fu_132305_p3.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln340_91_fu_102813_p2() {
    xor_ln340_91_fu_102813_p2 = (tmp_1154_fu_102774_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln340_920_fu_132413_p2() {
    xor_ln340_920_fu_132413_p2 = (tmp_3373_fu_132380_p3.read() ^ tmp_3374_fu_132393_p3.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln340_921_fu_132501_p2() {
    xor_ln340_921_fu_132501_p2 = (tmp_3380_fu_132468_p3.read() ^ tmp_3381_fu_132481_p3.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln340_922_fu_132589_p2() {
    xor_ln340_922_fu_132589_p2 = (tmp_3387_fu_132556_p3.read() ^ tmp_3388_fu_132569_p3.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln340_923_fu_132677_p2() {
    xor_ln340_923_fu_132677_p2 = (tmp_3394_fu_132644_p3.read() ^ tmp_3395_fu_132657_p3.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln340_924_fu_132765_p2() {
    xor_ln340_924_fu_132765_p2 = (tmp_3401_fu_132732_p3.read() ^ tmp_3402_fu_132745_p3.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln340_925_fu_132853_p2() {
    xor_ln340_925_fu_132853_p2 = (tmp_3408_fu_132820_p3.read() ^ tmp_3409_fu_132833_p3.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln340_926_fu_132941_p2() {
    xor_ln340_926_fu_132941_p2 = (tmp_3415_fu_132908_p3.read() ^ tmp_3416_fu_132921_p3.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln340_927_fu_133200_p2() {
    xor_ln340_927_fu_133200_p2 = (tmp_3422_fu_133166_p3.read() ^ tmp_3423_fu_133180_p3.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln340_928_fu_133288_p2() {
    xor_ln340_928_fu_133288_p2 = (tmp_3429_fu_133255_p3.read() ^ tmp_3430_fu_133268_p3.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln340_929_fu_133376_p2() {
    xor_ln340_929_fu_133376_p2 = (tmp_3436_fu_133343_p3.read() ^ tmp_3437_fu_133356_p3.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln340_92_fu_102901_p2() {
    xor_ln340_92_fu_102901_p2 = (tmp_1161_fu_102862_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln340_930_fu_133464_p2() {
    xor_ln340_930_fu_133464_p2 = (tmp_3443_fu_133431_p3.read() ^ tmp_3444_fu_133444_p3.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln340_931_fu_133552_p2() {
    xor_ln340_931_fu_133552_p2 = (tmp_3450_fu_133519_p3.read() ^ tmp_3451_fu_133532_p3.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln340_932_fu_133640_p2() {
    xor_ln340_932_fu_133640_p2 = (tmp_3457_fu_133607_p3.read() ^ tmp_3458_fu_133620_p3.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln340_933_fu_133728_p2() {
    xor_ln340_933_fu_133728_p2 = (tmp_3464_fu_133695_p3.read() ^ tmp_3465_fu_133708_p3.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln340_934_fu_133816_p2() {
    xor_ln340_934_fu_133816_p2 = (tmp_3471_fu_133783_p3.read() ^ tmp_3472_fu_133796_p3.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln340_935_fu_133904_p2() {
    xor_ln340_935_fu_133904_p2 = (tmp_3478_fu_133871_p3.read() ^ tmp_3479_fu_133884_p3.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln340_936_fu_133992_p2() {
    xor_ln340_936_fu_133992_p2 = (tmp_3485_fu_133959_p3.read() ^ tmp_3486_fu_133972_p3.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln340_937_fu_134080_p2() {
    xor_ln340_937_fu_134080_p2 = (tmp_3492_fu_134047_p3.read() ^ tmp_3493_fu_134060_p3.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln340_938_fu_134168_p2() {
    xor_ln340_938_fu_134168_p2 = (tmp_3499_fu_134135_p3.read() ^ tmp_3500_fu_134148_p3.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln340_939_fu_134256_p2() {
    xor_ln340_939_fu_134256_p2 = (tmp_3506_fu_134223_p3.read() ^ tmp_3507_fu_134236_p3.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln340_93_fu_102989_p2() {
    xor_ln340_93_fu_102989_p2 = (tmp_1168_fu_102950_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln340_940_fu_134344_p2() {
    xor_ln340_940_fu_134344_p2 = (tmp_3513_fu_134311_p3.read() ^ tmp_3514_fu_134324_p3.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln340_941_fu_134432_p2() {
    xor_ln340_941_fu_134432_p2 = (tmp_3520_fu_134399_p3.read() ^ tmp_3521_fu_134412_p3.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln340_942_fu_134520_p2() {
    xor_ln340_942_fu_134520_p2 = (tmp_3527_fu_134487_p3.read() ^ tmp_3528_fu_134500_p3.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln340_943_fu_134608_p2() {
    xor_ln340_943_fu_134608_p2 = (tmp_3534_fu_134575_p3.read() ^ tmp_3535_fu_134588_p3.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln340_944_fu_134696_p2() {
    xor_ln340_944_fu_134696_p2 = (tmp_3541_fu_134663_p3.read() ^ tmp_3542_fu_134676_p3.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln340_945_fu_134784_p2() {
    xor_ln340_945_fu_134784_p2 = (tmp_3548_fu_134751_p3.read() ^ tmp_3549_fu_134764_p3.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln340_946_fu_134872_p2() {
    xor_ln340_946_fu_134872_p2 = (tmp_3555_fu_134839_p3.read() ^ tmp_3556_fu_134852_p3.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln340_947_fu_134960_p2() {
    xor_ln340_947_fu_134960_p2 = (tmp_3562_fu_134927_p3.read() ^ tmp_3563_fu_134940_p3.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln340_948_fu_135048_p2() {
    xor_ln340_948_fu_135048_p2 = (tmp_3569_fu_135015_p3.read() ^ tmp_3570_fu_135028_p3.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln340_949_fu_135136_p2() {
    xor_ln340_949_fu_135136_p2 = (tmp_3576_fu_135103_p3.read() ^ tmp_3577_fu_135116_p3.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln340_94_fu_103077_p2() {
    xor_ln340_94_fu_103077_p2 = (tmp_1175_fu_103038_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln340_950_fu_135224_p2() {
    xor_ln340_950_fu_135224_p2 = (tmp_3583_fu_135191_p3.read() ^ tmp_3584_fu_135204_p3.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln340_951_fu_135312_p2() {
    xor_ln340_951_fu_135312_p2 = (tmp_3590_fu_135279_p3.read() ^ tmp_3591_fu_135292_p3.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln340_952_fu_135400_p2() {
    xor_ln340_952_fu_135400_p2 = (tmp_3597_fu_135367_p3.read() ^ tmp_3598_fu_135380_p3.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln340_953_fu_135488_p2() {
    xor_ln340_953_fu_135488_p2 = (tmp_3604_fu_135455_p3.read() ^ tmp_3605_fu_135468_p3.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln340_954_fu_135576_p2() {
    xor_ln340_954_fu_135576_p2 = (tmp_3611_fu_135543_p3.read() ^ tmp_3612_fu_135556_p3.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln340_955_fu_135664_p2() {
    xor_ln340_955_fu_135664_p2 = (tmp_3618_fu_135631_p3.read() ^ tmp_3619_fu_135644_p3.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln340_956_fu_135752_p2() {
    xor_ln340_956_fu_135752_p2 = (tmp_3625_fu_135719_p3.read() ^ tmp_3626_fu_135732_p3.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln340_957_fu_135840_p2() {
    xor_ln340_957_fu_135840_p2 = (tmp_3632_fu_135807_p3.read() ^ tmp_3633_fu_135820_p3.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln340_958_fu_135928_p2() {
    xor_ln340_958_fu_135928_p2 = (tmp_3639_fu_135895_p3.read() ^ tmp_3640_fu_135908_p3.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln340_959_fu_136187_p2() {
    xor_ln340_959_fu_136187_p2 = (tmp_3646_fu_136153_p3.read() ^ tmp_3647_fu_136167_p3.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln340_95_fu_103336_p2() {
    xor_ln340_95_fu_103336_p2 = (tmp_1182_fu_103296_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln340_960_fu_136275_p2() {
    xor_ln340_960_fu_136275_p2 = (tmp_3653_fu_136242_p3.read() ^ tmp_3654_fu_136255_p3.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln340_961_fu_136363_p2() {
    xor_ln340_961_fu_136363_p2 = (tmp_3660_fu_136330_p3.read() ^ tmp_3661_fu_136343_p3.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln340_962_fu_136451_p2() {
    xor_ln340_962_fu_136451_p2 = (tmp_3667_fu_136418_p3.read() ^ tmp_3668_fu_136431_p3.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln340_963_fu_136539_p2() {
    xor_ln340_963_fu_136539_p2 = (tmp_3674_fu_136506_p3.read() ^ tmp_3675_fu_136519_p3.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln340_964_fu_136627_p2() {
    xor_ln340_964_fu_136627_p2 = (tmp_3681_fu_136594_p3.read() ^ tmp_3682_fu_136607_p3.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln340_965_fu_136715_p2() {
    xor_ln340_965_fu_136715_p2 = (tmp_3688_fu_136682_p3.read() ^ tmp_3689_fu_136695_p3.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln340_966_fu_136803_p2() {
    xor_ln340_966_fu_136803_p2 = (tmp_3695_fu_136770_p3.read() ^ tmp_3696_fu_136783_p3.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln340_967_fu_136891_p2() {
    xor_ln340_967_fu_136891_p2 = (tmp_3702_fu_136858_p3.read() ^ tmp_3703_fu_136871_p3.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln340_968_fu_136979_p2() {
    xor_ln340_968_fu_136979_p2 = (tmp_3709_fu_136946_p3.read() ^ tmp_3710_fu_136959_p3.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln340_969_fu_137067_p2() {
    xor_ln340_969_fu_137067_p2 = (tmp_3716_fu_137034_p3.read() ^ tmp_3717_fu_137047_p3.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln340_96_fu_103424_p2() {
    xor_ln340_96_fu_103424_p2 = (tmp_1189_fu_103385_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln340_970_fu_137155_p2() {
    xor_ln340_970_fu_137155_p2 = (tmp_3723_fu_137122_p3.read() ^ tmp_3724_fu_137135_p3.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln340_971_fu_137243_p2() {
    xor_ln340_971_fu_137243_p2 = (tmp_3730_fu_137210_p3.read() ^ tmp_3731_fu_137223_p3.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln340_972_fu_137331_p2() {
    xor_ln340_972_fu_137331_p2 = (tmp_3737_fu_137298_p3.read() ^ tmp_3738_fu_137311_p3.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln340_973_fu_137419_p2() {
    xor_ln340_973_fu_137419_p2 = (tmp_3744_fu_137386_p3.read() ^ tmp_3745_fu_137399_p3.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln340_974_fu_137507_p2() {
    xor_ln340_974_fu_137507_p2 = (tmp_3751_fu_137474_p3.read() ^ tmp_3752_fu_137487_p3.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln340_975_fu_137595_p2() {
    xor_ln340_975_fu_137595_p2 = (tmp_3758_fu_137562_p3.read() ^ tmp_3759_fu_137575_p3.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln340_976_fu_137683_p2() {
    xor_ln340_976_fu_137683_p2 = (tmp_3765_fu_137650_p3.read() ^ tmp_3766_fu_137663_p3.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln340_977_fu_137771_p2() {
    xor_ln340_977_fu_137771_p2 = (tmp_3772_fu_137738_p3.read() ^ tmp_3773_fu_137751_p3.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln340_978_fu_137859_p2() {
    xor_ln340_978_fu_137859_p2 = (tmp_3779_fu_137826_p3.read() ^ tmp_3780_fu_137839_p3.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln340_979_fu_137947_p2() {
    xor_ln340_979_fu_137947_p2 = (tmp_3786_fu_137914_p3.read() ^ tmp_3787_fu_137927_p3.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln340_97_fu_103512_p2() {
    xor_ln340_97_fu_103512_p2 = (tmp_1196_fu_103473_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln340_980_fu_138035_p2() {
    xor_ln340_980_fu_138035_p2 = (tmp_3793_fu_138002_p3.read() ^ tmp_3794_fu_138015_p3.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln340_981_fu_138123_p2() {
    xor_ln340_981_fu_138123_p2 = (tmp_3800_fu_138090_p3.read() ^ tmp_3801_fu_138103_p3.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln340_982_fu_138211_p2() {
    xor_ln340_982_fu_138211_p2 = (tmp_3807_fu_138178_p3.read() ^ tmp_3808_fu_138191_p3.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln340_983_fu_138299_p2() {
    xor_ln340_983_fu_138299_p2 = (tmp_3814_fu_138266_p3.read() ^ tmp_3815_fu_138279_p3.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln340_984_fu_138387_p2() {
    xor_ln340_984_fu_138387_p2 = (tmp_3821_fu_138354_p3.read() ^ tmp_3822_fu_138367_p3.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln340_985_fu_138475_p2() {
    xor_ln340_985_fu_138475_p2 = (tmp_3828_fu_138442_p3.read() ^ tmp_3829_fu_138455_p3.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln340_986_fu_138563_p2() {
    xor_ln340_986_fu_138563_p2 = (tmp_3835_fu_138530_p3.read() ^ tmp_3836_fu_138543_p3.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln340_987_fu_138651_p2() {
    xor_ln340_987_fu_138651_p2 = (tmp_3842_fu_138618_p3.read() ^ tmp_3843_fu_138631_p3.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln340_988_fu_138739_p2() {
    xor_ln340_988_fu_138739_p2 = (tmp_3849_fu_138706_p3.read() ^ tmp_3850_fu_138719_p3.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln340_989_fu_138827_p2() {
    xor_ln340_989_fu_138827_p2 = (tmp_3856_fu_138794_p3.read() ^ tmp_3857_fu_138807_p3.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln340_98_fu_103600_p2() {
    xor_ln340_98_fu_103600_p2 = (tmp_1203_fu_103561_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln340_990_fu_138915_p2() {
    xor_ln340_990_fu_138915_p2 = (tmp_3863_fu_138882_p3.read() ^ tmp_3864_fu_138895_p3.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln340_991_fu_139174_p2() {
    xor_ln340_991_fu_139174_p2 = (tmp_3870_fu_139140_p3.read() ^ tmp_3871_fu_139154_p3.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln340_992_fu_139262_p2() {
    xor_ln340_992_fu_139262_p2 = (tmp_3877_fu_139229_p3.read() ^ tmp_3878_fu_139242_p3.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln340_993_fu_139350_p2() {
    xor_ln340_993_fu_139350_p2 = (tmp_3884_fu_139317_p3.read() ^ tmp_3885_fu_139330_p3.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln340_994_fu_139438_p2() {
    xor_ln340_994_fu_139438_p2 = (tmp_3891_fu_139405_p3.read() ^ tmp_3892_fu_139418_p3.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln340_995_fu_139526_p2() {
    xor_ln340_995_fu_139526_p2 = (tmp_3898_fu_139493_p3.read() ^ tmp_3899_fu_139506_p3.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln340_996_fu_139614_p2() {
    xor_ln340_996_fu_139614_p2 = (tmp_3905_fu_139581_p3.read() ^ tmp_3906_fu_139594_p3.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln340_997_fu_139702_p2() {
    xor_ln340_997_fu_139702_p2 = (tmp_3912_fu_139669_p3.read() ^ tmp_3913_fu_139682_p3.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln340_998_fu_139790_p2() {
    xor_ln340_998_fu_139790_p2 = (tmp_3919_fu_139757_p3.read() ^ tmp_3920_fu_139770_p3.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln340_999_fu_139878_p2() {
    xor_ln340_999_fu_139878_p2 = (tmp_3926_fu_139845_p3.read() ^ tmp_3927_fu_139858_p3.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln340_99_fu_103688_p2() {
    xor_ln340_99_fu_103688_p2 = (tmp_1210_fu_103649_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln340_9_fu_95249_p2() {
    xor_ln340_9_fu_95249_p2 = (tmp_580_fu_95210_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln340_fu_94457_p2() {
    xor_ln340_fu_94457_p2 = (tmp_517_fu_94418_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_100_fu_22517_p2() {
    xor_ln416_100_fu_22517_p2 = (tmp_1215_fu_22509_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_101_fu_22697_p2() {
    xor_ln416_101_fu_22697_p2 = (tmp_1222_fu_22689_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_102_fu_22877_p2() {
    xor_ln416_102_fu_22877_p2 = (tmp_1229_fu_22869_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_103_fu_23057_p2() {
    xor_ln416_103_fu_23057_p2 = (tmp_1236_fu_23049_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_104_fu_23237_p2() {
    xor_ln416_104_fu_23237_p2 = (tmp_1243_fu_23229_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_105_fu_23417_p2() {
    xor_ln416_105_fu_23417_p2 = (tmp_1250_fu_23409_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_106_fu_23597_p2() {
    xor_ln416_106_fu_23597_p2 = (tmp_1257_fu_23589_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_107_fu_23777_p2() {
    xor_ln416_107_fu_23777_p2 = (tmp_1264_fu_23769_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_108_fu_23957_p2() {
    xor_ln416_108_fu_23957_p2 = (tmp_1271_fu_23949_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_109_fu_24137_p2() {
    xor_ln416_109_fu_24137_p2 = (tmp_1278_fu_24129_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_10_fu_6579_p2() {
    xor_ln416_10_fu_6579_p2 = (tmp_585_fu_6571_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_110_fu_24317_p2() {
    xor_ln416_110_fu_24317_p2 = (tmp_1285_fu_24309_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_111_fu_24497_p2() {
    xor_ln416_111_fu_24497_p2 = (tmp_1292_fu_24489_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_112_fu_24677_p2() {
    xor_ln416_112_fu_24677_p2 = (tmp_1299_fu_24669_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_113_fu_24857_p2() {
    xor_ln416_113_fu_24857_p2 = (tmp_1306_fu_24849_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_114_fu_25037_p2() {
    xor_ln416_114_fu_25037_p2 = (tmp_1313_fu_25029_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_115_fu_25217_p2() {
    xor_ln416_115_fu_25217_p2 = (tmp_1320_fu_25209_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_116_fu_25397_p2() {
    xor_ln416_116_fu_25397_p2 = (tmp_1327_fu_25389_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_117_fu_25577_p2() {
    xor_ln416_117_fu_25577_p2 = (tmp_1334_fu_25569_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_118_fu_25757_p2() {
    xor_ln416_118_fu_25757_p2 = (tmp_1341_fu_25749_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_119_fu_25937_p2() {
    xor_ln416_119_fu_25937_p2 = (tmp_1348_fu_25929_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_11_fu_6771_p2() {
    xor_ln416_11_fu_6771_p2 = (tmp_592_fu_6763_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_120_fu_26117_p2() {
    xor_ln416_120_fu_26117_p2 = (tmp_1355_fu_26109_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_121_fu_26297_p2() {
    xor_ln416_121_fu_26297_p2 = (tmp_1362_fu_26289_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_122_fu_26477_p2() {
    xor_ln416_122_fu_26477_p2 = (tmp_1369_fu_26469_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_123_fu_26657_p2() {
    xor_ln416_123_fu_26657_p2 = (tmp_1376_fu_26649_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_124_fu_26837_p2() {
    xor_ln416_124_fu_26837_p2 = (tmp_1383_fu_26829_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_125_fu_27017_p2() {
    xor_ln416_125_fu_27017_p2 = (tmp_1390_fu_27009_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_126_fu_27197_p2() {
    xor_ln416_126_fu_27197_p2 = (tmp_1397_fu_27189_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_127_fu_106151_p2() {
    xor_ln416_127_fu_106151_p2 = (tmp_1404_fu_106143_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_128_fu_27387_p2() {
    xor_ln416_128_fu_27387_p2 = (tmp_1411_fu_27379_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_129_fu_27567_p2() {
    xor_ln416_129_fu_27567_p2 = (tmp_1418_fu_27559_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_12_fu_6963_p2() {
    xor_ln416_12_fu_6963_p2 = (tmp_599_fu_6955_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_130_fu_27747_p2() {
    xor_ln416_130_fu_27747_p2 = (tmp_1425_fu_27739_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_131_fu_27927_p2() {
    xor_ln416_131_fu_27927_p2 = (tmp_1432_fu_27919_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_132_fu_28107_p2() {
    xor_ln416_132_fu_28107_p2 = (tmp_1439_fu_28099_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_133_fu_28287_p2() {
    xor_ln416_133_fu_28287_p2 = (tmp_1446_fu_28279_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_134_fu_28467_p2() {
    xor_ln416_134_fu_28467_p2 = (tmp_1453_fu_28459_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_135_fu_28647_p2() {
    xor_ln416_135_fu_28647_p2 = (tmp_1460_fu_28639_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_136_fu_28827_p2() {
    xor_ln416_136_fu_28827_p2 = (tmp_1467_fu_28819_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_137_fu_29007_p2() {
    xor_ln416_137_fu_29007_p2 = (tmp_1474_fu_28999_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_138_fu_29187_p2() {
    xor_ln416_138_fu_29187_p2 = (tmp_1481_fu_29179_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_139_fu_29367_p2() {
    xor_ln416_139_fu_29367_p2 = (tmp_1488_fu_29359_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_13_fu_7155_p2() {
    xor_ln416_13_fu_7155_p2 = (tmp_606_fu_7147_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_140_fu_29547_p2() {
    xor_ln416_140_fu_29547_p2 = (tmp_1495_fu_29539_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_141_fu_29727_p2() {
    xor_ln416_141_fu_29727_p2 = (tmp_1502_fu_29719_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_142_fu_29907_p2() {
    xor_ln416_142_fu_29907_p2 = (tmp_1509_fu_29899_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_143_fu_30087_p2() {
    xor_ln416_143_fu_30087_p2 = (tmp_1516_fu_30079_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_144_fu_30267_p2() {
    xor_ln416_144_fu_30267_p2 = (tmp_1523_fu_30259_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_145_fu_30447_p2() {
    xor_ln416_145_fu_30447_p2 = (tmp_1530_fu_30439_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_146_fu_30627_p2() {
    xor_ln416_146_fu_30627_p2 = (tmp_1537_fu_30619_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_147_fu_30807_p2() {
    xor_ln416_147_fu_30807_p2 = (tmp_1544_fu_30799_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_148_fu_30987_p2() {
    xor_ln416_148_fu_30987_p2 = (tmp_1551_fu_30979_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_149_fu_31167_p2() {
    xor_ln416_149_fu_31167_p2 = (tmp_1558_fu_31159_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_14_fu_7347_p2() {
    xor_ln416_14_fu_7347_p2 = (tmp_613_fu_7339_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_150_fu_31347_p2() {
    xor_ln416_150_fu_31347_p2 = (tmp_1565_fu_31339_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_151_fu_31527_p2() {
    xor_ln416_151_fu_31527_p2 = (tmp_1572_fu_31519_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_152_fu_31707_p2() {
    xor_ln416_152_fu_31707_p2 = (tmp_1579_fu_31699_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_153_fu_31887_p2() {
    xor_ln416_153_fu_31887_p2 = (tmp_1586_fu_31879_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_154_fu_32067_p2() {
    xor_ln416_154_fu_32067_p2 = (tmp_1593_fu_32059_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_155_fu_32247_p2() {
    xor_ln416_155_fu_32247_p2 = (tmp_1600_fu_32239_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_156_fu_32427_p2() {
    xor_ln416_156_fu_32427_p2 = (tmp_1607_fu_32419_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_157_fu_32607_p2() {
    xor_ln416_157_fu_32607_p2 = (tmp_1614_fu_32599_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_158_fu_32787_p2() {
    xor_ln416_158_fu_32787_p2 = (tmp_1621_fu_32779_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_159_fu_109138_p2() {
    xor_ln416_159_fu_109138_p2 = (tmp_1628_fu_109130_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_15_fu_7539_p2() {
    xor_ln416_15_fu_7539_p2 = (tmp_620_fu_7531_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_160_fu_32977_p2() {
    xor_ln416_160_fu_32977_p2 = (tmp_1635_fu_32969_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_161_fu_33157_p2() {
    xor_ln416_161_fu_33157_p2 = (tmp_1642_fu_33149_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_162_fu_33337_p2() {
    xor_ln416_162_fu_33337_p2 = (tmp_1649_fu_33329_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_163_fu_33517_p2() {
    xor_ln416_163_fu_33517_p2 = (tmp_1656_fu_33509_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_164_fu_33697_p2() {
    xor_ln416_164_fu_33697_p2 = (tmp_1663_fu_33689_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_165_fu_33877_p2() {
    xor_ln416_165_fu_33877_p2 = (tmp_1670_fu_33869_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_166_fu_34057_p2() {
    xor_ln416_166_fu_34057_p2 = (tmp_1677_fu_34049_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_167_fu_34237_p2() {
    xor_ln416_167_fu_34237_p2 = (tmp_1684_fu_34229_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_168_fu_34417_p2() {
    xor_ln416_168_fu_34417_p2 = (tmp_1691_fu_34409_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_169_fu_34597_p2() {
    xor_ln416_169_fu_34597_p2 = (tmp_1698_fu_34589_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_16_fu_7731_p2() {
    xor_ln416_16_fu_7731_p2 = (tmp_627_fu_7723_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_170_fu_34777_p2() {
    xor_ln416_170_fu_34777_p2 = (tmp_1705_fu_34769_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_171_fu_34957_p2() {
    xor_ln416_171_fu_34957_p2 = (tmp_1712_fu_34949_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_172_fu_35137_p2() {
    xor_ln416_172_fu_35137_p2 = (tmp_1719_fu_35129_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_173_fu_35317_p2() {
    xor_ln416_173_fu_35317_p2 = (tmp_1726_fu_35309_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_174_fu_35497_p2() {
    xor_ln416_174_fu_35497_p2 = (tmp_1733_fu_35489_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_175_fu_35677_p2() {
    xor_ln416_175_fu_35677_p2 = (tmp_1740_fu_35669_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_176_fu_35857_p2() {
    xor_ln416_176_fu_35857_p2 = (tmp_1747_fu_35849_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_177_fu_36037_p2() {
    xor_ln416_177_fu_36037_p2 = (tmp_1754_fu_36029_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_178_fu_36217_p2() {
    xor_ln416_178_fu_36217_p2 = (tmp_1761_fu_36209_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_179_fu_36397_p2() {
    xor_ln416_179_fu_36397_p2 = (tmp_1768_fu_36389_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_17_fu_7923_p2() {
    xor_ln416_17_fu_7923_p2 = (tmp_634_fu_7915_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_180_fu_36577_p2() {
    xor_ln416_180_fu_36577_p2 = (tmp_1775_fu_36569_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_181_fu_36757_p2() {
    xor_ln416_181_fu_36757_p2 = (tmp_1782_fu_36749_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_182_fu_36937_p2() {
    xor_ln416_182_fu_36937_p2 = (tmp_1789_fu_36929_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_183_fu_37117_p2() {
    xor_ln416_183_fu_37117_p2 = (tmp_1796_fu_37109_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_184_fu_37297_p2() {
    xor_ln416_184_fu_37297_p2 = (tmp_1803_fu_37289_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_185_fu_37477_p2() {
    xor_ln416_185_fu_37477_p2 = (tmp_1810_fu_37469_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_186_fu_37657_p2() {
    xor_ln416_186_fu_37657_p2 = (tmp_1817_fu_37649_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_187_fu_37837_p2() {
    xor_ln416_187_fu_37837_p2 = (tmp_1824_fu_37829_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_188_fu_38017_p2() {
    xor_ln416_188_fu_38017_p2 = (tmp_1831_fu_38009_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_189_fu_38197_p2() {
    xor_ln416_189_fu_38197_p2 = (tmp_1838_fu_38189_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_18_fu_8115_p2() {
    xor_ln416_18_fu_8115_p2 = (tmp_641_fu_8107_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_190_fu_38377_p2() {
    xor_ln416_190_fu_38377_p2 = (tmp_1845_fu_38369_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_191_fu_112125_p2() {
    xor_ln416_191_fu_112125_p2 = (tmp_1852_fu_112117_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_192_fu_38567_p2() {
    xor_ln416_192_fu_38567_p2 = (tmp_1859_fu_38559_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_193_fu_38747_p2() {
    xor_ln416_193_fu_38747_p2 = (tmp_1866_fu_38739_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_194_fu_38927_p2() {
    xor_ln416_194_fu_38927_p2 = (tmp_1873_fu_38919_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_195_fu_39107_p2() {
    xor_ln416_195_fu_39107_p2 = (tmp_1880_fu_39099_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_196_fu_39287_p2() {
    xor_ln416_196_fu_39287_p2 = (tmp_1887_fu_39279_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_197_fu_39467_p2() {
    xor_ln416_197_fu_39467_p2 = (tmp_1894_fu_39459_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_198_fu_39647_p2() {
    xor_ln416_198_fu_39647_p2 = (tmp_1901_fu_39639_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_199_fu_39827_p2() {
    xor_ln416_199_fu_39827_p2 = (tmp_1908_fu_39819_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_19_fu_8307_p2() {
    xor_ln416_19_fu_8307_p2 = (tmp_648_fu_8299_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_1_fu_4851_p2() {
    xor_ln416_1_fu_4851_p2 = (tmp_522_fu_4843_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_200_fu_40007_p2() {
    xor_ln416_200_fu_40007_p2 = (tmp_1915_fu_39999_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_201_fu_40187_p2() {
    xor_ln416_201_fu_40187_p2 = (tmp_1922_fu_40179_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_202_fu_40367_p2() {
    xor_ln416_202_fu_40367_p2 = (tmp_1929_fu_40359_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_203_fu_40547_p2() {
    xor_ln416_203_fu_40547_p2 = (tmp_1936_fu_40539_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_204_fu_40727_p2() {
    xor_ln416_204_fu_40727_p2 = (tmp_1943_fu_40719_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_205_fu_40907_p2() {
    xor_ln416_205_fu_40907_p2 = (tmp_1950_fu_40899_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_206_fu_41087_p2() {
    xor_ln416_206_fu_41087_p2 = (tmp_1957_fu_41079_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_207_fu_41267_p2() {
    xor_ln416_207_fu_41267_p2 = (tmp_1964_fu_41259_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_208_fu_41447_p2() {
    xor_ln416_208_fu_41447_p2 = (tmp_1971_fu_41439_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_209_fu_41627_p2() {
    xor_ln416_209_fu_41627_p2 = (tmp_1978_fu_41619_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_20_fu_8499_p2() {
    xor_ln416_20_fu_8499_p2 = (tmp_655_fu_8491_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_210_fu_41807_p2() {
    xor_ln416_210_fu_41807_p2 = (tmp_1985_fu_41799_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_211_fu_41987_p2() {
    xor_ln416_211_fu_41987_p2 = (tmp_1992_fu_41979_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_212_fu_42167_p2() {
    xor_ln416_212_fu_42167_p2 = (tmp_1999_fu_42159_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_213_fu_42347_p2() {
    xor_ln416_213_fu_42347_p2 = (tmp_2006_fu_42339_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_214_fu_42527_p2() {
    xor_ln416_214_fu_42527_p2 = (tmp_2013_fu_42519_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_215_fu_42707_p2() {
    xor_ln416_215_fu_42707_p2 = (tmp_2020_fu_42699_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_216_fu_42887_p2() {
    xor_ln416_216_fu_42887_p2 = (tmp_2027_fu_42879_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_217_fu_43067_p2() {
    xor_ln416_217_fu_43067_p2 = (tmp_2034_fu_43059_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_218_fu_43247_p2() {
    xor_ln416_218_fu_43247_p2 = (tmp_2041_fu_43239_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_219_fu_43427_p2() {
    xor_ln416_219_fu_43427_p2 = (tmp_2048_fu_43419_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_21_fu_8691_p2() {
    xor_ln416_21_fu_8691_p2 = (tmp_662_fu_8683_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_220_fu_43607_p2() {
    xor_ln416_220_fu_43607_p2 = (tmp_2055_fu_43599_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_221_fu_43787_p2() {
    xor_ln416_221_fu_43787_p2 = (tmp_2062_fu_43779_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_222_fu_43967_p2() {
    xor_ln416_222_fu_43967_p2 = (tmp_2069_fu_43959_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_223_fu_115112_p2() {
    xor_ln416_223_fu_115112_p2 = (tmp_2076_fu_115104_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_224_fu_44157_p2() {
    xor_ln416_224_fu_44157_p2 = (tmp_2083_fu_44149_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_225_fu_44337_p2() {
    xor_ln416_225_fu_44337_p2 = (tmp_2090_fu_44329_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_226_fu_44517_p2() {
    xor_ln416_226_fu_44517_p2 = (tmp_2097_fu_44509_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_227_fu_44697_p2() {
    xor_ln416_227_fu_44697_p2 = (tmp_2104_fu_44689_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_228_fu_44877_p2() {
    xor_ln416_228_fu_44877_p2 = (tmp_2111_fu_44869_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_229_fu_45057_p2() {
    xor_ln416_229_fu_45057_p2 = (tmp_2118_fu_45049_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_22_fu_8883_p2() {
    xor_ln416_22_fu_8883_p2 = (tmp_669_fu_8875_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_230_fu_45237_p2() {
    xor_ln416_230_fu_45237_p2 = (tmp_2125_fu_45229_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_231_fu_45417_p2() {
    xor_ln416_231_fu_45417_p2 = (tmp_2132_fu_45409_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_232_fu_45597_p2() {
    xor_ln416_232_fu_45597_p2 = (tmp_2139_fu_45589_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_233_fu_45777_p2() {
    xor_ln416_233_fu_45777_p2 = (tmp_2146_fu_45769_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_234_fu_45957_p2() {
    xor_ln416_234_fu_45957_p2 = (tmp_2153_fu_45949_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_235_fu_46137_p2() {
    xor_ln416_235_fu_46137_p2 = (tmp_2160_fu_46129_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_236_fu_46317_p2() {
    xor_ln416_236_fu_46317_p2 = (tmp_2167_fu_46309_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_237_fu_46497_p2() {
    xor_ln416_237_fu_46497_p2 = (tmp_2174_fu_46489_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_238_fu_46677_p2() {
    xor_ln416_238_fu_46677_p2 = (tmp_2181_fu_46669_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_239_fu_46857_p2() {
    xor_ln416_239_fu_46857_p2 = (tmp_2188_fu_46849_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_23_fu_9075_p2() {
    xor_ln416_23_fu_9075_p2 = (tmp_676_fu_9067_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_240_fu_47037_p2() {
    xor_ln416_240_fu_47037_p2 = (tmp_2195_fu_47029_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_241_fu_47217_p2() {
    xor_ln416_241_fu_47217_p2 = (tmp_2202_fu_47209_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_242_fu_47397_p2() {
    xor_ln416_242_fu_47397_p2 = (tmp_2209_fu_47389_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_243_fu_47577_p2() {
    xor_ln416_243_fu_47577_p2 = (tmp_2216_fu_47569_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_244_fu_47757_p2() {
    xor_ln416_244_fu_47757_p2 = (tmp_2223_fu_47749_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_245_fu_47937_p2() {
    xor_ln416_245_fu_47937_p2 = (tmp_2230_fu_47929_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_246_fu_48117_p2() {
    xor_ln416_246_fu_48117_p2 = (tmp_2237_fu_48109_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_247_fu_48297_p2() {
    xor_ln416_247_fu_48297_p2 = (tmp_2244_fu_48289_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_248_fu_48477_p2() {
    xor_ln416_248_fu_48477_p2 = (tmp_2251_fu_48469_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_249_fu_48657_p2() {
    xor_ln416_249_fu_48657_p2 = (tmp_2258_fu_48649_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_24_fu_9267_p2() {
    xor_ln416_24_fu_9267_p2 = (tmp_683_fu_9259_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_250_fu_48837_p2() {
    xor_ln416_250_fu_48837_p2 = (tmp_2265_fu_48829_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_251_fu_49017_p2() {
    xor_ln416_251_fu_49017_p2 = (tmp_2272_fu_49009_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_252_fu_49197_p2() {
    xor_ln416_252_fu_49197_p2 = (tmp_2279_fu_49189_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_253_fu_49377_p2() {
    xor_ln416_253_fu_49377_p2 = (tmp_2286_fu_49369_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_254_fu_49557_p2() {
    xor_ln416_254_fu_49557_p2 = (tmp_2293_fu_49549_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_255_fu_118099_p2() {
    xor_ln416_255_fu_118099_p2 = (tmp_2300_fu_118091_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_256_fu_49747_p2() {
    xor_ln416_256_fu_49747_p2 = (tmp_2307_fu_49739_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_257_fu_49927_p2() {
    xor_ln416_257_fu_49927_p2 = (tmp_2314_fu_49919_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_258_fu_50107_p2() {
    xor_ln416_258_fu_50107_p2 = (tmp_2321_fu_50099_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_259_fu_50287_p2() {
    xor_ln416_259_fu_50287_p2 = (tmp_2328_fu_50279_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_25_fu_9459_p2() {
    xor_ln416_25_fu_9459_p2 = (tmp_690_fu_9451_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_260_fu_50467_p2() {
    xor_ln416_260_fu_50467_p2 = (tmp_2335_fu_50459_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_261_fu_50647_p2() {
    xor_ln416_261_fu_50647_p2 = (tmp_2342_fu_50639_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_262_fu_50827_p2() {
    xor_ln416_262_fu_50827_p2 = (tmp_2349_fu_50819_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_263_fu_51007_p2() {
    xor_ln416_263_fu_51007_p2 = (tmp_2356_fu_50999_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_264_fu_51187_p2() {
    xor_ln416_264_fu_51187_p2 = (tmp_2363_fu_51179_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_265_fu_51367_p2() {
    xor_ln416_265_fu_51367_p2 = (tmp_2370_fu_51359_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_266_fu_51547_p2() {
    xor_ln416_266_fu_51547_p2 = (tmp_2377_fu_51539_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_267_fu_51727_p2() {
    xor_ln416_267_fu_51727_p2 = (tmp_2384_fu_51719_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_268_fu_51907_p2() {
    xor_ln416_268_fu_51907_p2 = (tmp_2391_fu_51899_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_269_fu_52087_p2() {
    xor_ln416_269_fu_52087_p2 = (tmp_2398_fu_52079_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_26_fu_9651_p2() {
    xor_ln416_26_fu_9651_p2 = (tmp_697_fu_9643_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_270_fu_52267_p2() {
    xor_ln416_270_fu_52267_p2 = (tmp_2405_fu_52259_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_271_fu_52447_p2() {
    xor_ln416_271_fu_52447_p2 = (tmp_2412_fu_52439_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_272_fu_52627_p2() {
    xor_ln416_272_fu_52627_p2 = (tmp_2419_fu_52619_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_273_fu_52807_p2() {
    xor_ln416_273_fu_52807_p2 = (tmp_2426_fu_52799_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_274_fu_52987_p2() {
    xor_ln416_274_fu_52987_p2 = (tmp_2433_fu_52979_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_275_fu_53167_p2() {
    xor_ln416_275_fu_53167_p2 = (tmp_2440_fu_53159_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_276_fu_53347_p2() {
    xor_ln416_276_fu_53347_p2 = (tmp_2447_fu_53339_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_277_fu_53527_p2() {
    xor_ln416_277_fu_53527_p2 = (tmp_2454_fu_53519_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_278_fu_53707_p2() {
    xor_ln416_278_fu_53707_p2 = (tmp_2461_fu_53699_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_279_fu_53887_p2() {
    xor_ln416_279_fu_53887_p2 = (tmp_2468_fu_53879_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_27_fu_9843_p2() {
    xor_ln416_27_fu_9843_p2 = (tmp_704_fu_9835_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_280_fu_54067_p2() {
    xor_ln416_280_fu_54067_p2 = (tmp_2475_fu_54059_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_281_fu_54247_p2() {
    xor_ln416_281_fu_54247_p2 = (tmp_2482_fu_54239_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_282_fu_54427_p2() {
    xor_ln416_282_fu_54427_p2 = (tmp_2489_fu_54419_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_283_fu_54607_p2() {
    xor_ln416_283_fu_54607_p2 = (tmp_2496_fu_54599_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_284_fu_54787_p2() {
    xor_ln416_284_fu_54787_p2 = (tmp_2503_fu_54779_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_285_fu_54967_p2() {
    xor_ln416_285_fu_54967_p2 = (tmp_2510_fu_54959_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_286_fu_55147_p2() {
    xor_ln416_286_fu_55147_p2 = (tmp_2517_fu_55139_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_287_fu_121086_p2() {
    xor_ln416_287_fu_121086_p2 = (tmp_2524_fu_121078_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_288_fu_55337_p2() {
    xor_ln416_288_fu_55337_p2 = (tmp_2531_fu_55329_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_289_fu_55517_p2() {
    xor_ln416_289_fu_55517_p2 = (tmp_2538_fu_55509_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_28_fu_10035_p2() {
    xor_ln416_28_fu_10035_p2 = (tmp_711_fu_10027_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_290_fu_55697_p2() {
    xor_ln416_290_fu_55697_p2 = (tmp_2545_fu_55689_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_291_fu_55877_p2() {
    xor_ln416_291_fu_55877_p2 = (tmp_2552_fu_55869_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_292_fu_56057_p2() {
    xor_ln416_292_fu_56057_p2 = (tmp_2559_fu_56049_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_293_fu_56237_p2() {
    xor_ln416_293_fu_56237_p2 = (tmp_2566_fu_56229_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_294_fu_56417_p2() {
    xor_ln416_294_fu_56417_p2 = (tmp_2573_fu_56409_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_295_fu_56597_p2() {
    xor_ln416_295_fu_56597_p2 = (tmp_2580_fu_56589_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_296_fu_56777_p2() {
    xor_ln416_296_fu_56777_p2 = (tmp_2587_fu_56769_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_297_fu_56957_p2() {
    xor_ln416_297_fu_56957_p2 = (tmp_2594_fu_56949_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_298_fu_57137_p2() {
    xor_ln416_298_fu_57137_p2 = (tmp_2601_fu_57129_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_299_fu_57317_p2() {
    xor_ln416_299_fu_57317_p2 = (tmp_2608_fu_57309_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_29_fu_10227_p2() {
    xor_ln416_29_fu_10227_p2 = (tmp_718_fu_10219_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_2_fu_5043_p2() {
    xor_ln416_2_fu_5043_p2 = (tmp_529_fu_5035_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_300_fu_57497_p2() {
    xor_ln416_300_fu_57497_p2 = (tmp_2615_fu_57489_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_301_fu_57677_p2() {
    xor_ln416_301_fu_57677_p2 = (tmp_2622_fu_57669_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_302_fu_57857_p2() {
    xor_ln416_302_fu_57857_p2 = (tmp_2629_fu_57849_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_303_fu_58037_p2() {
    xor_ln416_303_fu_58037_p2 = (tmp_2636_fu_58029_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_304_fu_58217_p2() {
    xor_ln416_304_fu_58217_p2 = (tmp_2643_fu_58209_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_305_fu_58397_p2() {
    xor_ln416_305_fu_58397_p2 = (tmp_2650_fu_58389_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_306_fu_58577_p2() {
    xor_ln416_306_fu_58577_p2 = (tmp_2657_fu_58569_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_307_fu_58757_p2() {
    xor_ln416_307_fu_58757_p2 = (tmp_2664_fu_58749_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_308_fu_58937_p2() {
    xor_ln416_308_fu_58937_p2 = (tmp_2671_fu_58929_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_309_fu_59117_p2() {
    xor_ln416_309_fu_59117_p2 = (tmp_2678_fu_59109_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_30_fu_10419_p2() {
    xor_ln416_30_fu_10419_p2 = (tmp_725_fu_10411_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_310_fu_59297_p2() {
    xor_ln416_310_fu_59297_p2 = (tmp_2685_fu_59289_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_311_fu_59477_p2() {
    xor_ln416_311_fu_59477_p2 = (tmp_2692_fu_59469_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_312_fu_59657_p2() {
    xor_ln416_312_fu_59657_p2 = (tmp_2699_fu_59649_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_313_fu_59837_p2() {
    xor_ln416_313_fu_59837_p2 = (tmp_2706_fu_59829_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_314_fu_60017_p2() {
    xor_ln416_314_fu_60017_p2 = (tmp_2713_fu_60009_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_315_fu_60197_p2() {
    xor_ln416_315_fu_60197_p2 = (tmp_2720_fu_60189_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_316_fu_60377_p2() {
    xor_ln416_316_fu_60377_p2 = (tmp_2727_fu_60369_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_317_fu_60557_p2() {
    xor_ln416_317_fu_60557_p2 = (tmp_2734_fu_60549_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_318_fu_60737_p2() {
    xor_ln416_318_fu_60737_p2 = (tmp_2741_fu_60729_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_319_fu_124073_p2() {
    xor_ln416_319_fu_124073_p2 = (tmp_2748_fu_124065_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_31_fu_97190_p2() {
    xor_ln416_31_fu_97190_p2 = (tmp_732_fu_97182_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_320_fu_60927_p2() {
    xor_ln416_320_fu_60927_p2 = (tmp_2755_fu_60919_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_321_fu_61107_p2() {
    xor_ln416_321_fu_61107_p2 = (tmp_2762_fu_61099_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_322_fu_61287_p2() {
    xor_ln416_322_fu_61287_p2 = (tmp_2769_fu_61279_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_323_fu_61467_p2() {
    xor_ln416_323_fu_61467_p2 = (tmp_2776_fu_61459_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_324_fu_61647_p2() {
    xor_ln416_324_fu_61647_p2 = (tmp_2783_fu_61639_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_325_fu_61827_p2() {
    xor_ln416_325_fu_61827_p2 = (tmp_2790_fu_61819_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_326_fu_62007_p2() {
    xor_ln416_326_fu_62007_p2 = (tmp_2797_fu_61999_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_327_fu_62187_p2() {
    xor_ln416_327_fu_62187_p2 = (tmp_2804_fu_62179_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_328_fu_62367_p2() {
    xor_ln416_328_fu_62367_p2 = (tmp_2811_fu_62359_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_329_fu_62547_p2() {
    xor_ln416_329_fu_62547_p2 = (tmp_2818_fu_62539_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_32_fu_10617_p2() {
    xor_ln416_32_fu_10617_p2 = (tmp_739_fu_10609_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_330_fu_62727_p2() {
    xor_ln416_330_fu_62727_p2 = (tmp_2825_fu_62719_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_331_fu_62907_p2() {
    xor_ln416_331_fu_62907_p2 = (tmp_2832_fu_62899_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_332_fu_63087_p2() {
    xor_ln416_332_fu_63087_p2 = (tmp_2839_fu_63079_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_333_fu_63267_p2() {
    xor_ln416_333_fu_63267_p2 = (tmp_2846_fu_63259_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_334_fu_63447_p2() {
    xor_ln416_334_fu_63447_p2 = (tmp_2853_fu_63439_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_335_fu_63627_p2() {
    xor_ln416_335_fu_63627_p2 = (tmp_2860_fu_63619_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_336_fu_63807_p2() {
    xor_ln416_336_fu_63807_p2 = (tmp_2867_fu_63799_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_337_fu_63987_p2() {
    xor_ln416_337_fu_63987_p2 = (tmp_2874_fu_63979_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_338_fu_64167_p2() {
    xor_ln416_338_fu_64167_p2 = (tmp_2881_fu_64159_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_339_fu_64347_p2() {
    xor_ln416_339_fu_64347_p2 = (tmp_2888_fu_64339_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_33_fu_10797_p2() {
    xor_ln416_33_fu_10797_p2 = (tmp_746_fu_10789_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_340_fu_64527_p2() {
    xor_ln416_340_fu_64527_p2 = (tmp_2895_fu_64519_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_341_fu_64707_p2() {
    xor_ln416_341_fu_64707_p2 = (tmp_2902_fu_64699_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_342_fu_64887_p2() {
    xor_ln416_342_fu_64887_p2 = (tmp_2909_fu_64879_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_343_fu_65067_p2() {
    xor_ln416_343_fu_65067_p2 = (tmp_2916_fu_65059_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_344_fu_65247_p2() {
    xor_ln416_344_fu_65247_p2 = (tmp_2923_fu_65239_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_345_fu_65427_p2() {
    xor_ln416_345_fu_65427_p2 = (tmp_2930_fu_65419_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_346_fu_65607_p2() {
    xor_ln416_346_fu_65607_p2 = (tmp_2937_fu_65599_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_347_fu_65787_p2() {
    xor_ln416_347_fu_65787_p2 = (tmp_2944_fu_65779_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_348_fu_65967_p2() {
    xor_ln416_348_fu_65967_p2 = (tmp_2951_fu_65959_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_349_fu_66147_p2() {
    xor_ln416_349_fu_66147_p2 = (tmp_2958_fu_66139_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_34_fu_10977_p2() {
    xor_ln416_34_fu_10977_p2 = (tmp_753_fu_10969_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_350_fu_66327_p2() {
    xor_ln416_350_fu_66327_p2 = (tmp_2965_fu_66319_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_351_fu_127060_p2() {
    xor_ln416_351_fu_127060_p2 = (tmp_2972_fu_127052_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_352_fu_66517_p2() {
    xor_ln416_352_fu_66517_p2 = (tmp_2979_fu_66509_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_353_fu_66697_p2() {
    xor_ln416_353_fu_66697_p2 = (tmp_2986_fu_66689_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_354_fu_66877_p2() {
    xor_ln416_354_fu_66877_p2 = (tmp_2993_fu_66869_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_355_fu_67057_p2() {
    xor_ln416_355_fu_67057_p2 = (tmp_3000_fu_67049_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_356_fu_67237_p2() {
    xor_ln416_356_fu_67237_p2 = (tmp_3007_fu_67229_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_357_fu_67417_p2() {
    xor_ln416_357_fu_67417_p2 = (tmp_3014_fu_67409_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_358_fu_67597_p2() {
    xor_ln416_358_fu_67597_p2 = (tmp_3021_fu_67589_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_359_fu_67777_p2() {
    xor_ln416_359_fu_67777_p2 = (tmp_3028_fu_67769_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_35_fu_11157_p2() {
    xor_ln416_35_fu_11157_p2 = (tmp_760_fu_11149_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_360_fu_67957_p2() {
    xor_ln416_360_fu_67957_p2 = (tmp_3035_fu_67949_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_361_fu_68137_p2() {
    xor_ln416_361_fu_68137_p2 = (tmp_3042_fu_68129_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_362_fu_68317_p2() {
    xor_ln416_362_fu_68317_p2 = (tmp_3049_fu_68309_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_363_fu_68497_p2() {
    xor_ln416_363_fu_68497_p2 = (tmp_3056_fu_68489_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_364_fu_68677_p2() {
    xor_ln416_364_fu_68677_p2 = (tmp_3063_fu_68669_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_365_fu_68857_p2() {
    xor_ln416_365_fu_68857_p2 = (tmp_3070_fu_68849_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_366_fu_69037_p2() {
    xor_ln416_366_fu_69037_p2 = (tmp_3077_fu_69029_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_367_fu_69217_p2() {
    xor_ln416_367_fu_69217_p2 = (tmp_3084_fu_69209_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_368_fu_69397_p2() {
    xor_ln416_368_fu_69397_p2 = (tmp_3091_fu_69389_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_369_fu_69577_p2() {
    xor_ln416_369_fu_69577_p2 = (tmp_3098_fu_69569_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_36_fu_11337_p2() {
    xor_ln416_36_fu_11337_p2 = (tmp_767_fu_11329_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_370_fu_69757_p2() {
    xor_ln416_370_fu_69757_p2 = (tmp_3105_fu_69749_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_371_fu_69937_p2() {
    xor_ln416_371_fu_69937_p2 = (tmp_3112_fu_69929_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_372_fu_70117_p2() {
    xor_ln416_372_fu_70117_p2 = (tmp_3119_fu_70109_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_373_fu_70297_p2() {
    xor_ln416_373_fu_70297_p2 = (tmp_3126_fu_70289_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_374_fu_70477_p2() {
    xor_ln416_374_fu_70477_p2 = (tmp_3133_fu_70469_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_375_fu_70657_p2() {
    xor_ln416_375_fu_70657_p2 = (tmp_3140_fu_70649_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_376_fu_70837_p2() {
    xor_ln416_376_fu_70837_p2 = (tmp_3147_fu_70829_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_377_fu_71017_p2() {
    xor_ln416_377_fu_71017_p2 = (tmp_3154_fu_71009_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_378_fu_71197_p2() {
    xor_ln416_378_fu_71197_p2 = (tmp_3161_fu_71189_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_379_fu_71377_p2() {
    xor_ln416_379_fu_71377_p2 = (tmp_3168_fu_71369_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_37_fu_11517_p2() {
    xor_ln416_37_fu_11517_p2 = (tmp_774_fu_11509_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_380_fu_71557_p2() {
    xor_ln416_380_fu_71557_p2 = (tmp_3175_fu_71549_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_381_fu_71737_p2() {
    xor_ln416_381_fu_71737_p2 = (tmp_3182_fu_71729_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_382_fu_71917_p2() {
    xor_ln416_382_fu_71917_p2 = (tmp_3189_fu_71909_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_383_fu_130047_p2() {
    xor_ln416_383_fu_130047_p2 = (tmp_3196_fu_130039_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_384_fu_72107_p2() {
    xor_ln416_384_fu_72107_p2 = (tmp_3203_fu_72099_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_385_fu_72287_p2() {
    xor_ln416_385_fu_72287_p2 = (tmp_3210_fu_72279_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_386_fu_72467_p2() {
    xor_ln416_386_fu_72467_p2 = (tmp_3217_fu_72459_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_387_fu_72647_p2() {
    xor_ln416_387_fu_72647_p2 = (tmp_3224_fu_72639_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_388_fu_72827_p2() {
    xor_ln416_388_fu_72827_p2 = (tmp_3231_fu_72819_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_389_fu_73007_p2() {
    xor_ln416_389_fu_73007_p2 = (tmp_3238_fu_72999_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_38_fu_11697_p2() {
    xor_ln416_38_fu_11697_p2 = (tmp_781_fu_11689_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_390_fu_73187_p2() {
    xor_ln416_390_fu_73187_p2 = (tmp_3245_fu_73179_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_391_fu_73367_p2() {
    xor_ln416_391_fu_73367_p2 = (tmp_3252_fu_73359_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_392_fu_73547_p2() {
    xor_ln416_392_fu_73547_p2 = (tmp_3259_fu_73539_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_393_fu_73727_p2() {
    xor_ln416_393_fu_73727_p2 = (tmp_3266_fu_73719_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_394_fu_73907_p2() {
    xor_ln416_394_fu_73907_p2 = (tmp_3273_fu_73899_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_395_fu_74087_p2() {
    xor_ln416_395_fu_74087_p2 = (tmp_3280_fu_74079_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_396_fu_74267_p2() {
    xor_ln416_396_fu_74267_p2 = (tmp_3287_fu_74259_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_397_fu_74447_p2() {
    xor_ln416_397_fu_74447_p2 = (tmp_3294_fu_74439_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_398_fu_74627_p2() {
    xor_ln416_398_fu_74627_p2 = (tmp_3301_fu_74619_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_399_fu_74807_p2() {
    xor_ln416_399_fu_74807_p2 = (tmp_3308_fu_74799_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_39_fu_11877_p2() {
    xor_ln416_39_fu_11877_p2 = (tmp_788_fu_11869_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_3_fu_5235_p2() {
    xor_ln416_3_fu_5235_p2 = (tmp_536_fu_5227_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_400_fu_74987_p2() {
    xor_ln416_400_fu_74987_p2 = (tmp_3315_fu_74979_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_401_fu_75167_p2() {
    xor_ln416_401_fu_75167_p2 = (tmp_3322_fu_75159_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_402_fu_75347_p2() {
    xor_ln416_402_fu_75347_p2 = (tmp_3329_fu_75339_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_403_fu_75527_p2() {
    xor_ln416_403_fu_75527_p2 = (tmp_3336_fu_75519_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_404_fu_75707_p2() {
    xor_ln416_404_fu_75707_p2 = (tmp_3343_fu_75699_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_405_fu_75887_p2() {
    xor_ln416_405_fu_75887_p2 = (tmp_3350_fu_75879_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_406_fu_76067_p2() {
    xor_ln416_406_fu_76067_p2 = (tmp_3357_fu_76059_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_407_fu_76247_p2() {
    xor_ln416_407_fu_76247_p2 = (tmp_3364_fu_76239_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_408_fu_76427_p2() {
    xor_ln416_408_fu_76427_p2 = (tmp_3371_fu_76419_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_409_fu_76607_p2() {
    xor_ln416_409_fu_76607_p2 = (tmp_3378_fu_76599_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_40_fu_12057_p2() {
    xor_ln416_40_fu_12057_p2 = (tmp_795_fu_12049_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_410_fu_76787_p2() {
    xor_ln416_410_fu_76787_p2 = (tmp_3385_fu_76779_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_411_fu_76967_p2() {
    xor_ln416_411_fu_76967_p2 = (tmp_3392_fu_76959_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_412_fu_77147_p2() {
    xor_ln416_412_fu_77147_p2 = (tmp_3399_fu_77139_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_413_fu_77327_p2() {
    xor_ln416_413_fu_77327_p2 = (tmp_3406_fu_77319_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_414_fu_77507_p2() {
    xor_ln416_414_fu_77507_p2 = (tmp_3413_fu_77499_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_415_fu_133034_p2() {
    xor_ln416_415_fu_133034_p2 = (tmp_3420_fu_133026_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_416_fu_77697_p2() {
    xor_ln416_416_fu_77697_p2 = (tmp_3427_fu_77689_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_417_fu_77877_p2() {
    xor_ln416_417_fu_77877_p2 = (tmp_3434_fu_77869_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_418_fu_78057_p2() {
    xor_ln416_418_fu_78057_p2 = (tmp_3441_fu_78049_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_419_fu_78237_p2() {
    xor_ln416_419_fu_78237_p2 = (tmp_3448_fu_78229_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_41_fu_12237_p2() {
    xor_ln416_41_fu_12237_p2 = (tmp_802_fu_12229_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_420_fu_78417_p2() {
    xor_ln416_420_fu_78417_p2 = (tmp_3455_fu_78409_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_421_fu_78597_p2() {
    xor_ln416_421_fu_78597_p2 = (tmp_3462_fu_78589_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_422_fu_78777_p2() {
    xor_ln416_422_fu_78777_p2 = (tmp_3469_fu_78769_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_423_fu_78957_p2() {
    xor_ln416_423_fu_78957_p2 = (tmp_3476_fu_78949_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_424_fu_79137_p2() {
    xor_ln416_424_fu_79137_p2 = (tmp_3483_fu_79129_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_425_fu_79317_p2() {
    xor_ln416_425_fu_79317_p2 = (tmp_3490_fu_79309_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_426_fu_79497_p2() {
    xor_ln416_426_fu_79497_p2 = (tmp_3497_fu_79489_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_427_fu_79677_p2() {
    xor_ln416_427_fu_79677_p2 = (tmp_3504_fu_79669_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_428_fu_79857_p2() {
    xor_ln416_428_fu_79857_p2 = (tmp_3511_fu_79849_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_429_fu_80037_p2() {
    xor_ln416_429_fu_80037_p2 = (tmp_3518_fu_80029_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_42_fu_12417_p2() {
    xor_ln416_42_fu_12417_p2 = (tmp_809_fu_12409_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_430_fu_80217_p2() {
    xor_ln416_430_fu_80217_p2 = (tmp_3525_fu_80209_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_431_fu_80397_p2() {
    xor_ln416_431_fu_80397_p2 = (tmp_3532_fu_80389_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_432_fu_80577_p2() {
    xor_ln416_432_fu_80577_p2 = (tmp_3539_fu_80569_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_433_fu_80757_p2() {
    xor_ln416_433_fu_80757_p2 = (tmp_3546_fu_80749_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_434_fu_80937_p2() {
    xor_ln416_434_fu_80937_p2 = (tmp_3553_fu_80929_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_435_fu_81117_p2() {
    xor_ln416_435_fu_81117_p2 = (tmp_3560_fu_81109_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_436_fu_81297_p2() {
    xor_ln416_436_fu_81297_p2 = (tmp_3567_fu_81289_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_437_fu_81477_p2() {
    xor_ln416_437_fu_81477_p2 = (tmp_3574_fu_81469_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_438_fu_81657_p2() {
    xor_ln416_438_fu_81657_p2 = (tmp_3581_fu_81649_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_439_fu_81837_p2() {
    xor_ln416_439_fu_81837_p2 = (tmp_3588_fu_81829_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_43_fu_12597_p2() {
    xor_ln416_43_fu_12597_p2 = (tmp_816_fu_12589_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_440_fu_82017_p2() {
    xor_ln416_440_fu_82017_p2 = (tmp_3595_fu_82009_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_441_fu_82197_p2() {
    xor_ln416_441_fu_82197_p2 = (tmp_3602_fu_82189_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_442_fu_82377_p2() {
    xor_ln416_442_fu_82377_p2 = (tmp_3609_fu_82369_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_443_fu_82557_p2() {
    xor_ln416_443_fu_82557_p2 = (tmp_3616_fu_82549_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_444_fu_82737_p2() {
    xor_ln416_444_fu_82737_p2 = (tmp_3623_fu_82729_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_445_fu_82917_p2() {
    xor_ln416_445_fu_82917_p2 = (tmp_3630_fu_82909_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_446_fu_83097_p2() {
    xor_ln416_446_fu_83097_p2 = (tmp_3637_fu_83089_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_447_fu_136021_p2() {
    xor_ln416_447_fu_136021_p2 = (tmp_3644_fu_136013_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_448_fu_83287_p2() {
    xor_ln416_448_fu_83287_p2 = (tmp_3651_fu_83279_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_449_fu_83467_p2() {
    xor_ln416_449_fu_83467_p2 = (tmp_3658_fu_83459_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_44_fu_12777_p2() {
    xor_ln416_44_fu_12777_p2 = (tmp_823_fu_12769_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_450_fu_83647_p2() {
    xor_ln416_450_fu_83647_p2 = (tmp_3665_fu_83639_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_451_fu_83827_p2() {
    xor_ln416_451_fu_83827_p2 = (tmp_3672_fu_83819_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_452_fu_84007_p2() {
    xor_ln416_452_fu_84007_p2 = (tmp_3679_fu_83999_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_453_fu_84187_p2() {
    xor_ln416_453_fu_84187_p2 = (tmp_3686_fu_84179_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_454_fu_84367_p2() {
    xor_ln416_454_fu_84367_p2 = (tmp_3693_fu_84359_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_455_fu_84547_p2() {
    xor_ln416_455_fu_84547_p2 = (tmp_3700_fu_84539_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_456_fu_84727_p2() {
    xor_ln416_456_fu_84727_p2 = (tmp_3707_fu_84719_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_457_fu_84907_p2() {
    xor_ln416_457_fu_84907_p2 = (tmp_3714_fu_84899_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_458_fu_85087_p2() {
    xor_ln416_458_fu_85087_p2 = (tmp_3721_fu_85079_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_459_fu_85267_p2() {
    xor_ln416_459_fu_85267_p2 = (tmp_3728_fu_85259_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_45_fu_12957_p2() {
    xor_ln416_45_fu_12957_p2 = (tmp_830_fu_12949_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_460_fu_85447_p2() {
    xor_ln416_460_fu_85447_p2 = (tmp_3735_fu_85439_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_461_fu_85627_p2() {
    xor_ln416_461_fu_85627_p2 = (tmp_3742_fu_85619_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_462_fu_85807_p2() {
    xor_ln416_462_fu_85807_p2 = (tmp_3749_fu_85799_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_463_fu_85987_p2() {
    xor_ln416_463_fu_85987_p2 = (tmp_3756_fu_85979_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_464_fu_86167_p2() {
    xor_ln416_464_fu_86167_p2 = (tmp_3763_fu_86159_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_465_fu_86347_p2() {
    xor_ln416_465_fu_86347_p2 = (tmp_3770_fu_86339_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_466_fu_86527_p2() {
    xor_ln416_466_fu_86527_p2 = (tmp_3777_fu_86519_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_467_fu_86707_p2() {
    xor_ln416_467_fu_86707_p2 = (tmp_3784_fu_86699_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_468_fu_86887_p2() {
    xor_ln416_468_fu_86887_p2 = (tmp_3791_fu_86879_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_469_fu_87067_p2() {
    xor_ln416_469_fu_87067_p2 = (tmp_3798_fu_87059_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_46_fu_13137_p2() {
    xor_ln416_46_fu_13137_p2 = (tmp_837_fu_13129_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_470_fu_87247_p2() {
    xor_ln416_470_fu_87247_p2 = (tmp_3805_fu_87239_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_471_fu_87427_p2() {
    xor_ln416_471_fu_87427_p2 = (tmp_3812_fu_87419_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_472_fu_87607_p2() {
    xor_ln416_472_fu_87607_p2 = (tmp_3819_fu_87599_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_473_fu_87787_p2() {
    xor_ln416_473_fu_87787_p2 = (tmp_3826_fu_87779_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_474_fu_87967_p2() {
    xor_ln416_474_fu_87967_p2 = (tmp_3833_fu_87959_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_475_fu_88147_p2() {
    xor_ln416_475_fu_88147_p2 = (tmp_3840_fu_88139_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_476_fu_88327_p2() {
    xor_ln416_476_fu_88327_p2 = (tmp_3847_fu_88319_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_477_fu_88507_p2() {
    xor_ln416_477_fu_88507_p2 = (tmp_3854_fu_88499_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_478_fu_88687_p2() {
    xor_ln416_478_fu_88687_p2 = (tmp_3861_fu_88679_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_479_fu_139008_p2() {
    xor_ln416_479_fu_139008_p2 = (tmp_3868_fu_139000_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_47_fu_13317_p2() {
    xor_ln416_47_fu_13317_p2 = (tmp_844_fu_13309_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_480_fu_88877_p2() {
    xor_ln416_480_fu_88877_p2 = (tmp_3875_fu_88869_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_481_fu_89057_p2() {
    xor_ln416_481_fu_89057_p2 = (tmp_3882_fu_89049_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_482_fu_89237_p2() {
    xor_ln416_482_fu_89237_p2 = (tmp_3889_fu_89229_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_483_fu_89417_p2() {
    xor_ln416_483_fu_89417_p2 = (tmp_3896_fu_89409_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_484_fu_89597_p2() {
    xor_ln416_484_fu_89597_p2 = (tmp_3903_fu_89589_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_485_fu_89777_p2() {
    xor_ln416_485_fu_89777_p2 = (tmp_3910_fu_89769_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_486_fu_89957_p2() {
    xor_ln416_486_fu_89957_p2 = (tmp_3917_fu_89949_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_487_fu_90137_p2() {
    xor_ln416_487_fu_90137_p2 = (tmp_3924_fu_90129_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_488_fu_90317_p2() {
    xor_ln416_488_fu_90317_p2 = (tmp_3931_fu_90309_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_489_fu_90497_p2() {
    xor_ln416_489_fu_90497_p2 = (tmp_3938_fu_90489_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_48_fu_13497_p2() {
    xor_ln416_48_fu_13497_p2 = (tmp_851_fu_13489_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_490_fu_90677_p2() {
    xor_ln416_490_fu_90677_p2 = (tmp_3945_fu_90669_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_491_fu_90857_p2() {
    xor_ln416_491_fu_90857_p2 = (tmp_3952_fu_90849_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_492_fu_91037_p2() {
    xor_ln416_492_fu_91037_p2 = (tmp_3959_fu_91029_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_493_fu_91217_p2() {
    xor_ln416_493_fu_91217_p2 = (tmp_3966_fu_91209_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_494_fu_91397_p2() {
    xor_ln416_494_fu_91397_p2 = (tmp_3973_fu_91389_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_495_fu_91577_p2() {
    xor_ln416_495_fu_91577_p2 = (tmp_3980_fu_91569_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_496_fu_91757_p2() {
    xor_ln416_496_fu_91757_p2 = (tmp_3987_fu_91749_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_497_fu_91937_p2() {
    xor_ln416_497_fu_91937_p2 = (tmp_3994_fu_91929_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_498_fu_92117_p2() {
    xor_ln416_498_fu_92117_p2 = (tmp_4001_fu_92109_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_499_fu_92297_p2() {
    xor_ln416_499_fu_92297_p2 = (tmp_4008_fu_92289_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_49_fu_13677_p2() {
    xor_ln416_49_fu_13677_p2 = (tmp_858_fu_13669_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_4_fu_5427_p2() {
    xor_ln416_4_fu_5427_p2 = (tmp_543_fu_5419_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_500_fu_92477_p2() {
    xor_ln416_500_fu_92477_p2 = (tmp_4015_fu_92469_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_501_fu_92657_p2() {
    xor_ln416_501_fu_92657_p2 = (tmp_4022_fu_92649_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_502_fu_92837_p2() {
    xor_ln416_502_fu_92837_p2 = (tmp_4029_fu_92829_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_503_fu_93017_p2() {
    xor_ln416_503_fu_93017_p2 = (tmp_4036_fu_93009_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_504_fu_93197_p2() {
    xor_ln416_504_fu_93197_p2 = (tmp_4043_fu_93189_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_505_fu_93377_p2() {
    xor_ln416_505_fu_93377_p2 = (tmp_4050_fu_93369_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_506_fu_93557_p2() {
    xor_ln416_506_fu_93557_p2 = (tmp_4057_fu_93549_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_507_fu_93737_p2() {
    xor_ln416_507_fu_93737_p2 = (tmp_4064_fu_93729_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_508_fu_93917_p2() {
    xor_ln416_508_fu_93917_p2 = (tmp_4071_fu_93909_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_509_fu_94097_p2() {
    xor_ln416_509_fu_94097_p2 = (tmp_4078_fu_94089_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_50_fu_13857_p2() {
    xor_ln416_50_fu_13857_p2 = (tmp_865_fu_13849_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_510_fu_94277_p2() {
    xor_ln416_510_fu_94277_p2 = (tmp_4085_fu_94269_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_511_fu_142013_p2() {
    xor_ln416_511_fu_142013_p2 = (tmp_4092_fu_142005_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_51_fu_14037_p2() {
    xor_ln416_51_fu_14037_p2 = (tmp_872_fu_14029_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_52_fu_14217_p2() {
    xor_ln416_52_fu_14217_p2 = (tmp_879_fu_14209_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_53_fu_14397_p2() {
    xor_ln416_53_fu_14397_p2 = (tmp_886_fu_14389_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_54_fu_14577_p2() {
    xor_ln416_54_fu_14577_p2 = (tmp_893_fu_14569_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_55_fu_14757_p2() {
    xor_ln416_55_fu_14757_p2 = (tmp_900_fu_14749_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_56_fu_14937_p2() {
    xor_ln416_56_fu_14937_p2 = (tmp_907_fu_14929_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_57_fu_15117_p2() {
    xor_ln416_57_fu_15117_p2 = (tmp_914_fu_15109_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_58_fu_15297_p2() {
    xor_ln416_58_fu_15297_p2 = (tmp_921_fu_15289_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_59_fu_15477_p2() {
    xor_ln416_59_fu_15477_p2 = (tmp_928_fu_15469_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_5_fu_5619_p2() {
    xor_ln416_5_fu_5619_p2 = (tmp_550_fu_5611_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_60_fu_15657_p2() {
    xor_ln416_60_fu_15657_p2 = (tmp_935_fu_15649_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_61_fu_15837_p2() {
    xor_ln416_61_fu_15837_p2 = (tmp_942_fu_15829_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_62_fu_16017_p2() {
    xor_ln416_62_fu_16017_p2 = (tmp_949_fu_16009_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_63_fu_100177_p2() {
    xor_ln416_63_fu_100177_p2 = (tmp_956_fu_100169_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_64_fu_16207_p2() {
    xor_ln416_64_fu_16207_p2 = (tmp_963_fu_16199_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_65_fu_16387_p2() {
    xor_ln416_65_fu_16387_p2 = (tmp_970_fu_16379_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_66_fu_16567_p2() {
    xor_ln416_66_fu_16567_p2 = (tmp_977_fu_16559_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_67_fu_16747_p2() {
    xor_ln416_67_fu_16747_p2 = (tmp_984_fu_16739_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_68_fu_16927_p2() {
    xor_ln416_68_fu_16927_p2 = (tmp_991_fu_16919_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_69_fu_17107_p2() {
    xor_ln416_69_fu_17107_p2 = (tmp_998_fu_17099_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_6_fu_5811_p2() {
    xor_ln416_6_fu_5811_p2 = (tmp_557_fu_5803_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_70_fu_17287_p2() {
    xor_ln416_70_fu_17287_p2 = (tmp_1005_fu_17279_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_71_fu_17467_p2() {
    xor_ln416_71_fu_17467_p2 = (tmp_1012_fu_17459_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_72_fu_17647_p2() {
    xor_ln416_72_fu_17647_p2 = (tmp_1019_fu_17639_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_73_fu_17827_p2() {
    xor_ln416_73_fu_17827_p2 = (tmp_1026_fu_17819_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_74_fu_18007_p2() {
    xor_ln416_74_fu_18007_p2 = (tmp_1033_fu_17999_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_75_fu_18187_p2() {
    xor_ln416_75_fu_18187_p2 = (tmp_1040_fu_18179_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_76_fu_18367_p2() {
    xor_ln416_76_fu_18367_p2 = (tmp_1047_fu_18359_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_77_fu_18547_p2() {
    xor_ln416_77_fu_18547_p2 = (tmp_1054_fu_18539_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_78_fu_18727_p2() {
    xor_ln416_78_fu_18727_p2 = (tmp_1061_fu_18719_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_79_fu_18907_p2() {
    xor_ln416_79_fu_18907_p2 = (tmp_1068_fu_18899_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_7_fu_6003_p2() {
    xor_ln416_7_fu_6003_p2 = (tmp_564_fu_5995_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_80_fu_19087_p2() {
    xor_ln416_80_fu_19087_p2 = (tmp_1075_fu_19079_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_81_fu_19267_p2() {
    xor_ln416_81_fu_19267_p2 = (tmp_1082_fu_19259_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_82_fu_19447_p2() {
    xor_ln416_82_fu_19447_p2 = (tmp_1089_fu_19439_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_83_fu_19627_p2() {
    xor_ln416_83_fu_19627_p2 = (tmp_1096_fu_19619_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_84_fu_19807_p2() {
    xor_ln416_84_fu_19807_p2 = (tmp_1103_fu_19799_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_85_fu_19987_p2() {
    xor_ln416_85_fu_19987_p2 = (tmp_1110_fu_19979_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_86_fu_20167_p2() {
    xor_ln416_86_fu_20167_p2 = (tmp_1117_fu_20159_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_87_fu_20347_p2() {
    xor_ln416_87_fu_20347_p2 = (tmp_1124_fu_20339_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_88_fu_20527_p2() {
    xor_ln416_88_fu_20527_p2 = (tmp_1131_fu_20519_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_89_fu_20707_p2() {
    xor_ln416_89_fu_20707_p2 = (tmp_1138_fu_20699_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_8_fu_6195_p2() {
    xor_ln416_8_fu_6195_p2 = (tmp_571_fu_6187_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_90_fu_20887_p2() {
    xor_ln416_90_fu_20887_p2 = (tmp_1145_fu_20879_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_91_fu_21067_p2() {
    xor_ln416_91_fu_21067_p2 = (tmp_1152_fu_21059_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_92_fu_21247_p2() {
    xor_ln416_92_fu_21247_p2 = (tmp_1159_fu_21239_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_93_fu_21427_p2() {
    xor_ln416_93_fu_21427_p2 = (tmp_1166_fu_21419_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_94_fu_21607_p2() {
    xor_ln416_94_fu_21607_p2 = (tmp_1173_fu_21599_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_95_fu_103164_p2() {
    xor_ln416_95_fu_103164_p2 = (tmp_1180_fu_103156_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_96_fu_21797_p2() {
    xor_ln416_96_fu_21797_p2 = (tmp_1187_fu_21789_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_97_fu_21977_p2() {
    xor_ln416_97_fu_21977_p2 = (tmp_1194_fu_21969_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_98_fu_22157_p2() {
    xor_ln416_98_fu_22157_p2 = (tmp_1201_fu_22149_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_99_fu_22337_p2() {
    xor_ln416_99_fu_22337_p2 = (tmp_1208_fu_22329_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_9_fu_6387_p2() {
    xor_ln416_9_fu_6387_p2 = (tmp_578_fu_6379_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln416_fu_4659_p2() {
    xor_ln416_fu_4659_p2 = (tmp_515_fu_4651_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_100_fu_22537_p2() {
    xor_ln779_100_fu_22537_p2 = (tmp_1212_fu_22469_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_101_fu_22717_p2() {
    xor_ln779_101_fu_22717_p2 = (tmp_1219_fu_22649_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_102_fu_22897_p2() {
    xor_ln779_102_fu_22897_p2 = (tmp_1226_fu_22829_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_103_fu_23077_p2() {
    xor_ln779_103_fu_23077_p2 = (tmp_1233_fu_23009_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_104_fu_23257_p2() {
    xor_ln779_104_fu_23257_p2 = (tmp_1240_fu_23189_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_105_fu_23437_p2() {
    xor_ln779_105_fu_23437_p2 = (tmp_1247_fu_23369_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_106_fu_23617_p2() {
    xor_ln779_106_fu_23617_p2 = (tmp_1254_fu_23549_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_107_fu_23797_p2() {
    xor_ln779_107_fu_23797_p2 = (tmp_1261_fu_23729_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_108_fu_23977_p2() {
    xor_ln779_108_fu_23977_p2 = (tmp_1268_fu_23909_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_109_fu_24157_p2() {
    xor_ln779_109_fu_24157_p2 = (tmp_1275_fu_24089_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_10_fu_6599_p2() {
    xor_ln779_10_fu_6599_p2 = (tmp_582_fu_6531_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_110_fu_24337_p2() {
    xor_ln779_110_fu_24337_p2 = (tmp_1282_fu_24269_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_111_fu_24517_p2() {
    xor_ln779_111_fu_24517_p2 = (tmp_1289_fu_24449_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_112_fu_24697_p2() {
    xor_ln779_112_fu_24697_p2 = (tmp_1296_fu_24629_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_113_fu_24877_p2() {
    xor_ln779_113_fu_24877_p2 = (tmp_1303_fu_24809_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_114_fu_25057_p2() {
    xor_ln779_114_fu_25057_p2 = (tmp_1310_fu_24989_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_115_fu_25237_p2() {
    xor_ln779_115_fu_25237_p2 = (tmp_1317_fu_25169_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_116_fu_25417_p2() {
    xor_ln779_116_fu_25417_p2 = (tmp_1324_fu_25349_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_117_fu_25597_p2() {
    xor_ln779_117_fu_25597_p2 = (tmp_1331_fu_25529_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_118_fu_25777_p2() {
    xor_ln779_118_fu_25777_p2 = (tmp_1338_fu_25709_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_119_fu_25957_p2() {
    xor_ln779_119_fu_25957_p2 = (tmp_1345_fu_25889_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_11_fu_6791_p2() {
    xor_ln779_11_fu_6791_p2 = (tmp_589_fu_6723_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_120_fu_26137_p2() {
    xor_ln779_120_fu_26137_p2 = (tmp_1352_fu_26069_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_121_fu_26317_p2() {
    xor_ln779_121_fu_26317_p2 = (tmp_1359_fu_26249_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_122_fu_26497_p2() {
    xor_ln779_122_fu_26497_p2 = (tmp_1366_fu_26429_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_123_fu_26677_p2() {
    xor_ln779_123_fu_26677_p2 = (tmp_1373_fu_26609_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_124_fu_26857_p2() {
    xor_ln779_124_fu_26857_p2 = (tmp_1380_fu_26789_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_125_fu_27037_p2() {
    xor_ln779_125_fu_27037_p2 = (tmp_1387_fu_26969_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_126_fu_27217_p2() {
    xor_ln779_126_fu_27217_p2 = (tmp_1394_fu_27149_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_127_fu_106171_p2() {
    xor_ln779_127_fu_106171_p2 = (tmp_1401_fu_106103_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_128_fu_27407_p2() {
    xor_ln779_128_fu_27407_p2 = (tmp_1408_fu_27339_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_129_fu_27587_p2() {
    xor_ln779_129_fu_27587_p2 = (tmp_1415_fu_27519_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_12_fu_6983_p2() {
    xor_ln779_12_fu_6983_p2 = (tmp_596_fu_6915_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_130_fu_27767_p2() {
    xor_ln779_130_fu_27767_p2 = (tmp_1422_fu_27699_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_131_fu_27947_p2() {
    xor_ln779_131_fu_27947_p2 = (tmp_1429_fu_27879_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_132_fu_28127_p2() {
    xor_ln779_132_fu_28127_p2 = (tmp_1436_fu_28059_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_133_fu_28307_p2() {
    xor_ln779_133_fu_28307_p2 = (tmp_1443_fu_28239_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_134_fu_28487_p2() {
    xor_ln779_134_fu_28487_p2 = (tmp_1450_fu_28419_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_135_fu_28667_p2() {
    xor_ln779_135_fu_28667_p2 = (tmp_1457_fu_28599_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_136_fu_28847_p2() {
    xor_ln779_136_fu_28847_p2 = (tmp_1464_fu_28779_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_137_fu_29027_p2() {
    xor_ln779_137_fu_29027_p2 = (tmp_1471_fu_28959_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_138_fu_29207_p2() {
    xor_ln779_138_fu_29207_p2 = (tmp_1478_fu_29139_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_139_fu_29387_p2() {
    xor_ln779_139_fu_29387_p2 = (tmp_1485_fu_29319_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_13_fu_7175_p2() {
    xor_ln779_13_fu_7175_p2 = (tmp_603_fu_7107_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_140_fu_29567_p2() {
    xor_ln779_140_fu_29567_p2 = (tmp_1492_fu_29499_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_141_fu_29747_p2() {
    xor_ln779_141_fu_29747_p2 = (tmp_1499_fu_29679_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_142_fu_29927_p2() {
    xor_ln779_142_fu_29927_p2 = (tmp_1506_fu_29859_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_143_fu_30107_p2() {
    xor_ln779_143_fu_30107_p2 = (tmp_1513_fu_30039_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_144_fu_30287_p2() {
    xor_ln779_144_fu_30287_p2 = (tmp_1520_fu_30219_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_145_fu_30467_p2() {
    xor_ln779_145_fu_30467_p2 = (tmp_1527_fu_30399_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_146_fu_30647_p2() {
    xor_ln779_146_fu_30647_p2 = (tmp_1534_fu_30579_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_147_fu_30827_p2() {
    xor_ln779_147_fu_30827_p2 = (tmp_1541_fu_30759_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_148_fu_31007_p2() {
    xor_ln779_148_fu_31007_p2 = (tmp_1548_fu_30939_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_149_fu_31187_p2() {
    xor_ln779_149_fu_31187_p2 = (tmp_1555_fu_31119_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_14_fu_7367_p2() {
    xor_ln779_14_fu_7367_p2 = (tmp_610_fu_7299_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_150_fu_31367_p2() {
    xor_ln779_150_fu_31367_p2 = (tmp_1562_fu_31299_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_151_fu_31547_p2() {
    xor_ln779_151_fu_31547_p2 = (tmp_1569_fu_31479_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_152_fu_31727_p2() {
    xor_ln779_152_fu_31727_p2 = (tmp_1576_fu_31659_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_153_fu_31907_p2() {
    xor_ln779_153_fu_31907_p2 = (tmp_1583_fu_31839_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_154_fu_32087_p2() {
    xor_ln779_154_fu_32087_p2 = (tmp_1590_fu_32019_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_155_fu_32267_p2() {
    xor_ln779_155_fu_32267_p2 = (tmp_1597_fu_32199_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_156_fu_32447_p2() {
    xor_ln779_156_fu_32447_p2 = (tmp_1604_fu_32379_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_157_fu_32627_p2() {
    xor_ln779_157_fu_32627_p2 = (tmp_1611_fu_32559_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_158_fu_32807_p2() {
    xor_ln779_158_fu_32807_p2 = (tmp_1618_fu_32739_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_159_fu_109158_p2() {
    xor_ln779_159_fu_109158_p2 = (tmp_1625_fu_109090_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_15_fu_7559_p2() {
    xor_ln779_15_fu_7559_p2 = (tmp_617_fu_7491_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_160_fu_32997_p2() {
    xor_ln779_160_fu_32997_p2 = (tmp_1632_fu_32929_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_161_fu_33177_p2() {
    xor_ln779_161_fu_33177_p2 = (tmp_1639_fu_33109_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_162_fu_33357_p2() {
    xor_ln779_162_fu_33357_p2 = (tmp_1646_fu_33289_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_163_fu_33537_p2() {
    xor_ln779_163_fu_33537_p2 = (tmp_1653_fu_33469_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_164_fu_33717_p2() {
    xor_ln779_164_fu_33717_p2 = (tmp_1660_fu_33649_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_165_fu_33897_p2() {
    xor_ln779_165_fu_33897_p2 = (tmp_1667_fu_33829_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_166_fu_34077_p2() {
    xor_ln779_166_fu_34077_p2 = (tmp_1674_fu_34009_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_167_fu_34257_p2() {
    xor_ln779_167_fu_34257_p2 = (tmp_1681_fu_34189_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_168_fu_34437_p2() {
    xor_ln779_168_fu_34437_p2 = (tmp_1688_fu_34369_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_169_fu_34617_p2() {
    xor_ln779_169_fu_34617_p2 = (tmp_1695_fu_34549_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_16_fu_7751_p2() {
    xor_ln779_16_fu_7751_p2 = (tmp_624_fu_7683_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_170_fu_34797_p2() {
    xor_ln779_170_fu_34797_p2 = (tmp_1702_fu_34729_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_171_fu_34977_p2() {
    xor_ln779_171_fu_34977_p2 = (tmp_1709_fu_34909_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_172_fu_35157_p2() {
    xor_ln779_172_fu_35157_p2 = (tmp_1716_fu_35089_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_173_fu_35337_p2() {
    xor_ln779_173_fu_35337_p2 = (tmp_1723_fu_35269_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_174_fu_35517_p2() {
    xor_ln779_174_fu_35517_p2 = (tmp_1730_fu_35449_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_175_fu_35697_p2() {
    xor_ln779_175_fu_35697_p2 = (tmp_1737_fu_35629_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_176_fu_35877_p2() {
    xor_ln779_176_fu_35877_p2 = (tmp_1744_fu_35809_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_177_fu_36057_p2() {
    xor_ln779_177_fu_36057_p2 = (tmp_1751_fu_35989_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_178_fu_36237_p2() {
    xor_ln779_178_fu_36237_p2 = (tmp_1758_fu_36169_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_179_fu_36417_p2() {
    xor_ln779_179_fu_36417_p2 = (tmp_1765_fu_36349_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_17_fu_7943_p2() {
    xor_ln779_17_fu_7943_p2 = (tmp_631_fu_7875_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_180_fu_36597_p2() {
    xor_ln779_180_fu_36597_p2 = (tmp_1772_fu_36529_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_181_fu_36777_p2() {
    xor_ln779_181_fu_36777_p2 = (tmp_1779_fu_36709_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_182_fu_36957_p2() {
    xor_ln779_182_fu_36957_p2 = (tmp_1786_fu_36889_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_183_fu_37137_p2() {
    xor_ln779_183_fu_37137_p2 = (tmp_1793_fu_37069_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_184_fu_37317_p2() {
    xor_ln779_184_fu_37317_p2 = (tmp_1800_fu_37249_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_185_fu_37497_p2() {
    xor_ln779_185_fu_37497_p2 = (tmp_1807_fu_37429_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_186_fu_37677_p2() {
    xor_ln779_186_fu_37677_p2 = (tmp_1814_fu_37609_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_187_fu_37857_p2() {
    xor_ln779_187_fu_37857_p2 = (tmp_1821_fu_37789_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_188_fu_38037_p2() {
    xor_ln779_188_fu_38037_p2 = (tmp_1828_fu_37969_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_189_fu_38217_p2() {
    xor_ln779_189_fu_38217_p2 = (tmp_1835_fu_38149_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_18_fu_8135_p2() {
    xor_ln779_18_fu_8135_p2 = (tmp_638_fu_8067_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_190_fu_38397_p2() {
    xor_ln779_190_fu_38397_p2 = (tmp_1842_fu_38329_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_191_fu_112145_p2() {
    xor_ln779_191_fu_112145_p2 = (tmp_1849_fu_112077_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_192_fu_38587_p2() {
    xor_ln779_192_fu_38587_p2 = (tmp_1856_fu_38519_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_193_fu_38767_p2() {
    xor_ln779_193_fu_38767_p2 = (tmp_1863_fu_38699_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_194_fu_38947_p2() {
    xor_ln779_194_fu_38947_p2 = (tmp_1870_fu_38879_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_195_fu_39127_p2() {
    xor_ln779_195_fu_39127_p2 = (tmp_1877_fu_39059_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_196_fu_39307_p2() {
    xor_ln779_196_fu_39307_p2 = (tmp_1884_fu_39239_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_197_fu_39487_p2() {
    xor_ln779_197_fu_39487_p2 = (tmp_1891_fu_39419_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_198_fu_39667_p2() {
    xor_ln779_198_fu_39667_p2 = (tmp_1898_fu_39599_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_199_fu_39847_p2() {
    xor_ln779_199_fu_39847_p2 = (tmp_1905_fu_39779_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_19_fu_8327_p2() {
    xor_ln779_19_fu_8327_p2 = (tmp_645_fu_8259_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_1_fu_4871_p2() {
    xor_ln779_1_fu_4871_p2 = (tmp_519_fu_4803_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_200_fu_40027_p2() {
    xor_ln779_200_fu_40027_p2 = (tmp_1912_fu_39959_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_201_fu_40207_p2() {
    xor_ln779_201_fu_40207_p2 = (tmp_1919_fu_40139_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_202_fu_40387_p2() {
    xor_ln779_202_fu_40387_p2 = (tmp_1926_fu_40319_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_203_fu_40567_p2() {
    xor_ln779_203_fu_40567_p2 = (tmp_1933_fu_40499_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_204_fu_40747_p2() {
    xor_ln779_204_fu_40747_p2 = (tmp_1940_fu_40679_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_205_fu_40927_p2() {
    xor_ln779_205_fu_40927_p2 = (tmp_1947_fu_40859_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_206_fu_41107_p2() {
    xor_ln779_206_fu_41107_p2 = (tmp_1954_fu_41039_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_207_fu_41287_p2() {
    xor_ln779_207_fu_41287_p2 = (tmp_1961_fu_41219_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_208_fu_41467_p2() {
    xor_ln779_208_fu_41467_p2 = (tmp_1968_fu_41399_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_209_fu_41647_p2() {
    xor_ln779_209_fu_41647_p2 = (tmp_1975_fu_41579_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_20_fu_8519_p2() {
    xor_ln779_20_fu_8519_p2 = (tmp_652_fu_8451_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_210_fu_41827_p2() {
    xor_ln779_210_fu_41827_p2 = (tmp_1982_fu_41759_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_211_fu_42007_p2() {
    xor_ln779_211_fu_42007_p2 = (tmp_1989_fu_41939_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_212_fu_42187_p2() {
    xor_ln779_212_fu_42187_p2 = (tmp_1996_fu_42119_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_213_fu_42367_p2() {
    xor_ln779_213_fu_42367_p2 = (tmp_2003_fu_42299_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_214_fu_42547_p2() {
    xor_ln779_214_fu_42547_p2 = (tmp_2010_fu_42479_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_215_fu_42727_p2() {
    xor_ln779_215_fu_42727_p2 = (tmp_2017_fu_42659_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_216_fu_42907_p2() {
    xor_ln779_216_fu_42907_p2 = (tmp_2024_fu_42839_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_217_fu_43087_p2() {
    xor_ln779_217_fu_43087_p2 = (tmp_2031_fu_43019_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_218_fu_43267_p2() {
    xor_ln779_218_fu_43267_p2 = (tmp_2038_fu_43199_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_219_fu_43447_p2() {
    xor_ln779_219_fu_43447_p2 = (tmp_2045_fu_43379_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_21_fu_8711_p2() {
    xor_ln779_21_fu_8711_p2 = (tmp_659_fu_8643_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_220_fu_43627_p2() {
    xor_ln779_220_fu_43627_p2 = (tmp_2052_fu_43559_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_221_fu_43807_p2() {
    xor_ln779_221_fu_43807_p2 = (tmp_2059_fu_43739_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_222_fu_43987_p2() {
    xor_ln779_222_fu_43987_p2 = (tmp_2066_fu_43919_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_223_fu_115132_p2() {
    xor_ln779_223_fu_115132_p2 = (tmp_2073_fu_115064_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_224_fu_44177_p2() {
    xor_ln779_224_fu_44177_p2 = (tmp_2080_fu_44109_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_225_fu_44357_p2() {
    xor_ln779_225_fu_44357_p2 = (tmp_2087_fu_44289_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_226_fu_44537_p2() {
    xor_ln779_226_fu_44537_p2 = (tmp_2094_fu_44469_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_227_fu_44717_p2() {
    xor_ln779_227_fu_44717_p2 = (tmp_2101_fu_44649_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_228_fu_44897_p2() {
    xor_ln779_228_fu_44897_p2 = (tmp_2108_fu_44829_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_229_fu_45077_p2() {
    xor_ln779_229_fu_45077_p2 = (tmp_2115_fu_45009_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_22_fu_8903_p2() {
    xor_ln779_22_fu_8903_p2 = (tmp_666_fu_8835_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_230_fu_45257_p2() {
    xor_ln779_230_fu_45257_p2 = (tmp_2122_fu_45189_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_231_fu_45437_p2() {
    xor_ln779_231_fu_45437_p2 = (tmp_2129_fu_45369_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_232_fu_45617_p2() {
    xor_ln779_232_fu_45617_p2 = (tmp_2136_fu_45549_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_233_fu_45797_p2() {
    xor_ln779_233_fu_45797_p2 = (tmp_2143_fu_45729_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_234_fu_45977_p2() {
    xor_ln779_234_fu_45977_p2 = (tmp_2150_fu_45909_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_235_fu_46157_p2() {
    xor_ln779_235_fu_46157_p2 = (tmp_2157_fu_46089_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_236_fu_46337_p2() {
    xor_ln779_236_fu_46337_p2 = (tmp_2164_fu_46269_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_237_fu_46517_p2() {
    xor_ln779_237_fu_46517_p2 = (tmp_2171_fu_46449_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_238_fu_46697_p2() {
    xor_ln779_238_fu_46697_p2 = (tmp_2178_fu_46629_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_239_fu_46877_p2() {
    xor_ln779_239_fu_46877_p2 = (tmp_2185_fu_46809_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_23_fu_9095_p2() {
    xor_ln779_23_fu_9095_p2 = (tmp_673_fu_9027_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_240_fu_47057_p2() {
    xor_ln779_240_fu_47057_p2 = (tmp_2192_fu_46989_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_241_fu_47237_p2() {
    xor_ln779_241_fu_47237_p2 = (tmp_2199_fu_47169_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_242_fu_47417_p2() {
    xor_ln779_242_fu_47417_p2 = (tmp_2206_fu_47349_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_243_fu_47597_p2() {
    xor_ln779_243_fu_47597_p2 = (tmp_2213_fu_47529_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_244_fu_47777_p2() {
    xor_ln779_244_fu_47777_p2 = (tmp_2220_fu_47709_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_245_fu_47957_p2() {
    xor_ln779_245_fu_47957_p2 = (tmp_2227_fu_47889_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_246_fu_48137_p2() {
    xor_ln779_246_fu_48137_p2 = (tmp_2234_fu_48069_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_247_fu_48317_p2() {
    xor_ln779_247_fu_48317_p2 = (tmp_2241_fu_48249_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_248_fu_48497_p2() {
    xor_ln779_248_fu_48497_p2 = (tmp_2248_fu_48429_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_249_fu_48677_p2() {
    xor_ln779_249_fu_48677_p2 = (tmp_2255_fu_48609_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_24_fu_9287_p2() {
    xor_ln779_24_fu_9287_p2 = (tmp_680_fu_9219_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_250_fu_48857_p2() {
    xor_ln779_250_fu_48857_p2 = (tmp_2262_fu_48789_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_251_fu_49037_p2() {
    xor_ln779_251_fu_49037_p2 = (tmp_2269_fu_48969_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_252_fu_49217_p2() {
    xor_ln779_252_fu_49217_p2 = (tmp_2276_fu_49149_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_253_fu_49397_p2() {
    xor_ln779_253_fu_49397_p2 = (tmp_2283_fu_49329_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_254_fu_49577_p2() {
    xor_ln779_254_fu_49577_p2 = (tmp_2290_fu_49509_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_255_fu_118119_p2() {
    xor_ln779_255_fu_118119_p2 = (tmp_2297_fu_118051_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_256_fu_49767_p2() {
    xor_ln779_256_fu_49767_p2 = (tmp_2304_fu_49699_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_257_fu_49947_p2() {
    xor_ln779_257_fu_49947_p2 = (tmp_2311_fu_49879_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_258_fu_50127_p2() {
    xor_ln779_258_fu_50127_p2 = (tmp_2318_fu_50059_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_259_fu_50307_p2() {
    xor_ln779_259_fu_50307_p2 = (tmp_2325_fu_50239_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_25_fu_9479_p2() {
    xor_ln779_25_fu_9479_p2 = (tmp_687_fu_9411_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_260_fu_50487_p2() {
    xor_ln779_260_fu_50487_p2 = (tmp_2332_fu_50419_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_261_fu_50667_p2() {
    xor_ln779_261_fu_50667_p2 = (tmp_2339_fu_50599_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_262_fu_50847_p2() {
    xor_ln779_262_fu_50847_p2 = (tmp_2346_fu_50779_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_263_fu_51027_p2() {
    xor_ln779_263_fu_51027_p2 = (tmp_2353_fu_50959_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_264_fu_51207_p2() {
    xor_ln779_264_fu_51207_p2 = (tmp_2360_fu_51139_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_265_fu_51387_p2() {
    xor_ln779_265_fu_51387_p2 = (tmp_2367_fu_51319_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_266_fu_51567_p2() {
    xor_ln779_266_fu_51567_p2 = (tmp_2374_fu_51499_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_267_fu_51747_p2() {
    xor_ln779_267_fu_51747_p2 = (tmp_2381_fu_51679_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_268_fu_51927_p2() {
    xor_ln779_268_fu_51927_p2 = (tmp_2388_fu_51859_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_269_fu_52107_p2() {
    xor_ln779_269_fu_52107_p2 = (tmp_2395_fu_52039_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_26_fu_9671_p2() {
    xor_ln779_26_fu_9671_p2 = (tmp_694_fu_9603_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_270_fu_52287_p2() {
    xor_ln779_270_fu_52287_p2 = (tmp_2402_fu_52219_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_271_fu_52467_p2() {
    xor_ln779_271_fu_52467_p2 = (tmp_2409_fu_52399_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_272_fu_52647_p2() {
    xor_ln779_272_fu_52647_p2 = (tmp_2416_fu_52579_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_273_fu_52827_p2() {
    xor_ln779_273_fu_52827_p2 = (tmp_2423_fu_52759_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_274_fu_53007_p2() {
    xor_ln779_274_fu_53007_p2 = (tmp_2430_fu_52939_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_275_fu_53187_p2() {
    xor_ln779_275_fu_53187_p2 = (tmp_2437_fu_53119_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_276_fu_53367_p2() {
    xor_ln779_276_fu_53367_p2 = (tmp_2444_fu_53299_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_277_fu_53547_p2() {
    xor_ln779_277_fu_53547_p2 = (tmp_2451_fu_53479_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_278_fu_53727_p2() {
    xor_ln779_278_fu_53727_p2 = (tmp_2458_fu_53659_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_279_fu_53907_p2() {
    xor_ln779_279_fu_53907_p2 = (tmp_2465_fu_53839_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_27_fu_9863_p2() {
    xor_ln779_27_fu_9863_p2 = (tmp_701_fu_9795_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_280_fu_54087_p2() {
    xor_ln779_280_fu_54087_p2 = (tmp_2472_fu_54019_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_281_fu_54267_p2() {
    xor_ln779_281_fu_54267_p2 = (tmp_2479_fu_54199_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_282_fu_54447_p2() {
    xor_ln779_282_fu_54447_p2 = (tmp_2486_fu_54379_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_283_fu_54627_p2() {
    xor_ln779_283_fu_54627_p2 = (tmp_2493_fu_54559_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_284_fu_54807_p2() {
    xor_ln779_284_fu_54807_p2 = (tmp_2500_fu_54739_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_285_fu_54987_p2() {
    xor_ln779_285_fu_54987_p2 = (tmp_2507_fu_54919_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_286_fu_55167_p2() {
    xor_ln779_286_fu_55167_p2 = (tmp_2514_fu_55099_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_287_fu_121106_p2() {
    xor_ln779_287_fu_121106_p2 = (tmp_2521_fu_121038_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_288_fu_55357_p2() {
    xor_ln779_288_fu_55357_p2 = (tmp_2528_fu_55289_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_289_fu_55537_p2() {
    xor_ln779_289_fu_55537_p2 = (tmp_2535_fu_55469_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_28_fu_10055_p2() {
    xor_ln779_28_fu_10055_p2 = (tmp_708_fu_9987_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_290_fu_55717_p2() {
    xor_ln779_290_fu_55717_p2 = (tmp_2542_fu_55649_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_291_fu_55897_p2() {
    xor_ln779_291_fu_55897_p2 = (tmp_2549_fu_55829_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_292_fu_56077_p2() {
    xor_ln779_292_fu_56077_p2 = (tmp_2556_fu_56009_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_293_fu_56257_p2() {
    xor_ln779_293_fu_56257_p2 = (tmp_2563_fu_56189_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_294_fu_56437_p2() {
    xor_ln779_294_fu_56437_p2 = (tmp_2570_fu_56369_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_295_fu_56617_p2() {
    xor_ln779_295_fu_56617_p2 = (tmp_2577_fu_56549_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_296_fu_56797_p2() {
    xor_ln779_296_fu_56797_p2 = (tmp_2584_fu_56729_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_297_fu_56977_p2() {
    xor_ln779_297_fu_56977_p2 = (tmp_2591_fu_56909_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_298_fu_57157_p2() {
    xor_ln779_298_fu_57157_p2 = (tmp_2598_fu_57089_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_299_fu_57337_p2() {
    xor_ln779_299_fu_57337_p2 = (tmp_2605_fu_57269_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_29_fu_10247_p2() {
    xor_ln779_29_fu_10247_p2 = (tmp_715_fu_10179_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_2_fu_5063_p2() {
    xor_ln779_2_fu_5063_p2 = (tmp_526_fu_4995_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_300_fu_57517_p2() {
    xor_ln779_300_fu_57517_p2 = (tmp_2612_fu_57449_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_301_fu_57697_p2() {
    xor_ln779_301_fu_57697_p2 = (tmp_2619_fu_57629_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_302_fu_57877_p2() {
    xor_ln779_302_fu_57877_p2 = (tmp_2626_fu_57809_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_303_fu_58057_p2() {
    xor_ln779_303_fu_58057_p2 = (tmp_2633_fu_57989_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_304_fu_58237_p2() {
    xor_ln779_304_fu_58237_p2 = (tmp_2640_fu_58169_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_305_fu_58417_p2() {
    xor_ln779_305_fu_58417_p2 = (tmp_2647_fu_58349_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_306_fu_58597_p2() {
    xor_ln779_306_fu_58597_p2 = (tmp_2654_fu_58529_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_307_fu_58777_p2() {
    xor_ln779_307_fu_58777_p2 = (tmp_2661_fu_58709_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_308_fu_58957_p2() {
    xor_ln779_308_fu_58957_p2 = (tmp_2668_fu_58889_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_309_fu_59137_p2() {
    xor_ln779_309_fu_59137_p2 = (tmp_2675_fu_59069_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_30_fu_10439_p2() {
    xor_ln779_30_fu_10439_p2 = (tmp_722_fu_10371_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_310_fu_59317_p2() {
    xor_ln779_310_fu_59317_p2 = (tmp_2682_fu_59249_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_311_fu_59497_p2() {
    xor_ln779_311_fu_59497_p2 = (tmp_2689_fu_59429_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_312_fu_59677_p2() {
    xor_ln779_312_fu_59677_p2 = (tmp_2696_fu_59609_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_313_fu_59857_p2() {
    xor_ln779_313_fu_59857_p2 = (tmp_2703_fu_59789_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_314_fu_60037_p2() {
    xor_ln779_314_fu_60037_p2 = (tmp_2710_fu_59969_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_315_fu_60217_p2() {
    xor_ln779_315_fu_60217_p2 = (tmp_2717_fu_60149_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_316_fu_60397_p2() {
    xor_ln779_316_fu_60397_p2 = (tmp_2724_fu_60329_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_317_fu_60577_p2() {
    xor_ln779_317_fu_60577_p2 = (tmp_2731_fu_60509_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_318_fu_60757_p2() {
    xor_ln779_318_fu_60757_p2 = (tmp_2738_fu_60689_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_319_fu_124093_p2() {
    xor_ln779_319_fu_124093_p2 = (tmp_2745_fu_124025_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_31_fu_97210_p2() {
    xor_ln779_31_fu_97210_p2 = (tmp_729_fu_97142_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_320_fu_60947_p2() {
    xor_ln779_320_fu_60947_p2 = (tmp_2752_fu_60879_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_321_fu_61127_p2() {
    xor_ln779_321_fu_61127_p2 = (tmp_2759_fu_61059_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_322_fu_61307_p2() {
    xor_ln779_322_fu_61307_p2 = (tmp_2766_fu_61239_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_323_fu_61487_p2() {
    xor_ln779_323_fu_61487_p2 = (tmp_2773_fu_61419_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_324_fu_61667_p2() {
    xor_ln779_324_fu_61667_p2 = (tmp_2780_fu_61599_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_325_fu_61847_p2() {
    xor_ln779_325_fu_61847_p2 = (tmp_2787_fu_61779_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_326_fu_62027_p2() {
    xor_ln779_326_fu_62027_p2 = (tmp_2794_fu_61959_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_327_fu_62207_p2() {
    xor_ln779_327_fu_62207_p2 = (tmp_2801_fu_62139_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_328_fu_62387_p2() {
    xor_ln779_328_fu_62387_p2 = (tmp_2808_fu_62319_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_329_fu_62567_p2() {
    xor_ln779_329_fu_62567_p2 = (tmp_2815_fu_62499_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_32_fu_10637_p2() {
    xor_ln779_32_fu_10637_p2 = (tmp_736_fu_10569_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_330_fu_62747_p2() {
    xor_ln779_330_fu_62747_p2 = (tmp_2822_fu_62679_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_331_fu_62927_p2() {
    xor_ln779_331_fu_62927_p2 = (tmp_2829_fu_62859_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_332_fu_63107_p2() {
    xor_ln779_332_fu_63107_p2 = (tmp_2836_fu_63039_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_333_fu_63287_p2() {
    xor_ln779_333_fu_63287_p2 = (tmp_2843_fu_63219_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_334_fu_63467_p2() {
    xor_ln779_334_fu_63467_p2 = (tmp_2850_fu_63399_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_335_fu_63647_p2() {
    xor_ln779_335_fu_63647_p2 = (tmp_2857_fu_63579_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_336_fu_63827_p2() {
    xor_ln779_336_fu_63827_p2 = (tmp_2864_fu_63759_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_337_fu_64007_p2() {
    xor_ln779_337_fu_64007_p2 = (tmp_2871_fu_63939_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_338_fu_64187_p2() {
    xor_ln779_338_fu_64187_p2 = (tmp_2878_fu_64119_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_339_fu_64367_p2() {
    xor_ln779_339_fu_64367_p2 = (tmp_2885_fu_64299_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_33_fu_10817_p2() {
    xor_ln779_33_fu_10817_p2 = (tmp_743_fu_10749_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_340_fu_64547_p2() {
    xor_ln779_340_fu_64547_p2 = (tmp_2892_fu_64479_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_341_fu_64727_p2() {
    xor_ln779_341_fu_64727_p2 = (tmp_2899_fu_64659_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_342_fu_64907_p2() {
    xor_ln779_342_fu_64907_p2 = (tmp_2906_fu_64839_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_343_fu_65087_p2() {
    xor_ln779_343_fu_65087_p2 = (tmp_2913_fu_65019_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_344_fu_65267_p2() {
    xor_ln779_344_fu_65267_p2 = (tmp_2920_fu_65199_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_345_fu_65447_p2() {
    xor_ln779_345_fu_65447_p2 = (tmp_2927_fu_65379_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_346_fu_65627_p2() {
    xor_ln779_346_fu_65627_p2 = (tmp_2934_fu_65559_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_347_fu_65807_p2() {
    xor_ln779_347_fu_65807_p2 = (tmp_2941_fu_65739_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_348_fu_65987_p2() {
    xor_ln779_348_fu_65987_p2 = (tmp_2948_fu_65919_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_349_fu_66167_p2() {
    xor_ln779_349_fu_66167_p2 = (tmp_2955_fu_66099_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_34_fu_10997_p2() {
    xor_ln779_34_fu_10997_p2 = (tmp_750_fu_10929_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_350_fu_66347_p2() {
    xor_ln779_350_fu_66347_p2 = (tmp_2962_fu_66279_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_351_fu_127080_p2() {
    xor_ln779_351_fu_127080_p2 = (tmp_2969_fu_127012_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_352_fu_66537_p2() {
    xor_ln779_352_fu_66537_p2 = (tmp_2976_fu_66469_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_353_fu_66717_p2() {
    xor_ln779_353_fu_66717_p2 = (tmp_2983_fu_66649_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_354_fu_66897_p2() {
    xor_ln779_354_fu_66897_p2 = (tmp_2990_fu_66829_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_355_fu_67077_p2() {
    xor_ln779_355_fu_67077_p2 = (tmp_2997_fu_67009_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_356_fu_67257_p2() {
    xor_ln779_356_fu_67257_p2 = (tmp_3004_fu_67189_p3.read() ^ ap_const_lv1_1);
}

}

