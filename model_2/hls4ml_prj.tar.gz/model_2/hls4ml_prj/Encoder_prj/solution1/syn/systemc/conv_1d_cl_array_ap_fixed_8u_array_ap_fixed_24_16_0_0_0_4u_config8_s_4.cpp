#include "conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s.h"
#include "AESL_pkg.h"

using namespace std;

namespace ap_rtl {

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_2721_fu_19317_p2() {
    or_ln340_2721_fu_19317_p2 = (tmp_5625_fu_19285_p3.read() | xor_ln340_757_fu_19311_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_2722_fu_8845_p2() {
    or_ln340_2722_fu_8845_p2 = (and_ln786_41_fu_8815_p2.read() | xor_ln779_41_fu_8783_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_2723_fu_8851_p2() {
    or_ln340_2723_fu_8851_p2 = (or_ln340_2722_fu_8845_p2.read() | and_ln416_711_fu_8769_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_2724_fu_19405_p2() {
    or_ln340_2724_fu_19405_p2 = (tmp_5632_fu_19373_p3.read() | xor_ln340_758_fu_19399_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_2725_fu_9025_p2() {
    or_ln340_2725_fu_9025_p2 = (and_ln786_42_fu_8995_p2.read() | xor_ln779_42_fu_8963_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_2726_fu_9031_p2() {
    or_ln340_2726_fu_9031_p2 = (or_ln340_2725_fu_9025_p2.read() | and_ln416_712_fu_8949_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_2727_fu_19493_p2() {
    or_ln340_2727_fu_19493_p2 = (tmp_5639_fu_19461_p3.read() | xor_ln340_759_fu_19487_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_2728_fu_9205_p2() {
    or_ln340_2728_fu_9205_p2 = (and_ln786_43_fu_9175_p2.read() | xor_ln779_43_fu_9143_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_2729_fu_9211_p2() {
    or_ln340_2729_fu_9211_p2 = (or_ln340_2728_fu_9205_p2.read() | and_ln416_713_fu_9129_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_2730_fu_19581_p2() {
    or_ln340_2730_fu_19581_p2 = (tmp_5646_fu_19549_p3.read() | xor_ln340_760_fu_19575_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_2731_fu_9385_p2() {
    or_ln340_2731_fu_9385_p2 = (and_ln786_44_fu_9355_p2.read() | xor_ln779_44_fu_9323_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_2732_fu_9391_p2() {
    or_ln340_2732_fu_9391_p2 = (or_ln340_2731_fu_9385_p2.read() | and_ln416_714_fu_9309_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_2733_fu_19669_p2() {
    or_ln340_2733_fu_19669_p2 = (tmp_5653_fu_19637_p3.read() | xor_ln340_761_fu_19663_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_2734_fu_9565_p2() {
    or_ln340_2734_fu_9565_p2 = (and_ln786_45_fu_9535_p2.read() | xor_ln779_45_fu_9503_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_2735_fu_9571_p2() {
    or_ln340_2735_fu_9571_p2 = (or_ln340_2734_fu_9565_p2.read() | and_ln416_715_fu_9489_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_2736_fu_19757_p2() {
    or_ln340_2736_fu_19757_p2 = (tmp_5660_fu_19725_p3.read() | xor_ln340_762_fu_19751_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_2737_fu_9745_p2() {
    or_ln340_2737_fu_9745_p2 = (and_ln786_46_fu_9715_p2.read() | xor_ln779_46_fu_9683_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_2738_fu_9751_p2() {
    or_ln340_2738_fu_9751_p2 = (or_ln340_2737_fu_9745_p2.read() | and_ln416_716_fu_9669_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_2739_fu_19845_p2() {
    or_ln340_2739_fu_19845_p2 = (tmp_5667_fu_19813_p3.read() | xor_ln340_763_fu_19839_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_2740_fu_9925_p2() {
    or_ln340_2740_fu_9925_p2 = (and_ln786_47_fu_9895_p2.read() | xor_ln779_47_fu_9863_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_2741_fu_9931_p2() {
    or_ln340_2741_fu_9931_p2 = (or_ln340_2740_fu_9925_p2.read() | and_ln416_717_fu_9849_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_2742_fu_19933_p2() {
    or_ln340_2742_fu_19933_p2 = (tmp_5674_fu_19901_p3.read() | xor_ln340_764_fu_19927_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_2743_fu_10105_p2() {
    or_ln340_2743_fu_10105_p2 = (and_ln786_48_fu_10075_p2.read() | xor_ln779_48_fu_10043_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_2744_fu_10111_p2() {
    or_ln340_2744_fu_10111_p2 = (or_ln340_2743_fu_10105_p2.read() | and_ln416_718_fu_10029_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_2745_fu_20021_p2() {
    or_ln340_2745_fu_20021_p2 = (tmp_5681_fu_19989_p3.read() | xor_ln340_765_fu_20015_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_2746_fu_10285_p2() {
    or_ln340_2746_fu_10285_p2 = (and_ln786_49_fu_10255_p2.read() | xor_ln779_49_fu_10223_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_2747_fu_10291_p2() {
    or_ln340_2747_fu_10291_p2 = (or_ln340_2746_fu_10285_p2.read() | and_ln416_719_fu_10209_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_2748_fu_20109_p2() {
    or_ln340_2748_fu_20109_p2 = (tmp_5688_fu_20077_p3.read() | xor_ln340_766_fu_20103_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_2749_fu_10465_p2() {
    or_ln340_2749_fu_10465_p2 = (and_ln786_50_fu_10435_p2.read() | xor_ln779_50_fu_10403_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_2750_fu_10471_p2() {
    or_ln340_2750_fu_10471_p2 = (or_ln340_2749_fu_10465_p2.read() | and_ln416_720_fu_10389_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_2751_fu_20197_p2() {
    or_ln340_2751_fu_20197_p2 = (tmp_5695_fu_20165_p3.read() | xor_ln340_767_fu_20191_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_2752_fu_10645_p2() {
    or_ln340_2752_fu_10645_p2 = (and_ln786_51_fu_10615_p2.read() | xor_ln779_51_fu_10583_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_2753_fu_10651_p2() {
    or_ln340_2753_fu_10651_p2 = (or_ln340_2752_fu_10645_p2.read() | and_ln416_721_fu_10569_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_2754_fu_20285_p2() {
    or_ln340_2754_fu_20285_p2 = (tmp_5702_fu_20253_p3.read() | xor_ln340_768_fu_20279_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_2755_fu_10825_p2() {
    or_ln340_2755_fu_10825_p2 = (and_ln786_52_fu_10795_p2.read() | xor_ln779_52_fu_10763_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_2756_fu_10831_p2() {
    or_ln340_2756_fu_10831_p2 = (or_ln340_2755_fu_10825_p2.read() | and_ln416_722_fu_10749_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_2757_fu_20373_p2() {
    or_ln340_2757_fu_20373_p2 = (tmp_5709_fu_20341_p3.read() | xor_ln340_769_fu_20367_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_2758_fu_11005_p2() {
    or_ln340_2758_fu_11005_p2 = (and_ln786_53_fu_10975_p2.read() | xor_ln779_53_fu_10943_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_2759_fu_11011_p2() {
    or_ln340_2759_fu_11011_p2 = (or_ln340_2758_fu_11005_p2.read() | and_ln416_723_fu_10929_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_2760_fu_20461_p2() {
    or_ln340_2760_fu_20461_p2 = (tmp_5716_fu_20429_p3.read() | xor_ln340_770_fu_20455_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_2761_fu_11185_p2() {
    or_ln340_2761_fu_11185_p2 = (and_ln786_54_fu_11155_p2.read() | xor_ln779_54_fu_11123_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_2762_fu_11191_p2() {
    or_ln340_2762_fu_11191_p2 = (or_ln340_2761_fu_11185_p2.read() | and_ln416_724_fu_11109_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_2763_fu_20549_p2() {
    or_ln340_2763_fu_20549_p2 = (tmp_5723_fu_20517_p3.read() | xor_ln340_771_fu_20543_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_2764_fu_11365_p2() {
    or_ln340_2764_fu_11365_p2 = (and_ln786_55_fu_11335_p2.read() | xor_ln779_55_fu_11303_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_2765_fu_11371_p2() {
    or_ln340_2765_fu_11371_p2 = (or_ln340_2764_fu_11365_p2.read() | and_ln416_725_fu_11289_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_2766_fu_20637_p2() {
    or_ln340_2766_fu_20637_p2 = (tmp_5730_fu_20605_p3.read() | xor_ln340_772_fu_20631_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_2767_fu_11545_p2() {
    or_ln340_2767_fu_11545_p2 = (and_ln786_56_fu_11515_p2.read() | xor_ln779_56_fu_11483_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_2768_fu_11551_p2() {
    or_ln340_2768_fu_11551_p2 = (or_ln340_2767_fu_11545_p2.read() | and_ln416_726_fu_11469_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_2769_fu_20725_p2() {
    or_ln340_2769_fu_20725_p2 = (tmp_5737_fu_20693_p3.read() | xor_ln340_773_fu_20719_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_2770_fu_11725_p2() {
    or_ln340_2770_fu_11725_p2 = (and_ln786_57_fu_11695_p2.read() | xor_ln779_57_fu_11663_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_2771_fu_11731_p2() {
    or_ln340_2771_fu_11731_p2 = (or_ln340_2770_fu_11725_p2.read() | and_ln416_727_fu_11649_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_2772_fu_20813_p2() {
    or_ln340_2772_fu_20813_p2 = (tmp_5744_fu_20781_p3.read() | xor_ln340_774_fu_20807_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_2773_fu_11905_p2() {
    or_ln340_2773_fu_11905_p2 = (and_ln786_58_fu_11875_p2.read() | xor_ln779_58_fu_11843_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_2774_fu_11911_p2() {
    or_ln340_2774_fu_11911_p2 = (or_ln340_2773_fu_11905_p2.read() | and_ln416_728_fu_11829_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_2775_fu_20901_p2() {
    or_ln340_2775_fu_20901_p2 = (tmp_5751_fu_20869_p3.read() | xor_ln340_775_fu_20895_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_2776_fu_21064_p2() {
    or_ln340_2776_fu_21064_p2 = (and_ln786_59_fu_21034_p2.read() | xor_ln779_59_fu_21002_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_2777_fu_21070_p2() {
    or_ln340_2777_fu_21070_p2 = (or_ln340_2776_fu_21064_p2.read() | and_ln416_729_fu_20988_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_2778_fu_21160_p2() {
    or_ln340_2778_fu_21160_p2 = (tmp_5758_fu_21128_p3.read() | xor_ln340_776_fu_21154_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_2779_fu_12095_p2() {
    or_ln340_2779_fu_12095_p2 = (and_ln786_60_fu_12065_p2.read() | xor_ln779_60_fu_12033_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_2780_fu_12101_p2() {
    or_ln340_2780_fu_12101_p2 = (or_ln340_2779_fu_12095_p2.read() | and_ln416_730_fu_12019_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_2781_fu_21248_p2() {
    or_ln340_2781_fu_21248_p2 = (tmp_5765_fu_21216_p3.read() | xor_ln340_777_fu_21242_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_2782_fu_12275_p2() {
    or_ln340_2782_fu_12275_p2 = (and_ln786_61_fu_12245_p2.read() | xor_ln779_61_fu_12213_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_2783_fu_12281_p2() {
    or_ln340_2783_fu_12281_p2 = (or_ln340_2782_fu_12275_p2.read() | and_ln416_731_fu_12199_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_2784_fu_21336_p2() {
    or_ln340_2784_fu_21336_p2 = (tmp_5772_fu_21304_p3.read() | xor_ln340_778_fu_21330_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_2785_fu_12455_p2() {
    or_ln340_2785_fu_12455_p2 = (and_ln786_62_fu_12425_p2.read() | xor_ln779_62_fu_12393_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_2786_fu_12461_p2() {
    or_ln340_2786_fu_12461_p2 = (or_ln340_2785_fu_12455_p2.read() | and_ln416_732_fu_12379_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_2787_fu_21424_p2() {
    or_ln340_2787_fu_21424_p2 = (tmp_5779_fu_21392_p3.read() | xor_ln340_779_fu_21418_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_2788_fu_12635_p2() {
    or_ln340_2788_fu_12635_p2 = (and_ln786_63_fu_12605_p2.read() | xor_ln779_63_fu_12573_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_2789_fu_12641_p2() {
    or_ln340_2789_fu_12641_p2 = (or_ln340_2788_fu_12635_p2.read() | and_ln416_733_fu_12559_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_2790_fu_21512_p2() {
    or_ln340_2790_fu_21512_p2 = (tmp_5786_fu_21480_p3.read() | xor_ln340_780_fu_21506_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_2791_fu_12815_p2() {
    or_ln340_2791_fu_12815_p2 = (and_ln786_64_fu_12785_p2.read() | xor_ln779_64_fu_12753_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_2792_fu_12821_p2() {
    or_ln340_2792_fu_12821_p2 = (or_ln340_2791_fu_12815_p2.read() | and_ln416_734_fu_12739_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_2793_fu_21600_p2() {
    or_ln340_2793_fu_21600_p2 = (tmp_5793_fu_21568_p3.read() | xor_ln340_781_fu_21594_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_2794_fu_12995_p2() {
    or_ln340_2794_fu_12995_p2 = (and_ln786_65_fu_12965_p2.read() | xor_ln779_65_fu_12933_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_2795_fu_13001_p2() {
    or_ln340_2795_fu_13001_p2 = (or_ln340_2794_fu_12995_p2.read() | and_ln416_735_fu_12919_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_2796_fu_21688_p2() {
    or_ln340_2796_fu_21688_p2 = (tmp_5800_fu_21656_p3.read() | xor_ln340_782_fu_21682_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_2797_fu_13175_p2() {
    or_ln340_2797_fu_13175_p2 = (and_ln786_66_fu_13145_p2.read() | xor_ln779_66_fu_13113_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_2798_fu_13181_p2() {
    or_ln340_2798_fu_13181_p2 = (or_ln340_2797_fu_13175_p2.read() | and_ln416_736_fu_13099_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_2799_fu_21776_p2() {
    or_ln340_2799_fu_21776_p2 = (tmp_5807_fu_21744_p3.read() | xor_ln340_783_fu_21770_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_27_fu_6489_p2() {
    or_ln340_27_fu_6489_p2 = (and_ln786_1981_fu_6483_p2.read() | and_ln785_697_fu_6459_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_2800_fu_13355_p2() {
    or_ln340_2800_fu_13355_p2 = (and_ln786_67_fu_13325_p2.read() | xor_ln779_67_fu_13293_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_2801_fu_13361_p2() {
    or_ln340_2801_fu_13361_p2 = (or_ln340_2800_fu_13355_p2.read() | and_ln416_737_fu_13279_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_2802_fu_21864_p2() {
    or_ln340_2802_fu_21864_p2 = (tmp_5814_fu_21832_p3.read() | xor_ln340_784_fu_21858_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_2803_fu_13535_p2() {
    or_ln340_2803_fu_13535_p2 = (and_ln786_68_fu_13505_p2.read() | xor_ln779_68_fu_13473_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_2804_fu_13541_p2() {
    or_ln340_2804_fu_13541_p2 = (or_ln340_2803_fu_13535_p2.read() | and_ln416_738_fu_13459_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_2805_fu_21952_p2() {
    or_ln340_2805_fu_21952_p2 = (tmp_5821_fu_21920_p3.read() | xor_ln340_785_fu_21946_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_2806_fu_13715_p2() {
    or_ln340_2806_fu_13715_p2 = (and_ln786_69_fu_13685_p2.read() | xor_ln779_69_fu_13653_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_2807_fu_13721_p2() {
    or_ln340_2807_fu_13721_p2 = (or_ln340_2806_fu_13715_p2.read() | and_ln416_739_fu_13639_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_2808_fu_22040_p2() {
    or_ln340_2808_fu_22040_p2 = (tmp_5828_fu_22008_p3.read() | xor_ln340_786_fu_22034_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_2809_fu_13895_p2() {
    or_ln340_2809_fu_13895_p2 = (and_ln786_70_fu_13865_p2.read() | xor_ln779_70_fu_13833_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_2810_fu_13901_p2() {
    or_ln340_2810_fu_13901_p2 = (or_ln340_2809_fu_13895_p2.read() | and_ln416_740_fu_13819_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_2811_fu_22128_p2() {
    or_ln340_2811_fu_22128_p2 = (tmp_5835_fu_22096_p3.read() | xor_ln340_787_fu_22122_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_2812_fu_14075_p2() {
    or_ln340_2812_fu_14075_p2 = (and_ln786_71_fu_14045_p2.read() | xor_ln779_71_fu_14013_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_2813_fu_14081_p2() {
    or_ln340_2813_fu_14081_p2 = (or_ln340_2812_fu_14075_p2.read() | and_ln416_741_fu_13999_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_2814_fu_22216_p2() {
    or_ln340_2814_fu_22216_p2 = (tmp_5842_fu_22184_p3.read() | xor_ln340_788_fu_22210_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_2815_fu_14255_p2() {
    or_ln340_2815_fu_14255_p2 = (and_ln786_72_fu_14225_p2.read() | xor_ln779_72_fu_14193_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_2816_fu_14261_p2() {
    or_ln340_2816_fu_14261_p2 = (or_ln340_2815_fu_14255_p2.read() | and_ln416_742_fu_14179_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_2817_fu_22304_p2() {
    or_ln340_2817_fu_22304_p2 = (tmp_5849_fu_22272_p3.read() | xor_ln340_789_fu_22298_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_2818_fu_14435_p2() {
    or_ln340_2818_fu_14435_p2 = (and_ln786_73_fu_14405_p2.read() | xor_ln779_73_fu_14373_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_2819_fu_14441_p2() {
    or_ln340_2819_fu_14441_p2 = (or_ln340_2818_fu_14435_p2.read() | and_ln416_743_fu_14359_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_2820_fu_22392_p2() {
    or_ln340_2820_fu_22392_p2 = (tmp_5856_fu_22360_p3.read() | xor_ln340_790_fu_22386_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_2821_fu_14615_p2() {
    or_ln340_2821_fu_14615_p2 = (and_ln786_74_fu_14585_p2.read() | xor_ln779_74_fu_14553_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_2822_fu_14621_p2() {
    or_ln340_2822_fu_14621_p2 = (or_ln340_2821_fu_14615_p2.read() | and_ln416_744_fu_14539_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_2823_fu_22480_p2() {
    or_ln340_2823_fu_22480_p2 = (tmp_5863_fu_22448_p3.read() | xor_ln340_791_fu_22474_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_2824_fu_14795_p2() {
    or_ln340_2824_fu_14795_p2 = (and_ln786_75_fu_14765_p2.read() | xor_ln779_75_fu_14733_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_2825_fu_14801_p2() {
    or_ln340_2825_fu_14801_p2 = (or_ln340_2824_fu_14795_p2.read() | and_ln416_745_fu_14719_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_2826_fu_22568_p2() {
    or_ln340_2826_fu_22568_p2 = (tmp_5870_fu_22536_p3.read() | xor_ln340_792_fu_22562_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_2827_fu_14975_p2() {
    or_ln340_2827_fu_14975_p2 = (and_ln786_76_fu_14945_p2.read() | xor_ln779_76_fu_14913_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_2828_fu_14981_p2() {
    or_ln340_2828_fu_14981_p2 = (or_ln340_2827_fu_14975_p2.read() | and_ln416_746_fu_14899_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_2829_fu_22656_p2() {
    or_ln340_2829_fu_22656_p2 = (tmp_5877_fu_22624_p3.read() | xor_ln340_793_fu_22650_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_2830_fu_15155_p2() {
    or_ln340_2830_fu_15155_p2 = (and_ln786_77_fu_15125_p2.read() | xor_ln779_77_fu_15093_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_2831_fu_15161_p2() {
    or_ln340_2831_fu_15161_p2 = (or_ln340_2830_fu_15155_p2.read() | and_ln416_747_fu_15079_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_2832_fu_22744_p2() {
    or_ln340_2832_fu_22744_p2 = (tmp_5884_fu_22712_p3.read() | xor_ln340_794_fu_22738_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_2833_fu_15335_p2() {
    or_ln340_2833_fu_15335_p2 = (and_ln786_78_fu_15305_p2.read() | xor_ln779_78_fu_15273_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_2834_fu_15341_p2() {
    or_ln340_2834_fu_15341_p2 = (or_ln340_2833_fu_15335_p2.read() | and_ln416_748_fu_15259_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_2835_fu_22832_p2() {
    or_ln340_2835_fu_22832_p2 = (tmp_5891_fu_22800_p3.read() | xor_ln340_795_fu_22826_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_2836_fu_22995_p2() {
    or_ln340_2836_fu_22995_p2 = (and_ln786_79_fu_22965_p2.read() | xor_ln779_79_fu_22933_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_2837_fu_23001_p2() {
    or_ln340_2837_fu_23001_p2 = (or_ln340_2836_fu_22995_p2.read() | and_ln416_749_fu_22919_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_2838_fu_23091_p2() {
    or_ln340_2838_fu_23091_p2 = (tmp_5898_fu_23059_p3.read() | xor_ln340_796_fu_23085_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_28_fu_6669_p2() {
    or_ln340_28_fu_6669_p2 = (and_ln786_1983_fu_6663_p2.read() | and_ln785_698_fu_6639_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_29_fu_6849_p2() {
    or_ln340_29_fu_6849_p2 = (and_ln786_1985_fu_6843_p2.read() | and_ln785_699_fu_6819_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_2_fu_1959_p2() {
    or_ln340_2_fu_1959_p2 = (and_ln786_1931_fu_1953_p2.read() | and_ln785_672_fu_1929_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_30_fu_7029_p2() {
    or_ln340_30_fu_7029_p2 = (and_ln786_1987_fu_7023_p2.read() | and_ln785_700_fu_6999_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_31_fu_7209_p2() {
    or_ln340_31_fu_7209_p2 = (and_ln786_1989_fu_7203_p2.read() | and_ln785_701_fu_7179_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_32_fu_7389_p2() {
    or_ln340_32_fu_7389_p2 = (and_ln786_1991_fu_7383_p2.read() | and_ln785_702_fu_7359_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_33_fu_7569_p2() {
    or_ln340_33_fu_7569_p2 = (and_ln786_1993_fu_7563_p2.read() | and_ln785_703_fu_7539_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_34_fu_7749_p2() {
    or_ln340_34_fu_7749_p2 = (and_ln786_1995_fu_7743_p2.read() | and_ln785_704_fu_7719_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_35_fu_7929_p2() {
    or_ln340_35_fu_7929_p2 = (and_ln786_1997_fu_7923_p2.read() | and_ln785_705_fu_7899_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_36_fu_8109_p2() {
    or_ln340_36_fu_8109_p2 = (and_ln786_1999_fu_8103_p2.read() | and_ln785_706_fu_8079_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_37_fu_8289_p2() {
    or_ln340_37_fu_8289_p2 = (and_ln786_2001_fu_8283_p2.read() | and_ln785_707_fu_8259_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_38_fu_8469_p2() {
    or_ln340_38_fu_8469_p2 = (and_ln786_2003_fu_8463_p2.read() | and_ln785_708_fu_8439_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_39_fu_19127_p2() {
    or_ln340_39_fu_19127_p2 = (and_ln786_2005_fu_19121_p2.read() | and_ln785_709_fu_19097_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_3_fu_2159_p2() {
    or_ln340_3_fu_2159_p2 = (and_ln786_1933_fu_2153_p2.read() | and_ln785_673_fu_2129_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_40_fu_8659_p2() {
    or_ln340_40_fu_8659_p2 = (and_ln786_2007_fu_8653_p2.read() | and_ln785_710_fu_8629_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_41_fu_8839_p2() {
    or_ln340_41_fu_8839_p2 = (and_ln786_2009_fu_8833_p2.read() | and_ln785_711_fu_8809_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_42_fu_9019_p2() {
    or_ln340_42_fu_9019_p2 = (and_ln786_2011_fu_9013_p2.read() | and_ln785_712_fu_8989_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_43_fu_9199_p2() {
    or_ln340_43_fu_9199_p2 = (and_ln786_2013_fu_9193_p2.read() | and_ln785_713_fu_9169_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_44_fu_9379_p2() {
    or_ln340_44_fu_9379_p2 = (and_ln786_2015_fu_9373_p2.read() | and_ln785_714_fu_9349_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_45_fu_9559_p2() {
    or_ln340_45_fu_9559_p2 = (and_ln786_2017_fu_9553_p2.read() | and_ln785_715_fu_9529_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_46_fu_9739_p2() {
    or_ln340_46_fu_9739_p2 = (and_ln786_2019_fu_9733_p2.read() | and_ln785_716_fu_9709_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_47_fu_9919_p2() {
    or_ln340_47_fu_9919_p2 = (and_ln786_2021_fu_9913_p2.read() | and_ln785_717_fu_9889_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_48_fu_10099_p2() {
    or_ln340_48_fu_10099_p2 = (and_ln786_2023_fu_10093_p2.read() | and_ln785_718_fu_10069_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_49_fu_10279_p2() {
    or_ln340_49_fu_10279_p2 = (and_ln786_2025_fu_10273_p2.read() | and_ln785_719_fu_10249_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_4_fu_2351_p2() {
    or_ln340_4_fu_2351_p2 = (and_ln786_1935_fu_2345_p2.read() | and_ln785_674_fu_2321_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_50_fu_10459_p2() {
    or_ln340_50_fu_10459_p2 = (and_ln786_2027_fu_10453_p2.read() | and_ln785_720_fu_10429_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_51_fu_10639_p2() {
    or_ln340_51_fu_10639_p2 = (and_ln786_2029_fu_10633_p2.read() | and_ln785_721_fu_10609_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_52_fu_10819_p2() {
    or_ln340_52_fu_10819_p2 = (and_ln786_2031_fu_10813_p2.read() | and_ln785_722_fu_10789_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_53_fu_10999_p2() {
    or_ln340_53_fu_10999_p2 = (and_ln786_2033_fu_10993_p2.read() | and_ln785_723_fu_10969_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_54_fu_11179_p2() {
    or_ln340_54_fu_11179_p2 = (and_ln786_2035_fu_11173_p2.read() | and_ln785_724_fu_11149_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_55_fu_11359_p2() {
    or_ln340_55_fu_11359_p2 = (and_ln786_2037_fu_11353_p2.read() | and_ln785_725_fu_11329_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_56_fu_11539_p2() {
    or_ln340_56_fu_11539_p2 = (and_ln786_2039_fu_11533_p2.read() | and_ln785_726_fu_11509_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_57_fu_11719_p2() {
    or_ln340_57_fu_11719_p2 = (and_ln786_2041_fu_11713_p2.read() | and_ln785_727_fu_11689_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_58_fu_11899_p2() {
    or_ln340_58_fu_11899_p2 = (and_ln786_2043_fu_11893_p2.read() | and_ln785_728_fu_11869_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_59_fu_21058_p2() {
    or_ln340_59_fu_21058_p2 = (and_ln786_2045_fu_21052_p2.read() | and_ln785_729_fu_21028_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_5_fu_2543_p2() {
    or_ln340_5_fu_2543_p2 = (and_ln786_1937_fu_2537_p2.read() | and_ln785_675_fu_2513_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_60_fu_12089_p2() {
    or_ln340_60_fu_12089_p2 = (and_ln786_2047_fu_12083_p2.read() | and_ln785_730_fu_12059_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_61_fu_12269_p2() {
    or_ln340_61_fu_12269_p2 = (and_ln786_2049_fu_12263_p2.read() | and_ln785_731_fu_12239_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_62_fu_12449_p2() {
    or_ln340_62_fu_12449_p2 = (and_ln786_2051_fu_12443_p2.read() | and_ln785_732_fu_12419_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_63_fu_12629_p2() {
    or_ln340_63_fu_12629_p2 = (and_ln786_2053_fu_12623_p2.read() | and_ln785_733_fu_12599_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_64_fu_12809_p2() {
    or_ln340_64_fu_12809_p2 = (and_ln786_2055_fu_12803_p2.read() | and_ln785_734_fu_12779_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_65_fu_12989_p2() {
    or_ln340_65_fu_12989_p2 = (and_ln786_2057_fu_12983_p2.read() | and_ln785_735_fu_12959_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_66_fu_13169_p2() {
    or_ln340_66_fu_13169_p2 = (and_ln786_2059_fu_13163_p2.read() | and_ln785_736_fu_13139_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_67_fu_13349_p2() {
    or_ln340_67_fu_13349_p2 = (and_ln786_2061_fu_13343_p2.read() | and_ln785_737_fu_13319_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_68_fu_13529_p2() {
    or_ln340_68_fu_13529_p2 = (and_ln786_2063_fu_13523_p2.read() | and_ln785_738_fu_13499_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_69_fu_13709_p2() {
    or_ln340_69_fu_13709_p2 = (and_ln786_2065_fu_13703_p2.read() | and_ln785_739_fu_13679_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_6_fu_2735_p2() {
    or_ln340_6_fu_2735_p2 = (and_ln786_1939_fu_2729_p2.read() | and_ln785_676_fu_2705_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_70_fu_13889_p2() {
    or_ln340_70_fu_13889_p2 = (and_ln786_2067_fu_13883_p2.read() | and_ln785_740_fu_13859_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_71_fu_14069_p2() {
    or_ln340_71_fu_14069_p2 = (and_ln786_2069_fu_14063_p2.read() | and_ln785_741_fu_14039_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_72_fu_14249_p2() {
    or_ln340_72_fu_14249_p2 = (and_ln786_2071_fu_14243_p2.read() | and_ln785_742_fu_14219_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_73_fu_14429_p2() {
    or_ln340_73_fu_14429_p2 = (and_ln786_2073_fu_14423_p2.read() | and_ln785_743_fu_14399_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_74_fu_14609_p2() {
    or_ln340_74_fu_14609_p2 = (and_ln786_2075_fu_14603_p2.read() | and_ln785_744_fu_14579_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_75_fu_14789_p2() {
    or_ln340_75_fu_14789_p2 = (and_ln786_2077_fu_14783_p2.read() | and_ln785_745_fu_14759_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_76_fu_14969_p2() {
    or_ln340_76_fu_14969_p2 = (and_ln786_2079_fu_14963_p2.read() | and_ln785_746_fu_14939_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_77_fu_15149_p2() {
    or_ln340_77_fu_15149_p2 = (and_ln786_2081_fu_15143_p2.read() | and_ln785_747_fu_15119_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_78_fu_15329_p2() {
    or_ln340_78_fu_15329_p2 = (and_ln786_2083_fu_15323_p2.read() | and_ln785_748_fu_15299_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_79_fu_22989_p2() {
    or_ln340_79_fu_22989_p2 = (and_ln786_2085_fu_22983_p2.read() | and_ln785_749_fu_22959_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_7_fu_2927_p2() {
    or_ln340_7_fu_2927_p2 = (and_ln786_1941_fu_2921_p2.read() | and_ln785_677_fu_2897_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_8_fu_3119_p2() {
    or_ln340_8_fu_3119_p2 = (and_ln786_1943_fu_3113_p2.read() | and_ln785_678_fu_3089_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_925_fu_3311_p2() {
    or_ln340_925_fu_3311_p2 = (and_ln786_1945_fu_3305_p2.read() | and_ln785_679_fu_3281_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_fu_1559_p2() {
    or_ln340_fu_1559_p2 = (and_ln786_1927_fu_1553_p2.read() | and_ln785_fu_1529_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln785_10_fu_3467_p2() {
    or_ln785_10_fu_3467_p2 = (tmp_5413_fu_3439_p3.read() | xor_ln785_10_fu_3461_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln785_11_fu_3659_p2() {
    or_ln785_11_fu_3659_p2 = (tmp_5420_fu_3631_p3.read() | xor_ln785_11_fu_3653_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln785_12_fu_3851_p2() {
    or_ln785_12_fu_3851_p2 = (tmp_5427_fu_3823_p3.read() | xor_ln785_12_fu_3845_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln785_13_fu_4043_p2() {
    or_ln785_13_fu_4043_p2 = (tmp_5434_fu_4015_p3.read() | xor_ln785_13_fu_4037_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln785_14_fu_4235_p2() {
    or_ln785_14_fu_4235_p2 = (tmp_5441_fu_4207_p3.read() | xor_ln785_14_fu_4229_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln785_15_fu_4427_p2() {
    or_ln785_15_fu_4427_p2 = (tmp_5448_fu_4399_p3.read() | xor_ln785_15_fu_4421_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln785_16_fu_4619_p2() {
    or_ln785_16_fu_4619_p2 = (tmp_5455_fu_4591_p3.read() | xor_ln785_16_fu_4613_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln785_17_fu_4811_p2() {
    or_ln785_17_fu_4811_p2 = (tmp_5462_fu_4783_p3.read() | xor_ln785_17_fu_4805_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln785_18_fu_5003_p2() {
    or_ln785_18_fu_5003_p2 = (tmp_5469_fu_4975_p3.read() | xor_ln785_18_fu_4997_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln785_19_fu_17160_p2() {
    or_ln785_19_fu_17160_p2 = (tmp_5476_fu_17132_p3.read() | xor_ln785_19_fu_17154_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln785_1_fu_1723_p2() {
    or_ln785_1_fu_1723_p2 = (tmp_5350_fu_1695_p3.read() | xor_ln785_1_fu_1717_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln785_20_fu_5193_p2() {
    or_ln785_20_fu_5193_p2 = (tmp_5483_fu_5165_p3.read() | xor_ln785_20_fu_5187_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln785_21_fu_5373_p2() {
    or_ln785_21_fu_5373_p2 = (tmp_5490_fu_5345_p3.read() | xor_ln785_21_fu_5367_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln785_22_fu_5553_p2() {
    or_ln785_22_fu_5553_p2 = (tmp_5497_fu_5525_p3.read() | xor_ln785_22_fu_5547_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln785_23_fu_5733_p2() {
    or_ln785_23_fu_5733_p2 = (tmp_5504_fu_5705_p3.read() | xor_ln785_23_fu_5727_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln785_24_fu_5913_p2() {
    or_ln785_24_fu_5913_p2 = (tmp_5511_fu_5885_p3.read() | xor_ln785_24_fu_5907_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln785_25_fu_6093_p2() {
    or_ln785_25_fu_6093_p2 = (tmp_5518_fu_6065_p3.read() | xor_ln785_25_fu_6087_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln785_26_fu_6273_p2() {
    or_ln785_26_fu_6273_p2 = (tmp_5525_fu_6245_p3.read() | xor_ln785_26_fu_6267_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln785_27_fu_6453_p2() {
    or_ln785_27_fu_6453_p2 = (tmp_5532_fu_6425_p3.read() | xor_ln785_27_fu_6447_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln785_28_fu_6633_p2() {
    or_ln785_28_fu_6633_p2 = (tmp_5539_fu_6605_p3.read() | xor_ln785_28_fu_6627_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln785_29_fu_6813_p2() {
    or_ln785_29_fu_6813_p2 = (tmp_5546_fu_6785_p3.read() | xor_ln785_29_fu_6807_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln785_2_fu_1923_p2() {
    or_ln785_2_fu_1923_p2 = (tmp_5357_fu_1895_p3.read() | xor_ln785_2_fu_1917_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln785_30_fu_6993_p2() {
    or_ln785_30_fu_6993_p2 = (tmp_5553_fu_6965_p3.read() | xor_ln785_30_fu_6987_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln785_31_fu_7173_p2() {
    or_ln785_31_fu_7173_p2 = (tmp_5560_fu_7145_p3.read() | xor_ln785_31_fu_7167_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln785_32_fu_7353_p2() {
    or_ln785_32_fu_7353_p2 = (tmp_5567_fu_7325_p3.read() | xor_ln785_32_fu_7347_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln785_33_fu_7533_p2() {
    or_ln785_33_fu_7533_p2 = (tmp_5574_fu_7505_p3.read() | xor_ln785_33_fu_7527_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln785_34_fu_7713_p2() {
    or_ln785_34_fu_7713_p2 = (tmp_5581_fu_7685_p3.read() | xor_ln785_34_fu_7707_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln785_35_fu_7893_p2() {
    or_ln785_35_fu_7893_p2 = (tmp_5588_fu_7865_p3.read() | xor_ln785_35_fu_7887_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln785_36_fu_8073_p2() {
    or_ln785_36_fu_8073_p2 = (tmp_5595_fu_8045_p3.read() | xor_ln785_36_fu_8067_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln785_37_fu_8253_p2() {
    or_ln785_37_fu_8253_p2 = (tmp_5602_fu_8225_p3.read() | xor_ln785_37_fu_8247_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln785_38_fu_8433_p2() {
    or_ln785_38_fu_8433_p2 = (tmp_5609_fu_8405_p3.read() | xor_ln785_38_fu_8427_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln785_39_fu_19091_p2() {
    or_ln785_39_fu_19091_p2 = (tmp_5616_fu_19063_p3.read() | xor_ln785_39_fu_19085_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln785_3_fu_2123_p2() {
    or_ln785_3_fu_2123_p2 = (tmp_5364_fu_2095_p3.read() | xor_ln785_3_fu_2117_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln785_40_fu_8623_p2() {
    or_ln785_40_fu_8623_p2 = (tmp_5623_fu_8595_p3.read() | xor_ln785_40_fu_8617_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln785_418_fu_2315_p2() {
    or_ln785_418_fu_2315_p2 = (tmp_5371_fu_2287_p3.read() | xor_ln785_4_fu_2309_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln785_41_fu_8803_p2() {
    or_ln785_41_fu_8803_p2 = (tmp_5630_fu_8775_p3.read() | xor_ln785_41_fu_8797_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln785_42_fu_8983_p2() {
    or_ln785_42_fu_8983_p2 = (tmp_5637_fu_8955_p3.read() | xor_ln785_42_fu_8977_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln785_43_fu_9163_p2() {
    or_ln785_43_fu_9163_p2 = (tmp_5644_fu_9135_p3.read() | xor_ln785_43_fu_9157_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln785_44_fu_9343_p2() {
    or_ln785_44_fu_9343_p2 = (tmp_5651_fu_9315_p3.read() | xor_ln785_44_fu_9337_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln785_45_fu_9523_p2() {
    or_ln785_45_fu_9523_p2 = (tmp_5658_fu_9495_p3.read() | xor_ln785_45_fu_9517_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln785_46_fu_9703_p2() {
    or_ln785_46_fu_9703_p2 = (tmp_5665_fu_9675_p3.read() | xor_ln785_46_fu_9697_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln785_47_fu_9883_p2() {
    or_ln785_47_fu_9883_p2 = (tmp_5672_fu_9855_p3.read() | xor_ln785_47_fu_9877_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln785_48_fu_10063_p2() {
    or_ln785_48_fu_10063_p2 = (tmp_5679_fu_10035_p3.read() | xor_ln785_48_fu_10057_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln785_49_fu_10243_p2() {
    or_ln785_49_fu_10243_p2 = (tmp_5686_fu_10215_p3.read() | xor_ln785_49_fu_10237_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln785_50_fu_10423_p2() {
    or_ln785_50_fu_10423_p2 = (tmp_5693_fu_10395_p3.read() | xor_ln785_50_fu_10417_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln785_51_fu_10603_p2() {
    or_ln785_51_fu_10603_p2 = (tmp_5700_fu_10575_p3.read() | xor_ln785_51_fu_10597_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln785_52_fu_10783_p2() {
    or_ln785_52_fu_10783_p2 = (tmp_5707_fu_10755_p3.read() | xor_ln785_52_fu_10777_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln785_53_fu_10963_p2() {
    or_ln785_53_fu_10963_p2 = (tmp_5714_fu_10935_p3.read() | xor_ln785_53_fu_10957_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln785_54_fu_11143_p2() {
    or_ln785_54_fu_11143_p2 = (tmp_5721_fu_11115_p3.read() | xor_ln785_54_fu_11137_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln785_55_fu_11323_p2() {
    or_ln785_55_fu_11323_p2 = (tmp_5728_fu_11295_p3.read() | xor_ln785_55_fu_11317_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln785_56_fu_11503_p2() {
    or_ln785_56_fu_11503_p2 = (tmp_5735_fu_11475_p3.read() | xor_ln785_56_fu_11497_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln785_57_fu_11683_p2() {
    or_ln785_57_fu_11683_p2 = (tmp_5742_fu_11655_p3.read() | xor_ln785_57_fu_11677_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln785_58_fu_11863_p2() {
    or_ln785_58_fu_11863_p2 = (tmp_5749_fu_11835_p3.read() | xor_ln785_58_fu_11857_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln785_59_fu_21022_p2() {
    or_ln785_59_fu_21022_p2 = (tmp_5756_fu_20994_p3.read() | xor_ln785_59_fu_21016_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln785_5_fu_2507_p2() {
    or_ln785_5_fu_2507_p2 = (tmp_5378_fu_2479_p3.read() | xor_ln785_5_fu_2501_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln785_60_fu_12053_p2() {
    or_ln785_60_fu_12053_p2 = (tmp_5763_fu_12025_p3.read() | xor_ln785_60_fu_12047_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln785_61_fu_12233_p2() {
    or_ln785_61_fu_12233_p2 = (tmp_5770_fu_12205_p3.read() | xor_ln785_61_fu_12227_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln785_62_fu_12413_p2() {
    or_ln785_62_fu_12413_p2 = (tmp_5777_fu_12385_p3.read() | xor_ln785_62_fu_12407_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln785_63_fu_12593_p2() {
    or_ln785_63_fu_12593_p2 = (tmp_5784_fu_12565_p3.read() | xor_ln785_63_fu_12587_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln785_64_fu_12773_p2() {
    or_ln785_64_fu_12773_p2 = (tmp_5791_fu_12745_p3.read() | xor_ln785_64_fu_12767_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln785_65_fu_12953_p2() {
    or_ln785_65_fu_12953_p2 = (tmp_5798_fu_12925_p3.read() | xor_ln785_65_fu_12947_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln785_66_fu_13133_p2() {
    or_ln785_66_fu_13133_p2 = (tmp_5805_fu_13105_p3.read() | xor_ln785_66_fu_13127_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln785_67_fu_13313_p2() {
    or_ln785_67_fu_13313_p2 = (tmp_5812_fu_13285_p3.read() | xor_ln785_67_fu_13307_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln785_68_fu_13493_p2() {
    or_ln785_68_fu_13493_p2 = (tmp_5819_fu_13465_p3.read() | xor_ln785_68_fu_13487_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln785_69_fu_13673_p2() {
    or_ln785_69_fu_13673_p2 = (tmp_5826_fu_13645_p3.read() | xor_ln785_69_fu_13667_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln785_6_fu_2699_p2() {
    or_ln785_6_fu_2699_p2 = (tmp_5385_fu_2671_p3.read() | xor_ln785_535_fu_2693_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln785_70_fu_13853_p2() {
    or_ln785_70_fu_13853_p2 = (tmp_5833_fu_13825_p3.read() | xor_ln785_70_fu_13847_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln785_71_fu_14033_p2() {
    or_ln785_71_fu_14033_p2 = (tmp_5840_fu_14005_p3.read() | xor_ln785_71_fu_14027_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln785_72_fu_14213_p2() {
    or_ln785_72_fu_14213_p2 = (tmp_5847_fu_14185_p3.read() | xor_ln785_72_fu_14207_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln785_73_fu_14393_p2() {
    or_ln785_73_fu_14393_p2 = (tmp_5854_fu_14365_p3.read() | xor_ln785_73_fu_14387_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln785_74_fu_14573_p2() {
    or_ln785_74_fu_14573_p2 = (tmp_5861_fu_14545_p3.read() | xor_ln785_74_fu_14567_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln785_75_fu_14753_p2() {
    or_ln785_75_fu_14753_p2 = (tmp_5868_fu_14725_p3.read() | xor_ln785_75_fu_14747_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln785_76_fu_14933_p2() {
    or_ln785_76_fu_14933_p2 = (tmp_5875_fu_14905_p3.read() | xor_ln785_76_fu_14927_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln785_77_fu_15113_p2() {
    or_ln785_77_fu_15113_p2 = (tmp_5882_fu_15085_p3.read() | xor_ln785_77_fu_15107_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln785_78_fu_15293_p2() {
    or_ln785_78_fu_15293_p2 = (tmp_5889_fu_15265_p3.read() | xor_ln785_78_fu_15287_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln785_79_fu_22953_p2() {
    or_ln785_79_fu_22953_p2 = (tmp_5896_fu_22925_p3.read() | xor_ln785_79_fu_22947_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln785_7_fu_2891_p2() {
    or_ln785_7_fu_2891_p2 = (tmp_5392_fu_2863_p3.read() | xor_ln785_536_fu_2885_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln785_8_fu_3083_p2() {
    or_ln785_8_fu_3083_p2 = (tmp_5399_fu_3055_p3.read() | xor_ln785_8_fu_3077_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln785_9_fu_3275_p2() {
    or_ln785_9_fu_3275_p2 = (tmp_5406_fu_3247_p3.read() | xor_ln785_9_fu_3269_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln785_fu_1523_p2() {
    or_ln785_fu_1523_p2 = (tmp_5343_fu_1495_p3.read() | xor_ln785_fu_1517_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln786_671_fu_1741_p2() {
    or_ln786_671_fu_1741_p2 = (and_ln416_671_fu_1689_p2.read() | and_ln786_1_fu_1735_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln786_672_fu_1941_p2() {
    or_ln786_672_fu_1941_p2 = (and_ln416_672_fu_1889_p2.read() | and_ln786_2_fu_1935_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln786_673_fu_2141_p2() {
    or_ln786_673_fu_2141_p2 = (and_ln416_673_fu_2089_p2.read() | and_ln786_3_fu_2135_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln786_674_fu_2333_p2() {
    or_ln786_674_fu_2333_p2 = (and_ln416_674_fu_2281_p2.read() | and_ln786_4_fu_2327_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln786_675_fu_2525_p2() {
    or_ln786_675_fu_2525_p2 = (and_ln416_675_fu_2473_p2.read() | and_ln786_5_fu_2519_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln786_676_fu_2717_p2() {
    or_ln786_676_fu_2717_p2 = (and_ln416_676_fu_2665_p2.read() | and_ln786_6_fu_2711_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln786_677_fu_2909_p2() {
    or_ln786_677_fu_2909_p2 = (and_ln416_677_fu_2857_p2.read() | and_ln786_7_fu_2903_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln786_678_fu_3101_p2() {
    or_ln786_678_fu_3101_p2 = (and_ln416_678_fu_3049_p2.read() | and_ln786_8_fu_3095_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln786_679_fu_3293_p2() {
    or_ln786_679_fu_3293_p2 = (and_ln416_679_fu_3241_p2.read() | and_ln786_9_fu_3287_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln786_680_fu_3485_p2() {
    or_ln786_680_fu_3485_p2 = (and_ln416_680_fu_3433_p2.read() | and_ln786_10_fu_3479_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln786_681_fu_3677_p2() {
    or_ln786_681_fu_3677_p2 = (and_ln416_681_fu_3625_p2.read() | and_ln786_11_fu_3671_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln786_682_fu_3869_p2() {
    or_ln786_682_fu_3869_p2 = (and_ln416_682_fu_3817_p2.read() | and_ln786_12_fu_3863_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln786_683_fu_4061_p2() {
    or_ln786_683_fu_4061_p2 = (and_ln416_683_fu_4009_p2.read() | and_ln786_13_fu_4055_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln786_684_fu_4253_p2() {
    or_ln786_684_fu_4253_p2 = (and_ln416_684_fu_4201_p2.read() | and_ln786_14_fu_4247_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln786_685_fu_4445_p2() {
    or_ln786_685_fu_4445_p2 = (and_ln416_685_fu_4393_p2.read() | and_ln786_15_fu_4439_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln786_686_fu_4637_p2() {
    or_ln786_686_fu_4637_p2 = (and_ln416_686_fu_4585_p2.read() | and_ln786_16_fu_4631_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln786_687_fu_4829_p2() {
    or_ln786_687_fu_4829_p2 = (and_ln416_687_fu_4777_p2.read() | and_ln786_17_fu_4823_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln786_688_fu_5021_p2() {
    or_ln786_688_fu_5021_p2 = (and_ln416_688_fu_4969_p2.read() | and_ln786_18_fu_5015_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln786_689_fu_17178_p2() {
    or_ln786_689_fu_17178_p2 = (and_ln416_689_fu_17126_p2.read() | and_ln786_19_fu_17172_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln786_690_fu_5211_p2() {
    or_ln786_690_fu_5211_p2 = (and_ln416_690_fu_5159_p2.read() | and_ln786_20_fu_5205_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln786_691_fu_5391_p2() {
    or_ln786_691_fu_5391_p2 = (and_ln416_691_fu_5339_p2.read() | and_ln786_21_fu_5385_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln786_692_fu_5571_p2() {
    or_ln786_692_fu_5571_p2 = (and_ln416_692_fu_5519_p2.read() | and_ln786_22_fu_5565_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln786_693_fu_5751_p2() {
    or_ln786_693_fu_5751_p2 = (and_ln416_693_fu_5699_p2.read() | and_ln786_23_fu_5745_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln786_694_fu_5931_p2() {
    or_ln786_694_fu_5931_p2 = (and_ln416_694_fu_5879_p2.read() | and_ln786_24_fu_5925_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln786_695_fu_6111_p2() {
    or_ln786_695_fu_6111_p2 = (and_ln416_695_fu_6059_p2.read() | and_ln786_25_fu_6105_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln786_696_fu_6291_p2() {
    or_ln786_696_fu_6291_p2 = (and_ln416_696_fu_6239_p2.read() | and_ln786_26_fu_6285_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln786_697_fu_6471_p2() {
    or_ln786_697_fu_6471_p2 = (and_ln416_697_fu_6419_p2.read() | and_ln786_27_fu_6465_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln786_698_fu_6651_p2() {
    or_ln786_698_fu_6651_p2 = (and_ln416_698_fu_6599_p2.read() | and_ln786_28_fu_6645_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln786_699_fu_6831_p2() {
    or_ln786_699_fu_6831_p2 = (and_ln416_699_fu_6779_p2.read() | and_ln786_29_fu_6825_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln786_700_fu_7011_p2() {
    or_ln786_700_fu_7011_p2 = (and_ln416_700_fu_6959_p2.read() | and_ln786_30_fu_7005_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln786_701_fu_7191_p2() {
    or_ln786_701_fu_7191_p2 = (and_ln416_701_fu_7139_p2.read() | and_ln786_31_fu_7185_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln786_702_fu_7371_p2() {
    or_ln786_702_fu_7371_p2 = (and_ln416_702_fu_7319_p2.read() | and_ln786_32_fu_7365_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln786_703_fu_7551_p2() {
    or_ln786_703_fu_7551_p2 = (and_ln416_703_fu_7499_p2.read() | and_ln786_33_fu_7545_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln786_704_fu_7731_p2() {
    or_ln786_704_fu_7731_p2 = (and_ln416_704_fu_7679_p2.read() | and_ln786_34_fu_7725_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln786_705_fu_7911_p2() {
    or_ln786_705_fu_7911_p2 = (and_ln416_705_fu_7859_p2.read() | and_ln786_35_fu_7905_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln786_706_fu_8091_p2() {
    or_ln786_706_fu_8091_p2 = (and_ln416_706_fu_8039_p2.read() | and_ln786_36_fu_8085_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln786_707_fu_8271_p2() {
    or_ln786_707_fu_8271_p2 = (and_ln416_707_fu_8219_p2.read() | and_ln786_37_fu_8265_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln786_708_fu_8451_p2() {
    or_ln786_708_fu_8451_p2 = (and_ln416_708_fu_8399_p2.read() | and_ln786_38_fu_8445_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln786_709_fu_19109_p2() {
    or_ln786_709_fu_19109_p2 = (and_ln416_709_fu_19057_p2.read() | and_ln786_39_fu_19103_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln786_710_fu_8641_p2() {
    or_ln786_710_fu_8641_p2 = (and_ln416_710_fu_8589_p2.read() | and_ln786_40_fu_8635_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln786_711_fu_8821_p2() {
    or_ln786_711_fu_8821_p2 = (and_ln416_711_fu_8769_p2.read() | and_ln786_41_fu_8815_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln786_712_fu_9001_p2() {
    or_ln786_712_fu_9001_p2 = (and_ln416_712_fu_8949_p2.read() | and_ln786_42_fu_8995_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln786_713_fu_9181_p2() {
    or_ln786_713_fu_9181_p2 = (and_ln416_713_fu_9129_p2.read() | and_ln786_43_fu_9175_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln786_714_fu_9361_p2() {
    or_ln786_714_fu_9361_p2 = (and_ln416_714_fu_9309_p2.read() | and_ln786_44_fu_9355_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln786_715_fu_9541_p2() {
    or_ln786_715_fu_9541_p2 = (and_ln416_715_fu_9489_p2.read() | and_ln786_45_fu_9535_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln786_716_fu_9721_p2() {
    or_ln786_716_fu_9721_p2 = (and_ln416_716_fu_9669_p2.read() | and_ln786_46_fu_9715_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln786_717_fu_9901_p2() {
    or_ln786_717_fu_9901_p2 = (and_ln416_717_fu_9849_p2.read() | and_ln786_47_fu_9895_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln786_718_fu_10081_p2() {
    or_ln786_718_fu_10081_p2 = (and_ln416_718_fu_10029_p2.read() | and_ln786_48_fu_10075_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln786_719_fu_10261_p2() {
    or_ln786_719_fu_10261_p2 = (and_ln416_719_fu_10209_p2.read() | and_ln786_49_fu_10255_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln786_720_fu_10441_p2() {
    or_ln786_720_fu_10441_p2 = (and_ln416_720_fu_10389_p2.read() | and_ln786_50_fu_10435_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln786_721_fu_10621_p2() {
    or_ln786_721_fu_10621_p2 = (and_ln416_721_fu_10569_p2.read() | and_ln786_51_fu_10615_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln786_722_fu_10801_p2() {
    or_ln786_722_fu_10801_p2 = (and_ln416_722_fu_10749_p2.read() | and_ln786_52_fu_10795_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln786_723_fu_10981_p2() {
    or_ln786_723_fu_10981_p2 = (and_ln416_723_fu_10929_p2.read() | and_ln786_53_fu_10975_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln786_724_fu_11161_p2() {
    or_ln786_724_fu_11161_p2 = (and_ln416_724_fu_11109_p2.read() | and_ln786_54_fu_11155_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln786_725_fu_11341_p2() {
    or_ln786_725_fu_11341_p2 = (and_ln416_725_fu_11289_p2.read() | and_ln786_55_fu_11335_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln786_726_fu_11521_p2() {
    or_ln786_726_fu_11521_p2 = (and_ln416_726_fu_11469_p2.read() | and_ln786_56_fu_11515_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln786_727_fu_11701_p2() {
    or_ln786_727_fu_11701_p2 = (and_ln416_727_fu_11649_p2.read() | and_ln786_57_fu_11695_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln786_728_fu_11881_p2() {
    or_ln786_728_fu_11881_p2 = (and_ln416_728_fu_11829_p2.read() | and_ln786_58_fu_11875_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln786_729_fu_21040_p2() {
    or_ln786_729_fu_21040_p2 = (and_ln416_729_fu_20988_p2.read() | and_ln786_59_fu_21034_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln786_730_fu_12071_p2() {
    or_ln786_730_fu_12071_p2 = (and_ln416_730_fu_12019_p2.read() | and_ln786_60_fu_12065_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln786_731_fu_12251_p2() {
    or_ln786_731_fu_12251_p2 = (and_ln416_731_fu_12199_p2.read() | and_ln786_61_fu_12245_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln786_732_fu_12431_p2() {
    or_ln786_732_fu_12431_p2 = (and_ln416_732_fu_12379_p2.read() | and_ln786_62_fu_12425_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln786_733_fu_12611_p2() {
    or_ln786_733_fu_12611_p2 = (and_ln416_733_fu_12559_p2.read() | and_ln786_63_fu_12605_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln786_734_fu_12791_p2() {
    or_ln786_734_fu_12791_p2 = (and_ln416_734_fu_12739_p2.read() | and_ln786_64_fu_12785_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln786_735_fu_12971_p2() {
    or_ln786_735_fu_12971_p2 = (and_ln416_735_fu_12919_p2.read() | and_ln786_65_fu_12965_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln786_736_fu_13151_p2() {
    or_ln786_736_fu_13151_p2 = (and_ln416_736_fu_13099_p2.read() | and_ln786_66_fu_13145_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln786_737_fu_13331_p2() {
    or_ln786_737_fu_13331_p2 = (and_ln416_737_fu_13279_p2.read() | and_ln786_67_fu_13325_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln786_738_fu_13511_p2() {
    or_ln786_738_fu_13511_p2 = (and_ln416_738_fu_13459_p2.read() | and_ln786_68_fu_13505_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln786_739_fu_13691_p2() {
    or_ln786_739_fu_13691_p2 = (and_ln416_739_fu_13639_p2.read() | and_ln786_69_fu_13685_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln786_740_fu_13871_p2() {
    or_ln786_740_fu_13871_p2 = (and_ln416_740_fu_13819_p2.read() | and_ln786_70_fu_13865_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln786_741_fu_14051_p2() {
    or_ln786_741_fu_14051_p2 = (and_ln416_741_fu_13999_p2.read() | and_ln786_71_fu_14045_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln786_742_fu_14231_p2() {
    or_ln786_742_fu_14231_p2 = (and_ln416_742_fu_14179_p2.read() | and_ln786_72_fu_14225_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln786_743_fu_14411_p2() {
    or_ln786_743_fu_14411_p2 = (and_ln416_743_fu_14359_p2.read() | and_ln786_73_fu_14405_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln786_744_fu_14591_p2() {
    or_ln786_744_fu_14591_p2 = (and_ln416_744_fu_14539_p2.read() | and_ln786_74_fu_14585_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln786_745_fu_14771_p2() {
    or_ln786_745_fu_14771_p2 = (and_ln416_745_fu_14719_p2.read() | and_ln786_75_fu_14765_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln786_746_fu_14951_p2() {
    or_ln786_746_fu_14951_p2 = (and_ln416_746_fu_14899_p2.read() | and_ln786_76_fu_14945_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln786_747_fu_15131_p2() {
    or_ln786_747_fu_15131_p2 = (and_ln416_747_fu_15079_p2.read() | and_ln786_77_fu_15125_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln786_748_fu_15311_p2() {
    or_ln786_748_fu_15311_p2 = (and_ln416_748_fu_15259_p2.read() | and_ln786_78_fu_15305_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln786_749_fu_22971_p2() {
    or_ln786_749_fu_22971_p2 = (and_ln416_749_fu_22919_p2.read() | and_ln786_79_fu_22965_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln786_fu_1541_p2() {
    or_ln786_fu_1541_p2 = (and_ln416_fu_1489_p2.read() | and_ln786_fu_1535_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_real_start() {
    if ((esl_seteq<1,1,1>(ap_const_logic_0, start_full_n.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_0, start_once_reg.read()))) {
        real_start = ap_const_logic_0;
    } else {
        real_start = ap_start.read();
    }
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_res_V_data_0_V_blk_n() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state8.read()) && 
         esl_seteq<1,1,1>(and_ln360_reg_24080.read(), ap_const_lv1_1))) {
        res_V_data_0_V_blk_n = res_V_data_0_V_full_n.read();
    } else {
        res_V_data_0_V_blk_n = ap_const_logic_1;
    }
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_res_V_data_0_V_din() {
    res_V_data_0_V_din = tmp_data_0_V_reg_24570.read();
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_res_V_data_0_V_write() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state8.read()) && 
         esl_seteq<1,1,1>(and_ln360_reg_24080.read(), ap_const_lv1_1) && 
         !(esl_seteq<1,1,1>(and_ln360_reg_24080.read(), ap_const_lv1_1) && esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op3666.read())))) {
        res_V_data_0_V_write = ap_const_logic_1;
    } else {
        res_V_data_0_V_write = ap_const_logic_0;
    }
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_res_V_data_1_V_blk_n() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state8.read()) && 
         esl_seteq<1,1,1>(and_ln360_reg_24080.read(), ap_const_lv1_1))) {
        res_V_data_1_V_blk_n = res_V_data_1_V_full_n.read();
    } else {
        res_V_data_1_V_blk_n = ap_const_logic_1;
    }
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_res_V_data_1_V_din() {
    res_V_data_1_V_din = tmp_data_1_V_reg_24576.read();
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_res_V_data_1_V_write() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state8.read()) && 
         esl_seteq<1,1,1>(and_ln360_reg_24080.read(), ap_const_lv1_1) && 
         !(esl_seteq<1,1,1>(and_ln360_reg_24080.read(), ap_const_lv1_1) && esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op3666.read())))) {
        res_V_data_1_V_write = ap_const_logic_1;
    } else {
        res_V_data_1_V_write = ap_const_logic_0;
    }
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_res_V_data_2_V_blk_n() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state8.read()) && 
         esl_seteq<1,1,1>(and_ln360_reg_24080.read(), ap_const_lv1_1))) {
        res_V_data_2_V_blk_n = res_V_data_2_V_full_n.read();
    } else {
        res_V_data_2_V_blk_n = ap_const_logic_1;
    }
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_res_V_data_2_V_din() {
    res_V_data_2_V_din = tmp_data_2_V_reg_24582.read();
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_res_V_data_2_V_write() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state8.read()) && 
         esl_seteq<1,1,1>(and_ln360_reg_24080.read(), ap_const_lv1_1) && 
         !(esl_seteq<1,1,1>(and_ln360_reg_24080.read(), ap_const_lv1_1) && esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op3666.read())))) {
        res_V_data_2_V_write = ap_const_logic_1;
    } else {
        res_V_data_2_V_write = ap_const_logic_0;
    }
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_res_V_data_3_V_blk_n() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state8.read()) && 
         esl_seteq<1,1,1>(and_ln360_reg_24080.read(), ap_const_lv1_1))) {
        res_V_data_3_V_blk_n = res_V_data_3_V_full_n.read();
    } else {
        res_V_data_3_V_blk_n = ap_const_logic_1;
    }
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_res_V_data_3_V_din() {
    res_V_data_3_V_din = tmp_data_3_V_reg_24588.read();
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_res_V_data_3_V_write() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state8.read()) && 
         esl_seteq<1,1,1>(and_ln360_reg_24080.read(), ap_const_lv1_1) && 
         !(esl_seteq<1,1,1>(and_ln360_reg_24080.read(), ap_const_lv1_1) && esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op3666.read())))) {
        res_V_data_3_V_write = ap_const_logic_1;
    } else {
        res_V_data_3_V_write = ap_const_logic_0;
    }
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_10_fu_3521_p3() {
    select_ln340_10_fu_3521_p3 = (!or_ln340_10_fu_3503_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_10_fu_3503_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: add_ln415_695_fu_3413_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_11_fu_3713_p3() {
    select_ln340_11_fu_3713_p3 = (!or_ln340_1126_fu_3695_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_1126_fu_3695_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: add_ln415_696_fu_3605_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_1231_fu_15445_p3() {
    select_ln340_1231_fu_15445_p3 = (!xor_ln340_1208_fu_15427_p2.read()[0].is_01())? sc_lv<24>(): ((xor_ln340_1208_fu_15427_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: acc_0_V_fu_15402_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_1232_fu_15533_p3() {
    select_ln340_1232_fu_15533_p3 = (!xor_ln340_1209_fu_15515_p2.read()[0].is_01())? sc_lv<24>(): ((xor_ln340_1209_fu_15515_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: acc_0_V_108_fu_15490_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_1233_fu_15621_p3() {
    select_ln340_1233_fu_15621_p3 = (!xor_ln340_1210_fu_15603_p2.read()[0].is_01())? sc_lv<24>(): ((xor_ln340_1210_fu_15603_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: acc_0_V_110_fu_15578_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_1234_fu_15709_p3() {
    select_ln340_1234_fu_15709_p3 = (!xor_ln340_1211_fu_15691_p2.read()[0].is_01())? sc_lv<24>(): ((xor_ln340_1211_fu_15691_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: acc_0_V_112_fu_15666_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_1235_fu_15797_p3() {
    select_ln340_1235_fu_15797_p3 = (!xor_ln340_1212_fu_15779_p2.read()[0].is_01())? sc_lv<24>(): ((xor_ln340_1212_fu_15779_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: acc_0_V_114_fu_15754_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_1236_fu_15885_p3() {
    select_ln340_1236_fu_15885_p3 = (!xor_ln340_1213_fu_15867_p2.read()[0].is_01())? sc_lv<24>(): ((xor_ln340_1213_fu_15867_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: acc_0_V_116_fu_15842_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_1237_fu_15973_p3() {
    select_ln340_1237_fu_15973_p3 = (!xor_ln340_1214_fu_15955_p2.read()[0].is_01())? sc_lv<24>(): ((xor_ln340_1214_fu_15955_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: acc_0_V_118_fu_15930_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_1238_fu_16061_p3() {
    select_ln340_1238_fu_16061_p3 = (!xor_ln340_1215_fu_16043_p2.read()[0].is_01())? sc_lv<24>(): ((xor_ln340_1215_fu_16043_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: acc_0_V_120_fu_16018_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_1239_fu_16149_p3() {
    select_ln340_1239_fu_16149_p3 = (!xor_ln340_1216_fu_16131_p2.read()[0].is_01())? sc_lv<24>(): ((xor_ln340_1216_fu_16131_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: acc_0_V_122_fu_16106_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_1240_fu_16237_p3() {
    select_ln340_1240_fu_16237_p3 = (!xor_ln340_1217_fu_16219_p2.read()[0].is_01())? sc_lv<24>(): ((xor_ln340_1217_fu_16219_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: acc_0_V_124_fu_16194_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_1241_fu_16325_p3() {
    select_ln340_1241_fu_16325_p3 = (!xor_ln340_1218_fu_16307_p2.read()[0].is_01())? sc_lv<24>(): ((xor_ln340_1218_fu_16307_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: acc_0_V_126_fu_16282_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_1242_fu_16413_p3() {
    select_ln340_1242_fu_16413_p3 = (!xor_ln340_1219_fu_16395_p2.read()[0].is_01())? sc_lv<24>(): ((xor_ln340_1219_fu_16395_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: acc_0_V_128_fu_16370_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_1243_fu_16501_p3() {
    select_ln340_1243_fu_16501_p3 = (!xor_ln340_1220_fu_16483_p2.read()[0].is_01())? sc_lv<24>(): ((xor_ln340_1220_fu_16483_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: acc_0_V_130_fu_16458_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_1244_fu_16589_p3() {
    select_ln340_1244_fu_16589_p3 = (!xor_ln340_1221_fu_16571_p2.read()[0].is_01())? sc_lv<24>(): ((xor_ln340_1221_fu_16571_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: acc_0_V_132_fu_16546_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_1245_fu_16677_p3() {
    select_ln340_1245_fu_16677_p3 = (!xor_ln340_1222_fu_16659_p2.read()[0].is_01())? sc_lv<24>(): ((xor_ln340_1222_fu_16659_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: acc_0_V_134_fu_16634_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_1246_fu_16765_p3() {
    select_ln340_1246_fu_16765_p3 = (!xor_ln340_1223_fu_16747_p2.read()[0].is_01())? sc_lv<24>(): ((xor_ln340_1223_fu_16747_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: acc_0_V_136_fu_16722_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_1247_fu_16853_p3() {
    select_ln340_1247_fu_16853_p3 = (!xor_ln340_1224_fu_16835_p2.read()[0].is_01())? sc_lv<24>(): ((xor_ln340_1224_fu_16835_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: acc_0_V_138_fu_16810_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_1248_fu_16941_p3() {
    select_ln340_1248_fu_16941_p3 = (!xor_ln340_1225_fu_16923_p2.read()[0].is_01())? sc_lv<24>(): ((xor_ln340_1225_fu_16923_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: acc_0_V_140_fu_16898_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_1249_fu_17029_p3() {
    select_ln340_1249_fu_17029_p3 = (!xor_ln340_1226_fu_17011_p2.read()[0].is_01())? sc_lv<24>(): ((xor_ln340_1226_fu_17011_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: acc_0_V_142_fu_16986_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_1250_fu_17304_p3() {
    select_ln340_1250_fu_17304_p3 = (!xor_ln340_1227_fu_17286_p2.read()[0].is_01())? sc_lv<24>(): ((xor_ln340_1227_fu_17286_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: acc_0_V_144_fu_17260_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_1251_fu_17392_p3() {
    select_ln340_1251_fu_17392_p3 = (!xor_ln340_1228_fu_17374_p2.read()[0].is_01())? sc_lv<24>(): ((xor_ln340_1228_fu_17374_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: acc_1_V_fu_17349_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_1252_fu_17480_p3() {
    select_ln340_1252_fu_17480_p3 = (!xor_ln340_1229_fu_17462_p2.read()[0].is_01())? sc_lv<24>(): ((xor_ln340_1229_fu_17462_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: acc_1_V_108_fu_17437_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_1253_fu_17568_p3() {
    select_ln340_1253_fu_17568_p3 = (!xor_ln340_1230_fu_17550_p2.read()[0].is_01())? sc_lv<24>(): ((xor_ln340_1230_fu_17550_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: acc_1_V_110_fu_17525_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_1254_fu_17656_p3() {
    select_ln340_1254_fu_17656_p3 = (!xor_ln340_1231_fu_17638_p2.read()[0].is_01())? sc_lv<24>(): ((xor_ln340_1231_fu_17638_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: acc_1_V_112_fu_17613_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_1255_fu_17744_p3() {
    select_ln340_1255_fu_17744_p3 = (!xor_ln340_1232_fu_17726_p2.read()[0].is_01())? sc_lv<24>(): ((xor_ln340_1232_fu_17726_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: acc_1_V_114_fu_17701_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_1256_fu_17832_p3() {
    select_ln340_1256_fu_17832_p3 = (!xor_ln340_1233_fu_17814_p2.read()[0].is_01())? sc_lv<24>(): ((xor_ln340_1233_fu_17814_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: acc_1_V_116_fu_17789_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_1257_fu_17920_p3() {
    select_ln340_1257_fu_17920_p3 = (!xor_ln340_1234_fu_17902_p2.read()[0].is_01())? sc_lv<24>(): ((xor_ln340_1234_fu_17902_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: acc_1_V_118_fu_17877_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_1258_fu_18008_p3() {
    select_ln340_1258_fu_18008_p3 = (!xor_ln340_1235_fu_17990_p2.read()[0].is_01())? sc_lv<24>(): ((xor_ln340_1235_fu_17990_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: acc_1_V_120_fu_17965_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_1259_fu_18096_p3() {
    select_ln340_1259_fu_18096_p3 = (!xor_ln340_1236_fu_18078_p2.read()[0].is_01())? sc_lv<24>(): ((xor_ln340_1236_fu_18078_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: acc_1_V_122_fu_18053_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_1260_fu_18184_p3() {
    select_ln340_1260_fu_18184_p3 = (!xor_ln340_1237_fu_18166_p2.read()[0].is_01())? sc_lv<24>(): ((xor_ln340_1237_fu_18166_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: acc_1_V_124_fu_18141_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_1261_fu_18272_p3() {
    select_ln340_1261_fu_18272_p3 = (!xor_ln340_1238_fu_18254_p2.read()[0].is_01())? sc_lv<24>(): ((xor_ln340_1238_fu_18254_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: acc_1_V_126_fu_18229_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_1262_fu_18360_p3() {
    select_ln340_1262_fu_18360_p3 = (!xor_ln340_1239_fu_18342_p2.read()[0].is_01())? sc_lv<24>(): ((xor_ln340_1239_fu_18342_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: acc_1_V_128_fu_18317_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_1263_fu_18448_p3() {
    select_ln340_1263_fu_18448_p3 = (!xor_ln340_1240_fu_18430_p2.read()[0].is_01())? sc_lv<24>(): ((xor_ln340_1240_fu_18430_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: acc_1_V_130_fu_18405_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_1264_fu_18536_p3() {
    select_ln340_1264_fu_18536_p3 = (!xor_ln340_1241_fu_18518_p2.read()[0].is_01())? sc_lv<24>(): ((xor_ln340_1241_fu_18518_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: acc_1_V_132_fu_18493_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_1265_fu_18624_p3() {
    select_ln340_1265_fu_18624_p3 = (!xor_ln340_1242_fu_18606_p2.read()[0].is_01())? sc_lv<24>(): ((xor_ln340_1242_fu_18606_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: acc_1_V_134_fu_18581_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_1266_fu_18712_p3() {
    select_ln340_1266_fu_18712_p3 = (!xor_ln340_1243_fu_18694_p2.read()[0].is_01())? sc_lv<24>(): ((xor_ln340_1243_fu_18694_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: acc_1_V_136_fu_18669_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_1267_fu_18800_p3() {
    select_ln340_1267_fu_18800_p3 = (!xor_ln340_1244_fu_18782_p2.read()[0].is_01())? sc_lv<24>(): ((xor_ln340_1244_fu_18782_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: acc_1_V_138_fu_18757_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_1268_fu_18888_p3() {
    select_ln340_1268_fu_18888_p3 = (!xor_ln340_1245_fu_18870_p2.read()[0].is_01())? sc_lv<24>(): ((xor_ln340_1245_fu_18870_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: acc_1_V_140_fu_18845_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_1269_fu_18976_p3() {
    select_ln340_1269_fu_18976_p3 = (!xor_ln340_1246_fu_18958_p2.read()[0].is_01())? sc_lv<24>(): ((xor_ln340_1246_fu_18958_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: acc_1_V_142_fu_18933_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_1270_fu_19235_p3() {
    select_ln340_1270_fu_19235_p3 = (!xor_ln340_1247_fu_19217_p2.read()[0].is_01())? sc_lv<24>(): ((xor_ln340_1247_fu_19217_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: acc_1_V_144_fu_19191_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_1271_fu_19323_p3() {
    select_ln340_1271_fu_19323_p3 = (!xor_ln340_1248_fu_19305_p2.read()[0].is_01())? sc_lv<24>(): ((xor_ln340_1248_fu_19305_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: acc_2_V_fu_19280_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_1272_fu_19411_p3() {
    select_ln340_1272_fu_19411_p3 = (!xor_ln340_1249_fu_19393_p2.read()[0].is_01())? sc_lv<24>(): ((xor_ln340_1249_fu_19393_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: acc_2_V_108_fu_19368_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_1273_fu_19499_p3() {
    select_ln340_1273_fu_19499_p3 = (!xor_ln340_1250_fu_19481_p2.read()[0].is_01())? sc_lv<24>(): ((xor_ln340_1250_fu_19481_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: acc_2_V_110_fu_19456_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_1274_fu_19587_p3() {
    select_ln340_1274_fu_19587_p3 = (!xor_ln340_1251_fu_19569_p2.read()[0].is_01())? sc_lv<24>(): ((xor_ln340_1251_fu_19569_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: acc_2_V_112_fu_19544_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_1275_fu_19675_p3() {
    select_ln340_1275_fu_19675_p3 = (!xor_ln340_1252_fu_19657_p2.read()[0].is_01())? sc_lv<24>(): ((xor_ln340_1252_fu_19657_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: acc_2_V_114_fu_19632_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_1276_fu_19763_p3() {
    select_ln340_1276_fu_19763_p3 = (!xor_ln340_1253_fu_19745_p2.read()[0].is_01())? sc_lv<24>(): ((xor_ln340_1253_fu_19745_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: acc_2_V_116_fu_19720_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_1277_fu_19851_p3() {
    select_ln340_1277_fu_19851_p3 = (!xor_ln340_1254_fu_19833_p2.read()[0].is_01())? sc_lv<24>(): ((xor_ln340_1254_fu_19833_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: acc_2_V_118_fu_19808_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_1278_fu_19939_p3() {
    select_ln340_1278_fu_19939_p3 = (!xor_ln340_1255_fu_19921_p2.read()[0].is_01())? sc_lv<24>(): ((xor_ln340_1255_fu_19921_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: acc_2_V_120_fu_19896_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_1279_fu_20027_p3() {
    select_ln340_1279_fu_20027_p3 = (!xor_ln340_1256_fu_20009_p2.read()[0].is_01())? sc_lv<24>(): ((xor_ln340_1256_fu_20009_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: acc_2_V_122_fu_19984_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_1280_fu_20115_p3() {
    select_ln340_1280_fu_20115_p3 = (!xor_ln340_1257_fu_20097_p2.read()[0].is_01())? sc_lv<24>(): ((xor_ln340_1257_fu_20097_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: acc_2_V_124_fu_20072_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_1281_fu_20203_p3() {
    select_ln340_1281_fu_20203_p3 = (!xor_ln340_1258_fu_20185_p2.read()[0].is_01())? sc_lv<24>(): ((xor_ln340_1258_fu_20185_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: acc_2_V_126_fu_20160_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_1282_fu_20291_p3() {
    select_ln340_1282_fu_20291_p3 = (!xor_ln340_1259_fu_20273_p2.read()[0].is_01())? sc_lv<24>(): ((xor_ln340_1259_fu_20273_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: acc_2_V_128_fu_20248_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_1283_fu_20379_p3() {
    select_ln340_1283_fu_20379_p3 = (!xor_ln340_1260_fu_20361_p2.read()[0].is_01())? sc_lv<24>(): ((xor_ln340_1260_fu_20361_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: acc_2_V_130_fu_20336_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_1284_fu_20467_p3() {
    select_ln340_1284_fu_20467_p3 = (!xor_ln340_1261_fu_20449_p2.read()[0].is_01())? sc_lv<24>(): ((xor_ln340_1261_fu_20449_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: acc_2_V_132_fu_20424_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_1285_fu_20555_p3() {
    select_ln340_1285_fu_20555_p3 = (!xor_ln340_1262_fu_20537_p2.read()[0].is_01())? sc_lv<24>(): ((xor_ln340_1262_fu_20537_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: acc_2_V_134_fu_20512_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_1286_fu_20643_p3() {
    select_ln340_1286_fu_20643_p3 = (!xor_ln340_1263_fu_20625_p2.read()[0].is_01())? sc_lv<24>(): ((xor_ln340_1263_fu_20625_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: acc_2_V_136_fu_20600_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_1287_fu_20731_p3() {
    select_ln340_1287_fu_20731_p3 = (!xor_ln340_1264_fu_20713_p2.read()[0].is_01())? sc_lv<24>(): ((xor_ln340_1264_fu_20713_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: acc_2_V_138_fu_20688_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_1288_fu_20819_p3() {
    select_ln340_1288_fu_20819_p3 = (!xor_ln340_1265_fu_20801_p2.read()[0].is_01())? sc_lv<24>(): ((xor_ln340_1265_fu_20801_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: acc_2_V_140_fu_20776_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_1289_fu_20907_p3() {
    select_ln340_1289_fu_20907_p3 = (!xor_ln340_1266_fu_20889_p2.read()[0].is_01())? sc_lv<24>(): ((xor_ln340_1266_fu_20889_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: acc_2_V_142_fu_20864_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_1290_fu_21166_p3() {
    select_ln340_1290_fu_21166_p3 = (!xor_ln340_1267_fu_21148_p2.read()[0].is_01())? sc_lv<24>(): ((xor_ln340_1267_fu_21148_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: acc_2_V_144_fu_21122_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_1291_fu_21254_p3() {
    select_ln340_1291_fu_21254_p3 = (!xor_ln340_1268_fu_21236_p2.read()[0].is_01())? sc_lv<24>(): ((xor_ln340_1268_fu_21236_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: acc_3_V_fu_21211_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_1292_fu_21342_p3() {
    select_ln340_1292_fu_21342_p3 = (!xor_ln340_1269_fu_21324_p2.read()[0].is_01())? sc_lv<24>(): ((xor_ln340_1269_fu_21324_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: acc_3_V_108_fu_21299_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_1293_fu_21430_p3() {
    select_ln340_1293_fu_21430_p3 = (!xor_ln340_1270_fu_21412_p2.read()[0].is_01())? sc_lv<24>(): ((xor_ln340_1270_fu_21412_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: acc_3_V_110_fu_21387_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_1294_fu_21518_p3() {
    select_ln340_1294_fu_21518_p3 = (!xor_ln340_1271_fu_21500_p2.read()[0].is_01())? sc_lv<24>(): ((xor_ln340_1271_fu_21500_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: acc_3_V_112_fu_21475_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_1295_fu_21606_p3() {
    select_ln340_1295_fu_21606_p3 = (!xor_ln340_1272_fu_21588_p2.read()[0].is_01())? sc_lv<24>(): ((xor_ln340_1272_fu_21588_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: acc_3_V_114_fu_21563_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_1296_fu_21694_p3() {
    select_ln340_1296_fu_21694_p3 = (!xor_ln340_1273_fu_21676_p2.read()[0].is_01())? sc_lv<24>(): ((xor_ln340_1273_fu_21676_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: acc_3_V_116_fu_21651_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_1297_fu_21782_p3() {
    select_ln340_1297_fu_21782_p3 = (!xor_ln340_1274_fu_21764_p2.read()[0].is_01())? sc_lv<24>(): ((xor_ln340_1274_fu_21764_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: acc_3_V_118_fu_21739_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_1298_fu_21870_p3() {
    select_ln340_1298_fu_21870_p3 = (!xor_ln340_1275_fu_21852_p2.read()[0].is_01())? sc_lv<24>(): ((xor_ln340_1275_fu_21852_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: acc_3_V_120_fu_21827_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_1299_fu_21958_p3() {
    select_ln340_1299_fu_21958_p3 = (!xor_ln340_1276_fu_21940_p2.read()[0].is_01())? sc_lv<24>(): ((xor_ln340_1276_fu_21940_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: acc_3_V_122_fu_21915_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_12_fu_3905_p3() {
    select_ln340_12_fu_3905_p3 = (!or_ln340_12_fu_3887_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_12_fu_3887_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: add_ln415_697_fu_3797_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_1300_fu_22046_p3() {
    select_ln340_1300_fu_22046_p3 = (!xor_ln340_1277_fu_22028_p2.read()[0].is_01())? sc_lv<24>(): ((xor_ln340_1277_fu_22028_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: acc_3_V_124_fu_22003_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_1301_fu_22134_p3() {
    select_ln340_1301_fu_22134_p3 = (!xor_ln340_1278_fu_22116_p2.read()[0].is_01())? sc_lv<24>(): ((xor_ln340_1278_fu_22116_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: acc_3_V_126_fu_22091_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_1302_fu_22222_p3() {
    select_ln340_1302_fu_22222_p3 = (!xor_ln340_1279_fu_22204_p2.read()[0].is_01())? sc_lv<24>(): ((xor_ln340_1279_fu_22204_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: acc_3_V_128_fu_22179_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_1303_fu_22310_p3() {
    select_ln340_1303_fu_22310_p3 = (!xor_ln340_1280_fu_22292_p2.read()[0].is_01())? sc_lv<24>(): ((xor_ln340_1280_fu_22292_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: acc_3_V_130_fu_22267_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_1304_fu_22398_p3() {
    select_ln340_1304_fu_22398_p3 = (!xor_ln340_1281_fu_22380_p2.read()[0].is_01())? sc_lv<24>(): ((xor_ln340_1281_fu_22380_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: acc_3_V_132_fu_22355_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_1305_fu_22486_p3() {
    select_ln340_1305_fu_22486_p3 = (!xor_ln340_1282_fu_22468_p2.read()[0].is_01())? sc_lv<24>(): ((xor_ln340_1282_fu_22468_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: acc_3_V_134_fu_22443_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_1306_fu_22574_p3() {
    select_ln340_1306_fu_22574_p3 = (!xor_ln340_1283_fu_22556_p2.read()[0].is_01())? sc_lv<24>(): ((xor_ln340_1283_fu_22556_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: acc_3_V_136_fu_22531_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_1307_fu_22662_p3() {
    select_ln340_1307_fu_22662_p3 = (!xor_ln340_1284_fu_22644_p2.read()[0].is_01())? sc_lv<24>(): ((xor_ln340_1284_fu_22644_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: acc_3_V_138_fu_22619_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_1308_fu_22750_p3() {
    select_ln340_1308_fu_22750_p3 = (!xor_ln340_1285_fu_22732_p2.read()[0].is_01())? sc_lv<24>(): ((xor_ln340_1285_fu_22732_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: acc_3_V_140_fu_22707_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_1309_fu_22838_p3() {
    select_ln340_1309_fu_22838_p3 = (!xor_ln340_1286_fu_22820_p2.read()[0].is_01())? sc_lv<24>(): ((xor_ln340_1286_fu_22820_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: acc_3_V_142_fu_22795_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_1310_fu_23097_p3() {
    select_ln340_1310_fu_23097_p3 = (!xor_ln340_1287_fu_23079_p2.read()[0].is_01())? sc_lv<24>(): ((xor_ln340_1287_fu_23079_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: acc_3_V_144_fu_23053_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_13_fu_4097_p3() {
    select_ln340_13_fu_4097_p3 = (!or_ln340_13_fu_4079_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_13_fu_4079_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: add_ln415_698_fu_3989_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_14_fu_4289_p3() {
    select_ln340_14_fu_4289_p3 = (!or_ln340_14_fu_4271_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_14_fu_4271_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: add_ln415_699_fu_4181_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_15_fu_4481_p3() {
    select_ln340_15_fu_4481_p3 = (!or_ln340_15_fu_4463_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_15_fu_4463_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: add_ln415_700_fu_4373_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_16_fu_4673_p3() {
    select_ln340_16_fu_4673_p3 = (!or_ln340_16_fu_4655_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_16_fu_4655_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: add_ln415_701_fu_4565_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_17_fu_4865_p3() {
    select_ln340_17_fu_4865_p3 = (!or_ln340_17_fu_4847_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_17_fu_4847_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: add_ln415_702_fu_4757_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_18_fu_5057_p3() {
    select_ln340_18_fu_5057_p3 = (!or_ln340_18_fu_5039_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_18_fu_5039_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: add_ln415_703_fu_4949_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_19_fu_17214_p3() {
    select_ln340_19_fu_17214_p3 = (!or_ln340_19_fu_17196_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_19_fu_17196_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: add_ln415_704_fu_17106_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_1_fu_1777_p3() {
    select_ln340_1_fu_1777_p3 = (!or_ln340_1_fu_1759_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_1_fu_1759_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: add_ln415_686_fu_1669_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_20_fu_5247_p3() {
    select_ln340_20_fu_5247_p3 = (!or_ln340_20_fu_5229_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_20_fu_5229_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: add_ln415_705_fu_5139_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_21_fu_5427_p3() {
    select_ln340_21_fu_5427_p3 = (!or_ln340_21_fu_5409_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_21_fu_5409_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: add_ln415_706_fu_5319_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_22_fu_5607_p3() {
    select_ln340_22_fu_5607_p3 = (!or_ln340_22_fu_5589_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_22_fu_5589_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: add_ln415_707_fu_5499_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_23_fu_5787_p3() {
    select_ln340_23_fu_5787_p3 = (!or_ln340_23_fu_5769_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_23_fu_5769_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: add_ln415_708_fu_5679_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_2416_fu_1593_p3() {
    select_ln340_2416_fu_1593_p3 = (!or_ln340_2600_fu_1571_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2600_fu_1571_p2.read()[0].to_bool())? select_ln340_fu_1577_p3.read(): select_ln388_fu_1585_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_2417_fu_15461_p3() {
    select_ln340_2417_fu_15461_p3 = (!or_ln340_2601_fu_15439_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2601_fu_15439_p2.read()[0].to_bool())? select_ln340_1231_fu_15445_p3.read(): acc_0_V_107_fu_15453_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_2418_fu_1793_p3() {
    select_ln340_2418_fu_1793_p3 = (!or_ln340_2603_fu_1771_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2603_fu_1771_p2.read()[0].to_bool())? select_ln340_1_fu_1777_p3.read(): select_ln388_1_fu_1785_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_2419_fu_15549_p3() {
    select_ln340_2419_fu_15549_p3 = (!or_ln340_2604_fu_15527_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2604_fu_15527_p2.read()[0].to_bool())? select_ln340_1232_fu_15533_p3.read(): acc_0_V_109_fu_15541_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_2420_fu_1993_p3() {
    select_ln340_2420_fu_1993_p3 = (!or_ln340_2606_fu_1971_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2606_fu_1971_p2.read()[0].to_bool())? select_ln340_2_fu_1977_p3.read(): select_ln388_2_fu_1985_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_2421_fu_15637_p3() {
    select_ln340_2421_fu_15637_p3 = (!or_ln340_2607_fu_15615_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2607_fu_15615_p2.read()[0].to_bool())? select_ln340_1233_fu_15621_p3.read(): acc_0_V_111_fu_15629_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_2422_fu_2193_p3() {
    select_ln340_2422_fu_2193_p3 = (!or_ln340_2609_fu_2171_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2609_fu_2171_p2.read()[0].to_bool())? select_ln340_3_fu_2177_p3.read(): select_ln388_3_fu_2185_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_2423_fu_15725_p3() {
    select_ln340_2423_fu_15725_p3 = (!or_ln340_2610_fu_15703_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2610_fu_15703_p2.read()[0].to_bool())? select_ln340_1234_fu_15709_p3.read(): acc_0_V_113_fu_15717_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_2424_fu_2385_p3() {
    select_ln340_2424_fu_2385_p3 = (!or_ln340_2612_fu_2363_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2612_fu_2363_p2.read()[0].to_bool())? select_ln340_4_fu_2369_p3.read(): select_ln388_4_fu_2377_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_2425_fu_15813_p3() {
    select_ln340_2425_fu_15813_p3 = (!or_ln340_2613_fu_15791_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2613_fu_15791_p2.read()[0].to_bool())? select_ln340_1235_fu_15797_p3.read(): acc_0_V_115_fu_15805_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_2426_fu_2577_p3() {
    select_ln340_2426_fu_2577_p3 = (!or_ln340_2615_fu_2555_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2615_fu_2555_p2.read()[0].to_bool())? select_ln340_5_fu_2561_p3.read(): select_ln388_5_fu_2569_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_2427_fu_15901_p3() {
    select_ln340_2427_fu_15901_p3 = (!or_ln340_2616_fu_15879_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2616_fu_15879_p2.read()[0].to_bool())? select_ln340_1236_fu_15885_p3.read(): acc_0_V_117_fu_15893_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_2428_fu_2769_p3() {
    select_ln340_2428_fu_2769_p3 = (!or_ln340_2618_fu_2747_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2618_fu_2747_p2.read()[0].to_bool())? select_ln340_6_fu_2753_p3.read(): select_ln388_6_fu_2761_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_2429_fu_15989_p3() {
    select_ln340_2429_fu_15989_p3 = (!or_ln340_2619_fu_15967_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2619_fu_15967_p2.read()[0].to_bool())? select_ln340_1237_fu_15973_p3.read(): acc_0_V_119_fu_15981_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_2430_fu_2961_p3() {
    select_ln340_2430_fu_2961_p3 = (!or_ln340_2621_fu_2939_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2621_fu_2939_p2.read()[0].to_bool())? select_ln340_7_fu_2945_p3.read(): select_ln388_7_fu_2953_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_2431_fu_16077_p3() {
    select_ln340_2431_fu_16077_p3 = (!or_ln340_2622_fu_16055_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2622_fu_16055_p2.read()[0].to_bool())? select_ln340_1238_fu_16061_p3.read(): acc_0_V_121_fu_16069_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_2432_fu_3153_p3() {
    select_ln340_2432_fu_3153_p3 = (!or_ln340_2624_fu_3131_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2624_fu_3131_p2.read()[0].to_bool())? select_ln340_8_fu_3137_p3.read(): select_ln388_8_fu_3145_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_2433_fu_16165_p3() {
    select_ln340_2433_fu_16165_p3 = (!or_ln340_2625_fu_16143_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2625_fu_16143_p2.read()[0].to_bool())? select_ln340_1239_fu_16149_p3.read(): acc_0_V_123_fu_16157_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_2434_fu_3345_p3() {
    select_ln340_2434_fu_3345_p3 = (!or_ln340_2627_fu_3323_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2627_fu_3323_p2.read()[0].to_bool())? select_ln340_9_fu_3329_p3.read(): select_ln388_9_fu_3337_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_2435_fu_16253_p3() {
    select_ln340_2435_fu_16253_p3 = (!or_ln340_2628_fu_16231_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2628_fu_16231_p2.read()[0].to_bool())? select_ln340_1240_fu_16237_p3.read(): acc_0_V_125_fu_16245_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_2436_fu_3537_p3() {
    select_ln340_2436_fu_3537_p3 = (!or_ln340_2630_fu_3515_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2630_fu_3515_p2.read()[0].to_bool())? select_ln340_10_fu_3521_p3.read(): select_ln388_10_fu_3529_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_2437_fu_16341_p3() {
    select_ln340_2437_fu_16341_p3 = (!or_ln340_2631_fu_16319_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2631_fu_16319_p2.read()[0].to_bool())? select_ln340_1241_fu_16325_p3.read(): acc_0_V_127_fu_16333_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_2438_fu_3729_p3() {
    select_ln340_2438_fu_3729_p3 = (!or_ln340_2633_fu_3707_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2633_fu_3707_p2.read()[0].to_bool())? select_ln340_11_fu_3713_p3.read(): select_ln388_11_fu_3721_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_2439_fu_16429_p3() {
    select_ln340_2439_fu_16429_p3 = (!or_ln340_2634_fu_16407_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2634_fu_16407_p2.read()[0].to_bool())? select_ln340_1242_fu_16413_p3.read(): acc_0_V_129_fu_16421_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_2440_fu_3921_p3() {
    select_ln340_2440_fu_3921_p3 = (!or_ln340_2636_fu_3899_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2636_fu_3899_p2.read()[0].to_bool())? select_ln340_12_fu_3905_p3.read(): select_ln388_12_fu_3913_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_2441_fu_16517_p3() {
    select_ln340_2441_fu_16517_p3 = (!or_ln340_2637_fu_16495_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2637_fu_16495_p2.read()[0].to_bool())? select_ln340_1243_fu_16501_p3.read(): acc_0_V_131_fu_16509_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_2442_fu_4113_p3() {
    select_ln340_2442_fu_4113_p3 = (!or_ln340_2639_fu_4091_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2639_fu_4091_p2.read()[0].to_bool())? select_ln340_13_fu_4097_p3.read(): select_ln388_13_fu_4105_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_2443_fu_16605_p3() {
    select_ln340_2443_fu_16605_p3 = (!or_ln340_2640_fu_16583_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2640_fu_16583_p2.read()[0].to_bool())? select_ln340_1244_fu_16589_p3.read(): acc_0_V_133_fu_16597_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_2444_fu_4305_p3() {
    select_ln340_2444_fu_4305_p3 = (!or_ln340_2642_fu_4283_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2642_fu_4283_p2.read()[0].to_bool())? select_ln340_14_fu_4289_p3.read(): select_ln388_14_fu_4297_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_2445_fu_16693_p3() {
    select_ln340_2445_fu_16693_p3 = (!or_ln340_2643_fu_16671_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2643_fu_16671_p2.read()[0].to_bool())? select_ln340_1245_fu_16677_p3.read(): acc_0_V_135_fu_16685_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_2446_fu_4497_p3() {
    select_ln340_2446_fu_4497_p3 = (!or_ln340_2645_fu_4475_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2645_fu_4475_p2.read()[0].to_bool())? select_ln340_15_fu_4481_p3.read(): select_ln388_15_fu_4489_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_2447_fu_16781_p3() {
    select_ln340_2447_fu_16781_p3 = (!or_ln340_2646_fu_16759_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2646_fu_16759_p2.read()[0].to_bool())? select_ln340_1246_fu_16765_p3.read(): acc_0_V_137_fu_16773_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_2448_fu_4689_p3() {
    select_ln340_2448_fu_4689_p3 = (!or_ln340_2648_fu_4667_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2648_fu_4667_p2.read()[0].to_bool())? select_ln340_16_fu_4673_p3.read(): select_ln388_16_fu_4681_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_2449_fu_16869_p3() {
    select_ln340_2449_fu_16869_p3 = (!or_ln340_2649_fu_16847_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2649_fu_16847_p2.read()[0].to_bool())? select_ln340_1247_fu_16853_p3.read(): acc_0_V_139_fu_16861_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_2450_fu_4881_p3() {
    select_ln340_2450_fu_4881_p3 = (!or_ln340_2651_fu_4859_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2651_fu_4859_p2.read()[0].to_bool())? select_ln340_17_fu_4865_p3.read(): select_ln388_17_fu_4873_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_2451_fu_16957_p3() {
    select_ln340_2451_fu_16957_p3 = (!or_ln340_2652_fu_16935_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2652_fu_16935_p2.read()[0].to_bool())? select_ln340_1248_fu_16941_p3.read(): acc_0_V_141_fu_16949_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_2452_fu_5073_p3() {
    select_ln340_2452_fu_5073_p3 = (!or_ln340_2654_fu_5051_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2654_fu_5051_p2.read()[0].to_bool())? select_ln340_18_fu_5057_p3.read(): select_ln388_18_fu_5065_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_2453_fu_17045_p3() {
    select_ln340_2453_fu_17045_p3 = (!or_ln340_2655_fu_17023_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2655_fu_17023_p2.read()[0].to_bool())? select_ln340_1249_fu_17029_p3.read(): acc_0_V_143_fu_17037_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_2454_fu_17230_p3() {
    select_ln340_2454_fu_17230_p3 = (!or_ln340_2657_fu_17208_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2657_fu_17208_p2.read()[0].to_bool())? select_ln340_19_fu_17214_p3.read(): select_ln388_19_fu_17222_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_2456_fu_5263_p3() {
    select_ln340_2456_fu_5263_p3 = (!or_ln340_2660_fu_5241_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2660_fu_5241_p2.read()[0].to_bool())? select_ln340_20_fu_5247_p3.read(): select_ln388_20_fu_5255_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_2457_fu_17408_p3() {
    select_ln340_2457_fu_17408_p3 = (!or_ln340_2661_fu_17386_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2661_fu_17386_p2.read()[0].to_bool())? select_ln340_1251_fu_17392_p3.read(): acc_1_V_107_fu_17400_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_2458_fu_5443_p3() {
    select_ln340_2458_fu_5443_p3 = (!or_ln340_2663_fu_5421_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2663_fu_5421_p2.read()[0].to_bool())? select_ln340_21_fu_5427_p3.read(): select_ln388_21_fu_5435_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_2459_fu_17496_p3() {
    select_ln340_2459_fu_17496_p3 = (!or_ln340_2664_fu_17474_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2664_fu_17474_p2.read()[0].to_bool())? select_ln340_1252_fu_17480_p3.read(): acc_1_V_109_fu_17488_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_2460_fu_5623_p3() {
    select_ln340_2460_fu_5623_p3 = (!or_ln340_2666_fu_5601_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2666_fu_5601_p2.read()[0].to_bool())? select_ln340_22_fu_5607_p3.read(): select_ln388_22_fu_5615_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_2461_fu_17584_p3() {
    select_ln340_2461_fu_17584_p3 = (!or_ln340_2667_fu_17562_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2667_fu_17562_p2.read()[0].to_bool())? select_ln340_1253_fu_17568_p3.read(): acc_1_V_111_fu_17576_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_2462_fu_5803_p3() {
    select_ln340_2462_fu_5803_p3 = (!or_ln340_2669_fu_5781_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2669_fu_5781_p2.read()[0].to_bool())? select_ln340_23_fu_5787_p3.read(): select_ln388_23_fu_5795_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_2463_fu_17672_p3() {
    select_ln340_2463_fu_17672_p3 = (!or_ln340_2670_fu_17650_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2670_fu_17650_p2.read()[0].to_bool())? select_ln340_1254_fu_17656_p3.read(): acc_1_V_113_fu_17664_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_2464_fu_5983_p3() {
    select_ln340_2464_fu_5983_p3 = (!or_ln340_2672_fu_5961_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2672_fu_5961_p2.read()[0].to_bool())? select_ln340_24_fu_5967_p3.read(): select_ln388_24_fu_5975_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_2465_fu_17760_p3() {
    select_ln340_2465_fu_17760_p3 = (!or_ln340_2673_fu_17738_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2673_fu_17738_p2.read()[0].to_bool())? select_ln340_1255_fu_17744_p3.read(): acc_1_V_115_fu_17752_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_2466_fu_6163_p3() {
    select_ln340_2466_fu_6163_p3 = (!or_ln340_2675_fu_6141_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2675_fu_6141_p2.read()[0].to_bool())? select_ln340_25_fu_6147_p3.read(): select_ln388_25_fu_6155_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_2467_fu_17848_p3() {
    select_ln340_2467_fu_17848_p3 = (!or_ln340_2676_fu_17826_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2676_fu_17826_p2.read()[0].to_bool())? select_ln340_1256_fu_17832_p3.read(): acc_1_V_117_fu_17840_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_2468_fu_6343_p3() {
    select_ln340_2468_fu_6343_p3 = (!or_ln340_2678_fu_6321_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2678_fu_6321_p2.read()[0].to_bool())? select_ln340_26_fu_6327_p3.read(): select_ln388_26_fu_6335_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_2469_fu_17936_p3() {
    select_ln340_2469_fu_17936_p3 = (!or_ln340_2679_fu_17914_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2679_fu_17914_p2.read()[0].to_bool())? select_ln340_1257_fu_17920_p3.read(): acc_1_V_119_fu_17928_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_2470_fu_6523_p3() {
    select_ln340_2470_fu_6523_p3 = (!or_ln340_2681_fu_6501_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2681_fu_6501_p2.read()[0].to_bool())? select_ln340_27_fu_6507_p3.read(): select_ln388_27_fu_6515_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_2471_fu_18024_p3() {
    select_ln340_2471_fu_18024_p3 = (!or_ln340_2682_fu_18002_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2682_fu_18002_p2.read()[0].to_bool())? select_ln340_1258_fu_18008_p3.read(): acc_1_V_121_fu_18016_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_2472_fu_6703_p3() {
    select_ln340_2472_fu_6703_p3 = (!or_ln340_2684_fu_6681_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2684_fu_6681_p2.read()[0].to_bool())? select_ln340_28_fu_6687_p3.read(): select_ln388_28_fu_6695_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_2473_fu_18112_p3() {
    select_ln340_2473_fu_18112_p3 = (!or_ln340_2685_fu_18090_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2685_fu_18090_p2.read()[0].to_bool())? select_ln340_1259_fu_18096_p3.read(): acc_1_V_123_fu_18104_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_2474_fu_6883_p3() {
    select_ln340_2474_fu_6883_p3 = (!or_ln340_2687_fu_6861_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2687_fu_6861_p2.read()[0].to_bool())? select_ln340_29_fu_6867_p3.read(): select_ln388_29_fu_6875_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_2475_fu_18200_p3() {
    select_ln340_2475_fu_18200_p3 = (!or_ln340_2688_fu_18178_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2688_fu_18178_p2.read()[0].to_bool())? select_ln340_1260_fu_18184_p3.read(): acc_1_V_125_fu_18192_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_2476_fu_7063_p3() {
    select_ln340_2476_fu_7063_p3 = (!or_ln340_2690_fu_7041_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2690_fu_7041_p2.read()[0].to_bool())? select_ln340_30_fu_7047_p3.read(): select_ln388_30_fu_7055_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_2477_fu_18288_p3() {
    select_ln340_2477_fu_18288_p3 = (!or_ln340_2691_fu_18266_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2691_fu_18266_p2.read()[0].to_bool())? select_ln340_1261_fu_18272_p3.read(): acc_1_V_127_fu_18280_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_2478_fu_7243_p3() {
    select_ln340_2478_fu_7243_p3 = (!or_ln340_2693_fu_7221_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2693_fu_7221_p2.read()[0].to_bool())? select_ln340_31_fu_7227_p3.read(): select_ln388_31_fu_7235_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_2479_fu_18376_p3() {
    select_ln340_2479_fu_18376_p3 = (!or_ln340_2694_fu_18354_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2694_fu_18354_p2.read()[0].to_bool())? select_ln340_1262_fu_18360_p3.read(): acc_1_V_129_fu_18368_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_2480_fu_7423_p3() {
    select_ln340_2480_fu_7423_p3 = (!or_ln340_2696_fu_7401_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2696_fu_7401_p2.read()[0].to_bool())? select_ln340_32_fu_7407_p3.read(): select_ln388_32_fu_7415_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_2481_fu_18464_p3() {
    select_ln340_2481_fu_18464_p3 = (!or_ln340_2697_fu_18442_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2697_fu_18442_p2.read()[0].to_bool())? select_ln340_1263_fu_18448_p3.read(): acc_1_V_131_fu_18456_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_2482_fu_7603_p3() {
    select_ln340_2482_fu_7603_p3 = (!or_ln340_2699_fu_7581_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2699_fu_7581_p2.read()[0].to_bool())? select_ln340_33_fu_7587_p3.read(): select_ln388_33_fu_7595_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_2483_fu_18552_p3() {
    select_ln340_2483_fu_18552_p3 = (!or_ln340_2700_fu_18530_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2700_fu_18530_p2.read()[0].to_bool())? select_ln340_1264_fu_18536_p3.read(): acc_1_V_133_fu_18544_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_2484_fu_7783_p3() {
    select_ln340_2484_fu_7783_p3 = (!or_ln340_2702_fu_7761_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2702_fu_7761_p2.read()[0].to_bool())? select_ln340_34_fu_7767_p3.read(): select_ln388_34_fu_7775_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_2485_fu_18640_p3() {
    select_ln340_2485_fu_18640_p3 = (!or_ln340_2703_fu_18618_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2703_fu_18618_p2.read()[0].to_bool())? select_ln340_1265_fu_18624_p3.read(): acc_1_V_135_fu_18632_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_2486_fu_7963_p3() {
    select_ln340_2486_fu_7963_p3 = (!or_ln340_2705_fu_7941_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2705_fu_7941_p2.read()[0].to_bool())? select_ln340_35_fu_7947_p3.read(): select_ln388_35_fu_7955_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_2487_fu_18728_p3() {
    select_ln340_2487_fu_18728_p3 = (!or_ln340_2706_fu_18706_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2706_fu_18706_p2.read()[0].to_bool())? select_ln340_1266_fu_18712_p3.read(): acc_1_V_137_fu_18720_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_2488_fu_8143_p3() {
    select_ln340_2488_fu_8143_p3 = (!or_ln340_2708_fu_8121_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2708_fu_8121_p2.read()[0].to_bool())? select_ln340_36_fu_8127_p3.read(): select_ln388_36_fu_8135_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_2489_fu_18816_p3() {
    select_ln340_2489_fu_18816_p3 = (!or_ln340_2709_fu_18794_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2709_fu_18794_p2.read()[0].to_bool())? select_ln340_1267_fu_18800_p3.read(): acc_1_V_139_fu_18808_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_2490_fu_8323_p3() {
    select_ln340_2490_fu_8323_p3 = (!or_ln340_2711_fu_8301_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2711_fu_8301_p2.read()[0].to_bool())? select_ln340_37_fu_8307_p3.read(): select_ln388_37_fu_8315_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_2491_fu_18904_p3() {
    select_ln340_2491_fu_18904_p3 = (!or_ln340_2712_fu_18882_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2712_fu_18882_p2.read()[0].to_bool())? select_ln340_1268_fu_18888_p3.read(): acc_1_V_141_fu_18896_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_2492_fu_8503_p3() {
    select_ln340_2492_fu_8503_p3 = (!or_ln340_2714_fu_8481_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2714_fu_8481_p2.read()[0].to_bool())? select_ln340_38_fu_8487_p3.read(): select_ln388_38_fu_8495_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_2493_fu_18992_p3() {
    select_ln340_2493_fu_18992_p3 = (!or_ln340_2715_fu_18970_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2715_fu_18970_p2.read()[0].to_bool())? select_ln340_1269_fu_18976_p3.read(): acc_1_V_143_fu_18984_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_2494_fu_19161_p3() {
    select_ln340_2494_fu_19161_p3 = (!or_ln340_2717_fu_19139_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2717_fu_19139_p2.read()[0].to_bool())? select_ln340_39_fu_19145_p3.read(): select_ln388_39_fu_19153_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_2496_fu_8693_p3() {
    select_ln340_2496_fu_8693_p3 = (!or_ln340_2720_fu_8671_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2720_fu_8671_p2.read()[0].to_bool())? select_ln340_40_fu_8677_p3.read(): select_ln388_40_fu_8685_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_2497_fu_19339_p3() {
    select_ln340_2497_fu_19339_p3 = (!or_ln340_2721_fu_19317_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2721_fu_19317_p2.read()[0].to_bool())? select_ln340_1271_fu_19323_p3.read(): acc_2_V_107_fu_19331_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_2498_fu_8873_p3() {
    select_ln340_2498_fu_8873_p3 = (!or_ln340_2723_fu_8851_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2723_fu_8851_p2.read()[0].to_bool())? select_ln340_41_fu_8857_p3.read(): select_ln388_41_fu_8865_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_2499_fu_19427_p3() {
    select_ln340_2499_fu_19427_p3 = (!or_ln340_2724_fu_19405_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2724_fu_19405_p2.read()[0].to_bool())? select_ln340_1272_fu_19411_p3.read(): acc_2_V_109_fu_19419_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_24_fu_5967_p3() {
    select_ln340_24_fu_5967_p3 = (!or_ln340_24_fu_5949_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_24_fu_5949_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: add_ln415_709_fu_5859_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_2500_fu_9053_p3() {
    select_ln340_2500_fu_9053_p3 = (!or_ln340_2726_fu_9031_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2726_fu_9031_p2.read()[0].to_bool())? select_ln340_42_fu_9037_p3.read(): select_ln388_42_fu_9045_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_2501_fu_19515_p3() {
    select_ln340_2501_fu_19515_p3 = (!or_ln340_2727_fu_19493_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2727_fu_19493_p2.read()[0].to_bool())? select_ln340_1273_fu_19499_p3.read(): acc_2_V_111_fu_19507_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_2502_fu_9233_p3() {
    select_ln340_2502_fu_9233_p3 = (!or_ln340_2729_fu_9211_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2729_fu_9211_p2.read()[0].to_bool())? select_ln340_43_fu_9217_p3.read(): select_ln388_43_fu_9225_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_2503_fu_19603_p3() {
    select_ln340_2503_fu_19603_p3 = (!or_ln340_2730_fu_19581_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2730_fu_19581_p2.read()[0].to_bool())? select_ln340_1274_fu_19587_p3.read(): acc_2_V_113_fu_19595_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_2504_fu_9413_p3() {
    select_ln340_2504_fu_9413_p3 = (!or_ln340_2732_fu_9391_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2732_fu_9391_p2.read()[0].to_bool())? select_ln340_44_fu_9397_p3.read(): select_ln388_44_fu_9405_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_2505_fu_19691_p3() {
    select_ln340_2505_fu_19691_p3 = (!or_ln340_2733_fu_19669_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2733_fu_19669_p2.read()[0].to_bool())? select_ln340_1275_fu_19675_p3.read(): acc_2_V_115_fu_19683_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_2506_fu_9593_p3() {
    select_ln340_2506_fu_9593_p3 = (!or_ln340_2735_fu_9571_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2735_fu_9571_p2.read()[0].to_bool())? select_ln340_45_fu_9577_p3.read(): select_ln388_45_fu_9585_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_2507_fu_19779_p3() {
    select_ln340_2507_fu_19779_p3 = (!or_ln340_2736_fu_19757_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2736_fu_19757_p2.read()[0].to_bool())? select_ln340_1276_fu_19763_p3.read(): acc_2_V_117_fu_19771_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_2508_fu_9773_p3() {
    select_ln340_2508_fu_9773_p3 = (!or_ln340_2738_fu_9751_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2738_fu_9751_p2.read()[0].to_bool())? select_ln340_46_fu_9757_p3.read(): select_ln388_46_fu_9765_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_2509_fu_19867_p3() {
    select_ln340_2509_fu_19867_p3 = (!or_ln340_2739_fu_19845_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2739_fu_19845_p2.read()[0].to_bool())? select_ln340_1277_fu_19851_p3.read(): acc_2_V_119_fu_19859_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_2510_fu_9953_p3() {
    select_ln340_2510_fu_9953_p3 = (!or_ln340_2741_fu_9931_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2741_fu_9931_p2.read()[0].to_bool())? select_ln340_47_fu_9937_p3.read(): select_ln388_47_fu_9945_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_2511_fu_19955_p3() {
    select_ln340_2511_fu_19955_p3 = (!or_ln340_2742_fu_19933_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2742_fu_19933_p2.read()[0].to_bool())? select_ln340_1278_fu_19939_p3.read(): acc_2_V_121_fu_19947_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_2512_fu_10133_p3() {
    select_ln340_2512_fu_10133_p3 = (!or_ln340_2744_fu_10111_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2744_fu_10111_p2.read()[0].to_bool())? select_ln340_48_fu_10117_p3.read(): select_ln388_48_fu_10125_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_2513_fu_20043_p3() {
    select_ln340_2513_fu_20043_p3 = (!or_ln340_2745_fu_20021_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2745_fu_20021_p2.read()[0].to_bool())? select_ln340_1279_fu_20027_p3.read(): acc_2_V_123_fu_20035_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_2514_fu_10313_p3() {
    select_ln340_2514_fu_10313_p3 = (!or_ln340_2747_fu_10291_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2747_fu_10291_p2.read()[0].to_bool())? select_ln340_49_fu_10297_p3.read(): select_ln388_49_fu_10305_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_2515_fu_20131_p3() {
    select_ln340_2515_fu_20131_p3 = (!or_ln340_2748_fu_20109_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2748_fu_20109_p2.read()[0].to_bool())? select_ln340_1280_fu_20115_p3.read(): acc_2_V_125_fu_20123_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_2516_fu_10493_p3() {
    select_ln340_2516_fu_10493_p3 = (!or_ln340_2750_fu_10471_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2750_fu_10471_p2.read()[0].to_bool())? select_ln340_50_fu_10477_p3.read(): select_ln388_50_fu_10485_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_2517_fu_20219_p3() {
    select_ln340_2517_fu_20219_p3 = (!or_ln340_2751_fu_20197_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2751_fu_20197_p2.read()[0].to_bool())? select_ln340_1281_fu_20203_p3.read(): acc_2_V_127_fu_20211_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_2518_fu_10673_p3() {
    select_ln340_2518_fu_10673_p3 = (!or_ln340_2753_fu_10651_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2753_fu_10651_p2.read()[0].to_bool())? select_ln340_51_fu_10657_p3.read(): select_ln388_51_fu_10665_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_2519_fu_20307_p3() {
    select_ln340_2519_fu_20307_p3 = (!or_ln340_2754_fu_20285_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2754_fu_20285_p2.read()[0].to_bool())? select_ln340_1282_fu_20291_p3.read(): acc_2_V_129_fu_20299_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_2520_fu_10853_p3() {
    select_ln340_2520_fu_10853_p3 = (!or_ln340_2756_fu_10831_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2756_fu_10831_p2.read()[0].to_bool())? select_ln340_52_fu_10837_p3.read(): select_ln388_52_fu_10845_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_2521_fu_20395_p3() {
    select_ln340_2521_fu_20395_p3 = (!or_ln340_2757_fu_20373_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2757_fu_20373_p2.read()[0].to_bool())? select_ln340_1283_fu_20379_p3.read(): acc_2_V_131_fu_20387_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_2522_fu_11033_p3() {
    select_ln340_2522_fu_11033_p3 = (!or_ln340_2759_fu_11011_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2759_fu_11011_p2.read()[0].to_bool())? select_ln340_53_fu_11017_p3.read(): select_ln388_53_fu_11025_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_2523_fu_20483_p3() {
    select_ln340_2523_fu_20483_p3 = (!or_ln340_2760_fu_20461_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2760_fu_20461_p2.read()[0].to_bool())? select_ln340_1284_fu_20467_p3.read(): acc_2_V_133_fu_20475_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_2524_fu_11213_p3() {
    select_ln340_2524_fu_11213_p3 = (!or_ln340_2762_fu_11191_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2762_fu_11191_p2.read()[0].to_bool())? select_ln340_54_fu_11197_p3.read(): select_ln388_54_fu_11205_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_2525_fu_20571_p3() {
    select_ln340_2525_fu_20571_p3 = (!or_ln340_2763_fu_20549_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2763_fu_20549_p2.read()[0].to_bool())? select_ln340_1285_fu_20555_p3.read(): acc_2_V_135_fu_20563_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_2526_fu_11393_p3() {
    select_ln340_2526_fu_11393_p3 = (!or_ln340_2765_fu_11371_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2765_fu_11371_p2.read()[0].to_bool())? select_ln340_55_fu_11377_p3.read(): select_ln388_55_fu_11385_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_2527_fu_20659_p3() {
    select_ln340_2527_fu_20659_p3 = (!or_ln340_2766_fu_20637_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2766_fu_20637_p2.read()[0].to_bool())? select_ln340_1286_fu_20643_p3.read(): acc_2_V_137_fu_20651_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_2528_fu_11573_p3() {
    select_ln340_2528_fu_11573_p3 = (!or_ln340_2768_fu_11551_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2768_fu_11551_p2.read()[0].to_bool())? select_ln340_56_fu_11557_p3.read(): select_ln388_56_fu_11565_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_2529_fu_20747_p3() {
    select_ln340_2529_fu_20747_p3 = (!or_ln340_2769_fu_20725_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2769_fu_20725_p2.read()[0].to_bool())? select_ln340_1287_fu_20731_p3.read(): acc_2_V_139_fu_20739_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_2530_fu_11753_p3() {
    select_ln340_2530_fu_11753_p3 = (!or_ln340_2771_fu_11731_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2771_fu_11731_p2.read()[0].to_bool())? select_ln340_57_fu_11737_p3.read(): select_ln388_57_fu_11745_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_2531_fu_20835_p3() {
    select_ln340_2531_fu_20835_p3 = (!or_ln340_2772_fu_20813_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2772_fu_20813_p2.read()[0].to_bool())? select_ln340_1288_fu_20819_p3.read(): acc_2_V_141_fu_20827_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_2532_fu_11933_p3() {
    select_ln340_2532_fu_11933_p3 = (!or_ln340_2774_fu_11911_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2774_fu_11911_p2.read()[0].to_bool())? select_ln340_58_fu_11917_p3.read(): select_ln388_58_fu_11925_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_2533_fu_20923_p3() {
    select_ln340_2533_fu_20923_p3 = (!or_ln340_2775_fu_20901_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2775_fu_20901_p2.read()[0].to_bool())? select_ln340_1289_fu_20907_p3.read(): acc_2_V_143_fu_20915_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_2534_fu_21092_p3() {
    select_ln340_2534_fu_21092_p3 = (!or_ln340_2777_fu_21070_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2777_fu_21070_p2.read()[0].to_bool())? select_ln340_59_fu_21076_p3.read(): select_ln388_59_fu_21084_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_2536_fu_12123_p3() {
    select_ln340_2536_fu_12123_p3 = (!or_ln340_2780_fu_12101_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2780_fu_12101_p2.read()[0].to_bool())? select_ln340_60_fu_12107_p3.read(): select_ln388_60_fu_12115_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_2537_fu_21270_p3() {
    select_ln340_2537_fu_21270_p3 = (!or_ln340_2781_fu_21248_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2781_fu_21248_p2.read()[0].to_bool())? select_ln340_1291_fu_21254_p3.read(): acc_3_V_107_fu_21262_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_2538_fu_12303_p3() {
    select_ln340_2538_fu_12303_p3 = (!or_ln340_2783_fu_12281_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2783_fu_12281_p2.read()[0].to_bool())? select_ln340_61_fu_12287_p3.read(): select_ln388_61_fu_12295_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_2539_fu_21358_p3() {
    select_ln340_2539_fu_21358_p3 = (!or_ln340_2784_fu_21336_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2784_fu_21336_p2.read()[0].to_bool())? select_ln340_1292_fu_21342_p3.read(): acc_3_V_109_fu_21350_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_2540_fu_12483_p3() {
    select_ln340_2540_fu_12483_p3 = (!or_ln340_2786_fu_12461_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2786_fu_12461_p2.read()[0].to_bool())? select_ln340_62_fu_12467_p3.read(): select_ln388_62_fu_12475_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_2541_fu_21446_p3() {
    select_ln340_2541_fu_21446_p3 = (!or_ln340_2787_fu_21424_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2787_fu_21424_p2.read()[0].to_bool())? select_ln340_1293_fu_21430_p3.read(): acc_3_V_111_fu_21438_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_2542_fu_12663_p3() {
    select_ln340_2542_fu_12663_p3 = (!or_ln340_2789_fu_12641_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2789_fu_12641_p2.read()[0].to_bool())? select_ln340_63_fu_12647_p3.read(): select_ln388_63_fu_12655_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_2543_fu_21534_p3() {
    select_ln340_2543_fu_21534_p3 = (!or_ln340_2790_fu_21512_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2790_fu_21512_p2.read()[0].to_bool())? select_ln340_1294_fu_21518_p3.read(): acc_3_V_113_fu_21526_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_2544_fu_12843_p3() {
    select_ln340_2544_fu_12843_p3 = (!or_ln340_2792_fu_12821_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2792_fu_12821_p2.read()[0].to_bool())? select_ln340_64_fu_12827_p3.read(): select_ln388_64_fu_12835_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_2545_fu_21622_p3() {
    select_ln340_2545_fu_21622_p3 = (!or_ln340_2793_fu_21600_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2793_fu_21600_p2.read()[0].to_bool())? select_ln340_1295_fu_21606_p3.read(): acc_3_V_115_fu_21614_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_2546_fu_13023_p3() {
    select_ln340_2546_fu_13023_p3 = (!or_ln340_2795_fu_13001_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2795_fu_13001_p2.read()[0].to_bool())? select_ln340_65_fu_13007_p3.read(): select_ln388_65_fu_13015_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_2547_fu_21710_p3() {
    select_ln340_2547_fu_21710_p3 = (!or_ln340_2796_fu_21688_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2796_fu_21688_p2.read()[0].to_bool())? select_ln340_1296_fu_21694_p3.read(): acc_3_V_117_fu_21702_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_2548_fu_13203_p3() {
    select_ln340_2548_fu_13203_p3 = (!or_ln340_2798_fu_13181_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2798_fu_13181_p2.read()[0].to_bool())? select_ln340_66_fu_13187_p3.read(): select_ln388_66_fu_13195_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_2549_fu_21798_p3() {
    select_ln340_2549_fu_21798_p3 = (!or_ln340_2799_fu_21776_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2799_fu_21776_p2.read()[0].to_bool())? select_ln340_1297_fu_21782_p3.read(): acc_3_V_119_fu_21790_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_2550_fu_13383_p3() {
    select_ln340_2550_fu_13383_p3 = (!or_ln340_2801_fu_13361_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2801_fu_13361_p2.read()[0].to_bool())? select_ln340_67_fu_13367_p3.read(): select_ln388_67_fu_13375_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_2551_fu_21886_p3() {
    select_ln340_2551_fu_21886_p3 = (!or_ln340_2802_fu_21864_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2802_fu_21864_p2.read()[0].to_bool())? select_ln340_1298_fu_21870_p3.read(): acc_3_V_121_fu_21878_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_2552_fu_13563_p3() {
    select_ln340_2552_fu_13563_p3 = (!or_ln340_2804_fu_13541_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2804_fu_13541_p2.read()[0].to_bool())? select_ln340_68_fu_13547_p3.read(): select_ln388_68_fu_13555_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_2553_fu_21974_p3() {
    select_ln340_2553_fu_21974_p3 = (!or_ln340_2805_fu_21952_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2805_fu_21952_p2.read()[0].to_bool())? select_ln340_1299_fu_21958_p3.read(): acc_3_V_123_fu_21966_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_2554_fu_13743_p3() {
    select_ln340_2554_fu_13743_p3 = (!or_ln340_2807_fu_13721_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2807_fu_13721_p2.read()[0].to_bool())? select_ln340_69_fu_13727_p3.read(): select_ln388_69_fu_13735_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_2555_fu_22062_p3() {
    select_ln340_2555_fu_22062_p3 = (!or_ln340_2808_fu_22040_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2808_fu_22040_p2.read()[0].to_bool())? select_ln340_1300_fu_22046_p3.read(): acc_3_V_125_fu_22054_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_2556_fu_13923_p3() {
    select_ln340_2556_fu_13923_p3 = (!or_ln340_2810_fu_13901_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2810_fu_13901_p2.read()[0].to_bool())? select_ln340_70_fu_13907_p3.read(): select_ln388_70_fu_13915_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_2557_fu_22150_p3() {
    select_ln340_2557_fu_22150_p3 = (!or_ln340_2811_fu_22128_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2811_fu_22128_p2.read()[0].to_bool())? select_ln340_1301_fu_22134_p3.read(): acc_3_V_127_fu_22142_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_2558_fu_14103_p3() {
    select_ln340_2558_fu_14103_p3 = (!or_ln340_2813_fu_14081_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2813_fu_14081_p2.read()[0].to_bool())? select_ln340_71_fu_14087_p3.read(): select_ln388_71_fu_14095_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_2559_fu_22238_p3() {
    select_ln340_2559_fu_22238_p3 = (!or_ln340_2814_fu_22216_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2814_fu_22216_p2.read()[0].to_bool())? select_ln340_1302_fu_22222_p3.read(): acc_3_V_129_fu_22230_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_2560_fu_14283_p3() {
    select_ln340_2560_fu_14283_p3 = (!or_ln340_2816_fu_14261_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2816_fu_14261_p2.read()[0].to_bool())? select_ln340_72_fu_14267_p3.read(): select_ln388_72_fu_14275_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_2561_fu_22326_p3() {
    select_ln340_2561_fu_22326_p3 = (!or_ln340_2817_fu_22304_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2817_fu_22304_p2.read()[0].to_bool())? select_ln340_1303_fu_22310_p3.read(): acc_3_V_131_fu_22318_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_2562_fu_14463_p3() {
    select_ln340_2562_fu_14463_p3 = (!or_ln340_2819_fu_14441_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2819_fu_14441_p2.read()[0].to_bool())? select_ln340_73_fu_14447_p3.read(): select_ln388_73_fu_14455_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_2563_fu_22414_p3() {
    select_ln340_2563_fu_22414_p3 = (!or_ln340_2820_fu_22392_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2820_fu_22392_p2.read()[0].to_bool())? select_ln340_1304_fu_22398_p3.read(): acc_3_V_133_fu_22406_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_2564_fu_14643_p3() {
    select_ln340_2564_fu_14643_p3 = (!or_ln340_2822_fu_14621_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2822_fu_14621_p2.read()[0].to_bool())? select_ln340_74_fu_14627_p3.read(): select_ln388_74_fu_14635_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_2565_fu_22502_p3() {
    select_ln340_2565_fu_22502_p3 = (!or_ln340_2823_fu_22480_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2823_fu_22480_p2.read()[0].to_bool())? select_ln340_1305_fu_22486_p3.read(): acc_3_V_135_fu_22494_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_2566_fu_14823_p3() {
    select_ln340_2566_fu_14823_p3 = (!or_ln340_2825_fu_14801_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2825_fu_14801_p2.read()[0].to_bool())? select_ln340_75_fu_14807_p3.read(): select_ln388_75_fu_14815_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_2567_fu_22590_p3() {
    select_ln340_2567_fu_22590_p3 = (!or_ln340_2826_fu_22568_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2826_fu_22568_p2.read()[0].to_bool())? select_ln340_1306_fu_22574_p3.read(): acc_3_V_137_fu_22582_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_2568_fu_15003_p3() {
    select_ln340_2568_fu_15003_p3 = (!or_ln340_2828_fu_14981_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2828_fu_14981_p2.read()[0].to_bool())? select_ln340_76_fu_14987_p3.read(): select_ln388_76_fu_14995_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_2569_fu_22678_p3() {
    select_ln340_2569_fu_22678_p3 = (!or_ln340_2829_fu_22656_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2829_fu_22656_p2.read()[0].to_bool())? select_ln340_1307_fu_22662_p3.read(): acc_3_V_139_fu_22670_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_2570_fu_15183_p3() {
    select_ln340_2570_fu_15183_p3 = (!or_ln340_2831_fu_15161_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2831_fu_15161_p2.read()[0].to_bool())? select_ln340_77_fu_15167_p3.read(): select_ln388_77_fu_15175_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_2571_fu_22766_p3() {
    select_ln340_2571_fu_22766_p3 = (!or_ln340_2832_fu_22744_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2832_fu_22744_p2.read()[0].to_bool())? select_ln340_1308_fu_22750_p3.read(): acc_3_V_141_fu_22758_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_2572_fu_15363_p3() {
    select_ln340_2572_fu_15363_p3 = (!or_ln340_2834_fu_15341_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2834_fu_15341_p2.read()[0].to_bool())? select_ln340_78_fu_15347_p3.read(): select_ln388_78_fu_15355_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_2573_fu_22854_p3() {
    select_ln340_2573_fu_22854_p3 = (!or_ln340_2835_fu_22832_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2835_fu_22832_p2.read()[0].to_bool())? select_ln340_1309_fu_22838_p3.read(): acc_3_V_143_fu_22846_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_2574_fu_23023_p3() {
    select_ln340_2574_fu_23023_p3 = (!or_ln340_2837_fu_23001_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2837_fu_23001_p2.read()[0].to_bool())? select_ln340_79_fu_23007_p3.read(): select_ln388_79_fu_23015_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_25_fu_6147_p3() {
    select_ln340_25_fu_6147_p3 = (!or_ln340_25_fu_6129_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_25_fu_6129_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: add_ln415_710_fu_6039_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_26_fu_6327_p3() {
    select_ln340_26_fu_6327_p3 = (!or_ln340_26_fu_6309_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_26_fu_6309_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: add_ln415_711_fu_6219_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_27_fu_6507_p3() {
    select_ln340_27_fu_6507_p3 = (!or_ln340_27_fu_6489_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_27_fu_6489_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: add_ln415_712_fu_6399_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_28_fu_6687_p3() {
    select_ln340_28_fu_6687_p3 = (!or_ln340_28_fu_6669_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_28_fu_6669_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: add_ln415_713_fu_6579_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_29_fu_6867_p3() {
    select_ln340_29_fu_6867_p3 = (!or_ln340_29_fu_6849_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_29_fu_6849_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: add_ln415_714_fu_6759_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_2_fu_1977_p3() {
    select_ln340_2_fu_1977_p3 = (!or_ln340_2_fu_1959_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_2_fu_1959_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: add_ln415_687_fu_1869_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_30_fu_7047_p3() {
    select_ln340_30_fu_7047_p3 = (!or_ln340_30_fu_7029_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_30_fu_7029_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: add_ln415_715_fu_6939_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_31_fu_7227_p3() {
    select_ln340_31_fu_7227_p3 = (!or_ln340_31_fu_7209_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_31_fu_7209_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: add_ln415_716_fu_7119_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_32_fu_7407_p3() {
    select_ln340_32_fu_7407_p3 = (!or_ln340_32_fu_7389_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_32_fu_7389_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: add_ln415_717_fu_7299_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_33_fu_7587_p3() {
    select_ln340_33_fu_7587_p3 = (!or_ln340_33_fu_7569_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_33_fu_7569_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: add_ln415_718_fu_7479_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_34_fu_7767_p3() {
    select_ln340_34_fu_7767_p3 = (!or_ln340_34_fu_7749_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_34_fu_7749_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: add_ln415_719_fu_7659_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_35_fu_7947_p3() {
    select_ln340_35_fu_7947_p3 = (!or_ln340_35_fu_7929_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_35_fu_7929_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: add_ln415_720_fu_7839_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_36_fu_8127_p3() {
    select_ln340_36_fu_8127_p3 = (!or_ln340_36_fu_8109_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_36_fu_8109_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: add_ln415_721_fu_8019_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_37_fu_8307_p3() {
    select_ln340_37_fu_8307_p3 = (!or_ln340_37_fu_8289_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_37_fu_8289_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: add_ln415_722_fu_8199_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_38_fu_8487_p3() {
    select_ln340_38_fu_8487_p3 = (!or_ln340_38_fu_8469_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_38_fu_8469_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: add_ln415_723_fu_8379_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_39_fu_19145_p3() {
    select_ln340_39_fu_19145_p3 = (!or_ln340_39_fu_19127_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_39_fu_19127_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: add_ln415_724_fu_19037_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_3_fu_2177_p3() {
    select_ln340_3_fu_2177_p3 = (!or_ln340_3_fu_2159_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_3_fu_2159_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: add_ln415_688_fu_2069_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_40_fu_8677_p3() {
    select_ln340_40_fu_8677_p3 = (!or_ln340_40_fu_8659_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_40_fu_8659_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: add_ln415_725_fu_8569_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_41_fu_8857_p3() {
    select_ln340_41_fu_8857_p3 = (!or_ln340_41_fu_8839_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_41_fu_8839_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: add_ln415_726_fu_8749_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_42_fu_9037_p3() {
    select_ln340_42_fu_9037_p3 = (!or_ln340_42_fu_9019_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_42_fu_9019_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: add_ln415_727_fu_8929_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_43_fu_9217_p3() {
    select_ln340_43_fu_9217_p3 = (!or_ln340_43_fu_9199_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_43_fu_9199_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: add_ln415_728_fu_9109_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_44_fu_9397_p3() {
    select_ln340_44_fu_9397_p3 = (!or_ln340_44_fu_9379_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_44_fu_9379_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: add_ln415_729_fu_9289_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_45_fu_9577_p3() {
    select_ln340_45_fu_9577_p3 = (!or_ln340_45_fu_9559_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_45_fu_9559_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: add_ln415_730_fu_9469_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_46_fu_9757_p3() {
    select_ln340_46_fu_9757_p3 = (!or_ln340_46_fu_9739_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_46_fu_9739_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: add_ln415_731_fu_9649_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_47_fu_9937_p3() {
    select_ln340_47_fu_9937_p3 = (!or_ln340_47_fu_9919_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_47_fu_9919_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: add_ln415_732_fu_9829_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_48_fu_10117_p3() {
    select_ln340_48_fu_10117_p3 = (!or_ln340_48_fu_10099_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_48_fu_10099_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: add_ln415_733_fu_10009_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_49_fu_10297_p3() {
    select_ln340_49_fu_10297_p3 = (!or_ln340_49_fu_10279_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_49_fu_10279_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: add_ln415_734_fu_10189_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_4_fu_2369_p3() {
    select_ln340_4_fu_2369_p3 = (!or_ln340_4_fu_2351_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_4_fu_2351_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: add_ln415_689_fu_2261_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_50_fu_10477_p3() {
    select_ln340_50_fu_10477_p3 = (!or_ln340_50_fu_10459_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_50_fu_10459_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: add_ln415_735_fu_10369_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_51_fu_10657_p3() {
    select_ln340_51_fu_10657_p3 = (!or_ln340_51_fu_10639_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_51_fu_10639_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: add_ln415_736_fu_10549_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_52_fu_10837_p3() {
    select_ln340_52_fu_10837_p3 = (!or_ln340_52_fu_10819_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_52_fu_10819_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: add_ln415_737_fu_10729_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_53_fu_11017_p3() {
    select_ln340_53_fu_11017_p3 = (!or_ln340_53_fu_10999_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_53_fu_10999_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: add_ln415_738_fu_10909_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_54_fu_11197_p3() {
    select_ln340_54_fu_11197_p3 = (!or_ln340_54_fu_11179_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_54_fu_11179_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: add_ln415_739_fu_11089_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_55_fu_11377_p3() {
    select_ln340_55_fu_11377_p3 = (!or_ln340_55_fu_11359_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_55_fu_11359_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: add_ln415_740_fu_11269_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_56_fu_11557_p3() {
    select_ln340_56_fu_11557_p3 = (!or_ln340_56_fu_11539_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_56_fu_11539_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: add_ln415_741_fu_11449_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_57_fu_11737_p3() {
    select_ln340_57_fu_11737_p3 = (!or_ln340_57_fu_11719_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_57_fu_11719_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: add_ln415_742_fu_11629_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_58_fu_11917_p3() {
    select_ln340_58_fu_11917_p3 = (!or_ln340_58_fu_11899_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_58_fu_11899_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: add_ln415_743_fu_11809_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_59_fu_21076_p3() {
    select_ln340_59_fu_21076_p3 = (!or_ln340_59_fu_21058_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_59_fu_21058_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: add_ln415_744_fu_20968_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_5_fu_2561_p3() {
    select_ln340_5_fu_2561_p3 = (!or_ln340_5_fu_2543_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_5_fu_2543_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: add_ln415_690_fu_2453_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_60_fu_12107_p3() {
    select_ln340_60_fu_12107_p3 = (!or_ln340_60_fu_12089_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_60_fu_12089_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: add_ln415_745_fu_11999_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_61_fu_12287_p3() {
    select_ln340_61_fu_12287_p3 = (!or_ln340_61_fu_12269_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_61_fu_12269_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: add_ln415_746_fu_12179_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_62_fu_12467_p3() {
    select_ln340_62_fu_12467_p3 = (!or_ln340_62_fu_12449_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_62_fu_12449_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: add_ln415_747_fu_12359_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_63_fu_12647_p3() {
    select_ln340_63_fu_12647_p3 = (!or_ln340_63_fu_12629_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_63_fu_12629_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: add_ln415_748_fu_12539_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_64_fu_12827_p3() {
    select_ln340_64_fu_12827_p3 = (!or_ln340_64_fu_12809_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_64_fu_12809_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: add_ln415_749_fu_12719_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_65_fu_13007_p3() {
    select_ln340_65_fu_13007_p3 = (!or_ln340_65_fu_12989_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_65_fu_12989_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: add_ln415_750_fu_12899_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_66_fu_13187_p3() {
    select_ln340_66_fu_13187_p3 = (!or_ln340_66_fu_13169_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_66_fu_13169_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: add_ln415_751_fu_13079_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_67_fu_13367_p3() {
    select_ln340_67_fu_13367_p3 = (!or_ln340_67_fu_13349_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_67_fu_13349_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: add_ln415_752_fu_13259_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_68_fu_13547_p3() {
    select_ln340_68_fu_13547_p3 = (!or_ln340_68_fu_13529_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_68_fu_13529_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: add_ln415_753_fu_13439_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_69_fu_13727_p3() {
    select_ln340_69_fu_13727_p3 = (!or_ln340_69_fu_13709_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_69_fu_13709_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: add_ln415_754_fu_13619_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_6_fu_2753_p3() {
    select_ln340_6_fu_2753_p3 = (!or_ln340_6_fu_2735_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_6_fu_2735_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: add_ln415_691_fu_2645_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_70_fu_13907_p3() {
    select_ln340_70_fu_13907_p3 = (!or_ln340_70_fu_13889_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_70_fu_13889_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: add_ln415_755_fu_13799_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_71_fu_14087_p3() {
    select_ln340_71_fu_14087_p3 = (!or_ln340_71_fu_14069_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_71_fu_14069_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: add_ln415_756_fu_13979_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_72_fu_14267_p3() {
    select_ln340_72_fu_14267_p3 = (!or_ln340_72_fu_14249_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_72_fu_14249_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: add_ln415_757_fu_14159_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_73_fu_14447_p3() {
    select_ln340_73_fu_14447_p3 = (!or_ln340_73_fu_14429_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_73_fu_14429_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: add_ln415_758_fu_14339_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_74_fu_14627_p3() {
    select_ln340_74_fu_14627_p3 = (!or_ln340_74_fu_14609_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_74_fu_14609_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: add_ln415_759_fu_14519_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_75_fu_14807_p3() {
    select_ln340_75_fu_14807_p3 = (!or_ln340_75_fu_14789_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_75_fu_14789_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: add_ln415_760_fu_14699_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_76_fu_14987_p3() {
    select_ln340_76_fu_14987_p3 = (!or_ln340_76_fu_14969_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_76_fu_14969_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: add_ln415_761_fu_14879_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_77_fu_15167_p3() {
    select_ln340_77_fu_15167_p3 = (!or_ln340_77_fu_15149_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_77_fu_15149_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: add_ln415_762_fu_15059_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_78_fu_15347_p3() {
    select_ln340_78_fu_15347_p3 = (!or_ln340_78_fu_15329_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_78_fu_15329_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: add_ln415_763_fu_15239_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_79_fu_23007_p3() {
    select_ln340_79_fu_23007_p3 = (!or_ln340_79_fu_22989_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_79_fu_22989_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: add_ln415_764_fu_22899_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_7_fu_2945_p3() {
    select_ln340_7_fu_2945_p3 = (!or_ln340_7_fu_2927_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_7_fu_2927_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: add_ln415_692_fu_2837_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_8_fu_3137_p3() {
    select_ln340_8_fu_3137_p3 = (!or_ln340_8_fu_3119_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_8_fu_3119_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: add_ln415_693_fu_3029_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_9_fu_3329_p3() {
    select_ln340_9_fu_3329_p3 = (!or_ln340_925_fu_3311_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_925_fu_3311_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: add_ln415_694_fu_3221_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln340_fu_1577_p3() {
    select_ln340_fu_1577_p3 = (!or_ln340_fu_1559_p2.read()[0].is_01())? sc_lv<24>(): ((or_ln340_fu_1559_p2.read()[0].to_bool())? ap_const_lv24_7FFFFF: add_ln415_fu_1469_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln388_10_fu_3529_p3() {
    select_ln388_10_fu_3529_p3 = (!and_ln786_1947_fu_3497_p2.read()[0].is_01())? sc_lv<24>(): ((and_ln786_1947_fu_3497_p2.read()[0].to_bool())? ap_const_lv24_800000: add_ln415_695_fu_3413_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln388_11_fu_3721_p3() {
    select_ln388_11_fu_3721_p3 = (!and_ln786_1949_fu_3689_p2.read()[0].is_01())? sc_lv<24>(): ((and_ln786_1949_fu_3689_p2.read()[0].to_bool())? ap_const_lv24_800000: add_ln415_696_fu_3605_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln388_12_fu_3913_p3() {
    select_ln388_12_fu_3913_p3 = (!and_ln786_1951_fu_3881_p2.read()[0].is_01())? sc_lv<24>(): ((and_ln786_1951_fu_3881_p2.read()[0].to_bool())? ap_const_lv24_800000: add_ln415_697_fu_3797_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln388_13_fu_4105_p3() {
    select_ln388_13_fu_4105_p3 = (!and_ln786_1953_fu_4073_p2.read()[0].is_01())? sc_lv<24>(): ((and_ln786_1953_fu_4073_p2.read()[0].to_bool())? ap_const_lv24_800000: add_ln415_698_fu_3989_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln388_14_fu_4297_p3() {
    select_ln388_14_fu_4297_p3 = (!and_ln786_1955_fu_4265_p2.read()[0].is_01())? sc_lv<24>(): ((and_ln786_1955_fu_4265_p2.read()[0].to_bool())? ap_const_lv24_800000: add_ln415_699_fu_4181_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln388_15_fu_4489_p3() {
    select_ln388_15_fu_4489_p3 = (!and_ln786_1957_fu_4457_p2.read()[0].is_01())? sc_lv<24>(): ((and_ln786_1957_fu_4457_p2.read()[0].to_bool())? ap_const_lv24_800000: add_ln415_700_fu_4373_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln388_16_fu_4681_p3() {
    select_ln388_16_fu_4681_p3 = (!and_ln786_1959_fu_4649_p2.read()[0].is_01())? sc_lv<24>(): ((and_ln786_1959_fu_4649_p2.read()[0].to_bool())? ap_const_lv24_800000: add_ln415_701_fu_4565_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln388_17_fu_4873_p3() {
    select_ln388_17_fu_4873_p3 = (!and_ln786_1961_fu_4841_p2.read()[0].is_01())? sc_lv<24>(): ((and_ln786_1961_fu_4841_p2.read()[0].to_bool())? ap_const_lv24_800000: add_ln415_702_fu_4757_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln388_18_fu_5065_p3() {
    select_ln388_18_fu_5065_p3 = (!and_ln786_1963_fu_5033_p2.read()[0].is_01())? sc_lv<24>(): ((and_ln786_1963_fu_5033_p2.read()[0].to_bool())? ap_const_lv24_800000: add_ln415_703_fu_4949_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln388_19_fu_17222_p3() {
    select_ln388_19_fu_17222_p3 = (!and_ln786_1965_fu_17190_p2.read()[0].is_01())? sc_lv<24>(): ((and_ln786_1965_fu_17190_p2.read()[0].to_bool())? ap_const_lv24_800000: add_ln415_704_fu_17106_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln388_1_fu_1785_p3() {
    select_ln388_1_fu_1785_p3 = (!and_ln786_1929_fu_1753_p2.read()[0].is_01())? sc_lv<24>(): ((and_ln786_1929_fu_1753_p2.read()[0].to_bool())? ap_const_lv24_800000: add_ln415_686_fu_1669_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln388_20_fu_5255_p3() {
    select_ln388_20_fu_5255_p3 = (!and_ln786_1967_fu_5223_p2.read()[0].is_01())? sc_lv<24>(): ((and_ln786_1967_fu_5223_p2.read()[0].to_bool())? ap_const_lv24_800000: add_ln415_705_fu_5139_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln388_21_fu_5435_p3() {
    select_ln388_21_fu_5435_p3 = (!and_ln786_1969_fu_5403_p2.read()[0].is_01())? sc_lv<24>(): ((and_ln786_1969_fu_5403_p2.read()[0].to_bool())? ap_const_lv24_800000: add_ln415_706_fu_5319_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln388_22_fu_5615_p3() {
    select_ln388_22_fu_5615_p3 = (!and_ln786_1971_fu_5583_p2.read()[0].is_01())? sc_lv<24>(): ((and_ln786_1971_fu_5583_p2.read()[0].to_bool())? ap_const_lv24_800000: add_ln415_707_fu_5499_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln388_23_fu_5795_p3() {
    select_ln388_23_fu_5795_p3 = (!and_ln786_1973_fu_5763_p2.read()[0].is_01())? sc_lv<24>(): ((and_ln786_1973_fu_5763_p2.read()[0].to_bool())? ap_const_lv24_800000: add_ln415_708_fu_5679_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln388_24_fu_5975_p3() {
    select_ln388_24_fu_5975_p3 = (!and_ln786_1975_fu_5943_p2.read()[0].is_01())? sc_lv<24>(): ((and_ln786_1975_fu_5943_p2.read()[0].to_bool())? ap_const_lv24_800000: add_ln415_709_fu_5859_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln388_25_fu_6155_p3() {
    select_ln388_25_fu_6155_p3 = (!and_ln786_1977_fu_6123_p2.read()[0].is_01())? sc_lv<24>(): ((and_ln786_1977_fu_6123_p2.read()[0].to_bool())? ap_const_lv24_800000: add_ln415_710_fu_6039_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln388_26_fu_6335_p3() {
    select_ln388_26_fu_6335_p3 = (!and_ln786_1979_fu_6303_p2.read()[0].is_01())? sc_lv<24>(): ((and_ln786_1979_fu_6303_p2.read()[0].to_bool())? ap_const_lv24_800000: add_ln415_711_fu_6219_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln388_27_fu_6515_p3() {
    select_ln388_27_fu_6515_p3 = (!and_ln786_1981_fu_6483_p2.read()[0].is_01())? sc_lv<24>(): ((and_ln786_1981_fu_6483_p2.read()[0].to_bool())? ap_const_lv24_800000: add_ln415_712_fu_6399_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln388_28_fu_6695_p3() {
    select_ln388_28_fu_6695_p3 = (!and_ln786_1983_fu_6663_p2.read()[0].is_01())? sc_lv<24>(): ((and_ln786_1983_fu_6663_p2.read()[0].to_bool())? ap_const_lv24_800000: add_ln415_713_fu_6579_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln388_29_fu_6875_p3() {
    select_ln388_29_fu_6875_p3 = (!and_ln786_1985_fu_6843_p2.read()[0].is_01())? sc_lv<24>(): ((and_ln786_1985_fu_6843_p2.read()[0].to_bool())? ap_const_lv24_800000: add_ln415_714_fu_6759_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln388_2_fu_1985_p3() {
    select_ln388_2_fu_1985_p3 = (!and_ln786_1931_fu_1953_p2.read()[0].is_01())? sc_lv<24>(): ((and_ln786_1931_fu_1953_p2.read()[0].to_bool())? ap_const_lv24_800000: add_ln415_687_fu_1869_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln388_30_fu_7055_p3() {
    select_ln388_30_fu_7055_p3 = (!and_ln786_1987_fu_7023_p2.read()[0].is_01())? sc_lv<24>(): ((and_ln786_1987_fu_7023_p2.read()[0].to_bool())? ap_const_lv24_800000: add_ln415_715_fu_6939_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln388_31_fu_7235_p3() {
    select_ln388_31_fu_7235_p3 = (!and_ln786_1989_fu_7203_p2.read()[0].is_01())? sc_lv<24>(): ((and_ln786_1989_fu_7203_p2.read()[0].to_bool())? ap_const_lv24_800000: add_ln415_716_fu_7119_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln388_32_fu_7415_p3() {
    select_ln388_32_fu_7415_p3 = (!and_ln786_1991_fu_7383_p2.read()[0].is_01())? sc_lv<24>(): ((and_ln786_1991_fu_7383_p2.read()[0].to_bool())? ap_const_lv24_800000: add_ln415_717_fu_7299_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln388_33_fu_7595_p3() {
    select_ln388_33_fu_7595_p3 = (!and_ln786_1993_fu_7563_p2.read()[0].is_01())? sc_lv<24>(): ((and_ln786_1993_fu_7563_p2.read()[0].to_bool())? ap_const_lv24_800000: add_ln415_718_fu_7479_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln388_34_fu_7775_p3() {
    select_ln388_34_fu_7775_p3 = (!and_ln786_1995_fu_7743_p2.read()[0].is_01())? sc_lv<24>(): ((and_ln786_1995_fu_7743_p2.read()[0].to_bool())? ap_const_lv24_800000: add_ln415_719_fu_7659_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln388_35_fu_7955_p3() {
    select_ln388_35_fu_7955_p3 = (!and_ln786_1997_fu_7923_p2.read()[0].is_01())? sc_lv<24>(): ((and_ln786_1997_fu_7923_p2.read()[0].to_bool())? ap_const_lv24_800000: add_ln415_720_fu_7839_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln388_36_fu_8135_p3() {
    select_ln388_36_fu_8135_p3 = (!and_ln786_1999_fu_8103_p2.read()[0].is_01())? sc_lv<24>(): ((and_ln786_1999_fu_8103_p2.read()[0].to_bool())? ap_const_lv24_800000: add_ln415_721_fu_8019_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln388_37_fu_8315_p3() {
    select_ln388_37_fu_8315_p3 = (!and_ln786_2001_fu_8283_p2.read()[0].is_01())? sc_lv<24>(): ((and_ln786_2001_fu_8283_p2.read()[0].to_bool())? ap_const_lv24_800000: add_ln415_722_fu_8199_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln388_38_fu_8495_p3() {
    select_ln388_38_fu_8495_p3 = (!and_ln786_2003_fu_8463_p2.read()[0].is_01())? sc_lv<24>(): ((and_ln786_2003_fu_8463_p2.read()[0].to_bool())? ap_const_lv24_800000: add_ln415_723_fu_8379_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln388_39_fu_19153_p3() {
    select_ln388_39_fu_19153_p3 = (!and_ln786_2005_fu_19121_p2.read()[0].is_01())? sc_lv<24>(): ((and_ln786_2005_fu_19121_p2.read()[0].to_bool())? ap_const_lv24_800000: add_ln415_724_fu_19037_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln388_3_fu_2185_p3() {
    select_ln388_3_fu_2185_p3 = (!and_ln786_1933_fu_2153_p2.read()[0].is_01())? sc_lv<24>(): ((and_ln786_1933_fu_2153_p2.read()[0].to_bool())? ap_const_lv24_800000: add_ln415_688_fu_2069_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln388_40_fu_8685_p3() {
    select_ln388_40_fu_8685_p3 = (!and_ln786_2007_fu_8653_p2.read()[0].is_01())? sc_lv<24>(): ((and_ln786_2007_fu_8653_p2.read()[0].to_bool())? ap_const_lv24_800000: add_ln415_725_fu_8569_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln388_41_fu_8865_p3() {
    select_ln388_41_fu_8865_p3 = (!and_ln786_2009_fu_8833_p2.read()[0].is_01())? sc_lv<24>(): ((and_ln786_2009_fu_8833_p2.read()[0].to_bool())? ap_const_lv24_800000: add_ln415_726_fu_8749_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln388_42_fu_9045_p3() {
    select_ln388_42_fu_9045_p3 = (!and_ln786_2011_fu_9013_p2.read()[0].is_01())? sc_lv<24>(): ((and_ln786_2011_fu_9013_p2.read()[0].to_bool())? ap_const_lv24_800000: add_ln415_727_fu_8929_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln388_43_fu_9225_p3() {
    select_ln388_43_fu_9225_p3 = (!and_ln786_2013_fu_9193_p2.read()[0].is_01())? sc_lv<24>(): ((and_ln786_2013_fu_9193_p2.read()[0].to_bool())? ap_const_lv24_800000: add_ln415_728_fu_9109_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln388_44_fu_9405_p3() {
    select_ln388_44_fu_9405_p3 = (!and_ln786_2015_fu_9373_p2.read()[0].is_01())? sc_lv<24>(): ((and_ln786_2015_fu_9373_p2.read()[0].to_bool())? ap_const_lv24_800000: add_ln415_729_fu_9289_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln388_45_fu_9585_p3() {
    select_ln388_45_fu_9585_p3 = (!and_ln786_2017_fu_9553_p2.read()[0].is_01())? sc_lv<24>(): ((and_ln786_2017_fu_9553_p2.read()[0].to_bool())? ap_const_lv24_800000: add_ln415_730_fu_9469_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln388_46_fu_9765_p3() {
    select_ln388_46_fu_9765_p3 = (!and_ln786_2019_fu_9733_p2.read()[0].is_01())? sc_lv<24>(): ((and_ln786_2019_fu_9733_p2.read()[0].to_bool())? ap_const_lv24_800000: add_ln415_731_fu_9649_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln388_47_fu_9945_p3() {
    select_ln388_47_fu_9945_p3 = (!and_ln786_2021_fu_9913_p2.read()[0].is_01())? sc_lv<24>(): ((and_ln786_2021_fu_9913_p2.read()[0].to_bool())? ap_const_lv24_800000: add_ln415_732_fu_9829_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln388_48_fu_10125_p3() {
    select_ln388_48_fu_10125_p3 = (!and_ln786_2023_fu_10093_p2.read()[0].is_01())? sc_lv<24>(): ((and_ln786_2023_fu_10093_p2.read()[0].to_bool())? ap_const_lv24_800000: add_ln415_733_fu_10009_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln388_49_fu_10305_p3() {
    select_ln388_49_fu_10305_p3 = (!and_ln786_2025_fu_10273_p2.read()[0].is_01())? sc_lv<24>(): ((and_ln786_2025_fu_10273_p2.read()[0].to_bool())? ap_const_lv24_800000: add_ln415_734_fu_10189_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln388_4_fu_2377_p3() {
    select_ln388_4_fu_2377_p3 = (!and_ln786_1935_fu_2345_p2.read()[0].is_01())? sc_lv<24>(): ((and_ln786_1935_fu_2345_p2.read()[0].to_bool())? ap_const_lv24_800000: add_ln415_689_fu_2261_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln388_50_fu_10485_p3() {
    select_ln388_50_fu_10485_p3 = (!and_ln786_2027_fu_10453_p2.read()[0].is_01())? sc_lv<24>(): ((and_ln786_2027_fu_10453_p2.read()[0].to_bool())? ap_const_lv24_800000: add_ln415_735_fu_10369_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln388_51_fu_10665_p3() {
    select_ln388_51_fu_10665_p3 = (!and_ln786_2029_fu_10633_p2.read()[0].is_01())? sc_lv<24>(): ((and_ln786_2029_fu_10633_p2.read()[0].to_bool())? ap_const_lv24_800000: add_ln415_736_fu_10549_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln388_52_fu_10845_p3() {
    select_ln388_52_fu_10845_p3 = (!and_ln786_2031_fu_10813_p2.read()[0].is_01())? sc_lv<24>(): ((and_ln786_2031_fu_10813_p2.read()[0].to_bool())? ap_const_lv24_800000: add_ln415_737_fu_10729_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln388_53_fu_11025_p3() {
    select_ln388_53_fu_11025_p3 = (!and_ln786_2033_fu_10993_p2.read()[0].is_01())? sc_lv<24>(): ((and_ln786_2033_fu_10993_p2.read()[0].to_bool())? ap_const_lv24_800000: add_ln415_738_fu_10909_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln388_54_fu_11205_p3() {
    select_ln388_54_fu_11205_p3 = (!and_ln786_2035_fu_11173_p2.read()[0].is_01())? sc_lv<24>(): ((and_ln786_2035_fu_11173_p2.read()[0].to_bool())? ap_const_lv24_800000: add_ln415_739_fu_11089_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln388_55_fu_11385_p3() {
    select_ln388_55_fu_11385_p3 = (!and_ln786_2037_fu_11353_p2.read()[0].is_01())? sc_lv<24>(): ((and_ln786_2037_fu_11353_p2.read()[0].to_bool())? ap_const_lv24_800000: add_ln415_740_fu_11269_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln388_56_fu_11565_p3() {
    select_ln388_56_fu_11565_p3 = (!and_ln786_2039_fu_11533_p2.read()[0].is_01())? sc_lv<24>(): ((and_ln786_2039_fu_11533_p2.read()[0].to_bool())? ap_const_lv24_800000: add_ln415_741_fu_11449_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln388_57_fu_11745_p3() {
    select_ln388_57_fu_11745_p3 = (!and_ln786_2041_fu_11713_p2.read()[0].is_01())? sc_lv<24>(): ((and_ln786_2041_fu_11713_p2.read()[0].to_bool())? ap_const_lv24_800000: add_ln415_742_fu_11629_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln388_58_fu_11925_p3() {
    select_ln388_58_fu_11925_p3 = (!and_ln786_2043_fu_11893_p2.read()[0].is_01())? sc_lv<24>(): ((and_ln786_2043_fu_11893_p2.read()[0].to_bool())? ap_const_lv24_800000: add_ln415_743_fu_11809_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln388_59_fu_21084_p3() {
    select_ln388_59_fu_21084_p3 = (!and_ln786_2045_fu_21052_p2.read()[0].is_01())? sc_lv<24>(): ((and_ln786_2045_fu_21052_p2.read()[0].to_bool())? ap_const_lv24_800000: add_ln415_744_fu_20968_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln388_5_fu_2569_p3() {
    select_ln388_5_fu_2569_p3 = (!and_ln786_1937_fu_2537_p2.read()[0].is_01())? sc_lv<24>(): ((and_ln786_1937_fu_2537_p2.read()[0].to_bool())? ap_const_lv24_800000: add_ln415_690_fu_2453_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln388_60_fu_12115_p3() {
    select_ln388_60_fu_12115_p3 = (!and_ln786_2047_fu_12083_p2.read()[0].is_01())? sc_lv<24>(): ((and_ln786_2047_fu_12083_p2.read()[0].to_bool())? ap_const_lv24_800000: add_ln415_745_fu_11999_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln388_61_fu_12295_p3() {
    select_ln388_61_fu_12295_p3 = (!and_ln786_2049_fu_12263_p2.read()[0].is_01())? sc_lv<24>(): ((and_ln786_2049_fu_12263_p2.read()[0].to_bool())? ap_const_lv24_800000: add_ln415_746_fu_12179_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln388_62_fu_12475_p3() {
    select_ln388_62_fu_12475_p3 = (!and_ln786_2051_fu_12443_p2.read()[0].is_01())? sc_lv<24>(): ((and_ln786_2051_fu_12443_p2.read()[0].to_bool())? ap_const_lv24_800000: add_ln415_747_fu_12359_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln388_63_fu_12655_p3() {
    select_ln388_63_fu_12655_p3 = (!and_ln786_2053_fu_12623_p2.read()[0].is_01())? sc_lv<24>(): ((and_ln786_2053_fu_12623_p2.read()[0].to_bool())? ap_const_lv24_800000: add_ln415_748_fu_12539_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln388_64_fu_12835_p3() {
    select_ln388_64_fu_12835_p3 = (!and_ln786_2055_fu_12803_p2.read()[0].is_01())? sc_lv<24>(): ((and_ln786_2055_fu_12803_p2.read()[0].to_bool())? ap_const_lv24_800000: add_ln415_749_fu_12719_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln388_65_fu_13015_p3() {
    select_ln388_65_fu_13015_p3 = (!and_ln786_2057_fu_12983_p2.read()[0].is_01())? sc_lv<24>(): ((and_ln786_2057_fu_12983_p2.read()[0].to_bool())? ap_const_lv24_800000: add_ln415_750_fu_12899_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln388_66_fu_13195_p3() {
    select_ln388_66_fu_13195_p3 = (!and_ln786_2059_fu_13163_p2.read()[0].is_01())? sc_lv<24>(): ((and_ln786_2059_fu_13163_p2.read()[0].to_bool())? ap_const_lv24_800000: add_ln415_751_fu_13079_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln388_67_fu_13375_p3() {
    select_ln388_67_fu_13375_p3 = (!and_ln786_2061_fu_13343_p2.read()[0].is_01())? sc_lv<24>(): ((and_ln786_2061_fu_13343_p2.read()[0].to_bool())? ap_const_lv24_800000: add_ln415_752_fu_13259_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln388_68_fu_13555_p3() {
    select_ln388_68_fu_13555_p3 = (!and_ln786_2063_fu_13523_p2.read()[0].is_01())? sc_lv<24>(): ((and_ln786_2063_fu_13523_p2.read()[0].to_bool())? ap_const_lv24_800000: add_ln415_753_fu_13439_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln388_69_fu_13735_p3() {
    select_ln388_69_fu_13735_p3 = (!and_ln786_2065_fu_13703_p2.read()[0].is_01())? sc_lv<24>(): ((and_ln786_2065_fu_13703_p2.read()[0].to_bool())? ap_const_lv24_800000: add_ln415_754_fu_13619_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln388_6_fu_2761_p3() {
    select_ln388_6_fu_2761_p3 = (!and_ln786_1939_fu_2729_p2.read()[0].is_01())? sc_lv<24>(): ((and_ln786_1939_fu_2729_p2.read()[0].to_bool())? ap_const_lv24_800000: add_ln415_691_fu_2645_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln388_70_fu_13915_p3() {
    select_ln388_70_fu_13915_p3 = (!and_ln786_2067_fu_13883_p2.read()[0].is_01())? sc_lv<24>(): ((and_ln786_2067_fu_13883_p2.read()[0].to_bool())? ap_const_lv24_800000: add_ln415_755_fu_13799_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln388_71_fu_14095_p3() {
    select_ln388_71_fu_14095_p3 = (!and_ln786_2069_fu_14063_p2.read()[0].is_01())? sc_lv<24>(): ((and_ln786_2069_fu_14063_p2.read()[0].to_bool())? ap_const_lv24_800000: add_ln415_756_fu_13979_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln388_72_fu_14275_p3() {
    select_ln388_72_fu_14275_p3 = (!and_ln786_2071_fu_14243_p2.read()[0].is_01())? sc_lv<24>(): ((and_ln786_2071_fu_14243_p2.read()[0].to_bool())? ap_const_lv24_800000: add_ln415_757_fu_14159_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln388_73_fu_14455_p3() {
    select_ln388_73_fu_14455_p3 = (!and_ln786_2073_fu_14423_p2.read()[0].is_01())? sc_lv<24>(): ((and_ln786_2073_fu_14423_p2.read()[0].to_bool())? ap_const_lv24_800000: add_ln415_758_fu_14339_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln388_74_fu_14635_p3() {
    select_ln388_74_fu_14635_p3 = (!and_ln786_2075_fu_14603_p2.read()[0].is_01())? sc_lv<24>(): ((and_ln786_2075_fu_14603_p2.read()[0].to_bool())? ap_const_lv24_800000: add_ln415_759_fu_14519_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln388_75_fu_14815_p3() {
    select_ln388_75_fu_14815_p3 = (!and_ln786_2077_fu_14783_p2.read()[0].is_01())? sc_lv<24>(): ((and_ln786_2077_fu_14783_p2.read()[0].to_bool())? ap_const_lv24_800000: add_ln415_760_fu_14699_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln388_76_fu_14995_p3() {
    select_ln388_76_fu_14995_p3 = (!and_ln786_2079_fu_14963_p2.read()[0].is_01())? sc_lv<24>(): ((and_ln786_2079_fu_14963_p2.read()[0].to_bool())? ap_const_lv24_800000: add_ln415_761_fu_14879_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln388_77_fu_15175_p3() {
    select_ln388_77_fu_15175_p3 = (!and_ln786_2081_fu_15143_p2.read()[0].is_01())? sc_lv<24>(): ((and_ln786_2081_fu_15143_p2.read()[0].to_bool())? ap_const_lv24_800000: add_ln415_762_fu_15059_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln388_78_fu_15355_p3() {
    select_ln388_78_fu_15355_p3 = (!and_ln786_2083_fu_15323_p2.read()[0].is_01())? sc_lv<24>(): ((and_ln786_2083_fu_15323_p2.read()[0].to_bool())? ap_const_lv24_800000: add_ln415_763_fu_15239_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln388_79_fu_23015_p3() {
    select_ln388_79_fu_23015_p3 = (!and_ln786_2085_fu_22983_p2.read()[0].is_01())? sc_lv<24>(): ((and_ln786_2085_fu_22983_p2.read()[0].to_bool())? ap_const_lv24_800000: add_ln415_764_fu_22899_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln388_7_fu_2953_p3() {
    select_ln388_7_fu_2953_p3 = (!and_ln786_1941_fu_2921_p2.read()[0].is_01())? sc_lv<24>(): ((and_ln786_1941_fu_2921_p2.read()[0].to_bool())? ap_const_lv24_800000: add_ln415_692_fu_2837_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln388_8_fu_3145_p3() {
    select_ln388_8_fu_3145_p3 = (!and_ln786_1943_fu_3113_p2.read()[0].is_01())? sc_lv<24>(): ((and_ln786_1943_fu_3113_p2.read()[0].to_bool())? ap_const_lv24_800000: add_ln415_693_fu_3029_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln388_9_fu_3337_p3() {
    select_ln388_9_fu_3337_p3 = (!and_ln786_1945_fu_3305_p2.read()[0].is_01())? sc_lv<24>(): ((and_ln786_1945_fu_3305_p2.read()[0].to_bool())? ap_const_lv24_800000: add_ln415_694_fu_3221_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln388_fu_1585_p3() {
    select_ln388_fu_1585_p3 = (!and_ln786_1927_fu_1553_p2.read()[0].is_01())? sc_lv<24>(): ((and_ln786_1927_fu_1553_p2.read()[0].to_bool())? ap_const_lv24_800000: add_ln415_fu_1469_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln391_fu_23142_p3() {
    select_ln391_fu_23142_p3 = (!icmp_ln360_reg_24069.read()[0].is_01())? sc_lv<32>(): ((icmp_ln360_reg_24069.read()[0].to_bool())? ap_const_lv32_3: add_ln391_fu_23137_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln416_671_fu_1709_p3() {
    select_ln416_671_fu_1709_p3 = (!and_ln416_671_fu_1689_p2.read()[0].is_01())? sc_lv<1>(): ((and_ln416_671_fu_1689_p2.read()[0].to_bool())? xor_ln779_1_fu_1703_p2.read(): tmp_5346_fu_1635_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln416_672_fu_1909_p3() {
    select_ln416_672_fu_1909_p3 = (!and_ln416_672_fu_1889_p2.read()[0].is_01())? sc_lv<1>(): ((and_ln416_672_fu_1889_p2.read()[0].to_bool())? xor_ln779_2_fu_1903_p2.read(): tmp_5353_fu_1835_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln416_673_fu_2109_p3() {
    select_ln416_673_fu_2109_p3 = (!and_ln416_673_fu_2089_p2.read()[0].is_01())? sc_lv<1>(): ((and_ln416_673_fu_2089_p2.read()[0].to_bool())? xor_ln779_3_fu_2103_p2.read(): tmp_5360_fu_2035_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln416_674_fu_2301_p3() {
    select_ln416_674_fu_2301_p3 = (!and_ln416_674_fu_2281_p2.read()[0].is_01())? sc_lv<1>(): ((and_ln416_674_fu_2281_p2.read()[0].to_bool())? xor_ln779_4_fu_2295_p2.read(): tmp_5367_fu_2227_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln416_675_fu_2493_p3() {
    select_ln416_675_fu_2493_p3 = (!and_ln416_675_fu_2473_p2.read()[0].is_01())? sc_lv<1>(): ((and_ln416_675_fu_2473_p2.read()[0].to_bool())? xor_ln779_5_fu_2487_p2.read(): tmp_5374_fu_2419_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln416_676_fu_2685_p3() {
    select_ln416_676_fu_2685_p3 = (!and_ln416_676_fu_2665_p2.read()[0].is_01())? sc_lv<1>(): ((and_ln416_676_fu_2665_p2.read()[0].to_bool())? xor_ln779_6_fu_2679_p2.read(): tmp_5381_fu_2611_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln416_677_fu_2877_p3() {
    select_ln416_677_fu_2877_p3 = (!and_ln416_677_fu_2857_p2.read()[0].is_01())? sc_lv<1>(): ((and_ln416_677_fu_2857_p2.read()[0].to_bool())? xor_ln779_7_fu_2871_p2.read(): tmp_5388_fu_2803_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln416_678_fu_3069_p3() {
    select_ln416_678_fu_3069_p3 = (!and_ln416_678_fu_3049_p2.read()[0].is_01())? sc_lv<1>(): ((and_ln416_678_fu_3049_p2.read()[0].to_bool())? xor_ln779_8_fu_3063_p2.read(): tmp_5395_fu_2995_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln416_679_fu_3261_p3() {
    select_ln416_679_fu_3261_p3 = (!and_ln416_679_fu_3241_p2.read()[0].is_01())? sc_lv<1>(): ((and_ln416_679_fu_3241_p2.read()[0].to_bool())? xor_ln779_9_fu_3255_p2.read(): tmp_5402_fu_3187_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln416_680_fu_3453_p3() {
    select_ln416_680_fu_3453_p3 = (!and_ln416_680_fu_3433_p2.read()[0].is_01())? sc_lv<1>(): ((and_ln416_680_fu_3433_p2.read()[0].to_bool())? xor_ln779_10_fu_3447_p2.read(): tmp_5409_fu_3379_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln416_681_fu_3645_p3() {
    select_ln416_681_fu_3645_p3 = (!and_ln416_681_fu_3625_p2.read()[0].is_01())? sc_lv<1>(): ((and_ln416_681_fu_3625_p2.read()[0].to_bool())? xor_ln779_11_fu_3639_p2.read(): tmp_5416_fu_3571_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln416_682_fu_3837_p3() {
    select_ln416_682_fu_3837_p3 = (!and_ln416_682_fu_3817_p2.read()[0].is_01())? sc_lv<1>(): ((and_ln416_682_fu_3817_p2.read()[0].to_bool())? xor_ln779_12_fu_3831_p2.read(): tmp_5423_fu_3763_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln416_683_fu_4029_p3() {
    select_ln416_683_fu_4029_p3 = (!and_ln416_683_fu_4009_p2.read()[0].is_01())? sc_lv<1>(): ((and_ln416_683_fu_4009_p2.read()[0].to_bool())? xor_ln779_13_fu_4023_p2.read(): tmp_5430_fu_3955_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln416_684_fu_4221_p3() {
    select_ln416_684_fu_4221_p3 = (!and_ln416_684_fu_4201_p2.read()[0].is_01())? sc_lv<1>(): ((and_ln416_684_fu_4201_p2.read()[0].to_bool())? xor_ln779_14_fu_4215_p2.read(): tmp_5437_fu_4147_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln416_685_fu_4413_p3() {
    select_ln416_685_fu_4413_p3 = (!and_ln416_685_fu_4393_p2.read()[0].is_01())? sc_lv<1>(): ((and_ln416_685_fu_4393_p2.read()[0].to_bool())? xor_ln779_15_fu_4407_p2.read(): tmp_5444_fu_4339_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln416_686_fu_4605_p3() {
    select_ln416_686_fu_4605_p3 = (!and_ln416_686_fu_4585_p2.read()[0].is_01())? sc_lv<1>(): ((and_ln416_686_fu_4585_p2.read()[0].to_bool())? xor_ln779_16_fu_4599_p2.read(): tmp_5451_fu_4531_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln416_687_fu_4797_p3() {
    select_ln416_687_fu_4797_p3 = (!and_ln416_687_fu_4777_p2.read()[0].is_01())? sc_lv<1>(): ((and_ln416_687_fu_4777_p2.read()[0].to_bool())? xor_ln779_17_fu_4791_p2.read(): tmp_5458_fu_4723_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln416_688_fu_4989_p3() {
    select_ln416_688_fu_4989_p3 = (!and_ln416_688_fu_4969_p2.read()[0].is_01())? sc_lv<1>(): ((and_ln416_688_fu_4969_p2.read()[0].to_bool())? xor_ln779_18_fu_4983_p2.read(): tmp_5465_fu_4915_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln416_689_fu_17146_p3() {
    select_ln416_689_fu_17146_p3 = (!and_ln416_689_fu_17126_p2.read()[0].is_01())? sc_lv<1>(): ((and_ln416_689_fu_17126_p2.read()[0].to_bool())? xor_ln779_19_fu_17140_p2.read(): tmp_5472_fu_17072_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln416_690_fu_5179_p3() {
    select_ln416_690_fu_5179_p3 = (!and_ln416_690_fu_5159_p2.read()[0].is_01())? sc_lv<1>(): ((and_ln416_690_fu_5159_p2.read()[0].to_bool())? xor_ln779_20_fu_5173_p2.read(): tmp_5479_fu_5105_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln416_691_fu_5359_p3() {
    select_ln416_691_fu_5359_p3 = (!and_ln416_691_fu_5339_p2.read()[0].is_01())? sc_lv<1>(): ((and_ln416_691_fu_5339_p2.read()[0].to_bool())? xor_ln779_21_fu_5353_p2.read(): tmp_5486_fu_5285_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln416_692_fu_5539_p3() {
    select_ln416_692_fu_5539_p3 = (!and_ln416_692_fu_5519_p2.read()[0].is_01())? sc_lv<1>(): ((and_ln416_692_fu_5519_p2.read()[0].to_bool())? xor_ln779_22_fu_5533_p2.read(): tmp_5493_fu_5465_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln416_693_fu_5719_p3() {
    select_ln416_693_fu_5719_p3 = (!and_ln416_693_fu_5699_p2.read()[0].is_01())? sc_lv<1>(): ((and_ln416_693_fu_5699_p2.read()[0].to_bool())? xor_ln779_23_fu_5713_p2.read(): tmp_5500_fu_5645_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln416_694_fu_5899_p3() {
    select_ln416_694_fu_5899_p3 = (!and_ln416_694_fu_5879_p2.read()[0].is_01())? sc_lv<1>(): ((and_ln416_694_fu_5879_p2.read()[0].to_bool())? xor_ln779_24_fu_5893_p2.read(): tmp_5507_fu_5825_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln416_695_fu_6079_p3() {
    select_ln416_695_fu_6079_p3 = (!and_ln416_695_fu_6059_p2.read()[0].is_01())? sc_lv<1>(): ((and_ln416_695_fu_6059_p2.read()[0].to_bool())? xor_ln779_25_fu_6073_p2.read(): tmp_5514_fu_6005_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln416_696_fu_6259_p3() {
    select_ln416_696_fu_6259_p3 = (!and_ln416_696_fu_6239_p2.read()[0].is_01())? sc_lv<1>(): ((and_ln416_696_fu_6239_p2.read()[0].to_bool())? xor_ln779_26_fu_6253_p2.read(): tmp_5521_fu_6185_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln416_697_fu_6439_p3() {
    select_ln416_697_fu_6439_p3 = (!and_ln416_697_fu_6419_p2.read()[0].is_01())? sc_lv<1>(): ((and_ln416_697_fu_6419_p2.read()[0].to_bool())? xor_ln779_27_fu_6433_p2.read(): tmp_5528_fu_6365_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln416_698_fu_6619_p3() {
    select_ln416_698_fu_6619_p3 = (!and_ln416_698_fu_6599_p2.read()[0].is_01())? sc_lv<1>(): ((and_ln416_698_fu_6599_p2.read()[0].to_bool())? xor_ln779_28_fu_6613_p2.read(): tmp_5535_fu_6545_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln416_699_fu_6799_p3() {
    select_ln416_699_fu_6799_p3 = (!and_ln416_699_fu_6779_p2.read()[0].is_01())? sc_lv<1>(): ((and_ln416_699_fu_6779_p2.read()[0].to_bool())? xor_ln779_29_fu_6793_p2.read(): tmp_5542_fu_6725_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln416_700_fu_6979_p3() {
    select_ln416_700_fu_6979_p3 = (!and_ln416_700_fu_6959_p2.read()[0].is_01())? sc_lv<1>(): ((and_ln416_700_fu_6959_p2.read()[0].to_bool())? xor_ln779_30_fu_6973_p2.read(): tmp_5549_fu_6905_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln416_701_fu_7159_p3() {
    select_ln416_701_fu_7159_p3 = (!and_ln416_701_fu_7139_p2.read()[0].is_01())? sc_lv<1>(): ((and_ln416_701_fu_7139_p2.read()[0].to_bool())? xor_ln779_31_fu_7153_p2.read(): tmp_5556_fu_7085_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln416_702_fu_7339_p3() {
    select_ln416_702_fu_7339_p3 = (!and_ln416_702_fu_7319_p2.read()[0].is_01())? sc_lv<1>(): ((and_ln416_702_fu_7319_p2.read()[0].to_bool())? xor_ln779_32_fu_7333_p2.read(): tmp_5563_fu_7265_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln416_703_fu_7519_p3() {
    select_ln416_703_fu_7519_p3 = (!and_ln416_703_fu_7499_p2.read()[0].is_01())? sc_lv<1>(): ((and_ln416_703_fu_7499_p2.read()[0].to_bool())? xor_ln779_33_fu_7513_p2.read(): tmp_5570_fu_7445_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln416_704_fu_7699_p3() {
    select_ln416_704_fu_7699_p3 = (!and_ln416_704_fu_7679_p2.read()[0].is_01())? sc_lv<1>(): ((and_ln416_704_fu_7679_p2.read()[0].to_bool())? xor_ln779_34_fu_7693_p2.read(): tmp_5577_fu_7625_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln416_705_fu_7879_p3() {
    select_ln416_705_fu_7879_p3 = (!and_ln416_705_fu_7859_p2.read()[0].is_01())? sc_lv<1>(): ((and_ln416_705_fu_7859_p2.read()[0].to_bool())? xor_ln779_35_fu_7873_p2.read(): tmp_5584_fu_7805_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln416_706_fu_8059_p3() {
    select_ln416_706_fu_8059_p3 = (!and_ln416_706_fu_8039_p2.read()[0].is_01())? sc_lv<1>(): ((and_ln416_706_fu_8039_p2.read()[0].to_bool())? xor_ln779_36_fu_8053_p2.read(): tmp_5591_fu_7985_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln416_707_fu_8239_p3() {
    select_ln416_707_fu_8239_p3 = (!and_ln416_707_fu_8219_p2.read()[0].is_01())? sc_lv<1>(): ((and_ln416_707_fu_8219_p2.read()[0].to_bool())? xor_ln779_37_fu_8233_p2.read(): tmp_5598_fu_8165_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln416_708_fu_8419_p3() {
    select_ln416_708_fu_8419_p3 = (!and_ln416_708_fu_8399_p2.read()[0].is_01())? sc_lv<1>(): ((and_ln416_708_fu_8399_p2.read()[0].to_bool())? xor_ln779_38_fu_8413_p2.read(): tmp_5605_fu_8345_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln416_709_fu_19077_p3() {
    select_ln416_709_fu_19077_p3 = (!and_ln416_709_fu_19057_p2.read()[0].is_01())? sc_lv<1>(): ((and_ln416_709_fu_19057_p2.read()[0].to_bool())? xor_ln779_39_fu_19071_p2.read(): tmp_5612_fu_19003_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln416_710_fu_8609_p3() {
    select_ln416_710_fu_8609_p3 = (!and_ln416_710_fu_8589_p2.read()[0].is_01())? sc_lv<1>(): ((and_ln416_710_fu_8589_p2.read()[0].to_bool())? xor_ln779_40_fu_8603_p2.read(): tmp_5619_fu_8535_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln416_711_fu_8789_p3() {
    select_ln416_711_fu_8789_p3 = (!and_ln416_711_fu_8769_p2.read()[0].is_01())? sc_lv<1>(): ((and_ln416_711_fu_8769_p2.read()[0].to_bool())? xor_ln779_41_fu_8783_p2.read(): tmp_5626_fu_8715_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln416_712_fu_8969_p3() {
    select_ln416_712_fu_8969_p3 = (!and_ln416_712_fu_8949_p2.read()[0].is_01())? sc_lv<1>(): ((and_ln416_712_fu_8949_p2.read()[0].to_bool())? xor_ln779_42_fu_8963_p2.read(): tmp_5633_fu_8895_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln416_713_fu_9149_p3() {
    select_ln416_713_fu_9149_p3 = (!and_ln416_713_fu_9129_p2.read()[0].is_01())? sc_lv<1>(): ((and_ln416_713_fu_9129_p2.read()[0].to_bool())? xor_ln779_43_fu_9143_p2.read(): tmp_5640_fu_9075_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln416_714_fu_9329_p3() {
    select_ln416_714_fu_9329_p3 = (!and_ln416_714_fu_9309_p2.read()[0].is_01())? sc_lv<1>(): ((and_ln416_714_fu_9309_p2.read()[0].to_bool())? xor_ln779_44_fu_9323_p2.read(): tmp_5647_fu_9255_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln416_715_fu_9509_p3() {
    select_ln416_715_fu_9509_p3 = (!and_ln416_715_fu_9489_p2.read()[0].is_01())? sc_lv<1>(): ((and_ln416_715_fu_9489_p2.read()[0].to_bool())? xor_ln779_45_fu_9503_p2.read(): tmp_5654_fu_9435_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln416_716_fu_9689_p3() {
    select_ln416_716_fu_9689_p3 = (!and_ln416_716_fu_9669_p2.read()[0].is_01())? sc_lv<1>(): ((and_ln416_716_fu_9669_p2.read()[0].to_bool())? xor_ln779_46_fu_9683_p2.read(): tmp_5661_fu_9615_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln416_717_fu_9869_p3() {
    select_ln416_717_fu_9869_p3 = (!and_ln416_717_fu_9849_p2.read()[0].is_01())? sc_lv<1>(): ((and_ln416_717_fu_9849_p2.read()[0].to_bool())? xor_ln779_47_fu_9863_p2.read(): tmp_5668_fu_9795_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln416_718_fu_10049_p3() {
    select_ln416_718_fu_10049_p3 = (!and_ln416_718_fu_10029_p2.read()[0].is_01())? sc_lv<1>(): ((and_ln416_718_fu_10029_p2.read()[0].to_bool())? xor_ln779_48_fu_10043_p2.read(): tmp_5675_fu_9975_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln416_719_fu_10229_p3() {
    select_ln416_719_fu_10229_p3 = (!and_ln416_719_fu_10209_p2.read()[0].is_01())? sc_lv<1>(): ((and_ln416_719_fu_10209_p2.read()[0].to_bool())? xor_ln779_49_fu_10223_p2.read(): tmp_5682_fu_10155_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln416_720_fu_10409_p3() {
    select_ln416_720_fu_10409_p3 = (!and_ln416_720_fu_10389_p2.read()[0].is_01())? sc_lv<1>(): ((and_ln416_720_fu_10389_p2.read()[0].to_bool())? xor_ln779_50_fu_10403_p2.read(): tmp_5689_fu_10335_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln416_721_fu_10589_p3() {
    select_ln416_721_fu_10589_p3 = (!and_ln416_721_fu_10569_p2.read()[0].is_01())? sc_lv<1>(): ((and_ln416_721_fu_10569_p2.read()[0].to_bool())? xor_ln779_51_fu_10583_p2.read(): tmp_5696_fu_10515_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln416_722_fu_10769_p3() {
    select_ln416_722_fu_10769_p3 = (!and_ln416_722_fu_10749_p2.read()[0].is_01())? sc_lv<1>(): ((and_ln416_722_fu_10749_p2.read()[0].to_bool())? xor_ln779_52_fu_10763_p2.read(): tmp_5703_fu_10695_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln416_723_fu_10949_p3() {
    select_ln416_723_fu_10949_p3 = (!and_ln416_723_fu_10929_p2.read()[0].is_01())? sc_lv<1>(): ((and_ln416_723_fu_10929_p2.read()[0].to_bool())? xor_ln779_53_fu_10943_p2.read(): tmp_5710_fu_10875_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln416_724_fu_11129_p3() {
    select_ln416_724_fu_11129_p3 = (!and_ln416_724_fu_11109_p2.read()[0].is_01())? sc_lv<1>(): ((and_ln416_724_fu_11109_p2.read()[0].to_bool())? xor_ln779_54_fu_11123_p2.read(): tmp_5717_fu_11055_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln416_725_fu_11309_p3() {
    select_ln416_725_fu_11309_p3 = (!and_ln416_725_fu_11289_p2.read()[0].is_01())? sc_lv<1>(): ((and_ln416_725_fu_11289_p2.read()[0].to_bool())? xor_ln779_55_fu_11303_p2.read(): tmp_5724_fu_11235_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln416_726_fu_11489_p3() {
    select_ln416_726_fu_11489_p3 = (!and_ln416_726_fu_11469_p2.read()[0].is_01())? sc_lv<1>(): ((and_ln416_726_fu_11469_p2.read()[0].to_bool())? xor_ln779_56_fu_11483_p2.read(): tmp_5731_fu_11415_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln416_727_fu_11669_p3() {
    select_ln416_727_fu_11669_p3 = (!and_ln416_727_fu_11649_p2.read()[0].is_01())? sc_lv<1>(): ((and_ln416_727_fu_11649_p2.read()[0].to_bool())? xor_ln779_57_fu_11663_p2.read(): tmp_5738_fu_11595_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln416_728_fu_11849_p3() {
    select_ln416_728_fu_11849_p3 = (!and_ln416_728_fu_11829_p2.read()[0].is_01())? sc_lv<1>(): ((and_ln416_728_fu_11829_p2.read()[0].to_bool())? xor_ln779_58_fu_11843_p2.read(): tmp_5745_fu_11775_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln416_729_fu_21008_p3() {
    select_ln416_729_fu_21008_p3 = (!and_ln416_729_fu_20988_p2.read()[0].is_01())? sc_lv<1>(): ((and_ln416_729_fu_20988_p2.read()[0].to_bool())? xor_ln779_59_fu_21002_p2.read(): tmp_5752_fu_20934_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln416_730_fu_12039_p3() {
    select_ln416_730_fu_12039_p3 = (!and_ln416_730_fu_12019_p2.read()[0].is_01())? sc_lv<1>(): ((and_ln416_730_fu_12019_p2.read()[0].to_bool())? xor_ln779_60_fu_12033_p2.read(): tmp_5759_fu_11965_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln416_731_fu_12219_p3() {
    select_ln416_731_fu_12219_p3 = (!and_ln416_731_fu_12199_p2.read()[0].is_01())? sc_lv<1>(): ((and_ln416_731_fu_12199_p2.read()[0].to_bool())? xor_ln779_61_fu_12213_p2.read(): tmp_5766_fu_12145_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln416_732_fu_12399_p3() {
    select_ln416_732_fu_12399_p3 = (!and_ln416_732_fu_12379_p2.read()[0].is_01())? sc_lv<1>(): ((and_ln416_732_fu_12379_p2.read()[0].to_bool())? xor_ln779_62_fu_12393_p2.read(): tmp_5773_fu_12325_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln416_733_fu_12579_p3() {
    select_ln416_733_fu_12579_p3 = (!and_ln416_733_fu_12559_p2.read()[0].is_01())? sc_lv<1>(): ((and_ln416_733_fu_12559_p2.read()[0].to_bool())? xor_ln779_63_fu_12573_p2.read(): tmp_5780_fu_12505_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln416_734_fu_12759_p3() {
    select_ln416_734_fu_12759_p3 = (!and_ln416_734_fu_12739_p2.read()[0].is_01())? sc_lv<1>(): ((and_ln416_734_fu_12739_p2.read()[0].to_bool())? xor_ln779_64_fu_12753_p2.read(): tmp_5787_fu_12685_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln416_735_fu_12939_p3() {
    select_ln416_735_fu_12939_p3 = (!and_ln416_735_fu_12919_p2.read()[0].is_01())? sc_lv<1>(): ((and_ln416_735_fu_12919_p2.read()[0].to_bool())? xor_ln779_65_fu_12933_p2.read(): tmp_5794_fu_12865_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln416_736_fu_13119_p3() {
    select_ln416_736_fu_13119_p3 = (!and_ln416_736_fu_13099_p2.read()[0].is_01())? sc_lv<1>(): ((and_ln416_736_fu_13099_p2.read()[0].to_bool())? xor_ln779_66_fu_13113_p2.read(): tmp_5801_fu_13045_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln416_737_fu_13299_p3() {
    select_ln416_737_fu_13299_p3 = (!and_ln416_737_fu_13279_p2.read()[0].is_01())? sc_lv<1>(): ((and_ln416_737_fu_13279_p2.read()[0].to_bool())? xor_ln779_67_fu_13293_p2.read(): tmp_5808_fu_13225_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln416_738_fu_13479_p3() {
    select_ln416_738_fu_13479_p3 = (!and_ln416_738_fu_13459_p2.read()[0].is_01())? sc_lv<1>(): ((and_ln416_738_fu_13459_p2.read()[0].to_bool())? xor_ln779_68_fu_13473_p2.read(): tmp_5815_fu_13405_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln416_739_fu_13659_p3() {
    select_ln416_739_fu_13659_p3 = (!and_ln416_739_fu_13639_p2.read()[0].is_01())? sc_lv<1>(): ((and_ln416_739_fu_13639_p2.read()[0].to_bool())? xor_ln779_69_fu_13653_p2.read(): tmp_5822_fu_13585_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln416_740_fu_13839_p3() {
    select_ln416_740_fu_13839_p3 = (!and_ln416_740_fu_13819_p2.read()[0].is_01())? sc_lv<1>(): ((and_ln416_740_fu_13819_p2.read()[0].to_bool())? xor_ln779_70_fu_13833_p2.read(): tmp_5829_fu_13765_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln416_741_fu_14019_p3() {
    select_ln416_741_fu_14019_p3 = (!and_ln416_741_fu_13999_p2.read()[0].is_01())? sc_lv<1>(): ((and_ln416_741_fu_13999_p2.read()[0].to_bool())? xor_ln779_71_fu_14013_p2.read(): tmp_5836_fu_13945_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln416_742_fu_14199_p3() {
    select_ln416_742_fu_14199_p3 = (!and_ln416_742_fu_14179_p2.read()[0].is_01())? sc_lv<1>(): ((and_ln416_742_fu_14179_p2.read()[0].to_bool())? xor_ln779_72_fu_14193_p2.read(): tmp_5843_fu_14125_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln416_743_fu_14379_p3() {
    select_ln416_743_fu_14379_p3 = (!and_ln416_743_fu_14359_p2.read()[0].is_01())? sc_lv<1>(): ((and_ln416_743_fu_14359_p2.read()[0].to_bool())? xor_ln779_73_fu_14373_p2.read(): tmp_5850_fu_14305_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln416_744_fu_14559_p3() {
    select_ln416_744_fu_14559_p3 = (!and_ln416_744_fu_14539_p2.read()[0].is_01())? sc_lv<1>(): ((and_ln416_744_fu_14539_p2.read()[0].to_bool())? xor_ln779_74_fu_14553_p2.read(): tmp_5857_fu_14485_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln416_745_fu_14739_p3() {
    select_ln416_745_fu_14739_p3 = (!and_ln416_745_fu_14719_p2.read()[0].is_01())? sc_lv<1>(): ((and_ln416_745_fu_14719_p2.read()[0].to_bool())? xor_ln779_75_fu_14733_p2.read(): tmp_5864_fu_14665_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln416_746_fu_14919_p3() {
    select_ln416_746_fu_14919_p3 = (!and_ln416_746_fu_14899_p2.read()[0].is_01())? sc_lv<1>(): ((and_ln416_746_fu_14899_p2.read()[0].to_bool())? xor_ln779_76_fu_14913_p2.read(): tmp_5871_fu_14845_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln416_747_fu_15099_p3() {
    select_ln416_747_fu_15099_p3 = (!and_ln416_747_fu_15079_p2.read()[0].is_01())? sc_lv<1>(): ((and_ln416_747_fu_15079_p2.read()[0].to_bool())? xor_ln779_77_fu_15093_p2.read(): tmp_5878_fu_15025_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln416_748_fu_15279_p3() {
    select_ln416_748_fu_15279_p3 = (!and_ln416_748_fu_15259_p2.read()[0].is_01())? sc_lv<1>(): ((and_ln416_748_fu_15259_p2.read()[0].to_bool())? xor_ln779_78_fu_15273_p2.read(): tmp_5885_fu_15205_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln416_749_fu_22939_p3() {
    select_ln416_749_fu_22939_p3 = (!and_ln416_749_fu_22919_p2.read()[0].is_01())? sc_lv<1>(): ((and_ln416_749_fu_22919_p2.read()[0].to_bool())? xor_ln779_79_fu_22933_p2.read(): tmp_5892_fu_22865_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln416_fu_1509_p3() {
    select_ln416_fu_1509_p3 = (!and_ln416_fu_1489_p2.read()[0].is_01())? sc_lv<1>(): ((and_ln416_fu_1489_p2.read()[0].to_bool())? xor_ln779_fu_1503_p2.read(): tmp_5339_fu_1435_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln56_20_fu_1609_p3() {
    select_ln56_20_fu_1609_p3 = (!in_index13_reg_856.read()[0].is_01())? sc_lv<24>(): ((in_index13_reg_856.read()[0].to_bool())? kernel_data_V_1_3.read(): kernel_data_V_1_2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln56_21_fu_1809_p3() {
    select_ln56_21_fu_1809_p3 = (!in_index13_reg_856.read()[0].is_01())? sc_lv<24>(): ((in_index13_reg_856.read()[0].to_bool())? kernel_data_V_1_5.read(): kernel_data_V_1_4.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln56_22_fu_2009_p3() {
    select_ln56_22_fu_2009_p3 = (!in_index13_reg_856.read()[0].is_01())? sc_lv<24>(): ((in_index13_reg_856.read()[0].to_bool())? kernel_data_V_1_7.read(): kernel_data_V_1_6.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln56_23_fu_2201_p3() {
    select_ln56_23_fu_2201_p3 = (!in_index13_reg_856.read()[0].is_01())? sc_lv<24>(): ((in_index13_reg_856.read()[0].to_bool())? kernel_data_V_1_9.read(): kernel_data_V_1_8.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln56_24_fu_2393_p3() {
    select_ln56_24_fu_2393_p3 = (!in_index13_reg_856.read()[0].is_01())? sc_lv<24>(): ((in_index13_reg_856.read()[0].to_bool())? kernel_data_V_1_11.read(): kernel_data_V_1_10.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln56_25_fu_2585_p3() {
    select_ln56_25_fu_2585_p3 = (!in_index13_reg_856.read()[0].is_01())? sc_lv<24>(): ((in_index13_reg_856.read()[0].to_bool())? kernel_data_V_1_13.read(): kernel_data_V_1_12.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln56_26_fu_2777_p3() {
    select_ln56_26_fu_2777_p3 = (!in_index13_reg_856.read()[0].is_01())? sc_lv<24>(): ((in_index13_reg_856.read()[0].to_bool())? kernel_data_V_1_15.read(): kernel_data_V_1_14.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln56_27_fu_2969_p3() {
    select_ln56_27_fu_2969_p3 = (!in_index13_reg_856.read()[0].is_01())? sc_lv<24>(): ((in_index13_reg_856.read()[0].to_bool())? kernel_data_V_1_17.read(): kernel_data_V_1_16.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln56_28_fu_3161_p3() {
    select_ln56_28_fu_3161_p3 = (!in_index13_reg_856.read()[0].is_01())? sc_lv<24>(): ((in_index13_reg_856.read()[0].to_bool())? kernel_data_V_1_19.read(): kernel_data_V_1_18.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln56_29_fu_3353_p3() {
    select_ln56_29_fu_3353_p3 = (!in_index13_reg_856.read()[0].is_01())? sc_lv<24>(): ((in_index13_reg_856.read()[0].to_bool())? kernel_data_V_1_21.read(): kernel_data_V_1_20.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln56_30_fu_3545_p3() {
    select_ln56_30_fu_3545_p3 = (!in_index13_reg_856.read()[0].is_01())? sc_lv<24>(): ((in_index13_reg_856.read()[0].to_bool())? kernel_data_V_1_23.read(): kernel_data_V_1_22.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln56_31_fu_3737_p3() {
    select_ln56_31_fu_3737_p3 = (!in_index13_reg_856.read()[0].is_01())? sc_lv<24>(): ((in_index13_reg_856.read()[0].to_bool())? kernel_data_V_1_25.read(): kernel_data_V_1_24.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln56_32_fu_3929_p3() {
    select_ln56_32_fu_3929_p3 = (!in_index13_reg_856.read()[0].is_01())? sc_lv<24>(): ((in_index13_reg_856.read()[0].to_bool())? kernel_data_V_1_27.read(): kernel_data_V_1_26.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln56_33_fu_4121_p3() {
    select_ln56_33_fu_4121_p3 = (!in_index13_reg_856.read()[0].is_01())? sc_lv<24>(): ((in_index13_reg_856.read()[0].to_bool())? kernel_data_V_1_29.read(): kernel_data_V_1_28.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln56_34_fu_4313_p3() {
    select_ln56_34_fu_4313_p3 = (!in_index13_reg_856.read()[0].is_01())? sc_lv<24>(): ((in_index13_reg_856.read()[0].to_bool())? kernel_data_V_1_31.read(): kernel_data_V_1_30.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln56_35_fu_4505_p3() {
    select_ln56_35_fu_4505_p3 = (!in_index13_reg_856.read()[0].is_01())? sc_lv<24>(): ((in_index13_reg_856.read()[0].to_bool())? kernel_data_V_1_33.read(): kernel_data_V_1_32.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln56_36_fu_4697_p3() {
    select_ln56_36_fu_4697_p3 = (!in_index13_reg_856.read()[0].is_01())? sc_lv<24>(): ((in_index13_reg_856.read()[0].to_bool())? kernel_data_V_1_35.read(): kernel_data_V_1_34.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln56_37_fu_4889_p3() {
    select_ln56_37_fu_4889_p3 = (!in_index13_reg_856.read()[0].is_01())? sc_lv<24>(): ((in_index13_reg_856.read()[0].to_bool())? kernel_data_V_1_37.read(): kernel_data_V_1_36.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln56_38_fu_17053_p3() {
    select_ln56_38_fu_17053_p3 = (!in_index13_reg_856_pp1_iter1_reg.read()[0].is_01())? sc_lv<24>(): ((in_index13_reg_856_pp1_iter1_reg.read()[0].to_bool())? kernel_data_V_1_39.read(): kernel_data_V_1_38.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_select_ln56_fu_1415_p3() {
    select_ln56_fu_1415_p3 = (!in_index13_reg_856.read()[0].is_01())? sc_lv<24>(): ((in_index13_reg_856.read()[0].to_bool())? kernel_data_V_1_1.read(): kernel_data_V_1_0.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_sext_ln1116_53_fu_1627_p1() {
    sext_ln1116_53_fu_1627_p1 = esl_sext<32,24>(select_ln56_20_fu_1609_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_sext_ln1116_54_fu_1827_p1() {
    sext_ln1116_54_fu_1827_p1 = esl_sext<32,24>(select_ln56_21_fu_1809_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_sext_ln1116_55_fu_2027_p1() {
    sext_ln1116_55_fu_2027_p1 = esl_sext<32,24>(select_ln56_22_fu_2009_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_sext_ln1116_56_fu_2219_p1() {
    sext_ln1116_56_fu_2219_p1 = esl_sext<32,24>(select_ln56_23_fu_2201_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_sext_ln1116_57_fu_2411_p1() {
    sext_ln1116_57_fu_2411_p1 = esl_sext<32,24>(select_ln56_24_fu_2393_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_sext_ln1116_58_fu_2603_p1() {
    sext_ln1116_58_fu_2603_p1 = esl_sext<32,24>(select_ln56_25_fu_2585_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_sext_ln1116_59_fu_2795_p1() {
    sext_ln1116_59_fu_2795_p1 = esl_sext<32,24>(select_ln56_26_fu_2777_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_sext_ln1116_60_fu_2987_p1() {
    sext_ln1116_60_fu_2987_p1 = esl_sext<32,24>(select_ln56_27_fu_2969_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_sext_ln1116_61_fu_3179_p1() {
    sext_ln1116_61_fu_3179_p1 = esl_sext<32,24>(select_ln56_28_fu_3161_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_sext_ln1116_62_fu_3371_p1() {
    sext_ln1116_62_fu_3371_p1 = esl_sext<32,24>(select_ln56_29_fu_3353_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_sext_ln1116_63_fu_3563_p1() {
    sext_ln1116_63_fu_3563_p1 = esl_sext<32,24>(select_ln56_30_fu_3545_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_sext_ln1116_64_fu_3755_p1() {
    sext_ln1116_64_fu_3755_p1 = esl_sext<32,24>(select_ln56_31_fu_3737_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_sext_ln1116_65_fu_3947_p1() {
    sext_ln1116_65_fu_3947_p1 = esl_sext<32,24>(select_ln56_32_fu_3929_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_sext_ln1116_66_fu_4139_p1() {
    sext_ln1116_66_fu_4139_p1 = esl_sext<32,24>(select_ln56_33_fu_4121_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_sext_ln1116_67_fu_4331_p1() {
    sext_ln1116_67_fu_4331_p1 = esl_sext<32,24>(select_ln56_34_fu_4313_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_sext_ln1116_68_fu_4523_p1() {
    sext_ln1116_68_fu_4523_p1 = esl_sext<32,24>(select_ln56_35_fu_4505_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_sext_ln1116_69_fu_4715_p1() {
    sext_ln1116_69_fu_4715_p1 = esl_sext<32,24>(select_ln56_36_fu_4697_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_sext_ln1116_70_fu_4907_p1() {
    sext_ln1116_70_fu_4907_p1 = esl_sext<32,24>(select_ln56_37_fu_4889_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_sext_ln1116_71_fu_17061_p1() {
    sext_ln1116_71_fu_17061_p1 = esl_sext<32,24>(select_ln56_38_fu_17053_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_sext_ln1116_fu_1427_p1() {
    sext_ln1116_fu_1427_p1 = esl_sext<32,24>(select_ln56_fu_1415_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_sext_ln703_1382_fu_15385_p1() {
    sext_ln703_1382_fu_15385_p1 = esl_sext<25,24>(select_ln340_2416_reg_24094.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_sext_ln703_1383_fu_15469_p1() {
    sext_ln703_1383_fu_15469_p1 = esl_sext<25,24>(select_ln340_2417_fu_15461_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_sext_ln703_1384_fu_15473_p1() {
    sext_ln703_1384_fu_15473_p1 = esl_sext<25,24>(select_ln340_2418_reg_24100.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_sext_ln703_1385_fu_15557_p1() {
    sext_ln703_1385_fu_15557_p1 = esl_sext<25,24>(select_ln340_2419_fu_15549_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_sext_ln703_1386_fu_15561_p1() {
    sext_ln703_1386_fu_15561_p1 = esl_sext<25,24>(select_ln340_2420_reg_24106.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_sext_ln703_1387_fu_15645_p1() {
    sext_ln703_1387_fu_15645_p1 = esl_sext<25,24>(select_ln340_2421_fu_15637_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_sext_ln703_1388_fu_15649_p1() {
    sext_ln703_1388_fu_15649_p1 = esl_sext<25,24>(select_ln340_2422_reg_24112.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_sext_ln703_1389_fu_15733_p1() {
    sext_ln703_1389_fu_15733_p1 = esl_sext<25,24>(select_ln340_2423_fu_15725_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_sext_ln703_1390_fu_15737_p1() {
    sext_ln703_1390_fu_15737_p1 = esl_sext<25,24>(select_ln340_2424_reg_24118.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_sext_ln703_1391_fu_15821_p1() {
    sext_ln703_1391_fu_15821_p1 = esl_sext<25,24>(select_ln340_2425_fu_15813_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_sext_ln703_1392_fu_15825_p1() {
    sext_ln703_1392_fu_15825_p1 = esl_sext<25,24>(select_ln340_2426_reg_24124.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_sext_ln703_1393_fu_15909_p1() {
    sext_ln703_1393_fu_15909_p1 = esl_sext<25,24>(select_ln340_2427_fu_15901_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_sext_ln703_1394_fu_15913_p1() {
    sext_ln703_1394_fu_15913_p1 = esl_sext<25,24>(select_ln340_2428_reg_24130.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_sext_ln703_1395_fu_15997_p1() {
    sext_ln703_1395_fu_15997_p1 = esl_sext<25,24>(select_ln340_2429_fu_15989_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_sext_ln703_1396_fu_16001_p1() {
    sext_ln703_1396_fu_16001_p1 = esl_sext<25,24>(select_ln340_2430_reg_24136.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_sext_ln703_1397_fu_16085_p1() {
    sext_ln703_1397_fu_16085_p1 = esl_sext<25,24>(select_ln340_2431_fu_16077_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_sext_ln703_1398_fu_16089_p1() {
    sext_ln703_1398_fu_16089_p1 = esl_sext<25,24>(select_ln340_2432_reg_24142.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_sext_ln703_1399_fu_16173_p1() {
    sext_ln703_1399_fu_16173_p1 = esl_sext<25,24>(select_ln340_2433_fu_16165_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_sext_ln703_1400_fu_16177_p1() {
    sext_ln703_1400_fu_16177_p1 = esl_sext<25,24>(select_ln340_2434_reg_24148.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_sext_ln703_1401_fu_16261_p1() {
    sext_ln703_1401_fu_16261_p1 = esl_sext<25,24>(select_ln340_2435_fu_16253_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_sext_ln703_1402_fu_16265_p1() {
    sext_ln703_1402_fu_16265_p1 = esl_sext<25,24>(select_ln340_2436_reg_24154.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_sext_ln703_1403_fu_16349_p1() {
    sext_ln703_1403_fu_16349_p1 = esl_sext<25,24>(select_ln340_2437_fu_16341_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_sext_ln703_1404_fu_16353_p1() {
    sext_ln703_1404_fu_16353_p1 = esl_sext<25,24>(select_ln340_2438_reg_24160.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_sext_ln703_1405_fu_16437_p1() {
    sext_ln703_1405_fu_16437_p1 = esl_sext<25,24>(select_ln340_2439_fu_16429_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_sext_ln703_1406_fu_16441_p1() {
    sext_ln703_1406_fu_16441_p1 = esl_sext<25,24>(select_ln340_2440_reg_24166.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_sext_ln703_1407_fu_16525_p1() {
    sext_ln703_1407_fu_16525_p1 = esl_sext<25,24>(select_ln340_2441_fu_16517_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_sext_ln703_1408_fu_16529_p1() {
    sext_ln703_1408_fu_16529_p1 = esl_sext<25,24>(select_ln340_2442_reg_24172.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_sext_ln703_1409_fu_16613_p1() {
    sext_ln703_1409_fu_16613_p1 = esl_sext<25,24>(select_ln340_2443_fu_16605_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_sext_ln703_1410_fu_16617_p1() {
    sext_ln703_1410_fu_16617_p1 = esl_sext<25,24>(select_ln340_2444_reg_24178.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_sext_ln703_1411_fu_16701_p1() {
    sext_ln703_1411_fu_16701_p1 = esl_sext<25,24>(select_ln340_2445_fu_16693_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_sext_ln703_1412_fu_16705_p1() {
    sext_ln703_1412_fu_16705_p1 = esl_sext<25,24>(select_ln340_2446_reg_24184.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_sext_ln703_1413_fu_16789_p1() {
    sext_ln703_1413_fu_16789_p1 = esl_sext<25,24>(select_ln340_2447_fu_16781_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_sext_ln703_1414_fu_16793_p1() {
    sext_ln703_1414_fu_16793_p1 = esl_sext<25,24>(select_ln340_2448_reg_24190.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_sext_ln703_1415_fu_16877_p1() {
    sext_ln703_1415_fu_16877_p1 = esl_sext<25,24>(select_ln340_2449_fu_16869_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_sext_ln703_1416_fu_16881_p1() {
    sext_ln703_1416_fu_16881_p1 = esl_sext<25,24>(select_ln340_2450_reg_24196.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_sext_ln703_1417_fu_16965_p1() {
    sext_ln703_1417_fu_16965_p1 = esl_sext<25,24>(select_ln340_2451_fu_16957_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_sext_ln703_1418_fu_16969_p1() {
    sext_ln703_1418_fu_16969_p1 = esl_sext<25,24>(select_ln340_2452_reg_24202.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_sext_ln703_1419_fu_17238_p1() {
    sext_ln703_1419_fu_17238_p1 = esl_sext<25,24>(select_ln340_2453_fu_17045_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_sext_ln703_1420_fu_17242_p1() {
    sext_ln703_1420_fu_17242_p1 = esl_sext<25,24>(select_ln340_2454_fu_17230_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_sext_ln703_1421_fu_17328_p1() {
    sext_ln703_1421_fu_17328_p1 = esl_sext<25,24>(tmp_data_1_V_139_reg_879.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_sext_ln703_1422_fu_17332_p1() {
    sext_ln703_1422_fu_17332_p1 = esl_sext<25,24>(select_ln340_2456_reg_24213.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_sext_ln703_1423_fu_17416_p1() {
    sext_ln703_1423_fu_17416_p1 = esl_sext<25,24>(select_ln340_2457_fu_17408_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_sext_ln703_1424_fu_17420_p1() {
    sext_ln703_1424_fu_17420_p1 = esl_sext<25,24>(select_ln340_2458_reg_24219.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_sext_ln703_1425_fu_17504_p1() {
    sext_ln703_1425_fu_17504_p1 = esl_sext<25,24>(select_ln340_2459_fu_17496_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_sext_ln703_1426_fu_17508_p1() {
    sext_ln703_1426_fu_17508_p1 = esl_sext<25,24>(select_ln340_2460_reg_24225.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_sext_ln703_1427_fu_17592_p1() {
    sext_ln703_1427_fu_17592_p1 = esl_sext<25,24>(select_ln340_2461_fu_17584_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_sext_ln703_1428_fu_17596_p1() {
    sext_ln703_1428_fu_17596_p1 = esl_sext<25,24>(select_ln340_2462_reg_24231.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_sext_ln703_1429_fu_17680_p1() {
    sext_ln703_1429_fu_17680_p1 = esl_sext<25,24>(select_ln340_2463_fu_17672_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_sext_ln703_1430_fu_17684_p1() {
    sext_ln703_1430_fu_17684_p1 = esl_sext<25,24>(select_ln340_2464_reg_24237.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_sext_ln703_1431_fu_17768_p1() {
    sext_ln703_1431_fu_17768_p1 = esl_sext<25,24>(select_ln340_2465_fu_17760_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_sext_ln703_1432_fu_17772_p1() {
    sext_ln703_1432_fu_17772_p1 = esl_sext<25,24>(select_ln340_2466_reg_24243.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_sext_ln703_1433_fu_17856_p1() {
    sext_ln703_1433_fu_17856_p1 = esl_sext<25,24>(select_ln340_2467_fu_17848_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_sext_ln703_1434_fu_17860_p1() {
    sext_ln703_1434_fu_17860_p1 = esl_sext<25,24>(select_ln340_2468_reg_24249.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_sext_ln703_1435_fu_17944_p1() {
    sext_ln703_1435_fu_17944_p1 = esl_sext<25,24>(select_ln340_2469_fu_17936_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_sext_ln703_1436_fu_17948_p1() {
    sext_ln703_1436_fu_17948_p1 = esl_sext<25,24>(select_ln340_2470_reg_24255.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_sext_ln703_1437_fu_18032_p1() {
    sext_ln703_1437_fu_18032_p1 = esl_sext<25,24>(select_ln340_2471_fu_18024_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_sext_ln703_1438_fu_18036_p1() {
    sext_ln703_1438_fu_18036_p1 = esl_sext<25,24>(select_ln340_2472_reg_24261.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_sext_ln703_1439_fu_18120_p1() {
    sext_ln703_1439_fu_18120_p1 = esl_sext<25,24>(select_ln340_2473_fu_18112_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_sext_ln703_1440_fu_18124_p1() {
    sext_ln703_1440_fu_18124_p1 = esl_sext<25,24>(select_ln340_2474_reg_24267.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_sext_ln703_1441_fu_18208_p1() {
    sext_ln703_1441_fu_18208_p1 = esl_sext<25,24>(select_ln340_2475_fu_18200_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_sext_ln703_1442_fu_18212_p1() {
    sext_ln703_1442_fu_18212_p1 = esl_sext<25,24>(select_ln340_2476_reg_24273.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_sext_ln703_1443_fu_18296_p1() {
    sext_ln703_1443_fu_18296_p1 = esl_sext<25,24>(select_ln340_2477_fu_18288_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_sext_ln703_1444_fu_18300_p1() {
    sext_ln703_1444_fu_18300_p1 = esl_sext<25,24>(select_ln340_2478_reg_24279.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_sext_ln703_1445_fu_18384_p1() {
    sext_ln703_1445_fu_18384_p1 = esl_sext<25,24>(select_ln340_2479_fu_18376_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_sext_ln703_1446_fu_18388_p1() {
    sext_ln703_1446_fu_18388_p1 = esl_sext<25,24>(select_ln340_2480_reg_24285.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_sext_ln703_1447_fu_18472_p1() {
    sext_ln703_1447_fu_18472_p1 = esl_sext<25,24>(select_ln340_2481_fu_18464_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_sext_ln703_1448_fu_18476_p1() {
    sext_ln703_1448_fu_18476_p1 = esl_sext<25,24>(select_ln340_2482_reg_24291.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_sext_ln703_1449_fu_18560_p1() {
    sext_ln703_1449_fu_18560_p1 = esl_sext<25,24>(select_ln340_2483_fu_18552_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_sext_ln703_1450_fu_18564_p1() {
    sext_ln703_1450_fu_18564_p1 = esl_sext<25,24>(select_ln340_2484_reg_24297.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_sext_ln703_1451_fu_18648_p1() {
    sext_ln703_1451_fu_18648_p1 = esl_sext<25,24>(select_ln340_2485_fu_18640_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_sext_ln703_1452_fu_18652_p1() {
    sext_ln703_1452_fu_18652_p1 = esl_sext<25,24>(select_ln340_2486_reg_24303.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_sext_ln703_1453_fu_18736_p1() {
    sext_ln703_1453_fu_18736_p1 = esl_sext<25,24>(select_ln340_2487_fu_18728_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_sext_ln703_1454_fu_18740_p1() {
    sext_ln703_1454_fu_18740_p1 = esl_sext<25,24>(select_ln340_2488_reg_24309.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_sext_ln703_1455_fu_18824_p1() {
    sext_ln703_1455_fu_18824_p1 = esl_sext<25,24>(select_ln340_2489_fu_18816_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_sext_ln703_1456_fu_18828_p1() {
    sext_ln703_1456_fu_18828_p1 = esl_sext<25,24>(select_ln340_2490_reg_24315.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_sext_ln703_1457_fu_18912_p1() {
    sext_ln703_1457_fu_18912_p1 = esl_sext<25,24>(select_ln340_2491_fu_18904_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_sext_ln703_1458_fu_18916_p1() {
    sext_ln703_1458_fu_18916_p1 = esl_sext<25,24>(select_ln340_2492_reg_24321.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_sext_ln703_1459_fu_19169_p1() {
    sext_ln703_1459_fu_19169_p1 = esl_sext<25,24>(select_ln340_2493_fu_18992_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_sext_ln703_1460_fu_19173_p1() {
    sext_ln703_1460_fu_19173_p1 = esl_sext<25,24>(select_ln340_2494_fu_19161_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_sext_ln703_1461_fu_19259_p1() {
    sext_ln703_1461_fu_19259_p1 = esl_sext<25,24>(tmp_data_2_V_137_reg_890.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_sext_ln703_1462_fu_19263_p1() {
    sext_ln703_1462_fu_19263_p1 = esl_sext<25,24>(select_ln340_2496_reg_24332.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_sext_ln703_1463_fu_19347_p1() {
    sext_ln703_1463_fu_19347_p1 = esl_sext<25,24>(select_ln340_2497_fu_19339_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_sext_ln703_1464_fu_19351_p1() {
    sext_ln703_1464_fu_19351_p1 = esl_sext<25,24>(select_ln340_2498_reg_24338.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_sext_ln703_1465_fu_19435_p1() {
    sext_ln703_1465_fu_19435_p1 = esl_sext<25,24>(select_ln340_2499_fu_19427_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_sext_ln703_1466_fu_19439_p1() {
    sext_ln703_1466_fu_19439_p1 = esl_sext<25,24>(select_ln340_2500_reg_24344.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_sext_ln703_1467_fu_19523_p1() {
    sext_ln703_1467_fu_19523_p1 = esl_sext<25,24>(select_ln340_2501_fu_19515_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_sext_ln703_1468_fu_19527_p1() {
    sext_ln703_1468_fu_19527_p1 = esl_sext<25,24>(select_ln340_2502_reg_24350.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_sext_ln703_1469_fu_19611_p1() {
    sext_ln703_1469_fu_19611_p1 = esl_sext<25,24>(select_ln340_2503_fu_19603_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_sext_ln703_1470_fu_19615_p1() {
    sext_ln703_1470_fu_19615_p1 = esl_sext<25,24>(select_ln340_2504_reg_24356.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_sext_ln703_1471_fu_19699_p1() {
    sext_ln703_1471_fu_19699_p1 = esl_sext<25,24>(select_ln340_2505_fu_19691_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_sext_ln703_1472_fu_19703_p1() {
    sext_ln703_1472_fu_19703_p1 = esl_sext<25,24>(select_ln340_2506_reg_24362.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_sext_ln703_1473_fu_19787_p1() {
    sext_ln703_1473_fu_19787_p1 = esl_sext<25,24>(select_ln340_2507_fu_19779_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_sext_ln703_1474_fu_19791_p1() {
    sext_ln703_1474_fu_19791_p1 = esl_sext<25,24>(select_ln340_2508_reg_24368.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_sext_ln703_1475_fu_19875_p1() {
    sext_ln703_1475_fu_19875_p1 = esl_sext<25,24>(select_ln340_2509_fu_19867_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_sext_ln703_1476_fu_19879_p1() {
    sext_ln703_1476_fu_19879_p1 = esl_sext<25,24>(select_ln340_2510_reg_24374.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_sext_ln703_1477_fu_19963_p1() {
    sext_ln703_1477_fu_19963_p1 = esl_sext<25,24>(select_ln340_2511_fu_19955_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_sext_ln703_1478_fu_19967_p1() {
    sext_ln703_1478_fu_19967_p1 = esl_sext<25,24>(select_ln340_2512_reg_24380.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_sext_ln703_1479_fu_20051_p1() {
    sext_ln703_1479_fu_20051_p1 = esl_sext<25,24>(select_ln340_2513_fu_20043_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_sext_ln703_1480_fu_20055_p1() {
    sext_ln703_1480_fu_20055_p1 = esl_sext<25,24>(select_ln340_2514_reg_24386.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_sext_ln703_1481_fu_20139_p1() {
    sext_ln703_1481_fu_20139_p1 = esl_sext<25,24>(select_ln340_2515_fu_20131_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_sext_ln703_1482_fu_20143_p1() {
    sext_ln703_1482_fu_20143_p1 = esl_sext<25,24>(select_ln340_2516_reg_24392.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_sext_ln703_1483_fu_20227_p1() {
    sext_ln703_1483_fu_20227_p1 = esl_sext<25,24>(select_ln340_2517_fu_20219_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_sext_ln703_1484_fu_20231_p1() {
    sext_ln703_1484_fu_20231_p1 = esl_sext<25,24>(select_ln340_2518_reg_24398.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_sext_ln703_1485_fu_20315_p1() {
    sext_ln703_1485_fu_20315_p1 = esl_sext<25,24>(select_ln340_2519_fu_20307_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_sext_ln703_1486_fu_20319_p1() {
    sext_ln703_1486_fu_20319_p1 = esl_sext<25,24>(select_ln340_2520_reg_24404.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_sext_ln703_1487_fu_20403_p1() {
    sext_ln703_1487_fu_20403_p1 = esl_sext<25,24>(select_ln340_2521_fu_20395_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_sext_ln703_1488_fu_20407_p1() {
    sext_ln703_1488_fu_20407_p1 = esl_sext<25,24>(select_ln340_2522_reg_24410.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_sext_ln703_1489_fu_20491_p1() {
    sext_ln703_1489_fu_20491_p1 = esl_sext<25,24>(select_ln340_2523_fu_20483_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_sext_ln703_1490_fu_20495_p1() {
    sext_ln703_1490_fu_20495_p1 = esl_sext<25,24>(select_ln340_2524_reg_24416.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_sext_ln703_1491_fu_20579_p1() {
    sext_ln703_1491_fu_20579_p1 = esl_sext<25,24>(select_ln340_2525_fu_20571_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_sext_ln703_1492_fu_20583_p1() {
    sext_ln703_1492_fu_20583_p1 = esl_sext<25,24>(select_ln340_2526_reg_24422.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_sext_ln703_1493_fu_20667_p1() {
    sext_ln703_1493_fu_20667_p1 = esl_sext<25,24>(select_ln340_2527_fu_20659_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_sext_ln703_1494_fu_20671_p1() {
    sext_ln703_1494_fu_20671_p1 = esl_sext<25,24>(select_ln340_2528_reg_24428.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_sext_ln703_1495_fu_20755_p1() {
    sext_ln703_1495_fu_20755_p1 = esl_sext<25,24>(select_ln340_2529_fu_20747_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_sext_ln703_1496_fu_20759_p1() {
    sext_ln703_1496_fu_20759_p1 = esl_sext<25,24>(select_ln340_2530_reg_24434.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_sext_ln703_1497_fu_20843_p1() {
    sext_ln703_1497_fu_20843_p1 = esl_sext<25,24>(select_ln340_2531_fu_20835_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_sext_ln703_1498_fu_20847_p1() {
    sext_ln703_1498_fu_20847_p1 = esl_sext<25,24>(select_ln340_2532_reg_24440.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_sext_ln703_1499_fu_21100_p1() {
    sext_ln703_1499_fu_21100_p1 = esl_sext<25,24>(select_ln340_2533_fu_20923_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_sext_ln703_1500_fu_21104_p1() {
    sext_ln703_1500_fu_21104_p1 = esl_sext<25,24>(select_ln340_2534_fu_21092_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_sext_ln703_1501_fu_21190_p1() {
    sext_ln703_1501_fu_21190_p1 = esl_sext<25,24>(tmp_data_3_V_135_reg_901.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_sext_ln703_1502_fu_21194_p1() {
    sext_ln703_1502_fu_21194_p1 = esl_sext<25,24>(select_ln340_2536_reg_24451.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_sext_ln703_1503_fu_21278_p1() {
    sext_ln703_1503_fu_21278_p1 = esl_sext<25,24>(select_ln340_2537_fu_21270_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_sext_ln703_1504_fu_21282_p1() {
    sext_ln703_1504_fu_21282_p1 = esl_sext<25,24>(select_ln340_2538_reg_24457.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_sext_ln703_1505_fu_21366_p1() {
    sext_ln703_1505_fu_21366_p1 = esl_sext<25,24>(select_ln340_2539_fu_21358_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_sext_ln703_1506_fu_21370_p1() {
    sext_ln703_1506_fu_21370_p1 = esl_sext<25,24>(select_ln340_2540_reg_24463.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_sext_ln703_1507_fu_21454_p1() {
    sext_ln703_1507_fu_21454_p1 = esl_sext<25,24>(select_ln340_2541_fu_21446_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_sext_ln703_1508_fu_21458_p1() {
    sext_ln703_1508_fu_21458_p1 = esl_sext<25,24>(select_ln340_2542_reg_24469.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_sext_ln703_1509_fu_21542_p1() {
    sext_ln703_1509_fu_21542_p1 = esl_sext<25,24>(select_ln340_2543_fu_21534_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_sext_ln703_1510_fu_21546_p1() {
    sext_ln703_1510_fu_21546_p1 = esl_sext<25,24>(select_ln340_2544_reg_24475.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_sext_ln703_1511_fu_21630_p1() {
    sext_ln703_1511_fu_21630_p1 = esl_sext<25,24>(select_ln340_2545_fu_21622_p3.read());
}

}

