#include "conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s.h"
#include "AESL_pkg.h"

using namespace std;

namespace ap_rtl {

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_ap_clk_no_reset_() {
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_CS_fsm = ap_ST_fsm_state1;
    } else {
        ap_CS_fsm = ap_NS_fsm.read();
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_done_reg = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, ap_continue.read())) {
            ap_done_reg = ap_const_logic_0;
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state8.read()) && 
                    !(esl_seteq<1,1,1>(and_ln360_reg_46774.read(), ap_const_lv1_1) && esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op7036.read())) && 
                    esl_seteq<1,1,1>(ap_const_lv1_1, icmp_ln64_fu_45066_p2.read()))) {
            ap_done_reg = ap_const_logic_1;
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_enable_reg_pp1_iter0 = ap_const_logic_0;
    } else {
        if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
             esl_seteq<1,1,1>(ap_block_pp1_stage0_subdone.read(), ap_const_boolean_0) && 
             esl_seteq<1,1,1>(ap_const_lv1_1, ap_phi_mux_in_index21_phi_fu_1258_p4.read()))) {
            ap_enable_reg_pp1_iter0 = ap_const_logic_0;
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state4.read()) && 
                    esl_seteq<1,1,1>(ap_const_lv1_1, and_ln360_fu_1832_p2.read()))) {
            ap_enable_reg_pp1_iter0 = ap_const_logic_1;
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_enable_reg_pp1_iter1 = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_block_pp1_stage0_subdone.read(), ap_const_boolean_0)) {
            ap_enable_reg_pp1_iter1 = ap_enable_reg_pp1_iter0.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_enable_reg_pp1_iter2 = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_block_pp1_stage0_subdone.read(), ap_const_boolean_0)) {
            ap_enable_reg_pp1_iter2 = ap_enable_reg_pp1_iter1.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state4.read()) && 
                    esl_seteq<1,1,1>(ap_const_lv1_1, and_ln360_fu_1832_p2.read()))) {
            ap_enable_reg_pp1_iter2 = ap_const_logic_0;
        }
    }
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state8.read()) && 
         !(esl_seteq<1,1,1>(and_ln360_reg_46774.read(), ap_const_lv1_1) && esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op7036.read())) && 
         esl_seteq<1,1,1>(icmp_ln64_fu_45066_p2.read(), ap_const_lv1_0))) {
        i_iw_0_i22_reg_1127 = i_iw_reg_46742.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
                !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1)))) {
        i_iw_0_i22_reg_1127 = ap_const_lv7_0;
    }
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state3.read()) && 
         esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln166_fu_1554_p2.read()))) {
        i_iw_0_i_i_i_reg_1139 = i_iw_2_fu_1560_p2.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read()) && 
                esl_seteq<1,1,1>(io_acc_block_signal_op30.read(), ap_const_logic_1))) {
        i_iw_0_i_i_i_reg_1139 = ap_const_lv3_0;
    }
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
         esl_seteq<1,1,1>(in_index21_reg_1254.read(), ap_const_lv1_0))) {
        in_index21_reg_1254 = in_index_reg_46783.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state4.read()) && 
                esl_seteq<1,1,1>(ap_const_lv1_1, and_ln360_fu_1832_p2.read()))) {
        in_index21_reg_1254 = ap_const_lv1_0;
    }
    if (esl_seteq<1,1,1>(ap_condition_647.read(), ap_const_boolean_1)) {
        if (esl_seteq<1,1,1>(ap_const_lv1_1, icmp_ln384_fu_45025_p2.read())) {
            pX_1 = ap_const_lv32_0;
        } else if (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln384_fu_45025_p2.read())) {
            pX_1 = add_ln389_fu_45030_p2.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        start_once_reg = ap_const_logic_0;
    } else {
        if ((esl_seteq<1,1,1>(ap_const_logic_1, real_start.read()) && 
             esl_seteq<1,1,1>(ap_const_logic_0, internal_ap_ready.read()))) {
            start_once_reg = ap_const_logic_1;
        } else if (esl_seteq<1,1,1>(ap_const_logic_1, internal_ap_ready.read())) {
            start_once_reg = ap_const_logic_0;
        }
    }
    if ((esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
         esl_seteq<1,1,1>(in_index21_reg_1254_pp1_iter1_reg.read(), ap_const_lv1_0))) {
        tmp_data_0_V_1519_reg_1266 = tmp_data_0_V_fu_31482_p3.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state4.read()) && 
                esl_seteq<1,1,1>(ap_const_lv1_1, and_ln360_fu_1832_p2.read()))) {
        tmp_data_0_V_1519_reg_1266 = ap_const_lv24_10;
    }
    if ((esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
         esl_seteq<1,1,1>(in_index21_reg_1254_pp1_iter1_reg.read(), ap_const_lv1_0))) {
        tmp_data_1_V_1217_reg_1277 = tmp_data_1_V_fu_33413_p3.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state4.read()) && 
                esl_seteq<1,1,1>(ap_const_lv1_1, and_ln360_fu_1832_p2.read()))) {
        tmp_data_1_V_1217_reg_1277 = ap_const_lv24_FFFFEE;
    }
    if ((esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
         esl_seteq<1,1,1>(in_index21_reg_1254_pp1_iter1_reg.read(), ap_const_lv1_0))) {
        tmp_data_2_V_1215_reg_1288 = tmp_data_2_V_fu_35344_p3.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state4.read()) && 
                esl_seteq<1,1,1>(ap_const_lv1_1, and_ln360_fu_1832_p2.read()))) {
        tmp_data_2_V_1215_reg_1288 = ap_const_lv24_FFFFD2;
    }
    if ((esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
         esl_seteq<1,1,1>(in_index21_reg_1254_pp1_iter1_reg.read(), ap_const_lv1_0))) {
        tmp_data_3_V_1213_reg_1299 = tmp_data_3_V_fu_37275_p3.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state4.read()) && 
                esl_seteq<1,1,1>(ap_const_lv1_1, and_ln360_fu_1832_p2.read()))) {
        tmp_data_3_V_1213_reg_1299 = ap_const_lv24_FFFFFA;
    }
    if ((esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
         esl_seteq<1,1,1>(in_index21_reg_1254_pp1_iter1_reg.read(), ap_const_lv1_0))) {
        tmp_data_4_V_911_reg_1310 = tmp_data_4_V_fu_39206_p3.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state4.read()) && 
                esl_seteq<1,1,1>(ap_const_lv1_1, and_ln360_fu_1832_p2.read()))) {
        tmp_data_4_V_911_reg_1310 = ap_const_lv24_E;
    }
    if ((esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
         esl_seteq<1,1,1>(in_index21_reg_1254_pp1_iter1_reg.read(), ap_const_lv1_0))) {
        tmp_data_5_V_99_reg_1321 = tmp_data_5_V_fu_41137_p3.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state4.read()) && 
                esl_seteq<1,1,1>(ap_const_lv1_1, and_ln360_fu_1832_p2.read()))) {
        tmp_data_5_V_99_reg_1321 = ap_const_lv24_FFFFF6;
    }
    if ((esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
         esl_seteq<1,1,1>(in_index21_reg_1254_pp1_iter1_reg.read(), ap_const_lv1_0))) {
        tmp_data_6_V_97_reg_1332 = tmp_data_6_V_fu_43068_p3.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state4.read()) && 
                esl_seteq<1,1,1>(ap_const_lv1_1, and_ln360_fu_1832_p2.read()))) {
        tmp_data_6_V_97_reg_1332 = ap_const_lv24_42;
    }
    if ((esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
         esl_seteq<1,1,1>(in_index21_reg_1254_pp1_iter1_reg.read(), ap_const_lv1_0))) {
        tmp_data_7_V_95_reg_1343 = tmp_data_7_V_fu_45017_p3.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state4.read()) && 
                esl_seteq<1,1,1>(ap_const_lv1_1, and_ln360_fu_1832_p2.read()))) {
        tmp_data_7_V_95_reg_1343 = ap_const_lv24_10;
    }
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state4.read())) {
        and_ln360_reg_46774 = and_ln360_fu_1832_p2.read();
        icmp_ln360_reg_46763 = icmp_ln360_fu_1806_p2.read();
        kernel_data_V_2_32 = tmp_data_V_16_0_reg_46662.read();
        kernel_data_V_2_33 = tmp_data_V_16_1_reg_46667.read();
        kernel_data_V_2_34 = tmp_data_V_16_2_reg_46672.read();
        kernel_data_V_2_35 = tmp_data_V_16_3_reg_46677.read();
        kernel_data_V_2_36 = tmp_data_V_16_4_reg_46682.read();
        kernel_data_V_2_37 = tmp_data_V_16_5_reg_46687.read();
        kernel_data_V_2_38 = tmp_data_V_16_6_reg_46692.read();
        kernel_data_V_2_39 = tmp_data_V_16_7_reg_46697.read();
        pX_1_load_reg_46768 = pX_1.read();
        sX_1_load_reg_46758 = sX_1.read();
    }
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read()) && esl_seteq<1,1,1>(io_acc_block_signal_op30.read(), ap_const_logic_1))) {
        i_iw_reg_46742 = i_iw_fu_1548_p2.read();
        kernel_data_V_2_32_load_reg_46702 = kernel_data_V_2_32.read();
        kernel_data_V_2_33_load_reg_46707 = kernel_data_V_2_33.read();
        kernel_data_V_2_34_load_reg_46712 = kernel_data_V_2_34.read();
        kernel_data_V_2_35_load_reg_46717 = kernel_data_V_2_35.read();
        kernel_data_V_2_36_load_reg_46722 = kernel_data_V_2_36.read();
        kernel_data_V_2_37_load_reg_46727 = kernel_data_V_2_37.read();
        kernel_data_V_2_38_load_reg_46732 = kernel_data_V_2_38.read();
        kernel_data_V_2_39_load_reg_46737 = kernel_data_V_2_39.read();
        tmp_data_V_16_0_reg_46662 = data_V_data_0_V_dout.read();
        tmp_data_V_16_1_reg_46667 = data_V_data_1_V_dout.read();
        tmp_data_V_16_2_reg_46672 = data_V_data_2_V_dout.read();
        tmp_data_V_16_3_reg_46677 = data_V_data_3_V_dout.read();
        tmp_data_V_16_4_reg_46682 = data_V_data_4_V_dout.read();
        tmp_data_V_16_5_reg_46687 = data_V_data_5_V_dout.read();
        tmp_data_V_16_6_reg_46692 = data_V_data_6_V_dout.read();
        tmp_data_V_16_7_reg_46697 = data_V_data_7_V_dout.read();
    }
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0))) {
        in_index21_reg_1254_pp1_iter1_reg = in_index21_reg_1254.read();
        select_ln340_2096_reg_46788 = select_ln340_2096_fu_2035_p3.read();
        select_ln340_2098_reg_46794 = select_ln340_2098_fu_2235_p3.read();
        select_ln340_2100_reg_46800 = select_ln340_2100_fu_2435_p3.read();
        select_ln340_2102_reg_46806 = select_ln340_2102_fu_2635_p3.read();
        select_ln340_2104_reg_46812 = select_ln340_2104_fu_2827_p3.read();
        select_ln340_2106_reg_46818 = select_ln340_2106_fu_3019_p3.read();
        select_ln340_2108_reg_46824 = select_ln340_2108_fu_3211_p3.read();
        select_ln340_2110_reg_46830 = select_ln340_2110_fu_3403_p3.read();
        select_ln340_2112_reg_46836 = select_ln340_2112_fu_3595_p3.read();
        select_ln340_2114_reg_46842 = select_ln340_2114_fu_3787_p3.read();
        select_ln340_2116_reg_46848 = select_ln340_2116_fu_3979_p3.read();
        select_ln340_2118_reg_46854 = select_ln340_2118_fu_4171_p3.read();
        select_ln340_2120_reg_46860 = select_ln340_2120_fu_4363_p3.read();
        select_ln340_2122_reg_46866 = select_ln340_2122_fu_4555_p3.read();
        select_ln340_2124_reg_46872 = select_ln340_2124_fu_4747_p3.read();
        select_ln340_2126_reg_46878 = select_ln340_2126_fu_4939_p3.read();
        select_ln340_2128_reg_46884 = select_ln340_2128_fu_5131_p3.read();
        select_ln340_2130_reg_46890 = select_ln340_2130_fu_5323_p3.read();
        select_ln340_2132_reg_46896 = select_ln340_2132_fu_5515_p3.read();
        select_ln340_2136_reg_46907 = select_ln340_2136_fu_5705_p3.read();
        select_ln340_2138_reg_46913 = select_ln340_2138_fu_5885_p3.read();
        select_ln340_2140_reg_46919 = select_ln340_2140_fu_6065_p3.read();
        select_ln340_2142_reg_46925 = select_ln340_2142_fu_6245_p3.read();
        select_ln340_2144_reg_46931 = select_ln340_2144_fu_6425_p3.read();
        select_ln340_2146_reg_46937 = select_ln340_2146_fu_6605_p3.read();
        select_ln340_2148_reg_46943 = select_ln340_2148_fu_6785_p3.read();
        select_ln340_2150_reg_46949 = select_ln340_2150_fu_6965_p3.read();
        select_ln340_2152_reg_46955 = select_ln340_2152_fu_7145_p3.read();
        select_ln340_2154_reg_46961 = select_ln340_2154_fu_7325_p3.read();
        select_ln340_2156_reg_46967 = select_ln340_2156_fu_7505_p3.read();
        select_ln340_2158_reg_46973 = select_ln340_2158_fu_7685_p3.read();
        select_ln340_2160_reg_46979 = select_ln340_2160_fu_7865_p3.read();
        select_ln340_2162_reg_46985 = select_ln340_2162_fu_8045_p3.read();
        select_ln340_2164_reg_46991 = select_ln340_2164_fu_8225_p3.read();
        select_ln340_2166_reg_46997 = select_ln340_2166_fu_8405_p3.read();
        select_ln340_2168_reg_47003 = select_ln340_2168_fu_8585_p3.read();
        select_ln340_2170_reg_47009 = select_ln340_2170_fu_8765_p3.read();
        select_ln340_2172_reg_47015 = select_ln340_2172_fu_8945_p3.read();
        select_ln340_2176_reg_47026 = select_ln340_2176_fu_9135_p3.read();
        select_ln340_2178_reg_47032 = select_ln340_2178_fu_9315_p3.read();
        select_ln340_2180_reg_47038 = select_ln340_2180_fu_9495_p3.read();
        select_ln340_2182_reg_47044 = select_ln340_2182_fu_9675_p3.read();
        select_ln340_2184_reg_47050 = select_ln340_2184_fu_9855_p3.read();
        select_ln340_2186_reg_47056 = select_ln340_2186_fu_10035_p3.read();
        select_ln340_2188_reg_47062 = select_ln340_2188_fu_10215_p3.read();
        select_ln340_2190_reg_47068 = select_ln340_2190_fu_10395_p3.read();
        select_ln340_2192_reg_47074 = select_ln340_2192_fu_10575_p3.read();
        select_ln340_2194_reg_47080 = select_ln340_2194_fu_10755_p3.read();
        select_ln340_2196_reg_47086 = select_ln340_2196_fu_10935_p3.read();
        select_ln340_2198_reg_47092 = select_ln340_2198_fu_11115_p3.read();
        select_ln340_2200_reg_47098 = select_ln340_2200_fu_11295_p3.read();
        select_ln340_2202_reg_47104 = select_ln340_2202_fu_11475_p3.read();
        select_ln340_2204_reg_47110 = select_ln340_2204_fu_11655_p3.read();
        select_ln340_2206_reg_47116 = select_ln340_2206_fu_11835_p3.read();
        select_ln340_2208_reg_47122 = select_ln340_2208_fu_12015_p3.read();
        select_ln340_2210_reg_47128 = select_ln340_2210_fu_12195_p3.read();
        select_ln340_2212_reg_47134 = select_ln340_2212_fu_12375_p3.read();
        select_ln340_2216_reg_47145 = select_ln340_2216_fu_12565_p3.read();
        select_ln340_2218_reg_47151 = select_ln340_2218_fu_12745_p3.read();
        select_ln340_2220_reg_47157 = select_ln340_2220_fu_12925_p3.read();
        select_ln340_2222_reg_47163 = select_ln340_2222_fu_13105_p3.read();
        select_ln340_2224_reg_47169 = select_ln340_2224_fu_13285_p3.read();
        select_ln340_2226_reg_47175 = select_ln340_2226_fu_13465_p3.read();
        select_ln340_2228_reg_47181 = select_ln340_2228_fu_13645_p3.read();
        select_ln340_2230_reg_47187 = select_ln340_2230_fu_13825_p3.read();
        select_ln340_2232_reg_47193 = select_ln340_2232_fu_14005_p3.read();
        select_ln340_2234_reg_47199 = select_ln340_2234_fu_14185_p3.read();
        select_ln340_2236_reg_47205 = select_ln340_2236_fu_14365_p3.read();
        select_ln340_2238_reg_47211 = select_ln340_2238_fu_14545_p3.read();
        select_ln340_2240_reg_47217 = select_ln340_2240_fu_14725_p3.read();
        select_ln340_2242_reg_47223 = select_ln340_2242_fu_14905_p3.read();
        select_ln340_2244_reg_47229 = select_ln340_2244_fu_15085_p3.read();
        select_ln340_2246_reg_47235 = select_ln340_2246_fu_15265_p3.read();
        select_ln340_2248_reg_47241 = select_ln340_2248_fu_15445_p3.read();
        select_ln340_2250_reg_47247 = select_ln340_2250_fu_15625_p3.read();
        select_ln340_2252_reg_47253 = select_ln340_2252_fu_15805_p3.read();
        select_ln340_2256_reg_47264 = select_ln340_2256_fu_15995_p3.read();
        select_ln340_2258_reg_47270 = select_ln340_2258_fu_16175_p3.read();
        select_ln340_2260_reg_47276 = select_ln340_2260_fu_16355_p3.read();
        select_ln340_2262_reg_47282 = select_ln340_2262_fu_16535_p3.read();
        select_ln340_2264_reg_47288 = select_ln340_2264_fu_16715_p3.read();
        select_ln340_2266_reg_47294 = select_ln340_2266_fu_16895_p3.read();
        select_ln340_2268_reg_47300 = select_ln340_2268_fu_17075_p3.read();
        select_ln340_2270_reg_47306 = select_ln340_2270_fu_17255_p3.read();
        select_ln340_2272_reg_47312 = select_ln340_2272_fu_17435_p3.read();
        select_ln340_2274_reg_47318 = select_ln340_2274_fu_17615_p3.read();
        select_ln340_2276_reg_47324 = select_ln340_2276_fu_17795_p3.read();
        select_ln340_2278_reg_47330 = select_ln340_2278_fu_17975_p3.read();
        select_ln340_2280_reg_47336 = select_ln340_2280_fu_18155_p3.read();
        select_ln340_2282_reg_47342 = select_ln340_2282_fu_18335_p3.read();
        select_ln340_2284_reg_47348 = select_ln340_2284_fu_18515_p3.read();
        select_ln340_2286_reg_47354 = select_ln340_2286_fu_18695_p3.read();
        select_ln340_2288_reg_47360 = select_ln340_2288_fu_18875_p3.read();
        select_ln340_2290_reg_47366 = select_ln340_2290_fu_19055_p3.read();
        select_ln340_2292_reg_47372 = select_ln340_2292_fu_19235_p3.read();
        select_ln340_2296_reg_47383 = select_ln340_2296_fu_19425_p3.read();
        select_ln340_2298_reg_47389 = select_ln340_2298_fu_19605_p3.read();
        select_ln340_2300_reg_47395 = select_ln340_2300_fu_19785_p3.read();
        select_ln340_2302_reg_47401 = select_ln340_2302_fu_19965_p3.read();
        select_ln340_2304_reg_47407 = select_ln340_2304_fu_20145_p3.read();
        select_ln340_2306_reg_47413 = select_ln340_2306_fu_20325_p3.read();
        select_ln340_2308_reg_47419 = select_ln340_2308_fu_20505_p3.read();
        select_ln340_2310_reg_47425 = select_ln340_2310_fu_20685_p3.read();
        select_ln340_2312_reg_47431 = select_ln340_2312_fu_20865_p3.read();
        select_ln340_2314_reg_47437 = select_ln340_2314_fu_21045_p3.read();
        select_ln340_2316_reg_47443 = select_ln340_2316_fu_21225_p3.read();
        select_ln340_2318_reg_47449 = select_ln340_2318_fu_21405_p3.read();
        select_ln340_2320_reg_47455 = select_ln340_2320_fu_21585_p3.read();
        select_ln340_2322_reg_47461 = select_ln340_2322_fu_21765_p3.read();
        select_ln340_2324_reg_47467 = select_ln340_2324_fu_21945_p3.read();
        select_ln340_2326_reg_47473 = select_ln340_2326_fu_22125_p3.read();
        select_ln340_2328_reg_47479 = select_ln340_2328_fu_22305_p3.read();
        select_ln340_2330_reg_47485 = select_ln340_2330_fu_22485_p3.read();
        select_ln340_2332_reg_47491 = select_ln340_2332_fu_22665_p3.read();
        select_ln340_2336_reg_47502 = select_ln340_2336_fu_22855_p3.read();
        select_ln340_2338_reg_47508 = select_ln340_2338_fu_23035_p3.read();
        select_ln340_2340_reg_47514 = select_ln340_2340_fu_23215_p3.read();
        select_ln340_2342_reg_47520 = select_ln340_2342_fu_23395_p3.read();
        select_ln340_2344_reg_47526 = select_ln340_2344_fu_23575_p3.read();
        select_ln340_2346_reg_47532 = select_ln340_2346_fu_23755_p3.read();
        select_ln340_2348_reg_47538 = select_ln340_2348_fu_23935_p3.read();
        select_ln340_2350_reg_47544 = select_ln340_2350_fu_24115_p3.read();
        select_ln340_2352_reg_47550 = select_ln340_2352_fu_24295_p3.read();
        select_ln340_2354_reg_47556 = select_ln340_2354_fu_24475_p3.read();
        select_ln340_2356_reg_47562 = select_ln340_2356_fu_24655_p3.read();
        select_ln340_2358_reg_47568 = select_ln340_2358_fu_24835_p3.read();
        select_ln340_2360_reg_47574 = select_ln340_2360_fu_25015_p3.read();
        select_ln340_2362_reg_47580 = select_ln340_2362_fu_25195_p3.read();
        select_ln340_2364_reg_47586 = select_ln340_2364_fu_25375_p3.read();
        select_ln340_2366_reg_47592 = select_ln340_2366_fu_25555_p3.read();
        select_ln340_2368_reg_47598 = select_ln340_2368_fu_25735_p3.read();
        select_ln340_2370_reg_47604 = select_ln340_2370_fu_25915_p3.read();
        select_ln340_2372_reg_47610 = select_ln340_2372_fu_26095_p3.read();
        select_ln340_2376_reg_47621 = select_ln340_2376_fu_26285_p3.read();
        select_ln340_2378_reg_47627 = select_ln340_2378_fu_26465_p3.read();
        select_ln340_2380_reg_47633 = select_ln340_2380_fu_26645_p3.read();
        select_ln340_2382_reg_47639 = select_ln340_2382_fu_26825_p3.read();
        select_ln340_2384_reg_47645 = select_ln340_2384_fu_27005_p3.read();
        select_ln340_2386_reg_47651 = select_ln340_2386_fu_27185_p3.read();
        select_ln340_2388_reg_47657 = select_ln340_2388_fu_27365_p3.read();
        select_ln340_2390_reg_47663 = select_ln340_2390_fu_27545_p3.read();
        select_ln340_2392_reg_47669 = select_ln340_2392_fu_27725_p3.read();
        select_ln340_2394_reg_47675 = select_ln340_2394_fu_27905_p3.read();
        select_ln340_2396_reg_47681 = select_ln340_2396_fu_28085_p3.read();
        select_ln340_2398_reg_47687 = select_ln340_2398_fu_28265_p3.read();
        select_ln340_2400_reg_47693 = select_ln340_2400_fu_28445_p3.read();
        select_ln340_2402_reg_47699 = select_ln340_2402_fu_28625_p3.read();
        select_ln340_2404_reg_47705 = select_ln340_2404_fu_28805_p3.read();
        select_ln340_2406_reg_47711 = select_ln340_2406_fu_28985_p3.read();
        select_ln340_2408_reg_47717 = select_ln340_2408_fu_29165_p3.read();
        select_ln340_2410_reg_47723 = select_ln340_2410_fu_29345_p3.read();
        select_ln340_2412_reg_47729 = select_ln340_2412_fu_29525_p3.read();
        tmp_531_reg_46902 = w5_V_q0.read().range(159, 152);
        tmp_551_reg_47021 = w5_V_q0.read().range(319, 312);
        tmp_571_reg_47140 = w5_V_q0.read().range(479, 472);
        tmp_591_reg_47259 = w5_V_q0.read().range(639, 632);
        tmp_611_reg_47378 = w5_V_q0.read().range(799, 792);
        tmp_631_reg_47497 = w5_V_q0.read().range(959, 952);
        tmp_651_reg_47616 = w5_V_q0.read().range(1119, 1112);
        tmp_671_reg_47735 = w5_V_q0.read().range(1276, 1272);
    }
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        in_index_reg_46783 = in_index_fu_1843_p2.read();
    }
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state3.read()) && esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln166_fu_1554_p2.read()) && esl_seteq<1,2,2>(trunc_ln203_fu_1566_p1.read(), ap_const_lv2_0))) {
        kernel_data_V_2_0 = ap_phi_mux_phi_ln203_phi_fu_1153_p8.read();
    }
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state3.read()) && esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln166_fu_1554_p2.read()) && esl_seteq<1,3,3>(ap_const_lv3_0, ap_phi_mux_i_iw_0_i_i_i_phi_fu_1143_p4.read()))) {
        kernel_data_V_2_1 = ap_phi_mux_phi_ln203_1_phi_fu_1166_p8.read();
        kernel_data_V_2_2 = ap_phi_mux_phi_ln203_2_phi_fu_1179_p8.read();
        kernel_data_V_2_3 = ap_phi_mux_phi_ln203_3_phi_fu_1192_p8.read();
        kernel_data_V_2_4 = ap_phi_mux_phi_ln203_4_phi_fu_1205_p8.read();
        kernel_data_V_2_5 = ap_phi_mux_phi_ln203_5_phi_fu_1218_p8.read();
        kernel_data_V_2_6 = ap_phi_mux_phi_ln203_6_phi_fu_1231_p8.read();
        kernel_data_V_2_7 = ap_phi_mux_phi_ln203_7_phi_fu_1244_p8.read();
    }
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state3.read()) && esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln166_fu_1554_p2.read()) && esl_seteq<1,3,3>(ap_phi_mux_i_iw_0_i_i_i_phi_fu_1143_p4.read(), ap_const_lv3_1))) {
        kernel_data_V_2_10 = ap_phi_mux_phi_ln203_2_phi_fu_1179_p8.read();
        kernel_data_V_2_11 = ap_phi_mux_phi_ln203_3_phi_fu_1192_p8.read();
        kernel_data_V_2_12 = ap_phi_mux_phi_ln203_4_phi_fu_1205_p8.read();
        kernel_data_V_2_13 = ap_phi_mux_phi_ln203_5_phi_fu_1218_p8.read();
        kernel_data_V_2_14 = ap_phi_mux_phi_ln203_6_phi_fu_1231_p8.read();
        kernel_data_V_2_15 = ap_phi_mux_phi_ln203_7_phi_fu_1244_p8.read();
        kernel_data_V_2_9 = ap_phi_mux_phi_ln203_1_phi_fu_1166_p8.read();
    }
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state3.read()) && esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln166_fu_1554_p2.read()) && esl_seteq<1,2,2>(trunc_ln203_fu_1566_p1.read(), ap_const_lv2_2))) {
        kernel_data_V_2_16 = ap_phi_mux_phi_ln203_phi_fu_1153_p8.read();
    }
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state3.read()) && esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln166_fu_1554_p2.read()) && esl_seteq<1,3,3>(ap_phi_mux_i_iw_0_i_i_i_phi_fu_1143_p4.read(), ap_const_lv3_2))) {
        kernel_data_V_2_17 = ap_phi_mux_phi_ln203_1_phi_fu_1166_p8.read();
        kernel_data_V_2_18 = ap_phi_mux_phi_ln203_2_phi_fu_1179_p8.read();
        kernel_data_V_2_19 = ap_phi_mux_phi_ln203_3_phi_fu_1192_p8.read();
        kernel_data_V_2_20 = ap_phi_mux_phi_ln203_4_phi_fu_1205_p8.read();
        kernel_data_V_2_21 = ap_phi_mux_phi_ln203_5_phi_fu_1218_p8.read();
        kernel_data_V_2_22 = ap_phi_mux_phi_ln203_6_phi_fu_1231_p8.read();
        kernel_data_V_2_23 = ap_phi_mux_phi_ln203_7_phi_fu_1244_p8.read();
    }
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state3.read()) && esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln166_fu_1554_p2.read()) && esl_seteq<1,2,2>(trunc_ln203_fu_1566_p1.read(), ap_const_lv2_3))) {
        kernel_data_V_2_24 = ap_phi_mux_phi_ln203_phi_fu_1153_p8.read();
    }
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state3.read()) && esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln166_fu_1554_p2.read()) && !esl_seteq<1,3,3>(ap_const_lv3_0, ap_phi_mux_i_iw_0_i_i_i_phi_fu_1143_p4.read()) && !esl_seteq<1,3,3>(ap_phi_mux_i_iw_0_i_i_i_phi_fu_1143_p4.read(), ap_const_lv3_1) && !esl_seteq<1,3,3>(ap_phi_mux_i_iw_0_i_i_i_phi_fu_1143_p4.read(), ap_const_lv3_2))) {
        kernel_data_V_2_25 = ap_phi_mux_phi_ln203_1_phi_fu_1166_p8.read();
        kernel_data_V_2_26 = ap_phi_mux_phi_ln203_2_phi_fu_1179_p8.read();
        kernel_data_V_2_27 = ap_phi_mux_phi_ln203_3_phi_fu_1192_p8.read();
        kernel_data_V_2_28 = ap_phi_mux_phi_ln203_4_phi_fu_1205_p8.read();
        kernel_data_V_2_29 = ap_phi_mux_phi_ln203_5_phi_fu_1218_p8.read();
        kernel_data_V_2_30 = ap_phi_mux_phi_ln203_6_phi_fu_1231_p8.read();
        kernel_data_V_2_31 = ap_phi_mux_phi_ln203_7_phi_fu_1244_p8.read();
    }
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state3.read()) && esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln166_fu_1554_p2.read()) && esl_seteq<1,2,2>(trunc_ln203_fu_1566_p1.read(), ap_const_lv2_1))) {
        kernel_data_V_2_8 = ap_phi_mux_phi_ln203_phi_fu_1153_p8.read();
    }
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state8.read()) && !(esl_seteq<1,1,1>(and_ln360_reg_46774.read(), ap_const_lv1_1) && esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op7036.read())))) {
        sX_1 = ap_phi_mux_storemerge_i_i_phi_fu_1357_p4.read();
    }
    if ((esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()))) {
        tmp_data_0_V_reg_47740 = tmp_data_0_V_fu_31482_p3.read();
        tmp_data_1_V_reg_47746 = tmp_data_1_V_fu_33413_p3.read();
        tmp_data_2_V_reg_47752 = tmp_data_2_V_fu_35344_p3.read();
        tmp_data_3_V_reg_47758 = tmp_data_3_V_fu_37275_p3.read();
        tmp_data_4_V_reg_47764 = tmp_data_4_V_fu_39206_p3.read();
        tmp_data_5_V_reg_47770 = tmp_data_5_V_fu_41137_p3.read();
        tmp_data_6_V_reg_47776 = tmp_data_6_V_fu_43068_p3.read();
        tmp_data_7_V_reg_47782 = tmp_data_7_V_fu_45017_p3.read();
    }
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_8u_config5_s::thread_ap_NS_fsm() {
    switch (ap_CS_fsm.read().to_uint64()) {
        case 1 : 
            if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1)))) {
                ap_NS_fsm = ap_ST_fsm_state2;
            } else {
                ap_NS_fsm = ap_ST_fsm_state1;
            }
            break;
        case 2 : 
            if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read()) && esl_seteq<1,1,1>(io_acc_block_signal_op30.read(), ap_const_logic_1))) {
                ap_NS_fsm = ap_ST_fsm_state3;
            } else {
                ap_NS_fsm = ap_ST_fsm_state2;
            }
            break;
        case 4 : 
            if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state3.read()) && esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln166_fu_1554_p2.read()))) {
                ap_NS_fsm = ap_ST_fsm_state3;
            } else {
                ap_NS_fsm = ap_ST_fsm_state4;
            }
            break;
        case 8 : 
            if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state4.read()) && esl_seteq<1,1,1>(ap_const_lv1_1, and_ln360_fu_1832_p2.read()))) {
                ap_NS_fsm = ap_ST_fsm_pp1_stage0;
            } else {
                ap_NS_fsm = ap_ST_fsm_state8;
            }
            break;
        case 16 : 
            if (!(esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && esl_seteq<1,1,1>(ap_block_pp1_stage0_subdone.read(), ap_const_boolean_0) && esl_seteq<1,1,1>(ap_enable_reg_pp1_iter1.read(), ap_const_logic_0))) {
                ap_NS_fsm = ap_ST_fsm_pp1_stage0;
            } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && esl_seteq<1,1,1>(ap_block_pp1_stage0_subdone.read(), ap_const_boolean_0) && esl_seteq<1,1,1>(ap_enable_reg_pp1_iter1.read(), ap_const_logic_0))) {
                ap_NS_fsm = ap_ST_fsm_state8;
            } else {
                ap_NS_fsm = ap_ST_fsm_pp1_stage0;
            }
            break;
        case 32 : 
            if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state8.read()) && !(esl_seteq<1,1,1>(and_ln360_reg_46774.read(), ap_const_lv1_1) && esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op7036.read())) && esl_seteq<1,1,1>(ap_const_lv1_1, icmp_ln64_fu_45066_p2.read()))) {
                ap_NS_fsm = ap_ST_fsm_state1;
            } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state8.read()) && !(esl_seteq<1,1,1>(and_ln360_reg_46774.read(), ap_const_lv1_1) && esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op7036.read())) && esl_seteq<1,1,1>(icmp_ln64_fu_45066_p2.read(), ap_const_lv1_0))) {
                ap_NS_fsm = ap_ST_fsm_state2;
            } else {
                ap_NS_fsm = ap_ST_fsm_state8;
            }
            break;
        default : 
            ap_NS_fsm =  (sc_lv<6>) ("XXXXXX");
            break;
    }
}

}

