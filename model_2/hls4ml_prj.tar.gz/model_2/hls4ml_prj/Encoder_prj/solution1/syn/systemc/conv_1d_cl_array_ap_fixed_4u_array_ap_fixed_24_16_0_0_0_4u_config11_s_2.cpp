#include "conv_1d_cl_array_ap_fixed_4u_array_ap_fixed_24_16_0_0_0_4u_config11_s.h"
#include "AESL_pkg.h"

using namespace std;

namespace ap_rtl {

void conv_1d_cl_array_ap_fixed_4u_array_ap_fixed_24_16_0_0_0_4u_config11_s::thread_ap_clk_no_reset_() {
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_CS_fsm = ap_ST_fsm_state1;
    } else {
        ap_CS_fsm = ap_NS_fsm.read();
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_done_reg = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_const_logic_1, ap_continue.read())) {
            ap_done_reg = ap_const_logic_0;
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state8.read()) && 
                    !(esl_seteq<1,1,1>(and_ln360_reg_12266.read(), ap_const_lv1_1) && esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op1863.read())) && 
                    esl_seteq<1,1,1>(ap_const_lv1_1, icmp_ln64_fu_11788_p2.read()))) {
            ap_done_reg = ap_const_logic_1;
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_enable_reg_pp1_iter0 = ap_const_logic_0;
    } else {
        if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
             esl_seteq<1,1,1>(ap_block_pp1_stage0_subdone.read(), ap_const_boolean_0) && 
             esl_seteq<1,1,1>(ap_const_lv1_1, ap_phi_mux_in_index13_phi_fu_546_p4.read()))) {
            ap_enable_reg_pp1_iter0 = ap_const_logic_0;
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state4.read()) && 
                    esl_seteq<1,1,1>(ap_const_lv1_1, and_ln360_fu_868_p2.read()))) {
            ap_enable_reg_pp1_iter0 = ap_const_logic_1;
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_enable_reg_pp1_iter1 = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_block_pp1_stage0_subdone.read(), ap_const_boolean_0)) {
            ap_enable_reg_pp1_iter1 = ap_enable_reg_pp1_iter0.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        ap_enable_reg_pp1_iter2 = ap_const_logic_0;
    } else {
        if (esl_seteq<1,1,1>(ap_block_pp1_stage0_subdone.read(), ap_const_boolean_0)) {
            ap_enable_reg_pp1_iter2 = ap_enable_reg_pp1_iter1.read();
        } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state4.read()) && 
                    esl_seteq<1,1,1>(ap_const_lv1_1, and_ln360_fu_868_p2.read()))) {
            ap_enable_reg_pp1_iter2 = ap_const_logic_0;
        }
    }
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state8.read()) && 
         !(esl_seteq<1,1,1>(and_ln360_reg_12266.read(), ap_const_lv1_1) && esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op1863.read())) && 
         esl_seteq<1,1,1>(icmp_ln64_fu_11788_p2.read(), ap_const_lv1_0))) {
        i_iw_0_i14_reg_467 = i_iw_reg_12234.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && 
                !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1)))) {
        i_iw_0_i14_reg_467 = ap_const_lv6_0;
    }
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state3.read()) && 
         esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln166_fu_706_p2.read()))) {
        i_iw_0_i_i_i_reg_479 = i_iw_4_fu_712_p2.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read()) && 
                esl_seteq<1,1,1>(io_acc_block_signal_op22.read(), ap_const_logic_1))) {
        i_iw_0_i_i_i_reg_479 = ap_const_lv3_0;
    }
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
         esl_seteq<1,1,1>(in_index13_reg_542.read(), ap_const_lv1_0))) {
        in_index13_reg_542 = in_index_reg_12275.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state4.read()) && 
                esl_seteq<1,1,1>(ap_const_lv1_1, and_ln360_fu_868_p2.read()))) {
        in_index13_reg_542 = ap_const_lv1_0;
    }
    if (esl_seteq<1,1,1>(ap_condition_315.read(), ap_const_boolean_1)) {
        if (esl_seteq<1,1,1>(ap_const_lv1_1, icmp_ln384_fu_11747_p2.read())) {
            pX_3 = ap_const_lv32_0;
        } else if (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln384_fu_11747_p2.read())) {
            pX_3 = add_ln389_fu_11752_p2.read();
        }
    }
    if ( ap_rst.read() == ap_const_logic_1) {
        start_once_reg = ap_const_logic_0;
    } else {
        if ((esl_seteq<1,1,1>(ap_const_logic_1, real_start.read()) && 
             esl_seteq<1,1,1>(ap_const_logic_0, internal_ap_ready.read()))) {
            start_once_reg = ap_const_logic_1;
        } else if (esl_seteq<1,1,1>(ap_const_logic_1, internal_ap_ready.read())) {
            start_once_reg = ap_const_logic_0;
        }
    }
    if ((esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
         esl_seteq<1,1,1>(in_index13_reg_542_pp1_iter1_reg.read(), ap_const_lv1_0))) {
        tmp_data_0_V_1711_reg_554 = tmp_data_0_V_20_fu_8582_p3.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state4.read()) && 
                esl_seteq<1,1,1>(ap_const_lv1_1, and_ln360_fu_868_p2.read()))) {
        tmp_data_0_V_1711_reg_554 = ap_const_lv24_FFFFFA;
    }
    if ((esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
         esl_seteq<1,1,1>(in_index13_reg_542_pp1_iter1_reg.read(), ap_const_lv1_0))) {
        tmp_data_1_V_149_reg_565 = tmp_data_1_V_19_fu_9633_p3.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state4.read()) && 
                esl_seteq<1,1,1>(ap_const_lv1_1, and_ln360_fu_868_p2.read()))) {
        tmp_data_1_V_149_reg_565 = ap_const_lv24_12;
    }
    if ((esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
         esl_seteq<1,1,1>(in_index13_reg_542_pp1_iter1_reg.read(), ap_const_lv1_0))) {
        tmp_data_2_V_147_reg_576 = tmp_data_2_V_19_fu_10684_p3.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state4.read()) && 
                esl_seteq<1,1,1>(ap_const_lv1_1, and_ln360_fu_868_p2.read()))) {
        tmp_data_2_V_147_reg_576 = ap_const_lv24_A;
    }
    if ((esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && 
         esl_seteq<1,1,1>(in_index13_reg_542_pp1_iter1_reg.read(), ap_const_lv1_0))) {
        tmp_data_3_V_145_reg_587 = tmp_data_3_V_19_fu_11739_p3.read();
    } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state4.read()) && 
                esl_seteq<1,1,1>(ap_const_lv1_1, and_ln360_fu_868_p2.read()))) {
        tmp_data_3_V_145_reg_587 = ap_const_lv24_FFFFFC;
    }
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state4.read())) {
        and_ln360_reg_12266 = and_ln360_fu_868_p2.read();
        icmp_ln360_reg_12255 = icmp_ln360_fu_842_p2.read();
        kernel_data_V_16 = tmp_data_0_V_reg_12194.read();
        kernel_data_V_17 = tmp_data_1_V_reg_12199.read();
        kernel_data_V_18 = tmp_data_2_V_reg_12204.read();
        kernel_data_V_19 = tmp_data_3_V_reg_12209.read();
        pX_3_load_reg_12260 = pX_3.read();
        sX_3_load_reg_12250 = sX_3.read();
    }
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read()) && esl_seteq<1,1,1>(io_acc_block_signal_op22.read(), ap_const_logic_1))) {
        i_iw_reg_12234 = i_iw_fu_700_p2.read();
        kernel_data_V_16_load_reg_12214 = kernel_data_V_16.read();
        kernel_data_V_17_load_reg_12219 = kernel_data_V_17.read();
        kernel_data_V_18_load_reg_12224 = kernel_data_V_18.read();
        kernel_data_V_19_load_reg_12229 = kernel_data_V_19.read();
        tmp_data_0_V_reg_12194 = data_V_data_0_V_dout.read();
        tmp_data_1_V_reg_12199 = data_V_data_1_V_dout.read();
        tmp_data_2_V_reg_12204 = data_V_data_2_V_dout.read();
        tmp_data_3_V_reg_12209 = data_V_data_3_V_dout.read();
    }
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0))) {
        in_index13_reg_542_pp1_iter1_reg = in_index13_reg_542.read();
        select_ln340_2576_reg_12280 = select_ln340_2576_fu_1071_p3.read();
        select_ln340_2578_reg_12286 = select_ln340_2578_fu_1271_p3.read();
        select_ln340_2580_reg_12292 = select_ln340_2580_fu_1463_p3.read();
        select_ln340_2582_reg_12298 = select_ln340_2582_fu_1655_p3.read();
        select_ln340_2584_reg_12304 = select_ln340_2584_fu_1847_p3.read();
        select_ln340_2586_reg_12310 = select_ln340_2586_fu_2039_p3.read();
        select_ln340_2588_reg_12316 = select_ln340_2588_fu_2231_p3.read();
        select_ln340_2590_reg_12322 = select_ln340_2590_fu_2423_p3.read();
        select_ln340_2592_reg_12328 = select_ln340_2592_fu_2615_p3.read();
        select_ln340_2596_reg_12339 = select_ln340_2596_fu_2805_p3.read();
        select_ln340_2598_reg_12345 = select_ln340_2598_fu_2985_p3.read();
        select_ln340_2600_reg_12351 = select_ln340_2600_fu_3165_p3.read();
        select_ln340_2602_reg_12357 = select_ln340_2602_fu_3345_p3.read();
        select_ln340_2604_reg_12363 = select_ln340_2604_fu_3525_p3.read();
        select_ln340_2606_reg_12369 = select_ln340_2606_fu_3705_p3.read();
        select_ln340_2608_reg_12375 = select_ln340_2608_fu_3885_p3.read();
        select_ln340_2610_reg_12381 = select_ln340_2610_fu_4065_p3.read();
        select_ln340_2612_reg_12387 = select_ln340_2612_fu_4245_p3.read();
        select_ln340_2616_reg_12398 = select_ln340_2616_fu_4435_p3.read();
        select_ln340_2618_reg_12404 = select_ln340_2618_fu_4615_p3.read();
        select_ln340_2620_reg_12410 = select_ln340_2620_fu_4795_p3.read();
        select_ln340_2622_reg_12416 = select_ln340_2622_fu_4975_p3.read();
        select_ln340_2624_reg_12422 = select_ln340_2624_fu_5155_p3.read();
        select_ln340_2626_reg_12428 = select_ln340_2626_fu_5335_p3.read();
        select_ln340_2628_reg_12434 = select_ln340_2628_fu_5515_p3.read();
        select_ln340_2630_reg_12440 = select_ln340_2630_fu_5695_p3.read();
        select_ln340_2632_reg_12446 = select_ln340_2632_fu_5875_p3.read();
        select_ln340_2636_reg_12457 = select_ln340_2636_fu_6065_p3.read();
        select_ln340_2638_reg_12463 = select_ln340_2638_fu_6245_p3.read();
        select_ln340_2640_reg_12469 = select_ln340_2640_fu_6425_p3.read();
        select_ln340_2642_reg_12475 = select_ln340_2642_fu_6605_p3.read();
        select_ln340_2644_reg_12481 = select_ln340_2644_fu_6785_p3.read();
        select_ln340_2646_reg_12487 = select_ln340_2646_fu_6965_p3.read();
        select_ln340_2648_reg_12493 = select_ln340_2648_fu_7145_p3.read();
        select_ln340_2650_reg_12499 = select_ln340_2650_fu_7325_p3.read();
        select_ln340_2652_reg_12505 = select_ln340_2652_fu_7505_p3.read();
        tmp_763_reg_12334 = w11_V_q0.read().range(79, 72);
        tmp_773_reg_12393 = w11_V_q0.read().range(159, 152);
        tmp_783_reg_12452 = w11_V_q0.read().range(239, 232);
        tmp_793_reg_12511 = w11_V_q0.read().range(317, 312);
    }
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter0.read()))) {
        in_index_reg_12275 = in_index_fu_879_p2.read();
    }
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state3.read()) && esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln166_fu_706_p2.read()) && esl_seteq<1,2,2>(trunc_ln203_fu_718_p1.read(), ap_const_lv2_0))) {
        kernel_data_V_0 = ap_phi_mux_phi_ln203_phi_fu_493_p8.read();
    }
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state3.read()) && esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln166_fu_706_p2.read()) && esl_seteq<1,3,3>(ap_phi_mux_i_iw_0_i_i_i_phi_fu_483_p4.read(), ap_const_lv3_2))) {
        kernel_data_V_10 = ap_phi_mux_phi_ln203_16_phi_fu_519_p8.read();
        kernel_data_V_11 = ap_phi_mux_phi_ln203_17_phi_fu_532_p8.read();
        kernel_data_V_9 = ap_phi_mux_phi_ln203_15_phi_fu_506_p8.read();
    }
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state3.read()) && esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln166_fu_706_p2.read()) && esl_seteq<1,3,3>(ap_const_lv3_0, ap_phi_mux_i_iw_0_i_i_i_phi_fu_483_p4.read()))) {
        kernel_data_V_1156 = ap_phi_mux_phi_ln203_15_phi_fu_506_p8.read();
        kernel_data_V_2157 = ap_phi_mux_phi_ln203_16_phi_fu_519_p8.read();
        kernel_data_V_3158 = ap_phi_mux_phi_ln203_17_phi_fu_532_p8.read();
    }
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state3.read()) && esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln166_fu_706_p2.read()) && esl_seteq<1,2,2>(trunc_ln203_fu_718_p1.read(), ap_const_lv2_3))) {
        kernel_data_V_12 = ap_phi_mux_phi_ln203_phi_fu_493_p8.read();
    }
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state3.read()) && esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln166_fu_706_p2.read()) && !esl_seteq<1,3,3>(ap_const_lv3_0, ap_phi_mux_i_iw_0_i_i_i_phi_fu_483_p4.read()) && !esl_seteq<1,3,3>(ap_phi_mux_i_iw_0_i_i_i_phi_fu_483_p4.read(), ap_const_lv3_1) && !esl_seteq<1,3,3>(ap_phi_mux_i_iw_0_i_i_i_phi_fu_483_p4.read(), ap_const_lv3_2))) {
        kernel_data_V_13 = ap_phi_mux_phi_ln203_15_phi_fu_506_p8.read();
        kernel_data_V_14 = ap_phi_mux_phi_ln203_16_phi_fu_519_p8.read();
        kernel_data_V_15 = ap_phi_mux_phi_ln203_17_phi_fu_532_p8.read();
    }
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state3.read()) && esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln166_fu_706_p2.read()) && esl_seteq<1,2,2>(trunc_ln203_fu_718_p1.read(), ap_const_lv2_1))) {
        kernel_data_V_4 = ap_phi_mux_phi_ln203_phi_fu_493_p8.read();
    }
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state3.read()) && esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln166_fu_706_p2.read()) && esl_seteq<1,3,3>(ap_phi_mux_i_iw_0_i_i_i_phi_fu_483_p4.read(), ap_const_lv3_1))) {
        kernel_data_V_5 = ap_phi_mux_phi_ln203_15_phi_fu_506_p8.read();
        kernel_data_V_6 = ap_phi_mux_phi_ln203_16_phi_fu_519_p8.read();
        kernel_data_V_7 = ap_phi_mux_phi_ln203_17_phi_fu_532_p8.read();
    }
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state3.read()) && esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln166_fu_706_p2.read()) && esl_seteq<1,2,2>(trunc_ln203_fu_718_p1.read(), ap_const_lv2_2))) {
        kernel_data_V_8 = ap_phi_mux_phi_ln203_phi_fu_493_p8.read();
    }
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state8.read()) && !(esl_seteq<1,1,1>(and_ln360_reg_12266.read(), ap_const_lv1_1) && esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op1863.read())))) {
        sX_3 = ap_phi_mux_storemerge_i_i_phi_fu_601_p4.read();
    }
    if ((esl_seteq<1,1,1>(ap_block_pp1_stage0_11001.read(), ap_const_boolean_0) && esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()))) {
        tmp_data_0_V_20_reg_12516 = tmp_data_0_V_20_fu_8582_p3.read();
        tmp_data_1_V_19_reg_12522 = tmp_data_1_V_19_fu_9633_p3.read();
        tmp_data_2_V_19_reg_12528 = tmp_data_2_V_19_fu_10684_p3.read();
        tmp_data_3_V_19_reg_12534 = tmp_data_3_V_19_fu_11739_p3.read();
    }
}

void conv_1d_cl_array_ap_fixed_4u_array_ap_fixed_24_16_0_0_0_4u_config11_s::thread_ap_NS_fsm() {
    switch (ap_CS_fsm.read().to_uint64()) {
        case 1 : 
            if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()) && !(esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1)))) {
                ap_NS_fsm = ap_ST_fsm_state2;
            } else {
                ap_NS_fsm = ap_ST_fsm_state1;
            }
            break;
        case 2 : 
            if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read()) && esl_seteq<1,1,1>(io_acc_block_signal_op22.read(), ap_const_logic_1))) {
                ap_NS_fsm = ap_ST_fsm_state3;
            } else {
                ap_NS_fsm = ap_ST_fsm_state2;
            }
            break;
        case 4 : 
            if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state3.read()) && esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln166_fu_706_p2.read()))) {
                ap_NS_fsm = ap_ST_fsm_state3;
            } else {
                ap_NS_fsm = ap_ST_fsm_state4;
            }
            break;
        case 8 : 
            if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state4.read()) && esl_seteq<1,1,1>(ap_const_lv1_1, and_ln360_fu_868_p2.read()))) {
                ap_NS_fsm = ap_ST_fsm_pp1_stage0;
            } else {
                ap_NS_fsm = ap_ST_fsm_state8;
            }
            break;
        case 16 : 
            if (!(esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && esl_seteq<1,1,1>(ap_block_pp1_stage0_subdone.read(), ap_const_boolean_0) && esl_seteq<1,1,1>(ap_enable_reg_pp1_iter1.read(), ap_const_logic_0))) {
                ap_NS_fsm = ap_ST_fsm_pp1_stage0;
            } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter2.read()) && esl_seteq<1,1,1>(ap_block_pp1_stage0_subdone.read(), ap_const_boolean_0) && esl_seteq<1,1,1>(ap_enable_reg_pp1_iter1.read(), ap_const_logic_0))) {
                ap_NS_fsm = ap_ST_fsm_state8;
            } else {
                ap_NS_fsm = ap_ST_fsm_pp1_stage0;
            }
            break;
        case 32 : 
            if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state8.read()) && !(esl_seteq<1,1,1>(and_ln360_reg_12266.read(), ap_const_lv1_1) && esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op1863.read())) && esl_seteq<1,1,1>(ap_const_lv1_1, icmp_ln64_fu_11788_p2.read()))) {
                ap_NS_fsm = ap_ST_fsm_state1;
            } else if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state8.read()) && !(esl_seteq<1,1,1>(and_ln360_reg_12266.read(), ap_const_lv1_1) && esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op1863.read())) && esl_seteq<1,1,1>(icmp_ln64_fu_11788_p2.read(), ap_const_lv1_0))) {
                ap_NS_fsm = ap_ST_fsm_state2;
            } else {
                ap_NS_fsm = ap_ST_fsm_state8;
            }
            break;
        default : 
            ap_NS_fsm =  (sc_lv<6>) ("XXXXXX");
            break;
    }
}

}

