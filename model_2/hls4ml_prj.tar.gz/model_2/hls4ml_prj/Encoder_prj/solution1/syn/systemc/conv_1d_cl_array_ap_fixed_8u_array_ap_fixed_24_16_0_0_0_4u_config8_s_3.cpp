#include "conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s.h"
#include "AESL_pkg.h"

using namespace std;

namespace ap_rtl {

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_acc_0_V_107_fu_15453_p3() {
    acc_0_V_107_fu_15453_p3 = (!and_ln786_1928_fu_15421_p2.read()[0].is_01())? sc_lv<24>(): ((and_ln786_1928_fu_15421_p2.read()[0].to_bool())? ap_const_lv24_800000: acc_0_V_fu_15402_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_acc_0_V_108_fu_15490_p2() {
    acc_0_V_108_fu_15490_p2 = (!select_ln340_2418_reg_24100.read().is_01() || !select_ln340_2417_fu_15461_p3.read().is_01())? sc_lv<24>(): (sc_bigint<24>(select_ln340_2418_reg_24100.read()) + sc_bigint<24>(select_ln340_2417_fu_15461_p3.read()));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_acc_0_V_109_fu_15541_p3() {
    acc_0_V_109_fu_15541_p3 = (!and_ln786_1930_fu_15509_p2.read()[0].is_01())? sc_lv<24>(): ((and_ln786_1930_fu_15509_p2.read()[0].to_bool())? ap_const_lv24_800000: acc_0_V_108_fu_15490_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_acc_0_V_110_fu_15578_p2() {
    acc_0_V_110_fu_15578_p2 = (!select_ln340_2420_reg_24106.read().is_01() || !select_ln340_2419_fu_15549_p3.read().is_01())? sc_lv<24>(): (sc_bigint<24>(select_ln340_2420_reg_24106.read()) + sc_bigint<24>(select_ln340_2419_fu_15549_p3.read()));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_acc_0_V_111_fu_15629_p3() {
    acc_0_V_111_fu_15629_p3 = (!and_ln786_1932_fu_15597_p2.read()[0].is_01())? sc_lv<24>(): ((and_ln786_1932_fu_15597_p2.read()[0].to_bool())? ap_const_lv24_800000: acc_0_V_110_fu_15578_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_acc_0_V_112_fu_15666_p2() {
    acc_0_V_112_fu_15666_p2 = (!select_ln340_2422_reg_24112.read().is_01() || !select_ln340_2421_fu_15637_p3.read().is_01())? sc_lv<24>(): (sc_bigint<24>(select_ln340_2422_reg_24112.read()) + sc_bigint<24>(select_ln340_2421_fu_15637_p3.read()));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_acc_0_V_113_fu_15717_p3() {
    acc_0_V_113_fu_15717_p3 = (!and_ln786_1934_fu_15685_p2.read()[0].is_01())? sc_lv<24>(): ((and_ln786_1934_fu_15685_p2.read()[0].to_bool())? ap_const_lv24_800000: acc_0_V_112_fu_15666_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_acc_0_V_114_fu_15754_p2() {
    acc_0_V_114_fu_15754_p2 = (!select_ln340_2424_reg_24118.read().is_01() || !select_ln340_2423_fu_15725_p3.read().is_01())? sc_lv<24>(): (sc_bigint<24>(select_ln340_2424_reg_24118.read()) + sc_bigint<24>(select_ln340_2423_fu_15725_p3.read()));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_acc_0_V_115_fu_15805_p3() {
    acc_0_V_115_fu_15805_p3 = (!and_ln786_1936_fu_15773_p2.read()[0].is_01())? sc_lv<24>(): ((and_ln786_1936_fu_15773_p2.read()[0].to_bool())? ap_const_lv24_800000: acc_0_V_114_fu_15754_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_acc_0_V_116_fu_15842_p2() {
    acc_0_V_116_fu_15842_p2 = (!select_ln340_2426_reg_24124.read().is_01() || !select_ln340_2425_fu_15813_p3.read().is_01())? sc_lv<24>(): (sc_bigint<24>(select_ln340_2426_reg_24124.read()) + sc_bigint<24>(select_ln340_2425_fu_15813_p3.read()));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_acc_0_V_117_fu_15893_p3() {
    acc_0_V_117_fu_15893_p3 = (!and_ln786_1938_fu_15861_p2.read()[0].is_01())? sc_lv<24>(): ((and_ln786_1938_fu_15861_p2.read()[0].to_bool())? ap_const_lv24_800000: acc_0_V_116_fu_15842_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_acc_0_V_118_fu_15930_p2() {
    acc_0_V_118_fu_15930_p2 = (!select_ln340_2428_reg_24130.read().is_01() || !select_ln340_2427_fu_15901_p3.read().is_01())? sc_lv<24>(): (sc_bigint<24>(select_ln340_2428_reg_24130.read()) + sc_bigint<24>(select_ln340_2427_fu_15901_p3.read()));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_acc_0_V_119_fu_15981_p3() {
    acc_0_V_119_fu_15981_p3 = (!and_ln786_1940_fu_15949_p2.read()[0].is_01())? sc_lv<24>(): ((and_ln786_1940_fu_15949_p2.read()[0].to_bool())? ap_const_lv24_800000: acc_0_V_118_fu_15930_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_acc_0_V_120_fu_16018_p2() {
    acc_0_V_120_fu_16018_p2 = (!select_ln340_2430_reg_24136.read().is_01() || !select_ln340_2429_fu_15989_p3.read().is_01())? sc_lv<24>(): (sc_bigint<24>(select_ln340_2430_reg_24136.read()) + sc_bigint<24>(select_ln340_2429_fu_15989_p3.read()));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_acc_0_V_121_fu_16069_p3() {
    acc_0_V_121_fu_16069_p3 = (!and_ln786_1942_fu_16037_p2.read()[0].is_01())? sc_lv<24>(): ((and_ln786_1942_fu_16037_p2.read()[0].to_bool())? ap_const_lv24_800000: acc_0_V_120_fu_16018_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_acc_0_V_122_fu_16106_p2() {
    acc_0_V_122_fu_16106_p2 = (!select_ln340_2432_reg_24142.read().is_01() || !select_ln340_2431_fu_16077_p3.read().is_01())? sc_lv<24>(): (sc_bigint<24>(select_ln340_2432_reg_24142.read()) + sc_bigint<24>(select_ln340_2431_fu_16077_p3.read()));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_acc_0_V_123_fu_16157_p3() {
    acc_0_V_123_fu_16157_p3 = (!and_ln786_1944_fu_16125_p2.read()[0].is_01())? sc_lv<24>(): ((and_ln786_1944_fu_16125_p2.read()[0].to_bool())? ap_const_lv24_800000: acc_0_V_122_fu_16106_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_acc_0_V_124_fu_16194_p2() {
    acc_0_V_124_fu_16194_p2 = (!select_ln340_2434_reg_24148.read().is_01() || !select_ln340_2433_fu_16165_p3.read().is_01())? sc_lv<24>(): (sc_bigint<24>(select_ln340_2434_reg_24148.read()) + sc_bigint<24>(select_ln340_2433_fu_16165_p3.read()));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_acc_0_V_125_fu_16245_p3() {
    acc_0_V_125_fu_16245_p3 = (!and_ln786_1946_fu_16213_p2.read()[0].is_01())? sc_lv<24>(): ((and_ln786_1946_fu_16213_p2.read()[0].to_bool())? ap_const_lv24_800000: acc_0_V_124_fu_16194_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_acc_0_V_126_fu_16282_p2() {
    acc_0_V_126_fu_16282_p2 = (!select_ln340_2436_reg_24154.read().is_01() || !select_ln340_2435_fu_16253_p3.read().is_01())? sc_lv<24>(): (sc_bigint<24>(select_ln340_2436_reg_24154.read()) + sc_bigint<24>(select_ln340_2435_fu_16253_p3.read()));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_acc_0_V_127_fu_16333_p3() {
    acc_0_V_127_fu_16333_p3 = (!and_ln786_1948_fu_16301_p2.read()[0].is_01())? sc_lv<24>(): ((and_ln786_1948_fu_16301_p2.read()[0].to_bool())? ap_const_lv24_800000: acc_0_V_126_fu_16282_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_acc_0_V_128_fu_16370_p2() {
    acc_0_V_128_fu_16370_p2 = (!select_ln340_2438_reg_24160.read().is_01() || !select_ln340_2437_fu_16341_p3.read().is_01())? sc_lv<24>(): (sc_bigint<24>(select_ln340_2438_reg_24160.read()) + sc_bigint<24>(select_ln340_2437_fu_16341_p3.read()));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_acc_0_V_129_fu_16421_p3() {
    acc_0_V_129_fu_16421_p3 = (!and_ln786_1950_fu_16389_p2.read()[0].is_01())? sc_lv<24>(): ((and_ln786_1950_fu_16389_p2.read()[0].to_bool())? ap_const_lv24_800000: acc_0_V_128_fu_16370_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_acc_0_V_130_fu_16458_p2() {
    acc_0_V_130_fu_16458_p2 = (!select_ln340_2440_reg_24166.read().is_01() || !select_ln340_2439_fu_16429_p3.read().is_01())? sc_lv<24>(): (sc_bigint<24>(select_ln340_2440_reg_24166.read()) + sc_bigint<24>(select_ln340_2439_fu_16429_p3.read()));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_acc_0_V_131_fu_16509_p3() {
    acc_0_V_131_fu_16509_p3 = (!and_ln786_1952_fu_16477_p2.read()[0].is_01())? sc_lv<24>(): ((and_ln786_1952_fu_16477_p2.read()[0].to_bool())? ap_const_lv24_800000: acc_0_V_130_fu_16458_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_acc_0_V_132_fu_16546_p2() {
    acc_0_V_132_fu_16546_p2 = (!select_ln340_2442_reg_24172.read().is_01() || !select_ln340_2441_fu_16517_p3.read().is_01())? sc_lv<24>(): (sc_bigint<24>(select_ln340_2442_reg_24172.read()) + sc_bigint<24>(select_ln340_2441_fu_16517_p3.read()));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_acc_0_V_133_fu_16597_p3() {
    acc_0_V_133_fu_16597_p3 = (!and_ln786_1954_fu_16565_p2.read()[0].is_01())? sc_lv<24>(): ((and_ln786_1954_fu_16565_p2.read()[0].to_bool())? ap_const_lv24_800000: acc_0_V_132_fu_16546_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_acc_0_V_134_fu_16634_p2() {
    acc_0_V_134_fu_16634_p2 = (!select_ln340_2444_reg_24178.read().is_01() || !select_ln340_2443_fu_16605_p3.read().is_01())? sc_lv<24>(): (sc_bigint<24>(select_ln340_2444_reg_24178.read()) + sc_bigint<24>(select_ln340_2443_fu_16605_p3.read()));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_acc_0_V_135_fu_16685_p3() {
    acc_0_V_135_fu_16685_p3 = (!and_ln786_1956_fu_16653_p2.read()[0].is_01())? sc_lv<24>(): ((and_ln786_1956_fu_16653_p2.read()[0].to_bool())? ap_const_lv24_800000: acc_0_V_134_fu_16634_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_acc_0_V_136_fu_16722_p2() {
    acc_0_V_136_fu_16722_p2 = (!select_ln340_2446_reg_24184.read().is_01() || !select_ln340_2445_fu_16693_p3.read().is_01())? sc_lv<24>(): (sc_bigint<24>(select_ln340_2446_reg_24184.read()) + sc_bigint<24>(select_ln340_2445_fu_16693_p3.read()));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_acc_0_V_137_fu_16773_p3() {
    acc_0_V_137_fu_16773_p3 = (!and_ln786_1958_fu_16741_p2.read()[0].is_01())? sc_lv<24>(): ((and_ln786_1958_fu_16741_p2.read()[0].to_bool())? ap_const_lv24_800000: acc_0_V_136_fu_16722_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_acc_0_V_138_fu_16810_p2() {
    acc_0_V_138_fu_16810_p2 = (!select_ln340_2448_reg_24190.read().is_01() || !select_ln340_2447_fu_16781_p3.read().is_01())? sc_lv<24>(): (sc_bigint<24>(select_ln340_2448_reg_24190.read()) + sc_bigint<24>(select_ln340_2447_fu_16781_p3.read()));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_acc_0_V_139_fu_16861_p3() {
    acc_0_V_139_fu_16861_p3 = (!and_ln786_1960_fu_16829_p2.read()[0].is_01())? sc_lv<24>(): ((and_ln786_1960_fu_16829_p2.read()[0].to_bool())? ap_const_lv24_800000: acc_0_V_138_fu_16810_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_acc_0_V_140_fu_16898_p2() {
    acc_0_V_140_fu_16898_p2 = (!select_ln340_2450_reg_24196.read().is_01() || !select_ln340_2449_fu_16869_p3.read().is_01())? sc_lv<24>(): (sc_bigint<24>(select_ln340_2450_reg_24196.read()) + sc_bigint<24>(select_ln340_2449_fu_16869_p3.read()));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_acc_0_V_141_fu_16949_p3() {
    acc_0_V_141_fu_16949_p3 = (!and_ln786_1962_fu_16917_p2.read()[0].is_01())? sc_lv<24>(): ((and_ln786_1962_fu_16917_p2.read()[0].to_bool())? ap_const_lv24_800000: acc_0_V_140_fu_16898_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_acc_0_V_142_fu_16986_p2() {
    acc_0_V_142_fu_16986_p2 = (!select_ln340_2452_reg_24202.read().is_01() || !select_ln340_2451_fu_16957_p3.read().is_01())? sc_lv<24>(): (sc_bigint<24>(select_ln340_2452_reg_24202.read()) + sc_bigint<24>(select_ln340_2451_fu_16957_p3.read()));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_acc_0_V_143_fu_17037_p3() {
    acc_0_V_143_fu_17037_p3 = (!and_ln786_1964_fu_17005_p2.read()[0].is_01())? sc_lv<24>(): ((and_ln786_1964_fu_17005_p2.read()[0].to_bool())? ap_const_lv24_800000: acc_0_V_142_fu_16986_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_acc_0_V_144_fu_17260_p2() {
    acc_0_V_144_fu_17260_p2 = (!select_ln340_2454_fu_17230_p3.read().is_01() || !select_ln340_2453_fu_17045_p3.read().is_01())? sc_lv<24>(): (sc_bigint<24>(select_ln340_2454_fu_17230_p3.read()) + sc_bigint<24>(select_ln340_2453_fu_17045_p3.read()));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_acc_0_V_145_fu_17312_p3() {
    acc_0_V_145_fu_17312_p3 = (!and_ln786_1966_fu_17280_p2.read()[0].is_01())? sc_lv<24>(): ((and_ln786_1966_fu_17280_p2.read()[0].to_bool())? ap_const_lv24_800000: acc_0_V_144_fu_17260_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_acc_0_V_fu_15402_p2() {
    acc_0_V_fu_15402_p2 = (!select_ln340_2416_reg_24094.read().is_01() || !tmp_data_0_V_1611_reg_868.read().is_01())? sc_lv<24>(): (sc_bigint<24>(select_ln340_2416_reg_24094.read()) + sc_bigint<24>(tmp_data_0_V_1611_reg_868.read()));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_acc_1_V_107_fu_17400_p3() {
    acc_1_V_107_fu_17400_p3 = (!and_ln786_1968_fu_17368_p2.read()[0].is_01())? sc_lv<24>(): ((and_ln786_1968_fu_17368_p2.read()[0].to_bool())? ap_const_lv24_800000: acc_1_V_fu_17349_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_acc_1_V_108_fu_17437_p2() {
    acc_1_V_108_fu_17437_p2 = (!select_ln340_2458_reg_24219.read().is_01() || !select_ln340_2457_fu_17408_p3.read().is_01())? sc_lv<24>(): (sc_bigint<24>(select_ln340_2458_reg_24219.read()) + sc_bigint<24>(select_ln340_2457_fu_17408_p3.read()));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_acc_1_V_109_fu_17488_p3() {
    acc_1_V_109_fu_17488_p3 = (!and_ln786_1970_fu_17456_p2.read()[0].is_01())? sc_lv<24>(): ((and_ln786_1970_fu_17456_p2.read()[0].to_bool())? ap_const_lv24_800000: acc_1_V_108_fu_17437_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_acc_1_V_110_fu_17525_p2() {
    acc_1_V_110_fu_17525_p2 = (!select_ln340_2460_reg_24225.read().is_01() || !select_ln340_2459_fu_17496_p3.read().is_01())? sc_lv<24>(): (sc_bigint<24>(select_ln340_2460_reg_24225.read()) + sc_bigint<24>(select_ln340_2459_fu_17496_p3.read()));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_acc_1_V_111_fu_17576_p3() {
    acc_1_V_111_fu_17576_p3 = (!and_ln786_1972_fu_17544_p2.read()[0].is_01())? sc_lv<24>(): ((and_ln786_1972_fu_17544_p2.read()[0].to_bool())? ap_const_lv24_800000: acc_1_V_110_fu_17525_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_acc_1_V_112_fu_17613_p2() {
    acc_1_V_112_fu_17613_p2 = (!select_ln340_2462_reg_24231.read().is_01() || !select_ln340_2461_fu_17584_p3.read().is_01())? sc_lv<24>(): (sc_bigint<24>(select_ln340_2462_reg_24231.read()) + sc_bigint<24>(select_ln340_2461_fu_17584_p3.read()));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_acc_1_V_113_fu_17664_p3() {
    acc_1_V_113_fu_17664_p3 = (!and_ln786_1974_fu_17632_p2.read()[0].is_01())? sc_lv<24>(): ((and_ln786_1974_fu_17632_p2.read()[0].to_bool())? ap_const_lv24_800000: acc_1_V_112_fu_17613_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_acc_1_V_114_fu_17701_p2() {
    acc_1_V_114_fu_17701_p2 = (!select_ln340_2464_reg_24237.read().is_01() || !select_ln340_2463_fu_17672_p3.read().is_01())? sc_lv<24>(): (sc_bigint<24>(select_ln340_2464_reg_24237.read()) + sc_bigint<24>(select_ln340_2463_fu_17672_p3.read()));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_acc_1_V_115_fu_17752_p3() {
    acc_1_V_115_fu_17752_p3 = (!and_ln786_1976_fu_17720_p2.read()[0].is_01())? sc_lv<24>(): ((and_ln786_1976_fu_17720_p2.read()[0].to_bool())? ap_const_lv24_800000: acc_1_V_114_fu_17701_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_acc_1_V_116_fu_17789_p2() {
    acc_1_V_116_fu_17789_p2 = (!select_ln340_2466_reg_24243.read().is_01() || !select_ln340_2465_fu_17760_p3.read().is_01())? sc_lv<24>(): (sc_bigint<24>(select_ln340_2466_reg_24243.read()) + sc_bigint<24>(select_ln340_2465_fu_17760_p3.read()));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_acc_1_V_117_fu_17840_p3() {
    acc_1_V_117_fu_17840_p3 = (!and_ln786_1978_fu_17808_p2.read()[0].is_01())? sc_lv<24>(): ((and_ln786_1978_fu_17808_p2.read()[0].to_bool())? ap_const_lv24_800000: acc_1_V_116_fu_17789_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_acc_1_V_118_fu_17877_p2() {
    acc_1_V_118_fu_17877_p2 = (!select_ln340_2468_reg_24249.read().is_01() || !select_ln340_2467_fu_17848_p3.read().is_01())? sc_lv<24>(): (sc_bigint<24>(select_ln340_2468_reg_24249.read()) + sc_bigint<24>(select_ln340_2467_fu_17848_p3.read()));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_acc_1_V_119_fu_17928_p3() {
    acc_1_V_119_fu_17928_p3 = (!and_ln786_1980_fu_17896_p2.read()[0].is_01())? sc_lv<24>(): ((and_ln786_1980_fu_17896_p2.read()[0].to_bool())? ap_const_lv24_800000: acc_1_V_118_fu_17877_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_acc_1_V_120_fu_17965_p2() {
    acc_1_V_120_fu_17965_p2 = (!select_ln340_2470_reg_24255.read().is_01() || !select_ln340_2469_fu_17936_p3.read().is_01())? sc_lv<24>(): (sc_bigint<24>(select_ln340_2470_reg_24255.read()) + sc_bigint<24>(select_ln340_2469_fu_17936_p3.read()));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_acc_1_V_121_fu_18016_p3() {
    acc_1_V_121_fu_18016_p3 = (!and_ln786_1982_fu_17984_p2.read()[0].is_01())? sc_lv<24>(): ((and_ln786_1982_fu_17984_p2.read()[0].to_bool())? ap_const_lv24_800000: acc_1_V_120_fu_17965_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_acc_1_V_122_fu_18053_p2() {
    acc_1_V_122_fu_18053_p2 = (!select_ln340_2472_reg_24261.read().is_01() || !select_ln340_2471_fu_18024_p3.read().is_01())? sc_lv<24>(): (sc_bigint<24>(select_ln340_2472_reg_24261.read()) + sc_bigint<24>(select_ln340_2471_fu_18024_p3.read()));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_acc_1_V_123_fu_18104_p3() {
    acc_1_V_123_fu_18104_p3 = (!and_ln786_1984_fu_18072_p2.read()[0].is_01())? sc_lv<24>(): ((and_ln786_1984_fu_18072_p2.read()[0].to_bool())? ap_const_lv24_800000: acc_1_V_122_fu_18053_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_acc_1_V_124_fu_18141_p2() {
    acc_1_V_124_fu_18141_p2 = (!select_ln340_2474_reg_24267.read().is_01() || !select_ln340_2473_fu_18112_p3.read().is_01())? sc_lv<24>(): (sc_bigint<24>(select_ln340_2474_reg_24267.read()) + sc_bigint<24>(select_ln340_2473_fu_18112_p3.read()));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_acc_1_V_125_fu_18192_p3() {
    acc_1_V_125_fu_18192_p3 = (!and_ln786_1986_fu_18160_p2.read()[0].is_01())? sc_lv<24>(): ((and_ln786_1986_fu_18160_p2.read()[0].to_bool())? ap_const_lv24_800000: acc_1_V_124_fu_18141_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_acc_1_V_126_fu_18229_p2() {
    acc_1_V_126_fu_18229_p2 = (!select_ln340_2476_reg_24273.read().is_01() || !select_ln340_2475_fu_18200_p3.read().is_01())? sc_lv<24>(): (sc_bigint<24>(select_ln340_2476_reg_24273.read()) + sc_bigint<24>(select_ln340_2475_fu_18200_p3.read()));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_acc_1_V_127_fu_18280_p3() {
    acc_1_V_127_fu_18280_p3 = (!and_ln786_1988_fu_18248_p2.read()[0].is_01())? sc_lv<24>(): ((and_ln786_1988_fu_18248_p2.read()[0].to_bool())? ap_const_lv24_800000: acc_1_V_126_fu_18229_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_acc_1_V_128_fu_18317_p2() {
    acc_1_V_128_fu_18317_p2 = (!select_ln340_2478_reg_24279.read().is_01() || !select_ln340_2477_fu_18288_p3.read().is_01())? sc_lv<24>(): (sc_bigint<24>(select_ln340_2478_reg_24279.read()) + sc_bigint<24>(select_ln340_2477_fu_18288_p3.read()));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_acc_1_V_129_fu_18368_p3() {
    acc_1_V_129_fu_18368_p3 = (!and_ln786_1990_fu_18336_p2.read()[0].is_01())? sc_lv<24>(): ((and_ln786_1990_fu_18336_p2.read()[0].to_bool())? ap_const_lv24_800000: acc_1_V_128_fu_18317_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_acc_1_V_130_fu_18405_p2() {
    acc_1_V_130_fu_18405_p2 = (!select_ln340_2480_reg_24285.read().is_01() || !select_ln340_2479_fu_18376_p3.read().is_01())? sc_lv<24>(): (sc_bigint<24>(select_ln340_2480_reg_24285.read()) + sc_bigint<24>(select_ln340_2479_fu_18376_p3.read()));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_acc_1_V_131_fu_18456_p3() {
    acc_1_V_131_fu_18456_p3 = (!and_ln786_1992_fu_18424_p2.read()[0].is_01())? sc_lv<24>(): ((and_ln786_1992_fu_18424_p2.read()[0].to_bool())? ap_const_lv24_800000: acc_1_V_130_fu_18405_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_acc_1_V_132_fu_18493_p2() {
    acc_1_V_132_fu_18493_p2 = (!select_ln340_2482_reg_24291.read().is_01() || !select_ln340_2481_fu_18464_p3.read().is_01())? sc_lv<24>(): (sc_bigint<24>(select_ln340_2482_reg_24291.read()) + sc_bigint<24>(select_ln340_2481_fu_18464_p3.read()));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_acc_1_V_133_fu_18544_p3() {
    acc_1_V_133_fu_18544_p3 = (!and_ln786_1994_fu_18512_p2.read()[0].is_01())? sc_lv<24>(): ((and_ln786_1994_fu_18512_p2.read()[0].to_bool())? ap_const_lv24_800000: acc_1_V_132_fu_18493_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_acc_1_V_134_fu_18581_p2() {
    acc_1_V_134_fu_18581_p2 = (!select_ln340_2484_reg_24297.read().is_01() || !select_ln340_2483_fu_18552_p3.read().is_01())? sc_lv<24>(): (sc_bigint<24>(select_ln340_2484_reg_24297.read()) + sc_bigint<24>(select_ln340_2483_fu_18552_p3.read()));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_acc_1_V_135_fu_18632_p3() {
    acc_1_V_135_fu_18632_p3 = (!and_ln786_1996_fu_18600_p2.read()[0].is_01())? sc_lv<24>(): ((and_ln786_1996_fu_18600_p2.read()[0].to_bool())? ap_const_lv24_800000: acc_1_V_134_fu_18581_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_acc_1_V_136_fu_18669_p2() {
    acc_1_V_136_fu_18669_p2 = (!select_ln340_2486_reg_24303.read().is_01() || !select_ln340_2485_fu_18640_p3.read().is_01())? sc_lv<24>(): (sc_bigint<24>(select_ln340_2486_reg_24303.read()) + sc_bigint<24>(select_ln340_2485_fu_18640_p3.read()));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_acc_1_V_137_fu_18720_p3() {
    acc_1_V_137_fu_18720_p3 = (!and_ln786_1998_fu_18688_p2.read()[0].is_01())? sc_lv<24>(): ((and_ln786_1998_fu_18688_p2.read()[0].to_bool())? ap_const_lv24_800000: acc_1_V_136_fu_18669_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_acc_1_V_138_fu_18757_p2() {
    acc_1_V_138_fu_18757_p2 = (!select_ln340_2488_reg_24309.read().is_01() || !select_ln340_2487_fu_18728_p3.read().is_01())? sc_lv<24>(): (sc_bigint<24>(select_ln340_2488_reg_24309.read()) + sc_bigint<24>(select_ln340_2487_fu_18728_p3.read()));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_acc_1_V_139_fu_18808_p3() {
    acc_1_V_139_fu_18808_p3 = (!and_ln786_2000_fu_18776_p2.read()[0].is_01())? sc_lv<24>(): ((and_ln786_2000_fu_18776_p2.read()[0].to_bool())? ap_const_lv24_800000: acc_1_V_138_fu_18757_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_acc_1_V_140_fu_18845_p2() {
    acc_1_V_140_fu_18845_p2 = (!select_ln340_2490_reg_24315.read().is_01() || !select_ln340_2489_fu_18816_p3.read().is_01())? sc_lv<24>(): (sc_bigint<24>(select_ln340_2490_reg_24315.read()) + sc_bigint<24>(select_ln340_2489_fu_18816_p3.read()));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_acc_1_V_141_fu_18896_p3() {
    acc_1_V_141_fu_18896_p3 = (!and_ln786_2002_fu_18864_p2.read()[0].is_01())? sc_lv<24>(): ((and_ln786_2002_fu_18864_p2.read()[0].to_bool())? ap_const_lv24_800000: acc_1_V_140_fu_18845_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_acc_1_V_142_fu_18933_p2() {
    acc_1_V_142_fu_18933_p2 = (!select_ln340_2492_reg_24321.read().is_01() || !select_ln340_2491_fu_18904_p3.read().is_01())? sc_lv<24>(): (sc_bigint<24>(select_ln340_2492_reg_24321.read()) + sc_bigint<24>(select_ln340_2491_fu_18904_p3.read()));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_acc_1_V_143_fu_18984_p3() {
    acc_1_V_143_fu_18984_p3 = (!and_ln786_2004_fu_18952_p2.read()[0].is_01())? sc_lv<24>(): ((and_ln786_2004_fu_18952_p2.read()[0].to_bool())? ap_const_lv24_800000: acc_1_V_142_fu_18933_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_acc_1_V_144_fu_19191_p2() {
    acc_1_V_144_fu_19191_p2 = (!select_ln340_2494_fu_19161_p3.read().is_01() || !select_ln340_2493_fu_18992_p3.read().is_01())? sc_lv<24>(): (sc_bigint<24>(select_ln340_2494_fu_19161_p3.read()) + sc_bigint<24>(select_ln340_2493_fu_18992_p3.read()));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_acc_1_V_145_fu_19243_p3() {
    acc_1_V_145_fu_19243_p3 = (!and_ln786_2006_fu_19211_p2.read()[0].is_01())? sc_lv<24>(): ((and_ln786_2006_fu_19211_p2.read()[0].to_bool())? ap_const_lv24_800000: acc_1_V_144_fu_19191_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_acc_1_V_fu_17349_p2() {
    acc_1_V_fu_17349_p2 = (!select_ln340_2456_reg_24213.read().is_01() || !tmp_data_1_V_139_reg_879.read().is_01())? sc_lv<24>(): (sc_bigint<24>(select_ln340_2456_reg_24213.read()) + sc_bigint<24>(tmp_data_1_V_139_reg_879.read()));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_acc_2_V_107_fu_19331_p3() {
    acc_2_V_107_fu_19331_p3 = (!and_ln786_2008_fu_19299_p2.read()[0].is_01())? sc_lv<24>(): ((and_ln786_2008_fu_19299_p2.read()[0].to_bool())? ap_const_lv24_800000: acc_2_V_fu_19280_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_acc_2_V_108_fu_19368_p2() {
    acc_2_V_108_fu_19368_p2 = (!select_ln340_2498_reg_24338.read().is_01() || !select_ln340_2497_fu_19339_p3.read().is_01())? sc_lv<24>(): (sc_bigint<24>(select_ln340_2498_reg_24338.read()) + sc_bigint<24>(select_ln340_2497_fu_19339_p3.read()));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_acc_2_V_109_fu_19419_p3() {
    acc_2_V_109_fu_19419_p3 = (!and_ln786_2010_fu_19387_p2.read()[0].is_01())? sc_lv<24>(): ((and_ln786_2010_fu_19387_p2.read()[0].to_bool())? ap_const_lv24_800000: acc_2_V_108_fu_19368_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_acc_2_V_110_fu_19456_p2() {
    acc_2_V_110_fu_19456_p2 = (!select_ln340_2500_reg_24344.read().is_01() || !select_ln340_2499_fu_19427_p3.read().is_01())? sc_lv<24>(): (sc_bigint<24>(select_ln340_2500_reg_24344.read()) + sc_bigint<24>(select_ln340_2499_fu_19427_p3.read()));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_acc_2_V_111_fu_19507_p3() {
    acc_2_V_111_fu_19507_p3 = (!and_ln786_2012_fu_19475_p2.read()[0].is_01())? sc_lv<24>(): ((and_ln786_2012_fu_19475_p2.read()[0].to_bool())? ap_const_lv24_800000: acc_2_V_110_fu_19456_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_acc_2_V_112_fu_19544_p2() {
    acc_2_V_112_fu_19544_p2 = (!select_ln340_2502_reg_24350.read().is_01() || !select_ln340_2501_fu_19515_p3.read().is_01())? sc_lv<24>(): (sc_bigint<24>(select_ln340_2502_reg_24350.read()) + sc_bigint<24>(select_ln340_2501_fu_19515_p3.read()));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_acc_2_V_113_fu_19595_p3() {
    acc_2_V_113_fu_19595_p3 = (!and_ln786_2014_fu_19563_p2.read()[0].is_01())? sc_lv<24>(): ((and_ln786_2014_fu_19563_p2.read()[0].to_bool())? ap_const_lv24_800000: acc_2_V_112_fu_19544_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_acc_2_V_114_fu_19632_p2() {
    acc_2_V_114_fu_19632_p2 = (!select_ln340_2504_reg_24356.read().is_01() || !select_ln340_2503_fu_19603_p3.read().is_01())? sc_lv<24>(): (sc_bigint<24>(select_ln340_2504_reg_24356.read()) + sc_bigint<24>(select_ln340_2503_fu_19603_p3.read()));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_acc_2_V_115_fu_19683_p3() {
    acc_2_V_115_fu_19683_p3 = (!and_ln786_2016_fu_19651_p2.read()[0].is_01())? sc_lv<24>(): ((and_ln786_2016_fu_19651_p2.read()[0].to_bool())? ap_const_lv24_800000: acc_2_V_114_fu_19632_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_acc_2_V_116_fu_19720_p2() {
    acc_2_V_116_fu_19720_p2 = (!select_ln340_2506_reg_24362.read().is_01() || !select_ln340_2505_fu_19691_p3.read().is_01())? sc_lv<24>(): (sc_bigint<24>(select_ln340_2506_reg_24362.read()) + sc_bigint<24>(select_ln340_2505_fu_19691_p3.read()));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_acc_2_V_117_fu_19771_p3() {
    acc_2_V_117_fu_19771_p3 = (!and_ln786_2018_fu_19739_p2.read()[0].is_01())? sc_lv<24>(): ((and_ln786_2018_fu_19739_p2.read()[0].to_bool())? ap_const_lv24_800000: acc_2_V_116_fu_19720_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_acc_2_V_118_fu_19808_p2() {
    acc_2_V_118_fu_19808_p2 = (!select_ln340_2508_reg_24368.read().is_01() || !select_ln340_2507_fu_19779_p3.read().is_01())? sc_lv<24>(): (sc_bigint<24>(select_ln340_2508_reg_24368.read()) + sc_bigint<24>(select_ln340_2507_fu_19779_p3.read()));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_acc_2_V_119_fu_19859_p3() {
    acc_2_V_119_fu_19859_p3 = (!and_ln786_2020_fu_19827_p2.read()[0].is_01())? sc_lv<24>(): ((and_ln786_2020_fu_19827_p2.read()[0].to_bool())? ap_const_lv24_800000: acc_2_V_118_fu_19808_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_acc_2_V_120_fu_19896_p2() {
    acc_2_V_120_fu_19896_p2 = (!select_ln340_2510_reg_24374.read().is_01() || !select_ln340_2509_fu_19867_p3.read().is_01())? sc_lv<24>(): (sc_bigint<24>(select_ln340_2510_reg_24374.read()) + sc_bigint<24>(select_ln340_2509_fu_19867_p3.read()));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_acc_2_V_121_fu_19947_p3() {
    acc_2_V_121_fu_19947_p3 = (!and_ln786_2022_fu_19915_p2.read()[0].is_01())? sc_lv<24>(): ((and_ln786_2022_fu_19915_p2.read()[0].to_bool())? ap_const_lv24_800000: acc_2_V_120_fu_19896_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_acc_2_V_122_fu_19984_p2() {
    acc_2_V_122_fu_19984_p2 = (!select_ln340_2512_reg_24380.read().is_01() || !select_ln340_2511_fu_19955_p3.read().is_01())? sc_lv<24>(): (sc_bigint<24>(select_ln340_2512_reg_24380.read()) + sc_bigint<24>(select_ln340_2511_fu_19955_p3.read()));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_acc_2_V_123_fu_20035_p3() {
    acc_2_V_123_fu_20035_p3 = (!and_ln786_2024_fu_20003_p2.read()[0].is_01())? sc_lv<24>(): ((and_ln786_2024_fu_20003_p2.read()[0].to_bool())? ap_const_lv24_800000: acc_2_V_122_fu_19984_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_acc_2_V_124_fu_20072_p2() {
    acc_2_V_124_fu_20072_p2 = (!select_ln340_2514_reg_24386.read().is_01() || !select_ln340_2513_fu_20043_p3.read().is_01())? sc_lv<24>(): (sc_bigint<24>(select_ln340_2514_reg_24386.read()) + sc_bigint<24>(select_ln340_2513_fu_20043_p3.read()));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_acc_2_V_125_fu_20123_p3() {
    acc_2_V_125_fu_20123_p3 = (!and_ln786_2026_fu_20091_p2.read()[0].is_01())? sc_lv<24>(): ((and_ln786_2026_fu_20091_p2.read()[0].to_bool())? ap_const_lv24_800000: acc_2_V_124_fu_20072_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_acc_2_V_126_fu_20160_p2() {
    acc_2_V_126_fu_20160_p2 = (!select_ln340_2516_reg_24392.read().is_01() || !select_ln340_2515_fu_20131_p3.read().is_01())? sc_lv<24>(): (sc_bigint<24>(select_ln340_2516_reg_24392.read()) + sc_bigint<24>(select_ln340_2515_fu_20131_p3.read()));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_acc_2_V_127_fu_20211_p3() {
    acc_2_V_127_fu_20211_p3 = (!and_ln786_2028_fu_20179_p2.read()[0].is_01())? sc_lv<24>(): ((and_ln786_2028_fu_20179_p2.read()[0].to_bool())? ap_const_lv24_800000: acc_2_V_126_fu_20160_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_acc_2_V_128_fu_20248_p2() {
    acc_2_V_128_fu_20248_p2 = (!select_ln340_2518_reg_24398.read().is_01() || !select_ln340_2517_fu_20219_p3.read().is_01())? sc_lv<24>(): (sc_bigint<24>(select_ln340_2518_reg_24398.read()) + sc_bigint<24>(select_ln340_2517_fu_20219_p3.read()));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_acc_2_V_129_fu_20299_p3() {
    acc_2_V_129_fu_20299_p3 = (!and_ln786_2030_fu_20267_p2.read()[0].is_01())? sc_lv<24>(): ((and_ln786_2030_fu_20267_p2.read()[0].to_bool())? ap_const_lv24_800000: acc_2_V_128_fu_20248_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_acc_2_V_130_fu_20336_p2() {
    acc_2_V_130_fu_20336_p2 = (!select_ln340_2520_reg_24404.read().is_01() || !select_ln340_2519_fu_20307_p3.read().is_01())? sc_lv<24>(): (sc_bigint<24>(select_ln340_2520_reg_24404.read()) + sc_bigint<24>(select_ln340_2519_fu_20307_p3.read()));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_acc_2_V_131_fu_20387_p3() {
    acc_2_V_131_fu_20387_p3 = (!and_ln786_2032_fu_20355_p2.read()[0].is_01())? sc_lv<24>(): ((and_ln786_2032_fu_20355_p2.read()[0].to_bool())? ap_const_lv24_800000: acc_2_V_130_fu_20336_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_acc_2_V_132_fu_20424_p2() {
    acc_2_V_132_fu_20424_p2 = (!select_ln340_2522_reg_24410.read().is_01() || !select_ln340_2521_fu_20395_p3.read().is_01())? sc_lv<24>(): (sc_bigint<24>(select_ln340_2522_reg_24410.read()) + sc_bigint<24>(select_ln340_2521_fu_20395_p3.read()));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_acc_2_V_133_fu_20475_p3() {
    acc_2_V_133_fu_20475_p3 = (!and_ln786_2034_fu_20443_p2.read()[0].is_01())? sc_lv<24>(): ((and_ln786_2034_fu_20443_p2.read()[0].to_bool())? ap_const_lv24_800000: acc_2_V_132_fu_20424_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_acc_2_V_134_fu_20512_p2() {
    acc_2_V_134_fu_20512_p2 = (!select_ln340_2524_reg_24416.read().is_01() || !select_ln340_2523_fu_20483_p3.read().is_01())? sc_lv<24>(): (sc_bigint<24>(select_ln340_2524_reg_24416.read()) + sc_bigint<24>(select_ln340_2523_fu_20483_p3.read()));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_acc_2_V_135_fu_20563_p3() {
    acc_2_V_135_fu_20563_p3 = (!and_ln786_2036_fu_20531_p2.read()[0].is_01())? sc_lv<24>(): ((and_ln786_2036_fu_20531_p2.read()[0].to_bool())? ap_const_lv24_800000: acc_2_V_134_fu_20512_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_acc_2_V_136_fu_20600_p2() {
    acc_2_V_136_fu_20600_p2 = (!select_ln340_2526_reg_24422.read().is_01() || !select_ln340_2525_fu_20571_p3.read().is_01())? sc_lv<24>(): (sc_bigint<24>(select_ln340_2526_reg_24422.read()) + sc_bigint<24>(select_ln340_2525_fu_20571_p3.read()));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_acc_2_V_137_fu_20651_p3() {
    acc_2_V_137_fu_20651_p3 = (!and_ln786_2038_fu_20619_p2.read()[0].is_01())? sc_lv<24>(): ((and_ln786_2038_fu_20619_p2.read()[0].to_bool())? ap_const_lv24_800000: acc_2_V_136_fu_20600_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_acc_2_V_138_fu_20688_p2() {
    acc_2_V_138_fu_20688_p2 = (!select_ln340_2528_reg_24428.read().is_01() || !select_ln340_2527_fu_20659_p3.read().is_01())? sc_lv<24>(): (sc_bigint<24>(select_ln340_2528_reg_24428.read()) + sc_bigint<24>(select_ln340_2527_fu_20659_p3.read()));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_acc_2_V_139_fu_20739_p3() {
    acc_2_V_139_fu_20739_p3 = (!and_ln786_2040_fu_20707_p2.read()[0].is_01())? sc_lv<24>(): ((and_ln786_2040_fu_20707_p2.read()[0].to_bool())? ap_const_lv24_800000: acc_2_V_138_fu_20688_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_acc_2_V_140_fu_20776_p2() {
    acc_2_V_140_fu_20776_p2 = (!select_ln340_2530_reg_24434.read().is_01() || !select_ln340_2529_fu_20747_p3.read().is_01())? sc_lv<24>(): (sc_bigint<24>(select_ln340_2530_reg_24434.read()) + sc_bigint<24>(select_ln340_2529_fu_20747_p3.read()));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_acc_2_V_141_fu_20827_p3() {
    acc_2_V_141_fu_20827_p3 = (!and_ln786_2042_fu_20795_p2.read()[0].is_01())? sc_lv<24>(): ((and_ln786_2042_fu_20795_p2.read()[0].to_bool())? ap_const_lv24_800000: acc_2_V_140_fu_20776_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_acc_2_V_142_fu_20864_p2() {
    acc_2_V_142_fu_20864_p2 = (!select_ln340_2532_reg_24440.read().is_01() || !select_ln340_2531_fu_20835_p3.read().is_01())? sc_lv<24>(): (sc_bigint<24>(select_ln340_2532_reg_24440.read()) + sc_bigint<24>(select_ln340_2531_fu_20835_p3.read()));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_acc_2_V_143_fu_20915_p3() {
    acc_2_V_143_fu_20915_p3 = (!and_ln786_2044_fu_20883_p2.read()[0].is_01())? sc_lv<24>(): ((and_ln786_2044_fu_20883_p2.read()[0].to_bool())? ap_const_lv24_800000: acc_2_V_142_fu_20864_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_acc_2_V_144_fu_21122_p2() {
    acc_2_V_144_fu_21122_p2 = (!select_ln340_2534_fu_21092_p3.read().is_01() || !select_ln340_2533_fu_20923_p3.read().is_01())? sc_lv<24>(): (sc_bigint<24>(select_ln340_2534_fu_21092_p3.read()) + sc_bigint<24>(select_ln340_2533_fu_20923_p3.read()));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_acc_2_V_145_fu_21174_p3() {
    acc_2_V_145_fu_21174_p3 = (!and_ln786_2046_fu_21142_p2.read()[0].is_01())? sc_lv<24>(): ((and_ln786_2046_fu_21142_p2.read()[0].to_bool())? ap_const_lv24_800000: acc_2_V_144_fu_21122_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_acc_2_V_fu_19280_p2() {
    acc_2_V_fu_19280_p2 = (!select_ln340_2496_reg_24332.read().is_01() || !tmp_data_2_V_137_reg_890.read().is_01())? sc_lv<24>(): (sc_bigint<24>(select_ln340_2496_reg_24332.read()) + sc_bigint<24>(tmp_data_2_V_137_reg_890.read()));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_acc_3_V_107_fu_21262_p3() {
    acc_3_V_107_fu_21262_p3 = (!and_ln786_2048_fu_21230_p2.read()[0].is_01())? sc_lv<24>(): ((and_ln786_2048_fu_21230_p2.read()[0].to_bool())? ap_const_lv24_800000: acc_3_V_fu_21211_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_acc_3_V_108_fu_21299_p2() {
    acc_3_V_108_fu_21299_p2 = (!select_ln340_2538_reg_24457.read().is_01() || !select_ln340_2537_fu_21270_p3.read().is_01())? sc_lv<24>(): (sc_bigint<24>(select_ln340_2538_reg_24457.read()) + sc_bigint<24>(select_ln340_2537_fu_21270_p3.read()));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_acc_3_V_109_fu_21350_p3() {
    acc_3_V_109_fu_21350_p3 = (!and_ln786_2050_fu_21318_p2.read()[0].is_01())? sc_lv<24>(): ((and_ln786_2050_fu_21318_p2.read()[0].to_bool())? ap_const_lv24_800000: acc_3_V_108_fu_21299_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_acc_3_V_110_fu_21387_p2() {
    acc_3_V_110_fu_21387_p2 = (!select_ln340_2540_reg_24463.read().is_01() || !select_ln340_2539_fu_21358_p3.read().is_01())? sc_lv<24>(): (sc_bigint<24>(select_ln340_2540_reg_24463.read()) + sc_bigint<24>(select_ln340_2539_fu_21358_p3.read()));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_acc_3_V_111_fu_21438_p3() {
    acc_3_V_111_fu_21438_p3 = (!and_ln786_2052_fu_21406_p2.read()[0].is_01())? sc_lv<24>(): ((and_ln786_2052_fu_21406_p2.read()[0].to_bool())? ap_const_lv24_800000: acc_3_V_110_fu_21387_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_acc_3_V_112_fu_21475_p2() {
    acc_3_V_112_fu_21475_p2 = (!select_ln340_2542_reg_24469.read().is_01() || !select_ln340_2541_fu_21446_p3.read().is_01())? sc_lv<24>(): (sc_bigint<24>(select_ln340_2542_reg_24469.read()) + sc_bigint<24>(select_ln340_2541_fu_21446_p3.read()));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_acc_3_V_113_fu_21526_p3() {
    acc_3_V_113_fu_21526_p3 = (!and_ln786_2054_fu_21494_p2.read()[0].is_01())? sc_lv<24>(): ((and_ln786_2054_fu_21494_p2.read()[0].to_bool())? ap_const_lv24_800000: acc_3_V_112_fu_21475_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_acc_3_V_114_fu_21563_p2() {
    acc_3_V_114_fu_21563_p2 = (!select_ln340_2544_reg_24475.read().is_01() || !select_ln340_2543_fu_21534_p3.read().is_01())? sc_lv<24>(): (sc_bigint<24>(select_ln340_2544_reg_24475.read()) + sc_bigint<24>(select_ln340_2543_fu_21534_p3.read()));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_acc_3_V_115_fu_21614_p3() {
    acc_3_V_115_fu_21614_p3 = (!and_ln786_2056_fu_21582_p2.read()[0].is_01())? sc_lv<24>(): ((and_ln786_2056_fu_21582_p2.read()[0].to_bool())? ap_const_lv24_800000: acc_3_V_114_fu_21563_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_acc_3_V_116_fu_21651_p2() {
    acc_3_V_116_fu_21651_p2 = (!select_ln340_2546_reg_24481.read().is_01() || !select_ln340_2545_fu_21622_p3.read().is_01())? sc_lv<24>(): (sc_bigint<24>(select_ln340_2546_reg_24481.read()) + sc_bigint<24>(select_ln340_2545_fu_21622_p3.read()));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_acc_3_V_117_fu_21702_p3() {
    acc_3_V_117_fu_21702_p3 = (!and_ln786_2058_fu_21670_p2.read()[0].is_01())? sc_lv<24>(): ((and_ln786_2058_fu_21670_p2.read()[0].to_bool())? ap_const_lv24_800000: acc_3_V_116_fu_21651_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_acc_3_V_118_fu_21739_p2() {
    acc_3_V_118_fu_21739_p2 = (!select_ln340_2548_reg_24487.read().is_01() || !select_ln340_2547_fu_21710_p3.read().is_01())? sc_lv<24>(): (sc_bigint<24>(select_ln340_2548_reg_24487.read()) + sc_bigint<24>(select_ln340_2547_fu_21710_p3.read()));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_acc_3_V_119_fu_21790_p3() {
    acc_3_V_119_fu_21790_p3 = (!and_ln786_2060_fu_21758_p2.read()[0].is_01())? sc_lv<24>(): ((and_ln786_2060_fu_21758_p2.read()[0].to_bool())? ap_const_lv24_800000: acc_3_V_118_fu_21739_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_acc_3_V_120_fu_21827_p2() {
    acc_3_V_120_fu_21827_p2 = (!select_ln340_2550_reg_24493.read().is_01() || !select_ln340_2549_fu_21798_p3.read().is_01())? sc_lv<24>(): (sc_bigint<24>(select_ln340_2550_reg_24493.read()) + sc_bigint<24>(select_ln340_2549_fu_21798_p3.read()));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_acc_3_V_121_fu_21878_p3() {
    acc_3_V_121_fu_21878_p3 = (!and_ln786_2062_fu_21846_p2.read()[0].is_01())? sc_lv<24>(): ((and_ln786_2062_fu_21846_p2.read()[0].to_bool())? ap_const_lv24_800000: acc_3_V_120_fu_21827_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_acc_3_V_122_fu_21915_p2() {
    acc_3_V_122_fu_21915_p2 = (!select_ln340_2552_reg_24499.read().is_01() || !select_ln340_2551_fu_21886_p3.read().is_01())? sc_lv<24>(): (sc_bigint<24>(select_ln340_2552_reg_24499.read()) + sc_bigint<24>(select_ln340_2551_fu_21886_p3.read()));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_acc_3_V_123_fu_21966_p3() {
    acc_3_V_123_fu_21966_p3 = (!and_ln786_2064_fu_21934_p2.read()[0].is_01())? sc_lv<24>(): ((and_ln786_2064_fu_21934_p2.read()[0].to_bool())? ap_const_lv24_800000: acc_3_V_122_fu_21915_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_acc_3_V_124_fu_22003_p2() {
    acc_3_V_124_fu_22003_p2 = (!select_ln340_2554_reg_24505.read().is_01() || !select_ln340_2553_fu_21974_p3.read().is_01())? sc_lv<24>(): (sc_bigint<24>(select_ln340_2554_reg_24505.read()) + sc_bigint<24>(select_ln340_2553_fu_21974_p3.read()));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_acc_3_V_125_fu_22054_p3() {
    acc_3_V_125_fu_22054_p3 = (!and_ln786_2066_fu_22022_p2.read()[0].is_01())? sc_lv<24>(): ((and_ln786_2066_fu_22022_p2.read()[0].to_bool())? ap_const_lv24_800000: acc_3_V_124_fu_22003_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_acc_3_V_126_fu_22091_p2() {
    acc_3_V_126_fu_22091_p2 = (!select_ln340_2556_reg_24511.read().is_01() || !select_ln340_2555_fu_22062_p3.read().is_01())? sc_lv<24>(): (sc_bigint<24>(select_ln340_2556_reg_24511.read()) + sc_bigint<24>(select_ln340_2555_fu_22062_p3.read()));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_acc_3_V_127_fu_22142_p3() {
    acc_3_V_127_fu_22142_p3 = (!and_ln786_2068_fu_22110_p2.read()[0].is_01())? sc_lv<24>(): ((and_ln786_2068_fu_22110_p2.read()[0].to_bool())? ap_const_lv24_800000: acc_3_V_126_fu_22091_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_acc_3_V_128_fu_22179_p2() {
    acc_3_V_128_fu_22179_p2 = (!select_ln340_2558_reg_24517.read().is_01() || !select_ln340_2557_fu_22150_p3.read().is_01())? sc_lv<24>(): (sc_bigint<24>(select_ln340_2558_reg_24517.read()) + sc_bigint<24>(select_ln340_2557_fu_22150_p3.read()));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_acc_3_V_129_fu_22230_p3() {
    acc_3_V_129_fu_22230_p3 = (!and_ln786_2070_fu_22198_p2.read()[0].is_01())? sc_lv<24>(): ((and_ln786_2070_fu_22198_p2.read()[0].to_bool())? ap_const_lv24_800000: acc_3_V_128_fu_22179_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_acc_3_V_130_fu_22267_p2() {
    acc_3_V_130_fu_22267_p2 = (!select_ln340_2560_reg_24523.read().is_01() || !select_ln340_2559_fu_22238_p3.read().is_01())? sc_lv<24>(): (sc_bigint<24>(select_ln340_2560_reg_24523.read()) + sc_bigint<24>(select_ln340_2559_fu_22238_p3.read()));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_acc_3_V_131_fu_22318_p3() {
    acc_3_V_131_fu_22318_p3 = (!and_ln786_2072_fu_22286_p2.read()[0].is_01())? sc_lv<24>(): ((and_ln786_2072_fu_22286_p2.read()[0].to_bool())? ap_const_lv24_800000: acc_3_V_130_fu_22267_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_acc_3_V_132_fu_22355_p2() {
    acc_3_V_132_fu_22355_p2 = (!select_ln340_2562_reg_24529.read().is_01() || !select_ln340_2561_fu_22326_p3.read().is_01())? sc_lv<24>(): (sc_bigint<24>(select_ln340_2562_reg_24529.read()) + sc_bigint<24>(select_ln340_2561_fu_22326_p3.read()));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_acc_3_V_133_fu_22406_p3() {
    acc_3_V_133_fu_22406_p3 = (!and_ln786_2074_fu_22374_p2.read()[0].is_01())? sc_lv<24>(): ((and_ln786_2074_fu_22374_p2.read()[0].to_bool())? ap_const_lv24_800000: acc_3_V_132_fu_22355_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_acc_3_V_134_fu_22443_p2() {
    acc_3_V_134_fu_22443_p2 = (!select_ln340_2564_reg_24535.read().is_01() || !select_ln340_2563_fu_22414_p3.read().is_01())? sc_lv<24>(): (sc_bigint<24>(select_ln340_2564_reg_24535.read()) + sc_bigint<24>(select_ln340_2563_fu_22414_p3.read()));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_acc_3_V_135_fu_22494_p3() {
    acc_3_V_135_fu_22494_p3 = (!and_ln786_2076_fu_22462_p2.read()[0].is_01())? sc_lv<24>(): ((and_ln786_2076_fu_22462_p2.read()[0].to_bool())? ap_const_lv24_800000: acc_3_V_134_fu_22443_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_acc_3_V_136_fu_22531_p2() {
    acc_3_V_136_fu_22531_p2 = (!select_ln340_2566_reg_24541.read().is_01() || !select_ln340_2565_fu_22502_p3.read().is_01())? sc_lv<24>(): (sc_bigint<24>(select_ln340_2566_reg_24541.read()) + sc_bigint<24>(select_ln340_2565_fu_22502_p3.read()));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_acc_3_V_137_fu_22582_p3() {
    acc_3_V_137_fu_22582_p3 = (!and_ln786_2078_fu_22550_p2.read()[0].is_01())? sc_lv<24>(): ((and_ln786_2078_fu_22550_p2.read()[0].to_bool())? ap_const_lv24_800000: acc_3_V_136_fu_22531_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_acc_3_V_138_fu_22619_p2() {
    acc_3_V_138_fu_22619_p2 = (!select_ln340_2568_reg_24547.read().is_01() || !select_ln340_2567_fu_22590_p3.read().is_01())? sc_lv<24>(): (sc_bigint<24>(select_ln340_2568_reg_24547.read()) + sc_bigint<24>(select_ln340_2567_fu_22590_p3.read()));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_acc_3_V_139_fu_22670_p3() {
    acc_3_V_139_fu_22670_p3 = (!and_ln786_2080_fu_22638_p2.read()[0].is_01())? sc_lv<24>(): ((and_ln786_2080_fu_22638_p2.read()[0].to_bool())? ap_const_lv24_800000: acc_3_V_138_fu_22619_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_acc_3_V_140_fu_22707_p2() {
    acc_3_V_140_fu_22707_p2 = (!select_ln340_2570_reg_24553.read().is_01() || !select_ln340_2569_fu_22678_p3.read().is_01())? sc_lv<24>(): (sc_bigint<24>(select_ln340_2570_reg_24553.read()) + sc_bigint<24>(select_ln340_2569_fu_22678_p3.read()));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_acc_3_V_141_fu_22758_p3() {
    acc_3_V_141_fu_22758_p3 = (!and_ln786_2082_fu_22726_p2.read()[0].is_01())? sc_lv<24>(): ((and_ln786_2082_fu_22726_p2.read()[0].to_bool())? ap_const_lv24_800000: acc_3_V_140_fu_22707_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_acc_3_V_142_fu_22795_p2() {
    acc_3_V_142_fu_22795_p2 = (!select_ln340_2572_reg_24559.read().is_01() || !select_ln340_2571_fu_22766_p3.read().is_01())? sc_lv<24>(): (sc_bigint<24>(select_ln340_2572_reg_24559.read()) + sc_bigint<24>(select_ln340_2571_fu_22766_p3.read()));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_acc_3_V_143_fu_22846_p3() {
    acc_3_V_143_fu_22846_p3 = (!and_ln786_2084_fu_22814_p2.read()[0].is_01())? sc_lv<24>(): ((and_ln786_2084_fu_22814_p2.read()[0].to_bool())? ap_const_lv24_800000: acc_3_V_142_fu_22795_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_acc_3_V_144_fu_23053_p2() {
    acc_3_V_144_fu_23053_p2 = (!select_ln340_2574_fu_23023_p3.read().is_01() || !select_ln340_2573_fu_22854_p3.read().is_01())? sc_lv<24>(): (sc_bigint<24>(select_ln340_2574_fu_23023_p3.read()) + sc_bigint<24>(select_ln340_2573_fu_22854_p3.read()));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_acc_3_V_145_fu_23105_p3() {
    acc_3_V_145_fu_23105_p3 = (!and_ln786_2086_fu_23073_p2.read()[0].is_01())? sc_lv<24>(): ((and_ln786_2086_fu_23073_p2.read()[0].to_bool())? ap_const_lv24_800000: acc_3_V_144_fu_23053_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_acc_3_V_fu_21211_p2() {
    acc_3_V_fu_21211_p2 = (!select_ln340_2536_reg_24451.read().is_01() || !tmp_data_3_V_135_reg_901.read().is_01())? sc_lv<24>(): (sc_bigint<24>(select_ln340_2536_reg_24451.read()) + sc_bigint<24>(tmp_data_3_V_135_reg_901.read()));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_add_ln1192_694_fu_15476_p2() {
    add_ln1192_694_fu_15476_p2 = (!sext_ln703_1383_fu_15469_p1.read().is_01() || !sext_ln703_1384_fu_15473_p1.read().is_01())? sc_lv<25>(): (sc_bigint<25>(sext_ln703_1383_fu_15469_p1.read()) + sc_bigint<25>(sext_ln703_1384_fu_15473_p1.read()));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_add_ln1192_695_fu_15564_p2() {
    add_ln1192_695_fu_15564_p2 = (!sext_ln703_1385_fu_15557_p1.read().is_01() || !sext_ln703_1386_fu_15561_p1.read().is_01())? sc_lv<25>(): (sc_bigint<25>(sext_ln703_1385_fu_15557_p1.read()) + sc_bigint<25>(sext_ln703_1386_fu_15561_p1.read()));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_add_ln1192_696_fu_15652_p2() {
    add_ln1192_696_fu_15652_p2 = (!sext_ln703_1387_fu_15645_p1.read().is_01() || !sext_ln703_1388_fu_15649_p1.read().is_01())? sc_lv<25>(): (sc_bigint<25>(sext_ln703_1387_fu_15645_p1.read()) + sc_bigint<25>(sext_ln703_1388_fu_15649_p1.read()));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_add_ln1192_697_fu_15740_p2() {
    add_ln1192_697_fu_15740_p2 = (!sext_ln703_1389_fu_15733_p1.read().is_01() || !sext_ln703_1390_fu_15737_p1.read().is_01())? sc_lv<25>(): (sc_bigint<25>(sext_ln703_1389_fu_15733_p1.read()) + sc_bigint<25>(sext_ln703_1390_fu_15737_p1.read()));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_add_ln1192_698_fu_15828_p2() {
    add_ln1192_698_fu_15828_p2 = (!sext_ln703_1391_fu_15821_p1.read().is_01() || !sext_ln703_1392_fu_15825_p1.read().is_01())? sc_lv<25>(): (sc_bigint<25>(sext_ln703_1391_fu_15821_p1.read()) + sc_bigint<25>(sext_ln703_1392_fu_15825_p1.read()));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_add_ln1192_699_fu_15916_p2() {
    add_ln1192_699_fu_15916_p2 = (!sext_ln703_1393_fu_15909_p1.read().is_01() || !sext_ln703_1394_fu_15913_p1.read().is_01())? sc_lv<25>(): (sc_bigint<25>(sext_ln703_1393_fu_15909_p1.read()) + sc_bigint<25>(sext_ln703_1394_fu_15913_p1.read()));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_add_ln1192_700_fu_16004_p2() {
    add_ln1192_700_fu_16004_p2 = (!sext_ln703_1395_fu_15997_p1.read().is_01() || !sext_ln703_1396_fu_16001_p1.read().is_01())? sc_lv<25>(): (sc_bigint<25>(sext_ln703_1395_fu_15997_p1.read()) + sc_bigint<25>(sext_ln703_1396_fu_16001_p1.read()));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_add_ln1192_701_fu_16092_p2() {
    add_ln1192_701_fu_16092_p2 = (!sext_ln703_1397_fu_16085_p1.read().is_01() || !sext_ln703_1398_fu_16089_p1.read().is_01())? sc_lv<25>(): (sc_bigint<25>(sext_ln703_1397_fu_16085_p1.read()) + sc_bigint<25>(sext_ln703_1398_fu_16089_p1.read()));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_add_ln1192_702_fu_16180_p2() {
    add_ln1192_702_fu_16180_p2 = (!sext_ln703_1399_fu_16173_p1.read().is_01() || !sext_ln703_1400_fu_16177_p1.read().is_01())? sc_lv<25>(): (sc_bigint<25>(sext_ln703_1399_fu_16173_p1.read()) + sc_bigint<25>(sext_ln703_1400_fu_16177_p1.read()));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_add_ln1192_703_fu_16268_p2() {
    add_ln1192_703_fu_16268_p2 = (!sext_ln703_1401_fu_16261_p1.read().is_01() || !sext_ln703_1402_fu_16265_p1.read().is_01())? sc_lv<25>(): (sc_bigint<25>(sext_ln703_1401_fu_16261_p1.read()) + sc_bigint<25>(sext_ln703_1402_fu_16265_p1.read()));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_add_ln1192_704_fu_16356_p2() {
    add_ln1192_704_fu_16356_p2 = (!sext_ln703_1403_fu_16349_p1.read().is_01() || !sext_ln703_1404_fu_16353_p1.read().is_01())? sc_lv<25>(): (sc_bigint<25>(sext_ln703_1403_fu_16349_p1.read()) + sc_bigint<25>(sext_ln703_1404_fu_16353_p1.read()));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_add_ln1192_705_fu_16444_p2() {
    add_ln1192_705_fu_16444_p2 = (!sext_ln703_1405_fu_16437_p1.read().is_01() || !sext_ln703_1406_fu_16441_p1.read().is_01())? sc_lv<25>(): (sc_bigint<25>(sext_ln703_1405_fu_16437_p1.read()) + sc_bigint<25>(sext_ln703_1406_fu_16441_p1.read()));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_add_ln1192_706_fu_16532_p2() {
    add_ln1192_706_fu_16532_p2 = (!sext_ln703_1407_fu_16525_p1.read().is_01() || !sext_ln703_1408_fu_16529_p1.read().is_01())? sc_lv<25>(): (sc_bigint<25>(sext_ln703_1407_fu_16525_p1.read()) + sc_bigint<25>(sext_ln703_1408_fu_16529_p1.read()));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_add_ln1192_707_fu_16620_p2() {
    add_ln1192_707_fu_16620_p2 = (!sext_ln703_1409_fu_16613_p1.read().is_01() || !sext_ln703_1410_fu_16617_p1.read().is_01())? sc_lv<25>(): (sc_bigint<25>(sext_ln703_1409_fu_16613_p1.read()) + sc_bigint<25>(sext_ln703_1410_fu_16617_p1.read()));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_add_ln1192_708_fu_16708_p2() {
    add_ln1192_708_fu_16708_p2 = (!sext_ln703_1411_fu_16701_p1.read().is_01() || !sext_ln703_1412_fu_16705_p1.read().is_01())? sc_lv<25>(): (sc_bigint<25>(sext_ln703_1411_fu_16701_p1.read()) + sc_bigint<25>(sext_ln703_1412_fu_16705_p1.read()));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_add_ln1192_709_fu_16796_p2() {
    add_ln1192_709_fu_16796_p2 = (!sext_ln703_1413_fu_16789_p1.read().is_01() || !sext_ln703_1414_fu_16793_p1.read().is_01())? sc_lv<25>(): (sc_bigint<25>(sext_ln703_1413_fu_16789_p1.read()) + sc_bigint<25>(sext_ln703_1414_fu_16793_p1.read()));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_add_ln1192_710_fu_16884_p2() {
    add_ln1192_710_fu_16884_p2 = (!sext_ln703_1415_fu_16877_p1.read().is_01() || !sext_ln703_1416_fu_16881_p1.read().is_01())? sc_lv<25>(): (sc_bigint<25>(sext_ln703_1415_fu_16877_p1.read()) + sc_bigint<25>(sext_ln703_1416_fu_16881_p1.read()));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_add_ln1192_711_fu_16972_p2() {
    add_ln1192_711_fu_16972_p2 = (!sext_ln703_1417_fu_16965_p1.read().is_01() || !sext_ln703_1418_fu_16969_p1.read().is_01())? sc_lv<25>(): (sc_bigint<25>(sext_ln703_1417_fu_16965_p1.read()) + sc_bigint<25>(sext_ln703_1418_fu_16969_p1.read()));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_add_ln1192_712_fu_17246_p2() {
    add_ln1192_712_fu_17246_p2 = (!sext_ln703_1419_fu_17238_p1.read().is_01() || !sext_ln703_1420_fu_17242_p1.read().is_01())? sc_lv<25>(): (sc_bigint<25>(sext_ln703_1419_fu_17238_p1.read()) + sc_bigint<25>(sext_ln703_1420_fu_17242_p1.read()));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_add_ln1192_713_fu_17335_p2() {
    add_ln1192_713_fu_17335_p2 = (!sext_ln703_1421_fu_17328_p1.read().is_01() || !sext_ln703_1422_fu_17332_p1.read().is_01())? sc_lv<25>(): (sc_bigint<25>(sext_ln703_1421_fu_17328_p1.read()) + sc_bigint<25>(sext_ln703_1422_fu_17332_p1.read()));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_add_ln1192_714_fu_17423_p2() {
    add_ln1192_714_fu_17423_p2 = (!sext_ln703_1423_fu_17416_p1.read().is_01() || !sext_ln703_1424_fu_17420_p1.read().is_01())? sc_lv<25>(): (sc_bigint<25>(sext_ln703_1423_fu_17416_p1.read()) + sc_bigint<25>(sext_ln703_1424_fu_17420_p1.read()));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_add_ln1192_715_fu_17511_p2() {
    add_ln1192_715_fu_17511_p2 = (!sext_ln703_1425_fu_17504_p1.read().is_01() || !sext_ln703_1426_fu_17508_p1.read().is_01())? sc_lv<25>(): (sc_bigint<25>(sext_ln703_1425_fu_17504_p1.read()) + sc_bigint<25>(sext_ln703_1426_fu_17508_p1.read()));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_add_ln1192_716_fu_17599_p2() {
    add_ln1192_716_fu_17599_p2 = (!sext_ln703_1427_fu_17592_p1.read().is_01() || !sext_ln703_1428_fu_17596_p1.read().is_01())? sc_lv<25>(): (sc_bigint<25>(sext_ln703_1427_fu_17592_p1.read()) + sc_bigint<25>(sext_ln703_1428_fu_17596_p1.read()));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_add_ln1192_717_fu_17687_p2() {
    add_ln1192_717_fu_17687_p2 = (!sext_ln703_1429_fu_17680_p1.read().is_01() || !sext_ln703_1430_fu_17684_p1.read().is_01())? sc_lv<25>(): (sc_bigint<25>(sext_ln703_1429_fu_17680_p1.read()) + sc_bigint<25>(sext_ln703_1430_fu_17684_p1.read()));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_add_ln1192_718_fu_17775_p2() {
    add_ln1192_718_fu_17775_p2 = (!sext_ln703_1431_fu_17768_p1.read().is_01() || !sext_ln703_1432_fu_17772_p1.read().is_01())? sc_lv<25>(): (sc_bigint<25>(sext_ln703_1431_fu_17768_p1.read()) + sc_bigint<25>(sext_ln703_1432_fu_17772_p1.read()));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_add_ln1192_719_fu_17863_p2() {
    add_ln1192_719_fu_17863_p2 = (!sext_ln703_1433_fu_17856_p1.read().is_01() || !sext_ln703_1434_fu_17860_p1.read().is_01())? sc_lv<25>(): (sc_bigint<25>(sext_ln703_1433_fu_17856_p1.read()) + sc_bigint<25>(sext_ln703_1434_fu_17860_p1.read()));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_add_ln1192_720_fu_17951_p2() {
    add_ln1192_720_fu_17951_p2 = (!sext_ln703_1435_fu_17944_p1.read().is_01() || !sext_ln703_1436_fu_17948_p1.read().is_01())? sc_lv<25>(): (sc_bigint<25>(sext_ln703_1435_fu_17944_p1.read()) + sc_bigint<25>(sext_ln703_1436_fu_17948_p1.read()));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_add_ln1192_721_fu_18039_p2() {
    add_ln1192_721_fu_18039_p2 = (!sext_ln703_1437_fu_18032_p1.read().is_01() || !sext_ln703_1438_fu_18036_p1.read().is_01())? sc_lv<25>(): (sc_bigint<25>(sext_ln703_1437_fu_18032_p1.read()) + sc_bigint<25>(sext_ln703_1438_fu_18036_p1.read()));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_add_ln1192_722_fu_18127_p2() {
    add_ln1192_722_fu_18127_p2 = (!sext_ln703_1439_fu_18120_p1.read().is_01() || !sext_ln703_1440_fu_18124_p1.read().is_01())? sc_lv<25>(): (sc_bigint<25>(sext_ln703_1439_fu_18120_p1.read()) + sc_bigint<25>(sext_ln703_1440_fu_18124_p1.read()));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_add_ln1192_723_fu_18215_p2() {
    add_ln1192_723_fu_18215_p2 = (!sext_ln703_1441_fu_18208_p1.read().is_01() || !sext_ln703_1442_fu_18212_p1.read().is_01())? sc_lv<25>(): (sc_bigint<25>(sext_ln703_1441_fu_18208_p1.read()) + sc_bigint<25>(sext_ln703_1442_fu_18212_p1.read()));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_add_ln1192_724_fu_18303_p2() {
    add_ln1192_724_fu_18303_p2 = (!sext_ln703_1443_fu_18296_p1.read().is_01() || !sext_ln703_1444_fu_18300_p1.read().is_01())? sc_lv<25>(): (sc_bigint<25>(sext_ln703_1443_fu_18296_p1.read()) + sc_bigint<25>(sext_ln703_1444_fu_18300_p1.read()));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_add_ln1192_725_fu_18391_p2() {
    add_ln1192_725_fu_18391_p2 = (!sext_ln703_1445_fu_18384_p1.read().is_01() || !sext_ln703_1446_fu_18388_p1.read().is_01())? sc_lv<25>(): (sc_bigint<25>(sext_ln703_1445_fu_18384_p1.read()) + sc_bigint<25>(sext_ln703_1446_fu_18388_p1.read()));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_add_ln1192_726_fu_18479_p2() {
    add_ln1192_726_fu_18479_p2 = (!sext_ln703_1447_fu_18472_p1.read().is_01() || !sext_ln703_1448_fu_18476_p1.read().is_01())? sc_lv<25>(): (sc_bigint<25>(sext_ln703_1447_fu_18472_p1.read()) + sc_bigint<25>(sext_ln703_1448_fu_18476_p1.read()));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_add_ln1192_727_fu_18567_p2() {
    add_ln1192_727_fu_18567_p2 = (!sext_ln703_1449_fu_18560_p1.read().is_01() || !sext_ln703_1450_fu_18564_p1.read().is_01())? sc_lv<25>(): (sc_bigint<25>(sext_ln703_1449_fu_18560_p1.read()) + sc_bigint<25>(sext_ln703_1450_fu_18564_p1.read()));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_add_ln1192_728_fu_18655_p2() {
    add_ln1192_728_fu_18655_p2 = (!sext_ln703_1451_fu_18648_p1.read().is_01() || !sext_ln703_1452_fu_18652_p1.read().is_01())? sc_lv<25>(): (sc_bigint<25>(sext_ln703_1451_fu_18648_p1.read()) + sc_bigint<25>(sext_ln703_1452_fu_18652_p1.read()));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_add_ln1192_729_fu_18743_p2() {
    add_ln1192_729_fu_18743_p2 = (!sext_ln703_1453_fu_18736_p1.read().is_01() || !sext_ln703_1454_fu_18740_p1.read().is_01())? sc_lv<25>(): (sc_bigint<25>(sext_ln703_1453_fu_18736_p1.read()) + sc_bigint<25>(sext_ln703_1454_fu_18740_p1.read()));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_add_ln1192_730_fu_18831_p2() {
    add_ln1192_730_fu_18831_p2 = (!sext_ln703_1455_fu_18824_p1.read().is_01() || !sext_ln703_1456_fu_18828_p1.read().is_01())? sc_lv<25>(): (sc_bigint<25>(sext_ln703_1455_fu_18824_p1.read()) + sc_bigint<25>(sext_ln703_1456_fu_18828_p1.read()));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_add_ln1192_731_fu_18919_p2() {
    add_ln1192_731_fu_18919_p2 = (!sext_ln703_1457_fu_18912_p1.read().is_01() || !sext_ln703_1458_fu_18916_p1.read().is_01())? sc_lv<25>(): (sc_bigint<25>(sext_ln703_1457_fu_18912_p1.read()) + sc_bigint<25>(sext_ln703_1458_fu_18916_p1.read()));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_add_ln1192_732_fu_19177_p2() {
    add_ln1192_732_fu_19177_p2 = (!sext_ln703_1459_fu_19169_p1.read().is_01() || !sext_ln703_1460_fu_19173_p1.read().is_01())? sc_lv<25>(): (sc_bigint<25>(sext_ln703_1459_fu_19169_p1.read()) + sc_bigint<25>(sext_ln703_1460_fu_19173_p1.read()));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_add_ln1192_733_fu_19266_p2() {
    add_ln1192_733_fu_19266_p2 = (!sext_ln703_1461_fu_19259_p1.read().is_01() || !sext_ln703_1462_fu_19263_p1.read().is_01())? sc_lv<25>(): (sc_bigint<25>(sext_ln703_1461_fu_19259_p1.read()) + sc_bigint<25>(sext_ln703_1462_fu_19263_p1.read()));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_add_ln1192_734_fu_19354_p2() {
    add_ln1192_734_fu_19354_p2 = (!sext_ln703_1463_fu_19347_p1.read().is_01() || !sext_ln703_1464_fu_19351_p1.read().is_01())? sc_lv<25>(): (sc_bigint<25>(sext_ln703_1463_fu_19347_p1.read()) + sc_bigint<25>(sext_ln703_1464_fu_19351_p1.read()));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_add_ln1192_735_fu_19442_p2() {
    add_ln1192_735_fu_19442_p2 = (!sext_ln703_1465_fu_19435_p1.read().is_01() || !sext_ln703_1466_fu_19439_p1.read().is_01())? sc_lv<25>(): (sc_bigint<25>(sext_ln703_1465_fu_19435_p1.read()) + sc_bigint<25>(sext_ln703_1466_fu_19439_p1.read()));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_add_ln1192_736_fu_19530_p2() {
    add_ln1192_736_fu_19530_p2 = (!sext_ln703_1467_fu_19523_p1.read().is_01() || !sext_ln703_1468_fu_19527_p1.read().is_01())? sc_lv<25>(): (sc_bigint<25>(sext_ln703_1467_fu_19523_p1.read()) + sc_bigint<25>(sext_ln703_1468_fu_19527_p1.read()));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_add_ln1192_737_fu_19618_p2() {
    add_ln1192_737_fu_19618_p2 = (!sext_ln703_1469_fu_19611_p1.read().is_01() || !sext_ln703_1470_fu_19615_p1.read().is_01())? sc_lv<25>(): (sc_bigint<25>(sext_ln703_1469_fu_19611_p1.read()) + sc_bigint<25>(sext_ln703_1470_fu_19615_p1.read()));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_add_ln1192_738_fu_19706_p2() {
    add_ln1192_738_fu_19706_p2 = (!sext_ln703_1471_fu_19699_p1.read().is_01() || !sext_ln703_1472_fu_19703_p1.read().is_01())? sc_lv<25>(): (sc_bigint<25>(sext_ln703_1471_fu_19699_p1.read()) + sc_bigint<25>(sext_ln703_1472_fu_19703_p1.read()));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_add_ln1192_739_fu_19794_p2() {
    add_ln1192_739_fu_19794_p2 = (!sext_ln703_1473_fu_19787_p1.read().is_01() || !sext_ln703_1474_fu_19791_p1.read().is_01())? sc_lv<25>(): (sc_bigint<25>(sext_ln703_1473_fu_19787_p1.read()) + sc_bigint<25>(sext_ln703_1474_fu_19791_p1.read()));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_add_ln1192_740_fu_19882_p2() {
    add_ln1192_740_fu_19882_p2 = (!sext_ln703_1475_fu_19875_p1.read().is_01() || !sext_ln703_1476_fu_19879_p1.read().is_01())? sc_lv<25>(): (sc_bigint<25>(sext_ln703_1475_fu_19875_p1.read()) + sc_bigint<25>(sext_ln703_1476_fu_19879_p1.read()));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_add_ln1192_741_fu_19970_p2() {
    add_ln1192_741_fu_19970_p2 = (!sext_ln703_1477_fu_19963_p1.read().is_01() || !sext_ln703_1478_fu_19967_p1.read().is_01())? sc_lv<25>(): (sc_bigint<25>(sext_ln703_1477_fu_19963_p1.read()) + sc_bigint<25>(sext_ln703_1478_fu_19967_p1.read()));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_add_ln1192_742_fu_20058_p2() {
    add_ln1192_742_fu_20058_p2 = (!sext_ln703_1479_fu_20051_p1.read().is_01() || !sext_ln703_1480_fu_20055_p1.read().is_01())? sc_lv<25>(): (sc_bigint<25>(sext_ln703_1479_fu_20051_p1.read()) + sc_bigint<25>(sext_ln703_1480_fu_20055_p1.read()));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_add_ln1192_743_fu_20146_p2() {
    add_ln1192_743_fu_20146_p2 = (!sext_ln703_1481_fu_20139_p1.read().is_01() || !sext_ln703_1482_fu_20143_p1.read().is_01())? sc_lv<25>(): (sc_bigint<25>(sext_ln703_1481_fu_20139_p1.read()) + sc_bigint<25>(sext_ln703_1482_fu_20143_p1.read()));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_add_ln1192_744_fu_20234_p2() {
    add_ln1192_744_fu_20234_p2 = (!sext_ln703_1483_fu_20227_p1.read().is_01() || !sext_ln703_1484_fu_20231_p1.read().is_01())? sc_lv<25>(): (sc_bigint<25>(sext_ln703_1483_fu_20227_p1.read()) + sc_bigint<25>(sext_ln703_1484_fu_20231_p1.read()));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_add_ln1192_745_fu_20322_p2() {
    add_ln1192_745_fu_20322_p2 = (!sext_ln703_1485_fu_20315_p1.read().is_01() || !sext_ln703_1486_fu_20319_p1.read().is_01())? sc_lv<25>(): (sc_bigint<25>(sext_ln703_1485_fu_20315_p1.read()) + sc_bigint<25>(sext_ln703_1486_fu_20319_p1.read()));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_add_ln1192_746_fu_20410_p2() {
    add_ln1192_746_fu_20410_p2 = (!sext_ln703_1487_fu_20403_p1.read().is_01() || !sext_ln703_1488_fu_20407_p1.read().is_01())? sc_lv<25>(): (sc_bigint<25>(sext_ln703_1487_fu_20403_p1.read()) + sc_bigint<25>(sext_ln703_1488_fu_20407_p1.read()));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_add_ln1192_747_fu_20498_p2() {
    add_ln1192_747_fu_20498_p2 = (!sext_ln703_1489_fu_20491_p1.read().is_01() || !sext_ln703_1490_fu_20495_p1.read().is_01())? sc_lv<25>(): (sc_bigint<25>(sext_ln703_1489_fu_20491_p1.read()) + sc_bigint<25>(sext_ln703_1490_fu_20495_p1.read()));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_add_ln1192_748_fu_20586_p2() {
    add_ln1192_748_fu_20586_p2 = (!sext_ln703_1491_fu_20579_p1.read().is_01() || !sext_ln703_1492_fu_20583_p1.read().is_01())? sc_lv<25>(): (sc_bigint<25>(sext_ln703_1491_fu_20579_p1.read()) + sc_bigint<25>(sext_ln703_1492_fu_20583_p1.read()));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_add_ln1192_749_fu_20674_p2() {
    add_ln1192_749_fu_20674_p2 = (!sext_ln703_1493_fu_20667_p1.read().is_01() || !sext_ln703_1494_fu_20671_p1.read().is_01())? sc_lv<25>(): (sc_bigint<25>(sext_ln703_1493_fu_20667_p1.read()) + sc_bigint<25>(sext_ln703_1494_fu_20671_p1.read()));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_add_ln1192_750_fu_20762_p2() {
    add_ln1192_750_fu_20762_p2 = (!sext_ln703_1495_fu_20755_p1.read().is_01() || !sext_ln703_1496_fu_20759_p1.read().is_01())? sc_lv<25>(): (sc_bigint<25>(sext_ln703_1495_fu_20755_p1.read()) + sc_bigint<25>(sext_ln703_1496_fu_20759_p1.read()));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_add_ln1192_751_fu_20850_p2() {
    add_ln1192_751_fu_20850_p2 = (!sext_ln703_1497_fu_20843_p1.read().is_01() || !sext_ln703_1498_fu_20847_p1.read().is_01())? sc_lv<25>(): (sc_bigint<25>(sext_ln703_1497_fu_20843_p1.read()) + sc_bigint<25>(sext_ln703_1498_fu_20847_p1.read()));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_add_ln1192_752_fu_21108_p2() {
    add_ln1192_752_fu_21108_p2 = (!sext_ln703_1499_fu_21100_p1.read().is_01() || !sext_ln703_1500_fu_21104_p1.read().is_01())? sc_lv<25>(): (sc_bigint<25>(sext_ln703_1499_fu_21100_p1.read()) + sc_bigint<25>(sext_ln703_1500_fu_21104_p1.read()));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_add_ln1192_753_fu_21197_p2() {
    add_ln1192_753_fu_21197_p2 = (!sext_ln703_1501_fu_21190_p1.read().is_01() || !sext_ln703_1502_fu_21194_p1.read().is_01())? sc_lv<25>(): (sc_bigint<25>(sext_ln703_1501_fu_21190_p1.read()) + sc_bigint<25>(sext_ln703_1502_fu_21194_p1.read()));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_add_ln1192_754_fu_21285_p2() {
    add_ln1192_754_fu_21285_p2 = (!sext_ln703_1503_fu_21278_p1.read().is_01() || !sext_ln703_1504_fu_21282_p1.read().is_01())? sc_lv<25>(): (sc_bigint<25>(sext_ln703_1503_fu_21278_p1.read()) + sc_bigint<25>(sext_ln703_1504_fu_21282_p1.read()));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_add_ln1192_755_fu_21373_p2() {
    add_ln1192_755_fu_21373_p2 = (!sext_ln703_1505_fu_21366_p1.read().is_01() || !sext_ln703_1506_fu_21370_p1.read().is_01())? sc_lv<25>(): (sc_bigint<25>(sext_ln703_1505_fu_21366_p1.read()) + sc_bigint<25>(sext_ln703_1506_fu_21370_p1.read()));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_add_ln1192_756_fu_21461_p2() {
    add_ln1192_756_fu_21461_p2 = (!sext_ln703_1507_fu_21454_p1.read().is_01() || !sext_ln703_1508_fu_21458_p1.read().is_01())? sc_lv<25>(): (sc_bigint<25>(sext_ln703_1507_fu_21454_p1.read()) + sc_bigint<25>(sext_ln703_1508_fu_21458_p1.read()));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_add_ln1192_757_fu_21549_p2() {
    add_ln1192_757_fu_21549_p2 = (!sext_ln703_1509_fu_21542_p1.read().is_01() || !sext_ln703_1510_fu_21546_p1.read().is_01())? sc_lv<25>(): (sc_bigint<25>(sext_ln703_1509_fu_21542_p1.read()) + sc_bigint<25>(sext_ln703_1510_fu_21546_p1.read()));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_add_ln1192_758_fu_21637_p2() {
    add_ln1192_758_fu_21637_p2 = (!sext_ln703_1511_fu_21630_p1.read().is_01() || !sext_ln703_1512_fu_21634_p1.read().is_01())? sc_lv<25>(): (sc_bigint<25>(sext_ln703_1511_fu_21630_p1.read()) + sc_bigint<25>(sext_ln703_1512_fu_21634_p1.read()));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_add_ln1192_759_fu_21725_p2() {
    add_ln1192_759_fu_21725_p2 = (!sext_ln703_1513_fu_21718_p1.read().is_01() || !sext_ln703_1514_fu_21722_p1.read().is_01())? sc_lv<25>(): (sc_bigint<25>(sext_ln703_1513_fu_21718_p1.read()) + sc_bigint<25>(sext_ln703_1514_fu_21722_p1.read()));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_add_ln1192_760_fu_21813_p2() {
    add_ln1192_760_fu_21813_p2 = (!sext_ln703_1515_fu_21806_p1.read().is_01() || !sext_ln703_1516_fu_21810_p1.read().is_01())? sc_lv<25>(): (sc_bigint<25>(sext_ln703_1515_fu_21806_p1.read()) + sc_bigint<25>(sext_ln703_1516_fu_21810_p1.read()));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_add_ln1192_761_fu_21901_p2() {
    add_ln1192_761_fu_21901_p2 = (!sext_ln703_1517_fu_21894_p1.read().is_01() || !sext_ln703_1518_fu_21898_p1.read().is_01())? sc_lv<25>(): (sc_bigint<25>(sext_ln703_1517_fu_21894_p1.read()) + sc_bigint<25>(sext_ln703_1518_fu_21898_p1.read()));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_add_ln1192_762_fu_21989_p2() {
    add_ln1192_762_fu_21989_p2 = (!sext_ln703_1519_fu_21982_p1.read().is_01() || !sext_ln703_1520_fu_21986_p1.read().is_01())? sc_lv<25>(): (sc_bigint<25>(sext_ln703_1519_fu_21982_p1.read()) + sc_bigint<25>(sext_ln703_1520_fu_21986_p1.read()));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_add_ln1192_763_fu_22077_p2() {
    add_ln1192_763_fu_22077_p2 = (!sext_ln703_1521_fu_22070_p1.read().is_01() || !sext_ln703_1522_fu_22074_p1.read().is_01())? sc_lv<25>(): (sc_bigint<25>(sext_ln703_1521_fu_22070_p1.read()) + sc_bigint<25>(sext_ln703_1522_fu_22074_p1.read()));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_add_ln1192_764_fu_22165_p2() {
    add_ln1192_764_fu_22165_p2 = (!sext_ln703_1523_fu_22158_p1.read().is_01() || !sext_ln703_1524_fu_22162_p1.read().is_01())? sc_lv<25>(): (sc_bigint<25>(sext_ln703_1523_fu_22158_p1.read()) + sc_bigint<25>(sext_ln703_1524_fu_22162_p1.read()));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_add_ln1192_765_fu_22253_p2() {
    add_ln1192_765_fu_22253_p2 = (!sext_ln703_1525_fu_22246_p1.read().is_01() || !sext_ln703_1526_fu_22250_p1.read().is_01())? sc_lv<25>(): (sc_bigint<25>(sext_ln703_1525_fu_22246_p1.read()) + sc_bigint<25>(sext_ln703_1526_fu_22250_p1.read()));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_add_ln1192_766_fu_22341_p2() {
    add_ln1192_766_fu_22341_p2 = (!sext_ln703_1527_fu_22334_p1.read().is_01() || !sext_ln703_1528_fu_22338_p1.read().is_01())? sc_lv<25>(): (sc_bigint<25>(sext_ln703_1527_fu_22334_p1.read()) + sc_bigint<25>(sext_ln703_1528_fu_22338_p1.read()));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_add_ln1192_767_fu_22429_p2() {
    add_ln1192_767_fu_22429_p2 = (!sext_ln703_1529_fu_22422_p1.read().is_01() || !sext_ln703_1530_fu_22426_p1.read().is_01())? sc_lv<25>(): (sc_bigint<25>(sext_ln703_1529_fu_22422_p1.read()) + sc_bigint<25>(sext_ln703_1530_fu_22426_p1.read()));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_add_ln1192_768_fu_22517_p2() {
    add_ln1192_768_fu_22517_p2 = (!sext_ln703_1531_fu_22510_p1.read().is_01() || !sext_ln703_1532_fu_22514_p1.read().is_01())? sc_lv<25>(): (sc_bigint<25>(sext_ln703_1531_fu_22510_p1.read()) + sc_bigint<25>(sext_ln703_1532_fu_22514_p1.read()));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_add_ln1192_769_fu_22605_p2() {
    add_ln1192_769_fu_22605_p2 = (!sext_ln703_1533_fu_22598_p1.read().is_01() || !sext_ln703_1534_fu_22602_p1.read().is_01())? sc_lv<25>(): (sc_bigint<25>(sext_ln703_1533_fu_22598_p1.read()) + sc_bigint<25>(sext_ln703_1534_fu_22602_p1.read()));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_add_ln1192_770_fu_22693_p2() {
    add_ln1192_770_fu_22693_p2 = (!sext_ln703_1535_fu_22686_p1.read().is_01() || !sext_ln703_1536_fu_22690_p1.read().is_01())? sc_lv<25>(): (sc_bigint<25>(sext_ln703_1535_fu_22686_p1.read()) + sc_bigint<25>(sext_ln703_1536_fu_22690_p1.read()));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_add_ln1192_771_fu_22781_p2() {
    add_ln1192_771_fu_22781_p2 = (!sext_ln703_1537_fu_22774_p1.read().is_01() || !sext_ln703_1538_fu_22778_p1.read().is_01())? sc_lv<25>(): (sc_bigint<25>(sext_ln703_1537_fu_22774_p1.read()) + sc_bigint<25>(sext_ln703_1538_fu_22778_p1.read()));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_add_ln1192_772_fu_23039_p2() {
    add_ln1192_772_fu_23039_p2 = (!sext_ln703_1539_fu_23031_p1.read().is_01() || !sext_ln703_1540_fu_23035_p1.read().is_01())? sc_lv<25>(): (sc_bigint<25>(sext_ln703_1539_fu_23031_p1.read()) + sc_bigint<25>(sext_ln703_1540_fu_23035_p1.read()));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_add_ln1192_fu_15388_p2() {
    add_ln1192_fu_15388_p2 = (!sext_ln703_fu_15381_p1.read().is_01() || !sext_ln703_1382_fu_15385_p1.read().is_01())? sc_lv<25>(): (sc_bigint<25>(sext_ln703_fu_15381_p1.read()) + sc_bigint<25>(sext_ln703_1382_fu_15385_p1.read()));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_add_ln389_fu_23126_p2() {
    add_ln389_fu_23126_p2 = (!pX_2_load_reg_24074.read().is_01() || !ap_const_lv32_1.is_01())? sc_lv<32>(): (sc_biguint<32>(pX_2_load_reg_24074.read()) + sc_biguint<32>(ap_const_lv32_1));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_add_ln391_fu_23137_p2() {
    add_ln391_fu_23137_p2 = (!sX_2_load_reg_24064.read().is_01() || !ap_const_lv32_1.is_01())? sc_lv<32>(): (sc_biguint<32>(sX_2_load_reg_24064.read()) + sc_biguint<32>(ap_const_lv32_1));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_add_ln415_686_fu_1669_p2() {
    add_ln415_686_fu_1669_p2 = (!trunc_ln708_s_fu_1642_p4.read().is_01() || !zext_ln415_686_fu_1665_p1.read().is_01())? sc_lv<24>(): (sc_biguint<24>(trunc_ln708_s_fu_1642_p4.read()) + sc_biguint<24>(zext_ln415_686_fu_1665_p1.read()));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_add_ln415_687_fu_1869_p2() {
    add_ln415_687_fu_1869_p2 = (!trunc_ln708_683_fu_1842_p4.read().is_01() || !zext_ln415_687_fu_1865_p1.read().is_01())? sc_lv<24>(): (sc_biguint<24>(trunc_ln708_683_fu_1842_p4.read()) + sc_biguint<24>(zext_ln415_687_fu_1865_p1.read()));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_add_ln415_688_fu_2069_p2() {
    add_ln415_688_fu_2069_p2 = (!trunc_ln708_684_fu_2042_p4.read().is_01() || !zext_ln415_688_fu_2065_p1.read().is_01())? sc_lv<24>(): (sc_biguint<24>(trunc_ln708_684_fu_2042_p4.read()) + sc_biguint<24>(zext_ln415_688_fu_2065_p1.read()));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_add_ln415_689_fu_2261_p2() {
    add_ln415_689_fu_2261_p2 = (!trunc_ln708_685_fu_2234_p4.read().is_01() || !zext_ln415_689_fu_2257_p1.read().is_01())? sc_lv<24>(): (sc_biguint<24>(trunc_ln708_685_fu_2234_p4.read()) + sc_biguint<24>(zext_ln415_689_fu_2257_p1.read()));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_add_ln415_690_fu_2453_p2() {
    add_ln415_690_fu_2453_p2 = (!trunc_ln708_686_fu_2426_p4.read().is_01() || !zext_ln415_690_fu_2449_p1.read().is_01())? sc_lv<24>(): (sc_biguint<24>(trunc_ln708_686_fu_2426_p4.read()) + sc_biguint<24>(zext_ln415_690_fu_2449_p1.read()));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_add_ln415_691_fu_2645_p2() {
    add_ln415_691_fu_2645_p2 = (!trunc_ln708_687_fu_2618_p4.read().is_01() || !zext_ln415_691_fu_2641_p1.read().is_01())? sc_lv<24>(): (sc_biguint<24>(trunc_ln708_687_fu_2618_p4.read()) + sc_biguint<24>(zext_ln415_691_fu_2641_p1.read()));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_add_ln415_692_fu_2837_p2() {
    add_ln415_692_fu_2837_p2 = (!trunc_ln708_688_fu_2810_p4.read().is_01() || !zext_ln415_692_fu_2833_p1.read().is_01())? sc_lv<24>(): (sc_biguint<24>(trunc_ln708_688_fu_2810_p4.read()) + sc_biguint<24>(zext_ln415_692_fu_2833_p1.read()));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_add_ln415_693_fu_3029_p2() {
    add_ln415_693_fu_3029_p2 = (!trunc_ln708_689_fu_3002_p4.read().is_01() || !zext_ln415_693_fu_3025_p1.read().is_01())? sc_lv<24>(): (sc_biguint<24>(trunc_ln708_689_fu_3002_p4.read()) + sc_biguint<24>(zext_ln415_693_fu_3025_p1.read()));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_add_ln415_694_fu_3221_p2() {
    add_ln415_694_fu_3221_p2 = (!trunc_ln708_690_fu_3194_p4.read().is_01() || !zext_ln415_694_fu_3217_p1.read().is_01())? sc_lv<24>(): (sc_biguint<24>(trunc_ln708_690_fu_3194_p4.read()) + sc_biguint<24>(zext_ln415_694_fu_3217_p1.read()));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_add_ln415_695_fu_3413_p2() {
    add_ln415_695_fu_3413_p2 = (!trunc_ln708_691_fu_3386_p4.read().is_01() || !zext_ln415_695_fu_3409_p1.read().is_01())? sc_lv<24>(): (sc_biguint<24>(trunc_ln708_691_fu_3386_p4.read()) + sc_biguint<24>(zext_ln415_695_fu_3409_p1.read()));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_add_ln415_696_fu_3605_p2() {
    add_ln415_696_fu_3605_p2 = (!trunc_ln708_692_fu_3578_p4.read().is_01() || !zext_ln415_696_fu_3601_p1.read().is_01())? sc_lv<24>(): (sc_biguint<24>(trunc_ln708_692_fu_3578_p4.read()) + sc_biguint<24>(zext_ln415_696_fu_3601_p1.read()));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_add_ln415_697_fu_3797_p2() {
    add_ln415_697_fu_3797_p2 = (!trunc_ln708_693_fu_3770_p4.read().is_01() || !zext_ln415_697_fu_3793_p1.read().is_01())? sc_lv<24>(): (sc_biguint<24>(trunc_ln708_693_fu_3770_p4.read()) + sc_biguint<24>(zext_ln415_697_fu_3793_p1.read()));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_add_ln415_698_fu_3989_p2() {
    add_ln415_698_fu_3989_p2 = (!trunc_ln708_694_fu_3962_p4.read().is_01() || !zext_ln415_698_fu_3985_p1.read().is_01())? sc_lv<24>(): (sc_biguint<24>(trunc_ln708_694_fu_3962_p4.read()) + sc_biguint<24>(zext_ln415_698_fu_3985_p1.read()));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_add_ln415_699_fu_4181_p2() {
    add_ln415_699_fu_4181_p2 = (!trunc_ln708_695_fu_4154_p4.read().is_01() || !zext_ln415_699_fu_4177_p1.read().is_01())? sc_lv<24>(): (sc_biguint<24>(trunc_ln708_695_fu_4154_p4.read()) + sc_biguint<24>(zext_ln415_699_fu_4177_p1.read()));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_add_ln415_700_fu_4373_p2() {
    add_ln415_700_fu_4373_p2 = (!trunc_ln708_696_fu_4346_p4.read().is_01() || !zext_ln415_700_fu_4369_p1.read().is_01())? sc_lv<24>(): (sc_biguint<24>(trunc_ln708_696_fu_4346_p4.read()) + sc_biguint<24>(zext_ln415_700_fu_4369_p1.read()));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_add_ln415_701_fu_4565_p2() {
    add_ln415_701_fu_4565_p2 = (!trunc_ln708_697_fu_4538_p4.read().is_01() || !zext_ln415_701_fu_4561_p1.read().is_01())? sc_lv<24>(): (sc_biguint<24>(trunc_ln708_697_fu_4538_p4.read()) + sc_biguint<24>(zext_ln415_701_fu_4561_p1.read()));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_add_ln415_702_fu_4757_p2() {
    add_ln415_702_fu_4757_p2 = (!trunc_ln708_698_fu_4730_p4.read().is_01() || !zext_ln415_702_fu_4753_p1.read().is_01())? sc_lv<24>(): (sc_biguint<24>(trunc_ln708_698_fu_4730_p4.read()) + sc_biguint<24>(zext_ln415_702_fu_4753_p1.read()));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_add_ln415_703_fu_4949_p2() {
    add_ln415_703_fu_4949_p2 = (!trunc_ln708_699_fu_4922_p4.read().is_01() || !zext_ln415_703_fu_4945_p1.read().is_01())? sc_lv<24>(): (sc_biguint<24>(trunc_ln708_699_fu_4922_p4.read()) + sc_biguint<24>(zext_ln415_703_fu_4945_p1.read()));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_add_ln415_704_fu_17106_p2() {
    add_ln415_704_fu_17106_p2 = (!trunc_ln708_700_fu_17079_p4.read().is_01() || !zext_ln415_704_fu_17102_p1.read().is_01())? sc_lv<24>(): (sc_biguint<24>(trunc_ln708_700_fu_17079_p4.read()) + sc_biguint<24>(zext_ln415_704_fu_17102_p1.read()));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_add_ln415_705_fu_5139_p2() {
    add_ln415_705_fu_5139_p2 = (!trunc_ln708_701_fu_5112_p4.read().is_01() || !zext_ln415_705_fu_5135_p1.read().is_01())? sc_lv<24>(): (sc_biguint<24>(trunc_ln708_701_fu_5112_p4.read()) + sc_biguint<24>(zext_ln415_705_fu_5135_p1.read()));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_add_ln415_706_fu_5319_p2() {
    add_ln415_706_fu_5319_p2 = (!trunc_ln708_702_fu_5292_p4.read().is_01() || !zext_ln415_706_fu_5315_p1.read().is_01())? sc_lv<24>(): (sc_biguint<24>(trunc_ln708_702_fu_5292_p4.read()) + sc_biguint<24>(zext_ln415_706_fu_5315_p1.read()));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_add_ln415_707_fu_5499_p2() {
    add_ln415_707_fu_5499_p2 = (!trunc_ln708_703_fu_5472_p4.read().is_01() || !zext_ln415_707_fu_5495_p1.read().is_01())? sc_lv<24>(): (sc_biguint<24>(trunc_ln708_703_fu_5472_p4.read()) + sc_biguint<24>(zext_ln415_707_fu_5495_p1.read()));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_add_ln415_708_fu_5679_p2() {
    add_ln415_708_fu_5679_p2 = (!trunc_ln708_704_fu_5652_p4.read().is_01() || !zext_ln415_708_fu_5675_p1.read().is_01())? sc_lv<24>(): (sc_biguint<24>(trunc_ln708_704_fu_5652_p4.read()) + sc_biguint<24>(zext_ln415_708_fu_5675_p1.read()));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_add_ln415_709_fu_5859_p2() {
    add_ln415_709_fu_5859_p2 = (!trunc_ln708_705_fu_5832_p4.read().is_01() || !zext_ln415_709_fu_5855_p1.read().is_01())? sc_lv<24>(): (sc_biguint<24>(trunc_ln708_705_fu_5832_p4.read()) + sc_biguint<24>(zext_ln415_709_fu_5855_p1.read()));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_add_ln415_710_fu_6039_p2() {
    add_ln415_710_fu_6039_p2 = (!trunc_ln708_706_fu_6012_p4.read().is_01() || !zext_ln415_710_fu_6035_p1.read().is_01())? sc_lv<24>(): (sc_biguint<24>(trunc_ln708_706_fu_6012_p4.read()) + sc_biguint<24>(zext_ln415_710_fu_6035_p1.read()));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_add_ln415_711_fu_6219_p2() {
    add_ln415_711_fu_6219_p2 = (!trunc_ln708_707_fu_6192_p4.read().is_01() || !zext_ln415_711_fu_6215_p1.read().is_01())? sc_lv<24>(): (sc_biguint<24>(trunc_ln708_707_fu_6192_p4.read()) + sc_biguint<24>(zext_ln415_711_fu_6215_p1.read()));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_add_ln415_712_fu_6399_p2() {
    add_ln415_712_fu_6399_p2 = (!trunc_ln708_708_fu_6372_p4.read().is_01() || !zext_ln415_712_fu_6395_p1.read().is_01())? sc_lv<24>(): (sc_biguint<24>(trunc_ln708_708_fu_6372_p4.read()) + sc_biguint<24>(zext_ln415_712_fu_6395_p1.read()));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_add_ln415_713_fu_6579_p2() {
    add_ln415_713_fu_6579_p2 = (!trunc_ln708_709_fu_6552_p4.read().is_01() || !zext_ln415_713_fu_6575_p1.read().is_01())? sc_lv<24>(): (sc_biguint<24>(trunc_ln708_709_fu_6552_p4.read()) + sc_biguint<24>(zext_ln415_713_fu_6575_p1.read()));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_add_ln415_714_fu_6759_p2() {
    add_ln415_714_fu_6759_p2 = (!trunc_ln708_710_fu_6732_p4.read().is_01() || !zext_ln415_714_fu_6755_p1.read().is_01())? sc_lv<24>(): (sc_biguint<24>(trunc_ln708_710_fu_6732_p4.read()) + sc_biguint<24>(zext_ln415_714_fu_6755_p1.read()));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_add_ln415_715_fu_6939_p2() {
    add_ln415_715_fu_6939_p2 = (!trunc_ln708_711_fu_6912_p4.read().is_01() || !zext_ln415_715_fu_6935_p1.read().is_01())? sc_lv<24>(): (sc_biguint<24>(trunc_ln708_711_fu_6912_p4.read()) + sc_biguint<24>(zext_ln415_715_fu_6935_p1.read()));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_add_ln415_716_fu_7119_p2() {
    add_ln415_716_fu_7119_p2 = (!trunc_ln708_712_fu_7092_p4.read().is_01() || !zext_ln415_716_fu_7115_p1.read().is_01())? sc_lv<24>(): (sc_biguint<24>(trunc_ln708_712_fu_7092_p4.read()) + sc_biguint<24>(zext_ln415_716_fu_7115_p1.read()));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_add_ln415_717_fu_7299_p2() {
    add_ln415_717_fu_7299_p2 = (!trunc_ln708_713_fu_7272_p4.read().is_01() || !zext_ln415_717_fu_7295_p1.read().is_01())? sc_lv<24>(): (sc_biguint<24>(trunc_ln708_713_fu_7272_p4.read()) + sc_biguint<24>(zext_ln415_717_fu_7295_p1.read()));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_add_ln415_718_fu_7479_p2() {
    add_ln415_718_fu_7479_p2 = (!trunc_ln708_714_fu_7452_p4.read().is_01() || !zext_ln415_718_fu_7475_p1.read().is_01())? sc_lv<24>(): (sc_biguint<24>(trunc_ln708_714_fu_7452_p4.read()) + sc_biguint<24>(zext_ln415_718_fu_7475_p1.read()));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_add_ln415_719_fu_7659_p2() {
    add_ln415_719_fu_7659_p2 = (!trunc_ln708_715_fu_7632_p4.read().is_01() || !zext_ln415_719_fu_7655_p1.read().is_01())? sc_lv<24>(): (sc_biguint<24>(trunc_ln708_715_fu_7632_p4.read()) + sc_biguint<24>(zext_ln415_719_fu_7655_p1.read()));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_add_ln415_720_fu_7839_p2() {
    add_ln415_720_fu_7839_p2 = (!trunc_ln708_716_fu_7812_p4.read().is_01() || !zext_ln415_720_fu_7835_p1.read().is_01())? sc_lv<24>(): (sc_biguint<24>(trunc_ln708_716_fu_7812_p4.read()) + sc_biguint<24>(zext_ln415_720_fu_7835_p1.read()));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_add_ln415_721_fu_8019_p2() {
    add_ln415_721_fu_8019_p2 = (!trunc_ln708_717_fu_7992_p4.read().is_01() || !zext_ln415_721_fu_8015_p1.read().is_01())? sc_lv<24>(): (sc_biguint<24>(trunc_ln708_717_fu_7992_p4.read()) + sc_biguint<24>(zext_ln415_721_fu_8015_p1.read()));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_add_ln415_722_fu_8199_p2() {
    add_ln415_722_fu_8199_p2 = (!trunc_ln708_718_fu_8172_p4.read().is_01() || !zext_ln415_722_fu_8195_p1.read().is_01())? sc_lv<24>(): (sc_biguint<24>(trunc_ln708_718_fu_8172_p4.read()) + sc_biguint<24>(zext_ln415_722_fu_8195_p1.read()));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_add_ln415_723_fu_8379_p2() {
    add_ln415_723_fu_8379_p2 = (!trunc_ln708_719_fu_8352_p4.read().is_01() || !zext_ln415_723_fu_8375_p1.read().is_01())? sc_lv<24>(): (sc_biguint<24>(trunc_ln708_719_fu_8352_p4.read()) + sc_biguint<24>(zext_ln415_723_fu_8375_p1.read()));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_add_ln415_724_fu_19037_p2() {
    add_ln415_724_fu_19037_p2 = (!trunc_ln708_720_fu_19010_p4.read().is_01() || !zext_ln415_724_fu_19033_p1.read().is_01())? sc_lv<24>(): (sc_biguint<24>(trunc_ln708_720_fu_19010_p4.read()) + sc_biguint<24>(zext_ln415_724_fu_19033_p1.read()));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_add_ln415_725_fu_8569_p2() {
    add_ln415_725_fu_8569_p2 = (!trunc_ln708_721_fu_8542_p4.read().is_01() || !zext_ln415_725_fu_8565_p1.read().is_01())? sc_lv<24>(): (sc_biguint<24>(trunc_ln708_721_fu_8542_p4.read()) + sc_biguint<24>(zext_ln415_725_fu_8565_p1.read()));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_add_ln415_726_fu_8749_p2() {
    add_ln415_726_fu_8749_p2 = (!trunc_ln708_722_fu_8722_p4.read().is_01() || !zext_ln415_726_fu_8745_p1.read().is_01())? sc_lv<24>(): (sc_biguint<24>(trunc_ln708_722_fu_8722_p4.read()) + sc_biguint<24>(zext_ln415_726_fu_8745_p1.read()));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_add_ln415_727_fu_8929_p2() {
    add_ln415_727_fu_8929_p2 = (!trunc_ln708_723_fu_8902_p4.read().is_01() || !zext_ln415_727_fu_8925_p1.read().is_01())? sc_lv<24>(): (sc_biguint<24>(trunc_ln708_723_fu_8902_p4.read()) + sc_biguint<24>(zext_ln415_727_fu_8925_p1.read()));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_add_ln415_728_fu_9109_p2() {
    add_ln415_728_fu_9109_p2 = (!trunc_ln708_724_fu_9082_p4.read().is_01() || !zext_ln415_728_fu_9105_p1.read().is_01())? sc_lv<24>(): (sc_biguint<24>(trunc_ln708_724_fu_9082_p4.read()) + sc_biguint<24>(zext_ln415_728_fu_9105_p1.read()));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_add_ln415_729_fu_9289_p2() {
    add_ln415_729_fu_9289_p2 = (!trunc_ln708_725_fu_9262_p4.read().is_01() || !zext_ln415_729_fu_9285_p1.read().is_01())? sc_lv<24>(): (sc_biguint<24>(trunc_ln708_725_fu_9262_p4.read()) + sc_biguint<24>(zext_ln415_729_fu_9285_p1.read()));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_add_ln415_730_fu_9469_p2() {
    add_ln415_730_fu_9469_p2 = (!trunc_ln708_726_fu_9442_p4.read().is_01() || !zext_ln415_730_fu_9465_p1.read().is_01())? sc_lv<24>(): (sc_biguint<24>(trunc_ln708_726_fu_9442_p4.read()) + sc_biguint<24>(zext_ln415_730_fu_9465_p1.read()));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_add_ln415_731_fu_9649_p2() {
    add_ln415_731_fu_9649_p2 = (!trunc_ln708_727_fu_9622_p4.read().is_01() || !zext_ln415_731_fu_9645_p1.read().is_01())? sc_lv<24>(): (sc_biguint<24>(trunc_ln708_727_fu_9622_p4.read()) + sc_biguint<24>(zext_ln415_731_fu_9645_p1.read()));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_add_ln415_732_fu_9829_p2() {
    add_ln415_732_fu_9829_p2 = (!trunc_ln708_728_fu_9802_p4.read().is_01() || !zext_ln415_732_fu_9825_p1.read().is_01())? sc_lv<24>(): (sc_biguint<24>(trunc_ln708_728_fu_9802_p4.read()) + sc_biguint<24>(zext_ln415_732_fu_9825_p1.read()));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_add_ln415_733_fu_10009_p2() {
    add_ln415_733_fu_10009_p2 = (!trunc_ln708_729_fu_9982_p4.read().is_01() || !zext_ln415_733_fu_10005_p1.read().is_01())? sc_lv<24>(): (sc_biguint<24>(trunc_ln708_729_fu_9982_p4.read()) + sc_biguint<24>(zext_ln415_733_fu_10005_p1.read()));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_add_ln415_734_fu_10189_p2() {
    add_ln415_734_fu_10189_p2 = (!trunc_ln708_730_fu_10162_p4.read().is_01() || !zext_ln415_734_fu_10185_p1.read().is_01())? sc_lv<24>(): (sc_biguint<24>(trunc_ln708_730_fu_10162_p4.read()) + sc_biguint<24>(zext_ln415_734_fu_10185_p1.read()));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_add_ln415_735_fu_10369_p2() {
    add_ln415_735_fu_10369_p2 = (!trunc_ln708_731_fu_10342_p4.read().is_01() || !zext_ln415_735_fu_10365_p1.read().is_01())? sc_lv<24>(): (sc_biguint<24>(trunc_ln708_731_fu_10342_p4.read()) + sc_biguint<24>(zext_ln415_735_fu_10365_p1.read()));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_add_ln415_736_fu_10549_p2() {
    add_ln415_736_fu_10549_p2 = (!trunc_ln708_732_fu_10522_p4.read().is_01() || !zext_ln415_736_fu_10545_p1.read().is_01())? sc_lv<24>(): (sc_biguint<24>(trunc_ln708_732_fu_10522_p4.read()) + sc_biguint<24>(zext_ln415_736_fu_10545_p1.read()));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_add_ln415_737_fu_10729_p2() {
    add_ln415_737_fu_10729_p2 = (!trunc_ln708_733_fu_10702_p4.read().is_01() || !zext_ln415_737_fu_10725_p1.read().is_01())? sc_lv<24>(): (sc_biguint<24>(trunc_ln708_733_fu_10702_p4.read()) + sc_biguint<24>(zext_ln415_737_fu_10725_p1.read()));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_add_ln415_738_fu_10909_p2() {
    add_ln415_738_fu_10909_p2 = (!trunc_ln708_734_fu_10882_p4.read().is_01() || !zext_ln415_738_fu_10905_p1.read().is_01())? sc_lv<24>(): (sc_biguint<24>(trunc_ln708_734_fu_10882_p4.read()) + sc_biguint<24>(zext_ln415_738_fu_10905_p1.read()));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_add_ln415_739_fu_11089_p2() {
    add_ln415_739_fu_11089_p2 = (!trunc_ln708_735_fu_11062_p4.read().is_01() || !zext_ln415_739_fu_11085_p1.read().is_01())? sc_lv<24>(): (sc_biguint<24>(trunc_ln708_735_fu_11062_p4.read()) + sc_biguint<24>(zext_ln415_739_fu_11085_p1.read()));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_add_ln415_740_fu_11269_p2() {
    add_ln415_740_fu_11269_p2 = (!trunc_ln708_736_fu_11242_p4.read().is_01() || !zext_ln415_740_fu_11265_p1.read().is_01())? sc_lv<24>(): (sc_biguint<24>(trunc_ln708_736_fu_11242_p4.read()) + sc_biguint<24>(zext_ln415_740_fu_11265_p1.read()));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_add_ln415_741_fu_11449_p2() {
    add_ln415_741_fu_11449_p2 = (!trunc_ln708_737_fu_11422_p4.read().is_01() || !zext_ln415_741_fu_11445_p1.read().is_01())? sc_lv<24>(): (sc_biguint<24>(trunc_ln708_737_fu_11422_p4.read()) + sc_biguint<24>(zext_ln415_741_fu_11445_p1.read()));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_add_ln415_742_fu_11629_p2() {
    add_ln415_742_fu_11629_p2 = (!trunc_ln708_738_fu_11602_p4.read().is_01() || !zext_ln415_742_fu_11625_p1.read().is_01())? sc_lv<24>(): (sc_biguint<24>(trunc_ln708_738_fu_11602_p4.read()) + sc_biguint<24>(zext_ln415_742_fu_11625_p1.read()));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_add_ln415_743_fu_11809_p2() {
    add_ln415_743_fu_11809_p2 = (!trunc_ln708_739_fu_11782_p4.read().is_01() || !zext_ln415_743_fu_11805_p1.read().is_01())? sc_lv<24>(): (sc_biguint<24>(trunc_ln708_739_fu_11782_p4.read()) + sc_biguint<24>(zext_ln415_743_fu_11805_p1.read()));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_add_ln415_744_fu_20968_p2() {
    add_ln415_744_fu_20968_p2 = (!trunc_ln708_740_fu_20941_p4.read().is_01() || !zext_ln415_744_fu_20964_p1.read().is_01())? sc_lv<24>(): (sc_biguint<24>(trunc_ln708_740_fu_20941_p4.read()) + sc_biguint<24>(zext_ln415_744_fu_20964_p1.read()));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_add_ln415_745_fu_11999_p2() {
    add_ln415_745_fu_11999_p2 = (!trunc_ln708_741_fu_11972_p4.read().is_01() || !zext_ln415_745_fu_11995_p1.read().is_01())? sc_lv<24>(): (sc_biguint<24>(trunc_ln708_741_fu_11972_p4.read()) + sc_biguint<24>(zext_ln415_745_fu_11995_p1.read()));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_add_ln415_746_fu_12179_p2() {
    add_ln415_746_fu_12179_p2 = (!trunc_ln708_742_fu_12152_p4.read().is_01() || !zext_ln415_746_fu_12175_p1.read().is_01())? sc_lv<24>(): (sc_biguint<24>(trunc_ln708_742_fu_12152_p4.read()) + sc_biguint<24>(zext_ln415_746_fu_12175_p1.read()));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_add_ln415_747_fu_12359_p2() {
    add_ln415_747_fu_12359_p2 = (!trunc_ln708_743_fu_12332_p4.read().is_01() || !zext_ln415_747_fu_12355_p1.read().is_01())? sc_lv<24>(): (sc_biguint<24>(trunc_ln708_743_fu_12332_p4.read()) + sc_biguint<24>(zext_ln415_747_fu_12355_p1.read()));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_add_ln415_748_fu_12539_p2() {
    add_ln415_748_fu_12539_p2 = (!trunc_ln708_744_fu_12512_p4.read().is_01() || !zext_ln415_748_fu_12535_p1.read().is_01())? sc_lv<24>(): (sc_biguint<24>(trunc_ln708_744_fu_12512_p4.read()) + sc_biguint<24>(zext_ln415_748_fu_12535_p1.read()));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_add_ln415_749_fu_12719_p2() {
    add_ln415_749_fu_12719_p2 = (!trunc_ln708_745_fu_12692_p4.read().is_01() || !zext_ln415_749_fu_12715_p1.read().is_01())? sc_lv<24>(): (sc_biguint<24>(trunc_ln708_745_fu_12692_p4.read()) + sc_biguint<24>(zext_ln415_749_fu_12715_p1.read()));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_add_ln415_750_fu_12899_p2() {
    add_ln415_750_fu_12899_p2 = (!trunc_ln708_746_fu_12872_p4.read().is_01() || !zext_ln415_750_fu_12895_p1.read().is_01())? sc_lv<24>(): (sc_biguint<24>(trunc_ln708_746_fu_12872_p4.read()) + sc_biguint<24>(zext_ln415_750_fu_12895_p1.read()));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_add_ln415_751_fu_13079_p2() {
    add_ln415_751_fu_13079_p2 = (!trunc_ln708_747_fu_13052_p4.read().is_01() || !zext_ln415_751_fu_13075_p1.read().is_01())? sc_lv<24>(): (sc_biguint<24>(trunc_ln708_747_fu_13052_p4.read()) + sc_biguint<24>(zext_ln415_751_fu_13075_p1.read()));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_add_ln415_752_fu_13259_p2() {
    add_ln415_752_fu_13259_p2 = (!trunc_ln708_748_fu_13232_p4.read().is_01() || !zext_ln415_752_fu_13255_p1.read().is_01())? sc_lv<24>(): (sc_biguint<24>(trunc_ln708_748_fu_13232_p4.read()) + sc_biguint<24>(zext_ln415_752_fu_13255_p1.read()));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_add_ln415_753_fu_13439_p2() {
    add_ln415_753_fu_13439_p2 = (!trunc_ln708_749_fu_13412_p4.read().is_01() || !zext_ln415_753_fu_13435_p1.read().is_01())? sc_lv<24>(): (sc_biguint<24>(trunc_ln708_749_fu_13412_p4.read()) + sc_biguint<24>(zext_ln415_753_fu_13435_p1.read()));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_add_ln415_754_fu_13619_p2() {
    add_ln415_754_fu_13619_p2 = (!trunc_ln708_750_fu_13592_p4.read().is_01() || !zext_ln415_754_fu_13615_p1.read().is_01())? sc_lv<24>(): (sc_biguint<24>(trunc_ln708_750_fu_13592_p4.read()) + sc_biguint<24>(zext_ln415_754_fu_13615_p1.read()));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_add_ln415_755_fu_13799_p2() {
    add_ln415_755_fu_13799_p2 = (!trunc_ln708_751_fu_13772_p4.read().is_01() || !zext_ln415_755_fu_13795_p1.read().is_01())? sc_lv<24>(): (sc_biguint<24>(trunc_ln708_751_fu_13772_p4.read()) + sc_biguint<24>(zext_ln415_755_fu_13795_p1.read()));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_add_ln415_756_fu_13979_p2() {
    add_ln415_756_fu_13979_p2 = (!trunc_ln708_752_fu_13952_p4.read().is_01() || !zext_ln415_756_fu_13975_p1.read().is_01())? sc_lv<24>(): (sc_biguint<24>(trunc_ln708_752_fu_13952_p4.read()) + sc_biguint<24>(zext_ln415_756_fu_13975_p1.read()));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_add_ln415_757_fu_14159_p2() {
    add_ln415_757_fu_14159_p2 = (!trunc_ln708_753_fu_14132_p4.read().is_01() || !zext_ln415_757_fu_14155_p1.read().is_01())? sc_lv<24>(): (sc_biguint<24>(trunc_ln708_753_fu_14132_p4.read()) + sc_biguint<24>(zext_ln415_757_fu_14155_p1.read()));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_add_ln415_758_fu_14339_p2() {
    add_ln415_758_fu_14339_p2 = (!trunc_ln708_754_fu_14312_p4.read().is_01() || !zext_ln415_758_fu_14335_p1.read().is_01())? sc_lv<24>(): (sc_biguint<24>(trunc_ln708_754_fu_14312_p4.read()) + sc_biguint<24>(zext_ln415_758_fu_14335_p1.read()));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_add_ln415_759_fu_14519_p2() {
    add_ln415_759_fu_14519_p2 = (!trunc_ln708_755_fu_14492_p4.read().is_01() || !zext_ln415_759_fu_14515_p1.read().is_01())? sc_lv<24>(): (sc_biguint<24>(trunc_ln708_755_fu_14492_p4.read()) + sc_biguint<24>(zext_ln415_759_fu_14515_p1.read()));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_add_ln415_760_fu_14699_p2() {
    add_ln415_760_fu_14699_p2 = (!trunc_ln708_756_fu_14672_p4.read().is_01() || !zext_ln415_760_fu_14695_p1.read().is_01())? sc_lv<24>(): (sc_biguint<24>(trunc_ln708_756_fu_14672_p4.read()) + sc_biguint<24>(zext_ln415_760_fu_14695_p1.read()));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_add_ln415_761_fu_14879_p2() {
    add_ln415_761_fu_14879_p2 = (!trunc_ln708_757_fu_14852_p4.read().is_01() || !zext_ln415_761_fu_14875_p1.read().is_01())? sc_lv<24>(): (sc_biguint<24>(trunc_ln708_757_fu_14852_p4.read()) + sc_biguint<24>(zext_ln415_761_fu_14875_p1.read()));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_add_ln415_762_fu_15059_p2() {
    add_ln415_762_fu_15059_p2 = (!trunc_ln708_758_fu_15032_p4.read().is_01() || !zext_ln415_762_fu_15055_p1.read().is_01())? sc_lv<24>(): (sc_biguint<24>(trunc_ln708_758_fu_15032_p4.read()) + sc_biguint<24>(zext_ln415_762_fu_15055_p1.read()));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_add_ln415_763_fu_15239_p2() {
    add_ln415_763_fu_15239_p2 = (!trunc_ln708_759_fu_15212_p4.read().is_01() || !zext_ln415_763_fu_15235_p1.read().is_01())? sc_lv<24>(): (sc_biguint<24>(trunc_ln708_759_fu_15212_p4.read()) + sc_biguint<24>(zext_ln415_763_fu_15235_p1.read()));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_add_ln415_764_fu_22899_p2() {
    add_ln415_764_fu_22899_p2 = (!trunc_ln708_760_fu_22872_p4.read().is_01() || !zext_ln415_764_fu_22895_p1.read().is_01())? sc_lv<24>(): (sc_biguint<24>(trunc_ln708_760_fu_22872_p4.read()) + sc_biguint<24>(zext_ln415_764_fu_22895_p1.read()));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_add_ln415_fu_1469_p2() {
    add_ln415_fu_1469_p2 = (!trunc_ln_fu_1442_p4.read().is_01() || !zext_ln415_fu_1465_p1.read().is_01())? sc_lv<24>(): (sc_biguint<24>(trunc_ln_fu_1442_p4.read()) + sc_biguint<24>(zext_ln415_fu_1465_p1.read()));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln360_fu_1390_p2() {
    and_ln360_fu_1390_p2 = (icmp_ln360_fu_1364_p2.read() & icmp_ln360_3_fu_1384_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln416_671_fu_1689_p2() {
    and_ln416_671_fu_1689_p2 = (tmp_5347_fu_1651_p3.read() & xor_ln416_671_fu_1683_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln416_672_fu_1889_p2() {
    and_ln416_672_fu_1889_p2 = (tmp_5354_fu_1851_p3.read() & xor_ln416_672_fu_1883_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln416_673_fu_2089_p2() {
    and_ln416_673_fu_2089_p2 = (tmp_5361_fu_2051_p3.read() & xor_ln416_673_fu_2083_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln416_674_fu_2281_p2() {
    and_ln416_674_fu_2281_p2 = (tmp_5368_fu_2243_p3.read() & xor_ln416_674_fu_2275_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln416_675_fu_2473_p2() {
    and_ln416_675_fu_2473_p2 = (tmp_5375_fu_2435_p3.read() & xor_ln416_675_fu_2467_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln416_676_fu_2665_p2() {
    and_ln416_676_fu_2665_p2 = (tmp_5382_fu_2627_p3.read() & xor_ln416_676_fu_2659_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln416_677_fu_2857_p2() {
    and_ln416_677_fu_2857_p2 = (tmp_5389_fu_2819_p3.read() & xor_ln416_677_fu_2851_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln416_678_fu_3049_p2() {
    and_ln416_678_fu_3049_p2 = (tmp_5396_fu_3011_p3.read() & xor_ln416_678_fu_3043_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln416_679_fu_3241_p2() {
    and_ln416_679_fu_3241_p2 = (tmp_5403_fu_3203_p3.read() & xor_ln416_679_fu_3235_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln416_680_fu_3433_p2() {
    and_ln416_680_fu_3433_p2 = (tmp_5410_fu_3395_p3.read() & xor_ln416_680_fu_3427_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln416_681_fu_3625_p2() {
    and_ln416_681_fu_3625_p2 = (tmp_5417_fu_3587_p3.read() & xor_ln416_681_fu_3619_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln416_682_fu_3817_p2() {
    and_ln416_682_fu_3817_p2 = (tmp_5424_fu_3779_p3.read() & xor_ln416_682_fu_3811_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln416_683_fu_4009_p2() {
    and_ln416_683_fu_4009_p2 = (tmp_5431_fu_3971_p3.read() & xor_ln416_683_fu_4003_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln416_684_fu_4201_p2() {
    and_ln416_684_fu_4201_p2 = (tmp_5438_fu_4163_p3.read() & xor_ln416_684_fu_4195_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln416_685_fu_4393_p2() {
    and_ln416_685_fu_4393_p2 = (tmp_5445_fu_4355_p3.read() & xor_ln416_685_fu_4387_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln416_686_fu_4585_p2() {
    and_ln416_686_fu_4585_p2 = (tmp_5452_fu_4547_p3.read() & xor_ln416_686_fu_4579_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln416_687_fu_4777_p2() {
    and_ln416_687_fu_4777_p2 = (tmp_5459_fu_4739_p3.read() & xor_ln416_687_fu_4771_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln416_688_fu_4969_p2() {
    and_ln416_688_fu_4969_p2 = (tmp_5466_fu_4931_p3.read() & xor_ln416_688_fu_4963_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln416_689_fu_17126_p2() {
    and_ln416_689_fu_17126_p2 = (tmp_5473_fu_17088_p3.read() & xor_ln416_689_fu_17120_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln416_690_fu_5159_p2() {
    and_ln416_690_fu_5159_p2 = (tmp_5480_fu_5121_p3.read() & xor_ln416_690_fu_5153_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln416_691_fu_5339_p2() {
    and_ln416_691_fu_5339_p2 = (tmp_5487_fu_5301_p3.read() & xor_ln416_691_fu_5333_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln416_692_fu_5519_p2() {
    and_ln416_692_fu_5519_p2 = (tmp_5494_fu_5481_p3.read() & xor_ln416_692_fu_5513_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln416_693_fu_5699_p2() {
    and_ln416_693_fu_5699_p2 = (tmp_5501_fu_5661_p3.read() & xor_ln416_693_fu_5693_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln416_694_fu_5879_p2() {
    and_ln416_694_fu_5879_p2 = (tmp_5508_fu_5841_p3.read() & xor_ln416_694_fu_5873_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln416_695_fu_6059_p2() {
    and_ln416_695_fu_6059_p2 = (tmp_5515_fu_6021_p3.read() & xor_ln416_695_fu_6053_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln416_696_fu_6239_p2() {
    and_ln416_696_fu_6239_p2 = (tmp_5522_fu_6201_p3.read() & xor_ln416_696_fu_6233_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln416_697_fu_6419_p2() {
    and_ln416_697_fu_6419_p2 = (tmp_5529_fu_6381_p3.read() & xor_ln416_697_fu_6413_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln416_698_fu_6599_p2() {
    and_ln416_698_fu_6599_p2 = (tmp_5536_fu_6561_p3.read() & xor_ln416_698_fu_6593_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln416_699_fu_6779_p2() {
    and_ln416_699_fu_6779_p2 = (tmp_5543_fu_6741_p3.read() & xor_ln416_699_fu_6773_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln416_700_fu_6959_p2() {
    and_ln416_700_fu_6959_p2 = (tmp_5550_fu_6921_p3.read() & xor_ln416_700_fu_6953_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln416_701_fu_7139_p2() {
    and_ln416_701_fu_7139_p2 = (tmp_5557_fu_7101_p3.read() & xor_ln416_701_fu_7133_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln416_702_fu_7319_p2() {
    and_ln416_702_fu_7319_p2 = (tmp_5564_fu_7281_p3.read() & xor_ln416_702_fu_7313_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln416_703_fu_7499_p2() {
    and_ln416_703_fu_7499_p2 = (tmp_5571_fu_7461_p3.read() & xor_ln416_703_fu_7493_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln416_704_fu_7679_p2() {
    and_ln416_704_fu_7679_p2 = (tmp_5578_fu_7641_p3.read() & xor_ln416_704_fu_7673_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln416_705_fu_7859_p2() {
    and_ln416_705_fu_7859_p2 = (tmp_5585_fu_7821_p3.read() & xor_ln416_705_fu_7853_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln416_706_fu_8039_p2() {
    and_ln416_706_fu_8039_p2 = (tmp_5592_fu_8001_p3.read() & xor_ln416_706_fu_8033_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln416_707_fu_8219_p2() {
    and_ln416_707_fu_8219_p2 = (tmp_5599_fu_8181_p3.read() & xor_ln416_707_fu_8213_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln416_708_fu_8399_p2() {
    and_ln416_708_fu_8399_p2 = (tmp_5606_fu_8361_p3.read() & xor_ln416_708_fu_8393_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln416_709_fu_19057_p2() {
    and_ln416_709_fu_19057_p2 = (tmp_5613_fu_19019_p3.read() & xor_ln416_709_fu_19051_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln416_710_fu_8589_p2() {
    and_ln416_710_fu_8589_p2 = (tmp_5620_fu_8551_p3.read() & xor_ln416_710_fu_8583_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln416_711_fu_8769_p2() {
    and_ln416_711_fu_8769_p2 = (tmp_5627_fu_8731_p3.read() & xor_ln416_711_fu_8763_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln416_712_fu_8949_p2() {
    and_ln416_712_fu_8949_p2 = (tmp_5634_fu_8911_p3.read() & xor_ln416_712_fu_8943_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln416_713_fu_9129_p2() {
    and_ln416_713_fu_9129_p2 = (tmp_5641_fu_9091_p3.read() & xor_ln416_713_fu_9123_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln416_714_fu_9309_p2() {
    and_ln416_714_fu_9309_p2 = (tmp_5648_fu_9271_p3.read() & xor_ln416_714_fu_9303_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln416_715_fu_9489_p2() {
    and_ln416_715_fu_9489_p2 = (tmp_5655_fu_9451_p3.read() & xor_ln416_715_fu_9483_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln416_716_fu_9669_p2() {
    and_ln416_716_fu_9669_p2 = (tmp_5662_fu_9631_p3.read() & xor_ln416_716_fu_9663_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln416_717_fu_9849_p2() {
    and_ln416_717_fu_9849_p2 = (tmp_5669_fu_9811_p3.read() & xor_ln416_717_fu_9843_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln416_718_fu_10029_p2() {
    and_ln416_718_fu_10029_p2 = (tmp_5676_fu_9991_p3.read() & xor_ln416_718_fu_10023_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln416_719_fu_10209_p2() {
    and_ln416_719_fu_10209_p2 = (tmp_5683_fu_10171_p3.read() & xor_ln416_719_fu_10203_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln416_720_fu_10389_p2() {
    and_ln416_720_fu_10389_p2 = (tmp_5690_fu_10351_p3.read() & xor_ln416_720_fu_10383_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln416_721_fu_10569_p2() {
    and_ln416_721_fu_10569_p2 = (tmp_5697_fu_10531_p3.read() & xor_ln416_721_fu_10563_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln416_722_fu_10749_p2() {
    and_ln416_722_fu_10749_p2 = (tmp_5704_fu_10711_p3.read() & xor_ln416_722_fu_10743_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln416_723_fu_10929_p2() {
    and_ln416_723_fu_10929_p2 = (tmp_5711_fu_10891_p3.read() & xor_ln416_723_fu_10923_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln416_724_fu_11109_p2() {
    and_ln416_724_fu_11109_p2 = (tmp_5718_fu_11071_p3.read() & xor_ln416_724_fu_11103_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln416_725_fu_11289_p2() {
    and_ln416_725_fu_11289_p2 = (tmp_5725_fu_11251_p3.read() & xor_ln416_725_fu_11283_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln416_726_fu_11469_p2() {
    and_ln416_726_fu_11469_p2 = (tmp_5732_fu_11431_p3.read() & xor_ln416_726_fu_11463_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln416_727_fu_11649_p2() {
    and_ln416_727_fu_11649_p2 = (tmp_5739_fu_11611_p3.read() & xor_ln416_727_fu_11643_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln416_728_fu_11829_p2() {
    and_ln416_728_fu_11829_p2 = (tmp_5746_fu_11791_p3.read() & xor_ln416_728_fu_11823_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln416_729_fu_20988_p2() {
    and_ln416_729_fu_20988_p2 = (tmp_5753_fu_20950_p3.read() & xor_ln416_729_fu_20982_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln416_730_fu_12019_p2() {
    and_ln416_730_fu_12019_p2 = (tmp_5760_fu_11981_p3.read() & xor_ln416_730_fu_12013_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln416_731_fu_12199_p2() {
    and_ln416_731_fu_12199_p2 = (tmp_5767_fu_12161_p3.read() & xor_ln416_731_fu_12193_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln416_732_fu_12379_p2() {
    and_ln416_732_fu_12379_p2 = (tmp_5774_fu_12341_p3.read() & xor_ln416_732_fu_12373_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln416_733_fu_12559_p2() {
    and_ln416_733_fu_12559_p2 = (tmp_5781_fu_12521_p3.read() & xor_ln416_733_fu_12553_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln416_734_fu_12739_p2() {
    and_ln416_734_fu_12739_p2 = (tmp_5788_fu_12701_p3.read() & xor_ln416_734_fu_12733_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln416_735_fu_12919_p2() {
    and_ln416_735_fu_12919_p2 = (tmp_5795_fu_12881_p3.read() & xor_ln416_735_fu_12913_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln416_736_fu_13099_p2() {
    and_ln416_736_fu_13099_p2 = (tmp_5802_fu_13061_p3.read() & xor_ln416_736_fu_13093_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln416_737_fu_13279_p2() {
    and_ln416_737_fu_13279_p2 = (tmp_5809_fu_13241_p3.read() & xor_ln416_737_fu_13273_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln416_738_fu_13459_p2() {
    and_ln416_738_fu_13459_p2 = (tmp_5816_fu_13421_p3.read() & xor_ln416_738_fu_13453_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln416_739_fu_13639_p2() {
    and_ln416_739_fu_13639_p2 = (tmp_5823_fu_13601_p3.read() & xor_ln416_739_fu_13633_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln416_740_fu_13819_p2() {
    and_ln416_740_fu_13819_p2 = (tmp_5830_fu_13781_p3.read() & xor_ln416_740_fu_13813_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln416_741_fu_13999_p2() {
    and_ln416_741_fu_13999_p2 = (tmp_5837_fu_13961_p3.read() & xor_ln416_741_fu_13993_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln416_742_fu_14179_p2() {
    and_ln416_742_fu_14179_p2 = (tmp_5844_fu_14141_p3.read() & xor_ln416_742_fu_14173_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln416_743_fu_14359_p2() {
    and_ln416_743_fu_14359_p2 = (tmp_5851_fu_14321_p3.read() & xor_ln416_743_fu_14353_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln416_744_fu_14539_p2() {
    and_ln416_744_fu_14539_p2 = (tmp_5858_fu_14501_p3.read() & xor_ln416_744_fu_14533_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln416_745_fu_14719_p2() {
    and_ln416_745_fu_14719_p2 = (tmp_5865_fu_14681_p3.read() & xor_ln416_745_fu_14713_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln416_746_fu_14899_p2() {
    and_ln416_746_fu_14899_p2 = (tmp_5872_fu_14861_p3.read() & xor_ln416_746_fu_14893_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln416_747_fu_15079_p2() {
    and_ln416_747_fu_15079_p2 = (tmp_5879_fu_15041_p3.read() & xor_ln416_747_fu_15073_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln416_748_fu_15259_p2() {
    and_ln416_748_fu_15259_p2 = (tmp_5886_fu_15221_p3.read() & xor_ln416_748_fu_15253_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln416_749_fu_22919_p2() {
    and_ln416_749_fu_22919_p2 = (tmp_5893_fu_22881_p3.read() & xor_ln416_749_fu_22913_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln416_fu_1489_p2() {
    and_ln416_fu_1489_p2 = (tmp_5340_fu_1451_p3.read() & xor_ln416_fu_1483_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln785_671_fu_1729_p2() {
    and_ln785_671_fu_1729_p2 = (or_ln785_1_fu_1723_p2.read() & xor_ln779_1_fu_1703_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln785_672_fu_1929_p2() {
    and_ln785_672_fu_1929_p2 = (or_ln785_2_fu_1923_p2.read() & xor_ln779_2_fu_1903_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln785_673_fu_2129_p2() {
    and_ln785_673_fu_2129_p2 = (or_ln785_3_fu_2123_p2.read() & xor_ln779_3_fu_2103_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln785_674_fu_2321_p2() {
    and_ln785_674_fu_2321_p2 = (or_ln785_418_fu_2315_p2.read() & xor_ln779_4_fu_2295_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln785_675_fu_2513_p2() {
    and_ln785_675_fu_2513_p2 = (or_ln785_5_fu_2507_p2.read() & xor_ln779_5_fu_2487_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln785_676_fu_2705_p2() {
    and_ln785_676_fu_2705_p2 = (or_ln785_6_fu_2699_p2.read() & xor_ln779_6_fu_2679_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln785_677_fu_2897_p2() {
    and_ln785_677_fu_2897_p2 = (or_ln785_7_fu_2891_p2.read() & xor_ln779_7_fu_2871_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln785_678_fu_3089_p2() {
    and_ln785_678_fu_3089_p2 = (or_ln785_8_fu_3083_p2.read() & xor_ln779_8_fu_3063_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln785_679_fu_3281_p2() {
    and_ln785_679_fu_3281_p2 = (or_ln785_9_fu_3275_p2.read() & xor_ln779_9_fu_3255_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln785_680_fu_3473_p2() {
    and_ln785_680_fu_3473_p2 = (or_ln785_10_fu_3467_p2.read() & xor_ln779_10_fu_3447_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln785_681_fu_3665_p2() {
    and_ln785_681_fu_3665_p2 = (or_ln785_11_fu_3659_p2.read() & xor_ln779_11_fu_3639_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln785_682_fu_3857_p2() {
    and_ln785_682_fu_3857_p2 = (or_ln785_12_fu_3851_p2.read() & xor_ln779_12_fu_3831_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln785_683_fu_4049_p2() {
    and_ln785_683_fu_4049_p2 = (or_ln785_13_fu_4043_p2.read() & xor_ln779_13_fu_4023_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln785_684_fu_4241_p2() {
    and_ln785_684_fu_4241_p2 = (or_ln785_14_fu_4235_p2.read() & xor_ln779_14_fu_4215_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln785_685_fu_4433_p2() {
    and_ln785_685_fu_4433_p2 = (or_ln785_15_fu_4427_p2.read() & xor_ln779_15_fu_4407_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln785_686_fu_4625_p2() {
    and_ln785_686_fu_4625_p2 = (or_ln785_16_fu_4619_p2.read() & xor_ln779_16_fu_4599_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln785_687_fu_4817_p2() {
    and_ln785_687_fu_4817_p2 = (or_ln785_17_fu_4811_p2.read() & xor_ln779_17_fu_4791_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln785_688_fu_5009_p2() {
    and_ln785_688_fu_5009_p2 = (or_ln785_18_fu_5003_p2.read() & xor_ln779_18_fu_4983_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln785_689_fu_17166_p2() {
    and_ln785_689_fu_17166_p2 = (or_ln785_19_fu_17160_p2.read() & xor_ln779_19_fu_17140_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln785_690_fu_5199_p2() {
    and_ln785_690_fu_5199_p2 = (or_ln785_20_fu_5193_p2.read() & xor_ln779_20_fu_5173_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln785_691_fu_5379_p2() {
    and_ln785_691_fu_5379_p2 = (or_ln785_21_fu_5373_p2.read() & xor_ln779_21_fu_5353_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln785_692_fu_5559_p2() {
    and_ln785_692_fu_5559_p2 = (or_ln785_22_fu_5553_p2.read() & xor_ln779_22_fu_5533_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln785_693_fu_5739_p2() {
    and_ln785_693_fu_5739_p2 = (or_ln785_23_fu_5733_p2.read() & xor_ln779_23_fu_5713_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln785_694_fu_5919_p2() {
    and_ln785_694_fu_5919_p2 = (or_ln785_24_fu_5913_p2.read() & xor_ln779_24_fu_5893_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln785_695_fu_6099_p2() {
    and_ln785_695_fu_6099_p2 = (or_ln785_25_fu_6093_p2.read() & xor_ln779_25_fu_6073_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln785_696_fu_6279_p2() {
    and_ln785_696_fu_6279_p2 = (or_ln785_26_fu_6273_p2.read() & xor_ln779_26_fu_6253_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln785_697_fu_6459_p2() {
    and_ln785_697_fu_6459_p2 = (or_ln785_27_fu_6453_p2.read() & xor_ln779_27_fu_6433_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln785_698_fu_6639_p2() {
    and_ln785_698_fu_6639_p2 = (or_ln785_28_fu_6633_p2.read() & xor_ln779_28_fu_6613_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln785_699_fu_6819_p2() {
    and_ln785_699_fu_6819_p2 = (or_ln785_29_fu_6813_p2.read() & xor_ln779_29_fu_6793_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln785_700_fu_6999_p2() {
    and_ln785_700_fu_6999_p2 = (or_ln785_30_fu_6993_p2.read() & xor_ln779_30_fu_6973_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln785_701_fu_7179_p2() {
    and_ln785_701_fu_7179_p2 = (or_ln785_31_fu_7173_p2.read() & xor_ln779_31_fu_7153_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln785_702_fu_7359_p2() {
    and_ln785_702_fu_7359_p2 = (or_ln785_32_fu_7353_p2.read() & xor_ln779_32_fu_7333_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln785_703_fu_7539_p2() {
    and_ln785_703_fu_7539_p2 = (or_ln785_33_fu_7533_p2.read() & xor_ln779_33_fu_7513_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln785_704_fu_7719_p2() {
    and_ln785_704_fu_7719_p2 = (or_ln785_34_fu_7713_p2.read() & xor_ln779_34_fu_7693_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln785_705_fu_7899_p2() {
    and_ln785_705_fu_7899_p2 = (or_ln785_35_fu_7893_p2.read() & xor_ln779_35_fu_7873_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln785_706_fu_8079_p2() {
    and_ln785_706_fu_8079_p2 = (or_ln785_36_fu_8073_p2.read() & xor_ln779_36_fu_8053_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln785_707_fu_8259_p2() {
    and_ln785_707_fu_8259_p2 = (or_ln785_37_fu_8253_p2.read() & xor_ln779_37_fu_8233_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln785_708_fu_8439_p2() {
    and_ln785_708_fu_8439_p2 = (or_ln785_38_fu_8433_p2.read() & xor_ln779_38_fu_8413_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln785_709_fu_19097_p2() {
    and_ln785_709_fu_19097_p2 = (or_ln785_39_fu_19091_p2.read() & xor_ln779_39_fu_19071_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln785_710_fu_8629_p2() {
    and_ln785_710_fu_8629_p2 = (or_ln785_40_fu_8623_p2.read() & xor_ln779_40_fu_8603_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln785_711_fu_8809_p2() {
    and_ln785_711_fu_8809_p2 = (or_ln785_41_fu_8803_p2.read() & xor_ln779_41_fu_8783_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln785_712_fu_8989_p2() {
    and_ln785_712_fu_8989_p2 = (or_ln785_42_fu_8983_p2.read() & xor_ln779_42_fu_8963_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln785_713_fu_9169_p2() {
    and_ln785_713_fu_9169_p2 = (or_ln785_43_fu_9163_p2.read() & xor_ln779_43_fu_9143_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln785_714_fu_9349_p2() {
    and_ln785_714_fu_9349_p2 = (or_ln785_44_fu_9343_p2.read() & xor_ln779_44_fu_9323_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln785_715_fu_9529_p2() {
    and_ln785_715_fu_9529_p2 = (or_ln785_45_fu_9523_p2.read() & xor_ln779_45_fu_9503_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln785_716_fu_9709_p2() {
    and_ln785_716_fu_9709_p2 = (or_ln785_46_fu_9703_p2.read() & xor_ln779_46_fu_9683_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln785_717_fu_9889_p2() {
    and_ln785_717_fu_9889_p2 = (or_ln785_47_fu_9883_p2.read() & xor_ln779_47_fu_9863_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln785_718_fu_10069_p2() {
    and_ln785_718_fu_10069_p2 = (or_ln785_48_fu_10063_p2.read() & xor_ln779_48_fu_10043_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln785_719_fu_10249_p2() {
    and_ln785_719_fu_10249_p2 = (or_ln785_49_fu_10243_p2.read() & xor_ln779_49_fu_10223_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln785_720_fu_10429_p2() {
    and_ln785_720_fu_10429_p2 = (or_ln785_50_fu_10423_p2.read() & xor_ln779_50_fu_10403_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln785_721_fu_10609_p2() {
    and_ln785_721_fu_10609_p2 = (or_ln785_51_fu_10603_p2.read() & xor_ln779_51_fu_10583_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln785_722_fu_10789_p2() {
    and_ln785_722_fu_10789_p2 = (or_ln785_52_fu_10783_p2.read() & xor_ln779_52_fu_10763_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln785_723_fu_10969_p2() {
    and_ln785_723_fu_10969_p2 = (or_ln785_53_fu_10963_p2.read() & xor_ln779_53_fu_10943_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln785_724_fu_11149_p2() {
    and_ln785_724_fu_11149_p2 = (or_ln785_54_fu_11143_p2.read() & xor_ln779_54_fu_11123_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln785_725_fu_11329_p2() {
    and_ln785_725_fu_11329_p2 = (or_ln785_55_fu_11323_p2.read() & xor_ln779_55_fu_11303_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln785_726_fu_11509_p2() {
    and_ln785_726_fu_11509_p2 = (or_ln785_56_fu_11503_p2.read() & xor_ln779_56_fu_11483_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln785_727_fu_11689_p2() {
    and_ln785_727_fu_11689_p2 = (or_ln785_57_fu_11683_p2.read() & xor_ln779_57_fu_11663_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln785_728_fu_11869_p2() {
    and_ln785_728_fu_11869_p2 = (or_ln785_58_fu_11863_p2.read() & xor_ln779_58_fu_11843_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln785_729_fu_21028_p2() {
    and_ln785_729_fu_21028_p2 = (or_ln785_59_fu_21022_p2.read() & xor_ln779_59_fu_21002_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln785_730_fu_12059_p2() {
    and_ln785_730_fu_12059_p2 = (or_ln785_60_fu_12053_p2.read() & xor_ln779_60_fu_12033_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln785_731_fu_12239_p2() {
    and_ln785_731_fu_12239_p2 = (or_ln785_61_fu_12233_p2.read() & xor_ln779_61_fu_12213_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln785_732_fu_12419_p2() {
    and_ln785_732_fu_12419_p2 = (or_ln785_62_fu_12413_p2.read() & xor_ln779_62_fu_12393_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln785_733_fu_12599_p2() {
    and_ln785_733_fu_12599_p2 = (or_ln785_63_fu_12593_p2.read() & xor_ln779_63_fu_12573_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln785_734_fu_12779_p2() {
    and_ln785_734_fu_12779_p2 = (or_ln785_64_fu_12773_p2.read() & xor_ln779_64_fu_12753_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln785_735_fu_12959_p2() {
    and_ln785_735_fu_12959_p2 = (or_ln785_65_fu_12953_p2.read() & xor_ln779_65_fu_12933_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln785_736_fu_13139_p2() {
    and_ln785_736_fu_13139_p2 = (or_ln785_66_fu_13133_p2.read() & xor_ln779_66_fu_13113_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln785_737_fu_13319_p2() {
    and_ln785_737_fu_13319_p2 = (or_ln785_67_fu_13313_p2.read() & xor_ln779_67_fu_13293_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln785_738_fu_13499_p2() {
    and_ln785_738_fu_13499_p2 = (or_ln785_68_fu_13493_p2.read() & xor_ln779_68_fu_13473_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln785_739_fu_13679_p2() {
    and_ln785_739_fu_13679_p2 = (or_ln785_69_fu_13673_p2.read() & xor_ln779_69_fu_13653_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln785_740_fu_13859_p2() {
    and_ln785_740_fu_13859_p2 = (or_ln785_70_fu_13853_p2.read() & xor_ln779_70_fu_13833_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln785_741_fu_14039_p2() {
    and_ln785_741_fu_14039_p2 = (or_ln785_71_fu_14033_p2.read() & xor_ln779_71_fu_14013_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln785_742_fu_14219_p2() {
    and_ln785_742_fu_14219_p2 = (or_ln785_72_fu_14213_p2.read() & xor_ln779_72_fu_14193_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln785_743_fu_14399_p2() {
    and_ln785_743_fu_14399_p2 = (or_ln785_73_fu_14393_p2.read() & xor_ln779_73_fu_14373_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln785_744_fu_14579_p2() {
    and_ln785_744_fu_14579_p2 = (or_ln785_74_fu_14573_p2.read() & xor_ln779_74_fu_14553_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln785_745_fu_14759_p2() {
    and_ln785_745_fu_14759_p2 = (or_ln785_75_fu_14753_p2.read() & xor_ln779_75_fu_14733_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln785_746_fu_14939_p2() {
    and_ln785_746_fu_14939_p2 = (or_ln785_76_fu_14933_p2.read() & xor_ln779_76_fu_14913_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln785_747_fu_15119_p2() {
    and_ln785_747_fu_15119_p2 = (or_ln785_77_fu_15113_p2.read() & xor_ln779_77_fu_15093_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln785_748_fu_15299_p2() {
    and_ln785_748_fu_15299_p2 = (or_ln785_78_fu_15293_p2.read() & xor_ln779_78_fu_15273_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln785_749_fu_22959_p2() {
    and_ln785_749_fu_22959_p2 = (or_ln785_79_fu_22953_p2.read() & xor_ln779_79_fu_22933_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln785_fu_1529_p2() {
    and_ln785_fu_1529_p2 = (or_ln785_fu_1523_p2.read() & xor_ln779_fu_1503_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln786_10_fu_3479_p2() {
    and_ln786_10_fu_3479_p2 = (tmp_5413_fu_3439_p3.read() & select_ln416_680_fu_3453_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln786_11_fu_3671_p2() {
    and_ln786_11_fu_3671_p2 = (tmp_5420_fu_3631_p3.read() & select_ln416_681_fu_3645_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln786_12_fu_3863_p2() {
    and_ln786_12_fu_3863_p2 = (tmp_5427_fu_3823_p3.read() & select_ln416_682_fu_3837_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln786_13_fu_4055_p2() {
    and_ln786_13_fu_4055_p2 = (tmp_5434_fu_4015_p3.read() & select_ln416_683_fu_4029_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln786_14_fu_4247_p2() {
    and_ln786_14_fu_4247_p2 = (tmp_5441_fu_4207_p3.read() & select_ln416_684_fu_4221_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln786_15_fu_4439_p2() {
    and_ln786_15_fu_4439_p2 = (tmp_5448_fu_4399_p3.read() & select_ln416_685_fu_4413_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln786_16_fu_4631_p2() {
    and_ln786_16_fu_4631_p2 = (tmp_5455_fu_4591_p3.read() & select_ln416_686_fu_4605_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln786_17_fu_4823_p2() {
    and_ln786_17_fu_4823_p2 = (tmp_5462_fu_4783_p3.read() & select_ln416_687_fu_4797_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln786_18_fu_5015_p2() {
    and_ln786_18_fu_5015_p2 = (tmp_5469_fu_4975_p3.read() & select_ln416_688_fu_4989_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln786_1927_fu_1553_p2() {
    and_ln786_1927_fu_1553_p2 = (tmp_5339_fu_1435_p3.read() & xor_ln786_fu_1547_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln786_1928_fu_15421_p2() {
    and_ln786_1928_fu_15421_p2 = (tmp_5344_fu_15394_p3.read() & xor_ln786_1207_fu_15415_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln786_1929_fu_1753_p2() {
    and_ln786_1929_fu_1753_p2 = (tmp_5346_fu_1635_p3.read() & xor_ln786_1366_fu_1747_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln786_1930_fu_15509_p2() {
    and_ln786_1930_fu_15509_p2 = (tmp_5351_fu_15482_p3.read() & xor_ln786_1208_fu_15503_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln786_1931_fu_1953_p2() {
    and_ln786_1931_fu_1953_p2 = (tmp_5353_fu_1835_p3.read() & xor_ln786_1367_fu_1947_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln786_1932_fu_15597_p2() {
    and_ln786_1932_fu_15597_p2 = (tmp_5358_fu_15570_p3.read() & xor_ln786_1209_fu_15591_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln786_1933_fu_2153_p2() {
    and_ln786_1933_fu_2153_p2 = (tmp_5360_fu_2035_p3.read() & xor_ln786_1368_fu_2147_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln786_1934_fu_15685_p2() {
    and_ln786_1934_fu_15685_p2 = (tmp_5365_fu_15658_p3.read() & xor_ln786_1210_fu_15679_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln786_1935_fu_2345_p2() {
    and_ln786_1935_fu_2345_p2 = (tmp_5367_fu_2227_p3.read() & xor_ln786_1369_fu_2339_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln786_1936_fu_15773_p2() {
    and_ln786_1936_fu_15773_p2 = (tmp_5372_fu_15746_p3.read() & xor_ln786_1211_fu_15767_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln786_1937_fu_2537_p2() {
    and_ln786_1937_fu_2537_p2 = (tmp_5374_fu_2419_p3.read() & xor_ln786_1370_fu_2531_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln786_1938_fu_15861_p2() {
    and_ln786_1938_fu_15861_p2 = (tmp_5379_fu_15834_p3.read() & xor_ln786_1212_fu_15855_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln786_1939_fu_2729_p2() {
    and_ln786_1939_fu_2729_p2 = (tmp_5381_fu_2611_p3.read() & xor_ln786_1371_fu_2723_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln786_1940_fu_15949_p2() {
    and_ln786_1940_fu_15949_p2 = (tmp_5386_fu_15922_p3.read() & xor_ln786_1213_fu_15943_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln786_1941_fu_2921_p2() {
    and_ln786_1941_fu_2921_p2 = (tmp_5388_fu_2803_p3.read() & xor_ln786_1372_fu_2915_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln786_1942_fu_16037_p2() {
    and_ln786_1942_fu_16037_p2 = (tmp_5393_fu_16010_p3.read() & xor_ln786_1214_fu_16031_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln786_1943_fu_3113_p2() {
    and_ln786_1943_fu_3113_p2 = (tmp_5395_fu_2995_p3.read() & xor_ln786_1373_fu_3107_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln786_1944_fu_16125_p2() {
    and_ln786_1944_fu_16125_p2 = (tmp_5400_fu_16098_p3.read() & xor_ln786_1215_fu_16119_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln786_1945_fu_3305_p2() {
    and_ln786_1945_fu_3305_p2 = (tmp_5402_fu_3187_p3.read() & xor_ln786_1374_fu_3299_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln786_1946_fu_16213_p2() {
    and_ln786_1946_fu_16213_p2 = (tmp_5407_fu_16186_p3.read() & xor_ln786_1216_fu_16207_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln786_1947_fu_3497_p2() {
    and_ln786_1947_fu_3497_p2 = (tmp_5409_fu_3379_p3.read() & xor_ln786_1375_fu_3491_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln786_1948_fu_16301_p2() {
    and_ln786_1948_fu_16301_p2 = (tmp_5414_fu_16274_p3.read() & xor_ln786_1217_fu_16295_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln786_1949_fu_3689_p2() {
    and_ln786_1949_fu_3689_p2 = (tmp_5416_fu_3571_p3.read() & xor_ln786_1376_fu_3683_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln786_1950_fu_16389_p2() {
    and_ln786_1950_fu_16389_p2 = (tmp_5421_fu_16362_p3.read() & xor_ln786_1218_fu_16383_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln786_1951_fu_3881_p2() {
    and_ln786_1951_fu_3881_p2 = (tmp_5423_fu_3763_p3.read() & xor_ln786_1377_fu_3875_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln786_1952_fu_16477_p2() {
    and_ln786_1952_fu_16477_p2 = (tmp_5428_fu_16450_p3.read() & xor_ln786_1219_fu_16471_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln786_1953_fu_4073_p2() {
    and_ln786_1953_fu_4073_p2 = (tmp_5430_fu_3955_p3.read() & xor_ln786_1378_fu_4067_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln786_1954_fu_16565_p2() {
    and_ln786_1954_fu_16565_p2 = (tmp_5435_fu_16538_p3.read() & xor_ln786_1220_fu_16559_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln786_1955_fu_4265_p2() {
    and_ln786_1955_fu_4265_p2 = (tmp_5437_fu_4147_p3.read() & xor_ln786_1379_fu_4259_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln786_1956_fu_16653_p2() {
    and_ln786_1956_fu_16653_p2 = (tmp_5442_fu_16626_p3.read() & xor_ln786_1221_fu_16647_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln786_1957_fu_4457_p2() {
    and_ln786_1957_fu_4457_p2 = (tmp_5444_fu_4339_p3.read() & xor_ln786_1380_fu_4451_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln786_1958_fu_16741_p2() {
    and_ln786_1958_fu_16741_p2 = (tmp_5449_fu_16714_p3.read() & xor_ln786_1222_fu_16735_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln786_1959_fu_4649_p2() {
    and_ln786_1959_fu_4649_p2 = (tmp_5451_fu_4531_p3.read() & xor_ln786_1381_fu_4643_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln786_1960_fu_16829_p2() {
    and_ln786_1960_fu_16829_p2 = (tmp_5456_fu_16802_p3.read() & xor_ln786_1223_fu_16823_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln786_1961_fu_4841_p2() {
    and_ln786_1961_fu_4841_p2 = (tmp_5458_fu_4723_p3.read() & xor_ln786_1382_fu_4835_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln786_1962_fu_16917_p2() {
    and_ln786_1962_fu_16917_p2 = (tmp_5463_fu_16890_p3.read() & xor_ln786_1224_fu_16911_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln786_1963_fu_5033_p2() {
    and_ln786_1963_fu_5033_p2 = (tmp_5465_fu_4915_p3.read() & xor_ln786_1383_fu_5027_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln786_1964_fu_17005_p2() {
    and_ln786_1964_fu_17005_p2 = (tmp_5470_fu_16978_p3.read() & xor_ln786_1225_fu_16999_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln786_1965_fu_17190_p2() {
    and_ln786_1965_fu_17190_p2 = (tmp_5472_fu_17072_p3.read() & xor_ln786_1384_fu_17184_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln786_1966_fu_17280_p2() {
    and_ln786_1966_fu_17280_p2 = (tmp_5477_fu_17252_p3.read() & xor_ln786_1226_fu_17274_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln786_1967_fu_5223_p2() {
    and_ln786_1967_fu_5223_p2 = (tmp_5479_fu_5105_p3.read() & xor_ln786_1385_fu_5217_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln786_1968_fu_17368_p2() {
    and_ln786_1968_fu_17368_p2 = (tmp_5484_fu_17341_p3.read() & xor_ln786_1227_fu_17362_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln786_1969_fu_5403_p2() {
    and_ln786_1969_fu_5403_p2 = (tmp_5486_fu_5285_p3.read() & xor_ln786_1386_fu_5397_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln786_1970_fu_17456_p2() {
    and_ln786_1970_fu_17456_p2 = (tmp_5491_fu_17429_p3.read() & xor_ln786_1228_fu_17450_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln786_1971_fu_5583_p2() {
    and_ln786_1971_fu_5583_p2 = (tmp_5493_fu_5465_p3.read() & xor_ln786_1387_fu_5577_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln786_1972_fu_17544_p2() {
    and_ln786_1972_fu_17544_p2 = (tmp_5498_fu_17517_p3.read() & xor_ln786_1229_fu_17538_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln786_1973_fu_5763_p2() {
    and_ln786_1973_fu_5763_p2 = (tmp_5500_fu_5645_p3.read() & xor_ln786_1388_fu_5757_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln786_1974_fu_17632_p2() {
    and_ln786_1974_fu_17632_p2 = (tmp_5505_fu_17605_p3.read() & xor_ln786_1230_fu_17626_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln786_1975_fu_5943_p2() {
    and_ln786_1975_fu_5943_p2 = (tmp_5507_fu_5825_p3.read() & xor_ln786_1389_fu_5937_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln786_1976_fu_17720_p2() {
    and_ln786_1976_fu_17720_p2 = (tmp_5512_fu_17693_p3.read() & xor_ln786_1231_fu_17714_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln786_1977_fu_6123_p2() {
    and_ln786_1977_fu_6123_p2 = (tmp_5514_fu_6005_p3.read() & xor_ln786_1390_fu_6117_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln786_1978_fu_17808_p2() {
    and_ln786_1978_fu_17808_p2 = (tmp_5519_fu_17781_p3.read() & xor_ln786_1232_fu_17802_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln786_1979_fu_6303_p2() {
    and_ln786_1979_fu_6303_p2 = (tmp_5521_fu_6185_p3.read() & xor_ln786_1391_fu_6297_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln786_1980_fu_17896_p2() {
    and_ln786_1980_fu_17896_p2 = (tmp_5526_fu_17869_p3.read() & xor_ln786_1233_fu_17890_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln786_1981_fu_6483_p2() {
    and_ln786_1981_fu_6483_p2 = (tmp_5528_fu_6365_p3.read() & xor_ln786_1392_fu_6477_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln786_1982_fu_17984_p2() {
    and_ln786_1982_fu_17984_p2 = (tmp_5533_fu_17957_p3.read() & xor_ln786_1234_fu_17978_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln786_1983_fu_6663_p2() {
    and_ln786_1983_fu_6663_p2 = (tmp_5535_fu_6545_p3.read() & xor_ln786_1393_fu_6657_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln786_1984_fu_18072_p2() {
    and_ln786_1984_fu_18072_p2 = (tmp_5540_fu_18045_p3.read() & xor_ln786_1235_fu_18066_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln786_1985_fu_6843_p2() {
    and_ln786_1985_fu_6843_p2 = (tmp_5542_fu_6725_p3.read() & xor_ln786_1394_fu_6837_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln786_1986_fu_18160_p2() {
    and_ln786_1986_fu_18160_p2 = (tmp_5547_fu_18133_p3.read() & xor_ln786_1236_fu_18154_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln786_1987_fu_7023_p2() {
    and_ln786_1987_fu_7023_p2 = (tmp_5549_fu_6905_p3.read() & xor_ln786_1395_fu_7017_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln786_1988_fu_18248_p2() {
    and_ln786_1988_fu_18248_p2 = (tmp_5554_fu_18221_p3.read() & xor_ln786_1237_fu_18242_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln786_1989_fu_7203_p2() {
    and_ln786_1989_fu_7203_p2 = (tmp_5556_fu_7085_p3.read() & xor_ln786_1396_fu_7197_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln786_1990_fu_18336_p2() {
    and_ln786_1990_fu_18336_p2 = (tmp_5561_fu_18309_p3.read() & xor_ln786_1238_fu_18330_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln786_1991_fu_7383_p2() {
    and_ln786_1991_fu_7383_p2 = (tmp_5563_fu_7265_p3.read() & xor_ln786_1397_fu_7377_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln786_1992_fu_18424_p2() {
    and_ln786_1992_fu_18424_p2 = (tmp_5568_fu_18397_p3.read() & xor_ln786_1239_fu_18418_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln786_1993_fu_7563_p2() {
    and_ln786_1993_fu_7563_p2 = (tmp_5570_fu_7445_p3.read() & xor_ln786_1398_fu_7557_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln786_1994_fu_18512_p2() {
    and_ln786_1994_fu_18512_p2 = (tmp_5575_fu_18485_p3.read() & xor_ln786_1240_fu_18506_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln786_1995_fu_7743_p2() {
    and_ln786_1995_fu_7743_p2 = (tmp_5577_fu_7625_p3.read() & xor_ln786_1399_fu_7737_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln786_1996_fu_18600_p2() {
    and_ln786_1996_fu_18600_p2 = (tmp_5582_fu_18573_p3.read() & xor_ln786_1241_fu_18594_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln786_1997_fu_7923_p2() {
    and_ln786_1997_fu_7923_p2 = (tmp_5584_fu_7805_p3.read() & xor_ln786_1400_fu_7917_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln786_1998_fu_18688_p2() {
    and_ln786_1998_fu_18688_p2 = (tmp_5589_fu_18661_p3.read() & xor_ln786_1242_fu_18682_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln786_1999_fu_8103_p2() {
    and_ln786_1999_fu_8103_p2 = (tmp_5591_fu_7985_p3.read() & xor_ln786_1401_fu_8097_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln786_19_fu_17172_p2() {
    and_ln786_19_fu_17172_p2 = (tmp_5476_fu_17132_p3.read() & select_ln416_689_fu_17146_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln786_1_fu_1735_p2() {
    and_ln786_1_fu_1735_p2 = (tmp_5350_fu_1695_p3.read() & select_ln416_671_fu_1709_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln786_2000_fu_18776_p2() {
    and_ln786_2000_fu_18776_p2 = (tmp_5596_fu_18749_p3.read() & xor_ln786_1243_fu_18770_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln786_2001_fu_8283_p2() {
    and_ln786_2001_fu_8283_p2 = (tmp_5598_fu_8165_p3.read() & xor_ln786_1402_fu_8277_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln786_2002_fu_18864_p2() {
    and_ln786_2002_fu_18864_p2 = (tmp_5603_fu_18837_p3.read() & xor_ln786_1244_fu_18858_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln786_2003_fu_8463_p2() {
    and_ln786_2003_fu_8463_p2 = (tmp_5605_fu_8345_p3.read() & xor_ln786_1403_fu_8457_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln786_2004_fu_18952_p2() {
    and_ln786_2004_fu_18952_p2 = (tmp_5610_fu_18925_p3.read() & xor_ln786_1245_fu_18946_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln786_2005_fu_19121_p2() {
    and_ln786_2005_fu_19121_p2 = (tmp_5612_fu_19003_p3.read() & xor_ln786_1404_fu_19115_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln786_2006_fu_19211_p2() {
    and_ln786_2006_fu_19211_p2 = (tmp_5617_fu_19183_p3.read() & xor_ln786_1246_fu_19205_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln786_2007_fu_8653_p2() {
    and_ln786_2007_fu_8653_p2 = (tmp_5619_fu_8535_p3.read() & xor_ln786_1405_fu_8647_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln786_2008_fu_19299_p2() {
    and_ln786_2008_fu_19299_p2 = (tmp_5624_fu_19272_p3.read() & xor_ln786_1247_fu_19293_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln786_2009_fu_8833_p2() {
    and_ln786_2009_fu_8833_p2 = (tmp_5626_fu_8715_p3.read() & xor_ln786_1406_fu_8827_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln786_2010_fu_19387_p2() {
    and_ln786_2010_fu_19387_p2 = (tmp_5631_fu_19360_p3.read() & xor_ln786_1248_fu_19381_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln786_2011_fu_9013_p2() {
    and_ln786_2011_fu_9013_p2 = (tmp_5633_fu_8895_p3.read() & xor_ln786_1407_fu_9007_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln786_2012_fu_19475_p2() {
    and_ln786_2012_fu_19475_p2 = (tmp_5638_fu_19448_p3.read() & xor_ln786_1249_fu_19469_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln786_2013_fu_9193_p2() {
    and_ln786_2013_fu_9193_p2 = (tmp_5640_fu_9075_p3.read() & xor_ln786_1408_fu_9187_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln786_2014_fu_19563_p2() {
    and_ln786_2014_fu_19563_p2 = (tmp_5645_fu_19536_p3.read() & xor_ln786_1250_fu_19557_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln786_2015_fu_9373_p2() {
    and_ln786_2015_fu_9373_p2 = (tmp_5647_fu_9255_p3.read() & xor_ln786_1409_fu_9367_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln786_2016_fu_19651_p2() {
    and_ln786_2016_fu_19651_p2 = (tmp_5652_fu_19624_p3.read() & xor_ln786_1251_fu_19645_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln786_2017_fu_9553_p2() {
    and_ln786_2017_fu_9553_p2 = (tmp_5654_fu_9435_p3.read() & xor_ln786_1410_fu_9547_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln786_2018_fu_19739_p2() {
    and_ln786_2018_fu_19739_p2 = (tmp_5659_fu_19712_p3.read() & xor_ln786_1252_fu_19733_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln786_2019_fu_9733_p2() {
    and_ln786_2019_fu_9733_p2 = (tmp_5661_fu_9615_p3.read() & xor_ln786_1411_fu_9727_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln786_2020_fu_19827_p2() {
    and_ln786_2020_fu_19827_p2 = (tmp_5666_fu_19800_p3.read() & xor_ln786_1253_fu_19821_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln786_2021_fu_9913_p2() {
    and_ln786_2021_fu_9913_p2 = (tmp_5668_fu_9795_p3.read() & xor_ln786_1412_fu_9907_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln786_2022_fu_19915_p2() {
    and_ln786_2022_fu_19915_p2 = (tmp_5673_fu_19888_p3.read() & xor_ln786_1254_fu_19909_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln786_2023_fu_10093_p2() {
    and_ln786_2023_fu_10093_p2 = (tmp_5675_fu_9975_p3.read() & xor_ln786_1413_fu_10087_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln786_2024_fu_20003_p2() {
    and_ln786_2024_fu_20003_p2 = (tmp_5680_fu_19976_p3.read() & xor_ln786_1255_fu_19997_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln786_2025_fu_10273_p2() {
    and_ln786_2025_fu_10273_p2 = (tmp_5682_fu_10155_p3.read() & xor_ln786_1414_fu_10267_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln786_2026_fu_20091_p2() {
    and_ln786_2026_fu_20091_p2 = (tmp_5687_fu_20064_p3.read() & xor_ln786_1256_fu_20085_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln786_2027_fu_10453_p2() {
    and_ln786_2027_fu_10453_p2 = (tmp_5689_fu_10335_p3.read() & xor_ln786_1415_fu_10447_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln786_2028_fu_20179_p2() {
    and_ln786_2028_fu_20179_p2 = (tmp_5694_fu_20152_p3.read() & xor_ln786_1257_fu_20173_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln786_2029_fu_10633_p2() {
    and_ln786_2029_fu_10633_p2 = (tmp_5696_fu_10515_p3.read() & xor_ln786_1416_fu_10627_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln786_2030_fu_20267_p2() {
    and_ln786_2030_fu_20267_p2 = (tmp_5701_fu_20240_p3.read() & xor_ln786_1258_fu_20261_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln786_2031_fu_10813_p2() {
    and_ln786_2031_fu_10813_p2 = (tmp_5703_fu_10695_p3.read() & xor_ln786_1417_fu_10807_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln786_2032_fu_20355_p2() {
    and_ln786_2032_fu_20355_p2 = (tmp_5708_fu_20328_p3.read() & xor_ln786_1259_fu_20349_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln786_2033_fu_10993_p2() {
    and_ln786_2033_fu_10993_p2 = (tmp_5710_fu_10875_p3.read() & xor_ln786_1418_fu_10987_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln786_2034_fu_20443_p2() {
    and_ln786_2034_fu_20443_p2 = (tmp_5715_fu_20416_p3.read() & xor_ln786_1260_fu_20437_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln786_2035_fu_11173_p2() {
    and_ln786_2035_fu_11173_p2 = (tmp_5717_fu_11055_p3.read() & xor_ln786_1419_fu_11167_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln786_2036_fu_20531_p2() {
    and_ln786_2036_fu_20531_p2 = (tmp_5722_fu_20504_p3.read() & xor_ln786_1261_fu_20525_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln786_2037_fu_11353_p2() {
    and_ln786_2037_fu_11353_p2 = (tmp_5724_fu_11235_p3.read() & xor_ln786_1420_fu_11347_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln786_2038_fu_20619_p2() {
    and_ln786_2038_fu_20619_p2 = (tmp_5729_fu_20592_p3.read() & xor_ln786_1262_fu_20613_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln786_2039_fu_11533_p2() {
    and_ln786_2039_fu_11533_p2 = (tmp_5731_fu_11415_p3.read() & xor_ln786_1421_fu_11527_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln786_2040_fu_20707_p2() {
    and_ln786_2040_fu_20707_p2 = (tmp_5736_fu_20680_p3.read() & xor_ln786_1263_fu_20701_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln786_2041_fu_11713_p2() {
    and_ln786_2041_fu_11713_p2 = (tmp_5738_fu_11595_p3.read() & xor_ln786_1422_fu_11707_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln786_2042_fu_20795_p2() {
    and_ln786_2042_fu_20795_p2 = (tmp_5743_fu_20768_p3.read() & xor_ln786_1264_fu_20789_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln786_2043_fu_11893_p2() {
    and_ln786_2043_fu_11893_p2 = (tmp_5745_fu_11775_p3.read() & xor_ln786_1423_fu_11887_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln786_2044_fu_20883_p2() {
    and_ln786_2044_fu_20883_p2 = (tmp_5750_fu_20856_p3.read() & xor_ln786_1265_fu_20877_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln786_2045_fu_21052_p2() {
    and_ln786_2045_fu_21052_p2 = (tmp_5752_fu_20934_p3.read() & xor_ln786_1424_fu_21046_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln786_2046_fu_21142_p2() {
    and_ln786_2046_fu_21142_p2 = (tmp_5757_fu_21114_p3.read() & xor_ln786_1266_fu_21136_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln786_2047_fu_12083_p2() {
    and_ln786_2047_fu_12083_p2 = (tmp_5759_fu_11965_p3.read() & xor_ln786_1425_fu_12077_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln786_2048_fu_21230_p2() {
    and_ln786_2048_fu_21230_p2 = (tmp_5764_fu_21203_p3.read() & xor_ln786_1267_fu_21224_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln786_2049_fu_12263_p2() {
    and_ln786_2049_fu_12263_p2 = (tmp_5766_fu_12145_p3.read() & xor_ln786_1426_fu_12257_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln786_2050_fu_21318_p2() {
    and_ln786_2050_fu_21318_p2 = (tmp_5771_fu_21291_p3.read() & xor_ln786_1268_fu_21312_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln786_2051_fu_12443_p2() {
    and_ln786_2051_fu_12443_p2 = (tmp_5773_fu_12325_p3.read() & xor_ln786_1427_fu_12437_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln786_2052_fu_21406_p2() {
    and_ln786_2052_fu_21406_p2 = (tmp_5778_fu_21379_p3.read() & xor_ln786_1269_fu_21400_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln786_2053_fu_12623_p2() {
    and_ln786_2053_fu_12623_p2 = (tmp_5780_fu_12505_p3.read() & xor_ln786_1428_fu_12617_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln786_2054_fu_21494_p2() {
    and_ln786_2054_fu_21494_p2 = (tmp_5785_fu_21467_p3.read() & xor_ln786_1270_fu_21488_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln786_2055_fu_12803_p2() {
    and_ln786_2055_fu_12803_p2 = (tmp_5787_fu_12685_p3.read() & xor_ln786_1429_fu_12797_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln786_2056_fu_21582_p2() {
    and_ln786_2056_fu_21582_p2 = (tmp_5792_fu_21555_p3.read() & xor_ln786_1271_fu_21576_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln786_2057_fu_12983_p2() {
    and_ln786_2057_fu_12983_p2 = (tmp_5794_fu_12865_p3.read() & xor_ln786_1430_fu_12977_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln786_2058_fu_21670_p2() {
    and_ln786_2058_fu_21670_p2 = (tmp_5799_fu_21643_p3.read() & xor_ln786_1272_fu_21664_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln786_2059_fu_13163_p2() {
    and_ln786_2059_fu_13163_p2 = (tmp_5801_fu_13045_p3.read() & xor_ln786_1431_fu_13157_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln786_2060_fu_21758_p2() {
    and_ln786_2060_fu_21758_p2 = (tmp_5806_fu_21731_p3.read() & xor_ln786_1273_fu_21752_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln786_2061_fu_13343_p2() {
    and_ln786_2061_fu_13343_p2 = (tmp_5808_fu_13225_p3.read() & xor_ln786_1432_fu_13337_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln786_2062_fu_21846_p2() {
    and_ln786_2062_fu_21846_p2 = (tmp_5813_fu_21819_p3.read() & xor_ln786_1274_fu_21840_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln786_2063_fu_13523_p2() {
    and_ln786_2063_fu_13523_p2 = (tmp_5815_fu_13405_p3.read() & xor_ln786_1433_fu_13517_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln786_2064_fu_21934_p2() {
    and_ln786_2064_fu_21934_p2 = (tmp_5820_fu_21907_p3.read() & xor_ln786_1275_fu_21928_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln786_2065_fu_13703_p2() {
    and_ln786_2065_fu_13703_p2 = (tmp_5822_fu_13585_p3.read() & xor_ln786_1434_fu_13697_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln786_2066_fu_22022_p2() {
    and_ln786_2066_fu_22022_p2 = (tmp_5827_fu_21995_p3.read() & xor_ln786_1276_fu_22016_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln786_2067_fu_13883_p2() {
    and_ln786_2067_fu_13883_p2 = (tmp_5829_fu_13765_p3.read() & xor_ln786_1435_fu_13877_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln786_2068_fu_22110_p2() {
    and_ln786_2068_fu_22110_p2 = (tmp_5834_fu_22083_p3.read() & xor_ln786_1277_fu_22104_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln786_2069_fu_14063_p2() {
    and_ln786_2069_fu_14063_p2 = (tmp_5836_fu_13945_p3.read() & xor_ln786_1436_fu_14057_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln786_2070_fu_22198_p2() {
    and_ln786_2070_fu_22198_p2 = (tmp_5841_fu_22171_p3.read() & xor_ln786_1278_fu_22192_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln786_2071_fu_14243_p2() {
    and_ln786_2071_fu_14243_p2 = (tmp_5843_fu_14125_p3.read() & xor_ln786_1437_fu_14237_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln786_2072_fu_22286_p2() {
    and_ln786_2072_fu_22286_p2 = (tmp_5848_fu_22259_p3.read() & xor_ln786_1279_fu_22280_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln786_2073_fu_14423_p2() {
    and_ln786_2073_fu_14423_p2 = (tmp_5850_fu_14305_p3.read() & xor_ln786_1438_fu_14417_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln786_2074_fu_22374_p2() {
    and_ln786_2074_fu_22374_p2 = (tmp_5855_fu_22347_p3.read() & xor_ln786_1280_fu_22368_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln786_2075_fu_14603_p2() {
    and_ln786_2075_fu_14603_p2 = (tmp_5857_fu_14485_p3.read() & xor_ln786_1439_fu_14597_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln786_2076_fu_22462_p2() {
    and_ln786_2076_fu_22462_p2 = (tmp_5862_fu_22435_p3.read() & xor_ln786_1281_fu_22456_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln786_2077_fu_14783_p2() {
    and_ln786_2077_fu_14783_p2 = (tmp_5864_fu_14665_p3.read() & xor_ln786_1440_fu_14777_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln786_2078_fu_22550_p2() {
    and_ln786_2078_fu_22550_p2 = (tmp_5869_fu_22523_p3.read() & xor_ln786_1282_fu_22544_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln786_2079_fu_14963_p2() {
    and_ln786_2079_fu_14963_p2 = (tmp_5871_fu_14845_p3.read() & xor_ln786_1441_fu_14957_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln786_2080_fu_22638_p2() {
    and_ln786_2080_fu_22638_p2 = (tmp_5876_fu_22611_p3.read() & xor_ln786_1283_fu_22632_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln786_2081_fu_15143_p2() {
    and_ln786_2081_fu_15143_p2 = (tmp_5878_fu_15025_p3.read() & xor_ln786_1442_fu_15137_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln786_2082_fu_22726_p2() {
    and_ln786_2082_fu_22726_p2 = (tmp_5883_fu_22699_p3.read() & xor_ln786_1284_fu_22720_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln786_2083_fu_15323_p2() {
    and_ln786_2083_fu_15323_p2 = (tmp_5885_fu_15205_p3.read() & xor_ln786_1443_fu_15317_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln786_2084_fu_22814_p2() {
    and_ln786_2084_fu_22814_p2 = (tmp_5890_fu_22787_p3.read() & xor_ln786_1285_fu_22808_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln786_2085_fu_22983_p2() {
    and_ln786_2085_fu_22983_p2 = (tmp_5892_fu_22865_p3.read() & xor_ln786_1444_fu_22977_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln786_2086_fu_23073_p2() {
    and_ln786_2086_fu_23073_p2 = (tmp_5897_fu_23045_p3.read() & xor_ln786_1286_fu_23067_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln786_20_fu_5205_p2() {
    and_ln786_20_fu_5205_p2 = (tmp_5483_fu_5165_p3.read() & select_ln416_690_fu_5179_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln786_21_fu_5385_p2() {
    and_ln786_21_fu_5385_p2 = (tmp_5490_fu_5345_p3.read() & select_ln416_691_fu_5359_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln786_22_fu_5565_p2() {
    and_ln786_22_fu_5565_p2 = (tmp_5497_fu_5525_p3.read() & select_ln416_692_fu_5539_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln786_23_fu_5745_p2() {
    and_ln786_23_fu_5745_p2 = (tmp_5504_fu_5705_p3.read() & select_ln416_693_fu_5719_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln786_24_fu_5925_p2() {
    and_ln786_24_fu_5925_p2 = (tmp_5511_fu_5885_p3.read() & select_ln416_694_fu_5899_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln786_25_fu_6105_p2() {
    and_ln786_25_fu_6105_p2 = (tmp_5518_fu_6065_p3.read() & select_ln416_695_fu_6079_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln786_26_fu_6285_p2() {
    and_ln786_26_fu_6285_p2 = (tmp_5525_fu_6245_p3.read() & select_ln416_696_fu_6259_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln786_27_fu_6465_p2() {
    and_ln786_27_fu_6465_p2 = (tmp_5532_fu_6425_p3.read() & select_ln416_697_fu_6439_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln786_28_fu_6645_p2() {
    and_ln786_28_fu_6645_p2 = (tmp_5539_fu_6605_p3.read() & select_ln416_698_fu_6619_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln786_29_fu_6825_p2() {
    and_ln786_29_fu_6825_p2 = (tmp_5546_fu_6785_p3.read() & select_ln416_699_fu_6799_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln786_2_fu_1935_p2() {
    and_ln786_2_fu_1935_p2 = (tmp_5357_fu_1895_p3.read() & select_ln416_672_fu_1909_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln786_30_fu_7005_p2() {
    and_ln786_30_fu_7005_p2 = (tmp_5553_fu_6965_p3.read() & select_ln416_700_fu_6979_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln786_31_fu_7185_p2() {
    and_ln786_31_fu_7185_p2 = (tmp_5560_fu_7145_p3.read() & select_ln416_701_fu_7159_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln786_32_fu_7365_p2() {
    and_ln786_32_fu_7365_p2 = (tmp_5567_fu_7325_p3.read() & select_ln416_702_fu_7339_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln786_33_fu_7545_p2() {
    and_ln786_33_fu_7545_p2 = (tmp_5574_fu_7505_p3.read() & select_ln416_703_fu_7519_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln786_34_fu_7725_p2() {
    and_ln786_34_fu_7725_p2 = (tmp_5581_fu_7685_p3.read() & select_ln416_704_fu_7699_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln786_35_fu_7905_p2() {
    and_ln786_35_fu_7905_p2 = (tmp_5588_fu_7865_p3.read() & select_ln416_705_fu_7879_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln786_36_fu_8085_p2() {
    and_ln786_36_fu_8085_p2 = (tmp_5595_fu_8045_p3.read() & select_ln416_706_fu_8059_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln786_37_fu_8265_p2() {
    and_ln786_37_fu_8265_p2 = (tmp_5602_fu_8225_p3.read() & select_ln416_707_fu_8239_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln786_38_fu_8445_p2() {
    and_ln786_38_fu_8445_p2 = (tmp_5609_fu_8405_p3.read() & select_ln416_708_fu_8419_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln786_39_fu_19103_p2() {
    and_ln786_39_fu_19103_p2 = (tmp_5616_fu_19063_p3.read() & select_ln416_709_fu_19077_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln786_3_fu_2135_p2() {
    and_ln786_3_fu_2135_p2 = (tmp_5364_fu_2095_p3.read() & select_ln416_673_fu_2109_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln786_40_fu_8635_p2() {
    and_ln786_40_fu_8635_p2 = (tmp_5623_fu_8595_p3.read() & select_ln416_710_fu_8609_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln786_41_fu_8815_p2() {
    and_ln786_41_fu_8815_p2 = (tmp_5630_fu_8775_p3.read() & select_ln416_711_fu_8789_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln786_42_fu_8995_p2() {
    and_ln786_42_fu_8995_p2 = (tmp_5637_fu_8955_p3.read() & select_ln416_712_fu_8969_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln786_43_fu_9175_p2() {
    and_ln786_43_fu_9175_p2 = (tmp_5644_fu_9135_p3.read() & select_ln416_713_fu_9149_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln786_44_fu_9355_p2() {
    and_ln786_44_fu_9355_p2 = (tmp_5651_fu_9315_p3.read() & select_ln416_714_fu_9329_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln786_45_fu_9535_p2() {
    and_ln786_45_fu_9535_p2 = (tmp_5658_fu_9495_p3.read() & select_ln416_715_fu_9509_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln786_46_fu_9715_p2() {
    and_ln786_46_fu_9715_p2 = (tmp_5665_fu_9675_p3.read() & select_ln416_716_fu_9689_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln786_47_fu_9895_p2() {
    and_ln786_47_fu_9895_p2 = (tmp_5672_fu_9855_p3.read() & select_ln416_717_fu_9869_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln786_48_fu_10075_p2() {
    and_ln786_48_fu_10075_p2 = (tmp_5679_fu_10035_p3.read() & select_ln416_718_fu_10049_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln786_49_fu_10255_p2() {
    and_ln786_49_fu_10255_p2 = (tmp_5686_fu_10215_p3.read() & select_ln416_719_fu_10229_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln786_4_fu_2327_p2() {
    and_ln786_4_fu_2327_p2 = (tmp_5371_fu_2287_p3.read() & select_ln416_674_fu_2301_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln786_50_fu_10435_p2() {
    and_ln786_50_fu_10435_p2 = (tmp_5693_fu_10395_p3.read() & select_ln416_720_fu_10409_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln786_51_fu_10615_p2() {
    and_ln786_51_fu_10615_p2 = (tmp_5700_fu_10575_p3.read() & select_ln416_721_fu_10589_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln786_52_fu_10795_p2() {
    and_ln786_52_fu_10795_p2 = (tmp_5707_fu_10755_p3.read() & select_ln416_722_fu_10769_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln786_53_fu_10975_p2() {
    and_ln786_53_fu_10975_p2 = (tmp_5714_fu_10935_p3.read() & select_ln416_723_fu_10949_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln786_54_fu_11155_p2() {
    and_ln786_54_fu_11155_p2 = (tmp_5721_fu_11115_p3.read() & select_ln416_724_fu_11129_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln786_55_fu_11335_p2() {
    and_ln786_55_fu_11335_p2 = (tmp_5728_fu_11295_p3.read() & select_ln416_725_fu_11309_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln786_56_fu_11515_p2() {
    and_ln786_56_fu_11515_p2 = (tmp_5735_fu_11475_p3.read() & select_ln416_726_fu_11489_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln786_57_fu_11695_p2() {
    and_ln786_57_fu_11695_p2 = (tmp_5742_fu_11655_p3.read() & select_ln416_727_fu_11669_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln786_58_fu_11875_p2() {
    and_ln786_58_fu_11875_p2 = (tmp_5749_fu_11835_p3.read() & select_ln416_728_fu_11849_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln786_59_fu_21034_p2() {
    and_ln786_59_fu_21034_p2 = (tmp_5756_fu_20994_p3.read() & select_ln416_729_fu_21008_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln786_5_fu_2519_p2() {
    and_ln786_5_fu_2519_p2 = (tmp_5378_fu_2479_p3.read() & select_ln416_675_fu_2493_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln786_60_fu_12065_p2() {
    and_ln786_60_fu_12065_p2 = (tmp_5763_fu_12025_p3.read() & select_ln416_730_fu_12039_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln786_61_fu_12245_p2() {
    and_ln786_61_fu_12245_p2 = (tmp_5770_fu_12205_p3.read() & select_ln416_731_fu_12219_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln786_62_fu_12425_p2() {
    and_ln786_62_fu_12425_p2 = (tmp_5777_fu_12385_p3.read() & select_ln416_732_fu_12399_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln786_63_fu_12605_p2() {
    and_ln786_63_fu_12605_p2 = (tmp_5784_fu_12565_p3.read() & select_ln416_733_fu_12579_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln786_64_fu_12785_p2() {
    and_ln786_64_fu_12785_p2 = (tmp_5791_fu_12745_p3.read() & select_ln416_734_fu_12759_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln786_65_fu_12965_p2() {
    and_ln786_65_fu_12965_p2 = (tmp_5798_fu_12925_p3.read() & select_ln416_735_fu_12939_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln786_66_fu_13145_p2() {
    and_ln786_66_fu_13145_p2 = (tmp_5805_fu_13105_p3.read() & select_ln416_736_fu_13119_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln786_67_fu_13325_p2() {
    and_ln786_67_fu_13325_p2 = (tmp_5812_fu_13285_p3.read() & select_ln416_737_fu_13299_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln786_68_fu_13505_p2() {
    and_ln786_68_fu_13505_p2 = (tmp_5819_fu_13465_p3.read() & select_ln416_738_fu_13479_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln786_69_fu_13685_p2() {
    and_ln786_69_fu_13685_p2 = (tmp_5826_fu_13645_p3.read() & select_ln416_739_fu_13659_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln786_6_fu_2711_p2() {
    and_ln786_6_fu_2711_p2 = (tmp_5385_fu_2671_p3.read() & select_ln416_676_fu_2685_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln786_70_fu_13865_p2() {
    and_ln786_70_fu_13865_p2 = (tmp_5833_fu_13825_p3.read() & select_ln416_740_fu_13839_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln786_71_fu_14045_p2() {
    and_ln786_71_fu_14045_p2 = (tmp_5840_fu_14005_p3.read() & select_ln416_741_fu_14019_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln786_72_fu_14225_p2() {
    and_ln786_72_fu_14225_p2 = (tmp_5847_fu_14185_p3.read() & select_ln416_742_fu_14199_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln786_73_fu_14405_p2() {
    and_ln786_73_fu_14405_p2 = (tmp_5854_fu_14365_p3.read() & select_ln416_743_fu_14379_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln786_74_fu_14585_p2() {
    and_ln786_74_fu_14585_p2 = (tmp_5861_fu_14545_p3.read() & select_ln416_744_fu_14559_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln786_75_fu_14765_p2() {
    and_ln786_75_fu_14765_p2 = (tmp_5868_fu_14725_p3.read() & select_ln416_745_fu_14739_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln786_76_fu_14945_p2() {
    and_ln786_76_fu_14945_p2 = (tmp_5875_fu_14905_p3.read() & select_ln416_746_fu_14919_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln786_77_fu_15125_p2() {
    and_ln786_77_fu_15125_p2 = (tmp_5882_fu_15085_p3.read() & select_ln416_747_fu_15099_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln786_78_fu_15305_p2() {
    and_ln786_78_fu_15305_p2 = (tmp_5889_fu_15265_p3.read() & select_ln416_748_fu_15279_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln786_79_fu_22965_p2() {
    and_ln786_79_fu_22965_p2 = (tmp_5896_fu_22925_p3.read() & select_ln416_749_fu_22939_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln786_7_fu_2903_p2() {
    and_ln786_7_fu_2903_p2 = (tmp_5392_fu_2863_p3.read() & select_ln416_677_fu_2877_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln786_8_fu_3095_p2() {
    and_ln786_8_fu_3095_p2 = (tmp_5399_fu_3055_p3.read() & select_ln416_678_fu_3069_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln786_9_fu_3287_p2() {
    and_ln786_9_fu_3287_p2 = (tmp_5406_fu_3247_p3.read() & select_ln416_679_fu_3261_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_and_ln786_fu_1535_p2() {
    and_ln786_fu_1535_p2 = (tmp_5343_fu_1495_p3.read() & select_ln416_fu_1509_p3.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_ap_CS_fsm_pp1_stage0() {
    ap_CS_fsm_pp1_stage0 = ap_CS_fsm.read()[4];
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_ap_CS_fsm_state1() {
    ap_CS_fsm_state1 = ap_CS_fsm.read()[0];
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_ap_CS_fsm_state2() {
    ap_CS_fsm_state2 = ap_CS_fsm.read()[1];
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_ap_CS_fsm_state3() {
    ap_CS_fsm_state3 = ap_CS_fsm.read()[2];
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_ap_CS_fsm_state4() {
    ap_CS_fsm_state4 = ap_CS_fsm.read()[3];
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_ap_CS_fsm_state8() {
    ap_CS_fsm_state8 = ap_CS_fsm.read()[5];
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_ap_block_pp1_stage0() {
    ap_block_pp1_stage0 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_ap_block_pp1_stage0_11001() {
    ap_block_pp1_stage0_11001 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_ap_block_pp1_stage0_subdone() {
    ap_block_pp1_stage0_subdone = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_ap_block_state1() {
    ap_block_state1 = (esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) || esl_seteq<1,1,1>(ap_done_reg.read(), ap_const_logic_1));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_ap_block_state5_pp1_stage0_iter0() {
    ap_block_state5_pp1_stage0_iter0 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_ap_block_state6_pp1_stage0_iter1() {
    ap_block_state6_pp1_stage0_iter1 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_ap_block_state7_pp1_stage0_iter2() {
    ap_block_state7_pp1_stage0_iter2 = !esl_seteq<1,1,1>(ap_const_boolean_1, ap_const_boolean_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_ap_block_state8() {
    ap_block_state8 = (esl_seteq<1,1,1>(and_ln360_reg_24080.read(), ap_const_lv1_1) && esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op3666.read()));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_ap_condition_451() {
    ap_condition_451 = (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state8.read()) && !(esl_seteq<1,1,1>(and_ln360_reg_24080.read(), ap_const_lv1_1) && esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op3666.read())));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_ap_done() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state8.read()) && 
         !(esl_seteq<1,1,1>(and_ln360_reg_24080.read(), ap_const_lv1_1) && esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op3666.read())) && 
         esl_seteq<1,1,1>(ap_const_lv1_1, icmp_ln64_fu_23162_p2.read()))) {
        ap_done = ap_const_logic_1;
    } else {
        ap_done = ap_done_reg.read();
    }
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_ap_enable_pp1() {
    ap_enable_pp1 = (ap_idle_pp1.read() ^ ap_const_logic_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_ap_idle() {
    if ((esl_seteq<1,1,1>(ap_const_logic_0, real_start.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state1.read()))) {
        ap_idle = ap_const_logic_1;
    } else {
        ap_idle = ap_const_logic_0;
    }
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_ap_idle_pp1() {
    if ((esl_seteq<1,1,1>(ap_const_logic_0, ap_enable_reg_pp1_iter0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_0, ap_enable_reg_pp1_iter1.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_0, ap_enable_reg_pp1_iter2.read()))) {
        ap_idle_pp1 = ap_const_logic_1;
    } else {
        ap_idle_pp1 = ap_const_logic_0;
    }
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_ap_phi_mux_i_iw_0_i_i_i_phi_fu_745_p4() {
    ap_phi_mux_i_iw_0_i_i_i_phi_fu_745_p4 = i_iw_0_i_i_i_reg_741.read();
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_ap_phi_mux_in_index13_phi_fu_860_p4() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_pp1_stage0.read()) && 
         esl_seteq<1,1,1>(ap_const_logic_1, ap_enable_reg_pp1_iter1.read()) && 
         esl_seteq<1,1,1>(in_index13_reg_856.read(), ap_const_lv1_0) && 
         esl_seteq<1,1,1>(ap_block_pp1_stage0.read(), ap_const_boolean_0))) {
        ap_phi_mux_in_index13_phi_fu_860_p4 = in_index_reg_24089.read();
    } else {
        ap_phi_mux_in_index13_phi_fu_860_p4 = in_index13_reg_856.read();
    }
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_ap_phi_mux_phi_ln203_10_phi_fu_794_p8() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state3.read()) && esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln166_fu_1112_p2.read()))) {
        if (esl_seteq<1,2,2>(trunc_ln203_fu_1124_p1.read(), ap_const_lv2_3)) {
            ap_phi_mux_phi_ln203_10_phi_fu_794_p8 = kernel_data_V_1_35_load_reg_24023.read();
        } else if (esl_seteq<1,2,2>(trunc_ln203_fu_1124_p1.read(), ap_const_lv2_2)) {
            ap_phi_mux_phi_ln203_10_phi_fu_794_p8 = kernel_data_V_1_27.read();
        } else if (esl_seteq<1,2,2>(trunc_ln203_fu_1124_p1.read(), ap_const_lv2_1)) {
            ap_phi_mux_phi_ln203_10_phi_fu_794_p8 = kernel_data_V_1_19.read();
        } else if (esl_seteq<1,2,2>(trunc_ln203_fu_1124_p1.read(), ap_const_lv2_0)) {
            ap_phi_mux_phi_ln203_10_phi_fu_794_p8 = kernel_data_V_1_11.read();
        } else {
            ap_phi_mux_phi_ln203_10_phi_fu_794_p8 = "XXXXXXXXXXXXXXXXXXXXXXXX";
        }
    } else {
        ap_phi_mux_phi_ln203_10_phi_fu_794_p8 = "XXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_ap_phi_mux_phi_ln203_11_phi_fu_807_p8() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state3.read()) && esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln166_fu_1112_p2.read()))) {
        if (esl_seteq<1,2,2>(trunc_ln203_fu_1124_p1.read(), ap_const_lv2_3)) {
            ap_phi_mux_phi_ln203_11_phi_fu_807_p8 = kernel_data_V_1_36_load_reg_24028.read();
        } else if (esl_seteq<1,2,2>(trunc_ln203_fu_1124_p1.read(), ap_const_lv2_2)) {
            ap_phi_mux_phi_ln203_11_phi_fu_807_p8 = kernel_data_V_1_28.read();
        } else if (esl_seteq<1,2,2>(trunc_ln203_fu_1124_p1.read(), ap_const_lv2_1)) {
            ap_phi_mux_phi_ln203_11_phi_fu_807_p8 = kernel_data_V_1_20.read();
        } else if (esl_seteq<1,2,2>(trunc_ln203_fu_1124_p1.read(), ap_const_lv2_0)) {
            ap_phi_mux_phi_ln203_11_phi_fu_807_p8 = kernel_data_V_1_12.read();
        } else {
            ap_phi_mux_phi_ln203_11_phi_fu_807_p8 = "XXXXXXXXXXXXXXXXXXXXXXXX";
        }
    } else {
        ap_phi_mux_phi_ln203_11_phi_fu_807_p8 = "XXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_ap_phi_mux_phi_ln203_12_phi_fu_820_p8() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state3.read()) && esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln166_fu_1112_p2.read()))) {
        if (esl_seteq<1,2,2>(trunc_ln203_fu_1124_p1.read(), ap_const_lv2_3)) {
            ap_phi_mux_phi_ln203_12_phi_fu_820_p8 = kernel_data_V_1_37_load_reg_24033.read();
        } else if (esl_seteq<1,2,2>(trunc_ln203_fu_1124_p1.read(), ap_const_lv2_2)) {
            ap_phi_mux_phi_ln203_12_phi_fu_820_p8 = kernel_data_V_1_29.read();
        } else if (esl_seteq<1,2,2>(trunc_ln203_fu_1124_p1.read(), ap_const_lv2_1)) {
            ap_phi_mux_phi_ln203_12_phi_fu_820_p8 = kernel_data_V_1_21.read();
        } else if (esl_seteq<1,2,2>(trunc_ln203_fu_1124_p1.read(), ap_const_lv2_0)) {
            ap_phi_mux_phi_ln203_12_phi_fu_820_p8 = kernel_data_V_1_13.read();
        } else {
            ap_phi_mux_phi_ln203_12_phi_fu_820_p8 = "XXXXXXXXXXXXXXXXXXXXXXXX";
        }
    } else {
        ap_phi_mux_phi_ln203_12_phi_fu_820_p8 = "XXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_ap_phi_mux_phi_ln203_13_phi_fu_833_p8() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state3.read()) && esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln166_fu_1112_p2.read()))) {
        if (esl_seteq<1,2,2>(trunc_ln203_fu_1124_p1.read(), ap_const_lv2_3)) {
            ap_phi_mux_phi_ln203_13_phi_fu_833_p8 = kernel_data_V_1_38_load_reg_24038.read();
        } else if (esl_seteq<1,2,2>(trunc_ln203_fu_1124_p1.read(), ap_const_lv2_2)) {
            ap_phi_mux_phi_ln203_13_phi_fu_833_p8 = kernel_data_V_1_30.read();
        } else if (esl_seteq<1,2,2>(trunc_ln203_fu_1124_p1.read(), ap_const_lv2_1)) {
            ap_phi_mux_phi_ln203_13_phi_fu_833_p8 = kernel_data_V_1_22.read();
        } else if (esl_seteq<1,2,2>(trunc_ln203_fu_1124_p1.read(), ap_const_lv2_0)) {
            ap_phi_mux_phi_ln203_13_phi_fu_833_p8 = kernel_data_V_1_14.read();
        } else {
            ap_phi_mux_phi_ln203_13_phi_fu_833_p8 = "XXXXXXXXXXXXXXXXXXXXXXXX";
        }
    } else {
        ap_phi_mux_phi_ln203_13_phi_fu_833_p8 = "XXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_ap_phi_mux_phi_ln203_14_phi_fu_846_p8() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state3.read()) && esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln166_fu_1112_p2.read()))) {
        if (esl_seteq<1,2,2>(trunc_ln203_fu_1124_p1.read(), ap_const_lv2_3)) {
            ap_phi_mux_phi_ln203_14_phi_fu_846_p8 = kernel_data_V_1_39_load_reg_24043.read();
        } else if (esl_seteq<1,2,2>(trunc_ln203_fu_1124_p1.read(), ap_const_lv2_2)) {
            ap_phi_mux_phi_ln203_14_phi_fu_846_p8 = kernel_data_V_1_31.read();
        } else if (esl_seteq<1,2,2>(trunc_ln203_fu_1124_p1.read(), ap_const_lv2_1)) {
            ap_phi_mux_phi_ln203_14_phi_fu_846_p8 = kernel_data_V_1_23.read();
        } else if (esl_seteq<1,2,2>(trunc_ln203_fu_1124_p1.read(), ap_const_lv2_0)) {
            ap_phi_mux_phi_ln203_14_phi_fu_846_p8 = kernel_data_V_1_15.read();
        } else {
            ap_phi_mux_phi_ln203_14_phi_fu_846_p8 = "XXXXXXXXXXXXXXXXXXXXXXXX";
        }
    } else {
        ap_phi_mux_phi_ln203_14_phi_fu_846_p8 = "XXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_ap_phi_mux_phi_ln203_8_phi_fu_768_p8() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state3.read()) && esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln166_fu_1112_p2.read()))) {
        if (esl_seteq<1,2,2>(trunc_ln203_fu_1124_p1.read(), ap_const_lv2_3)) {
            ap_phi_mux_phi_ln203_8_phi_fu_768_p8 = kernel_data_V_1_33_load_reg_24013.read();
        } else if (esl_seteq<1,2,2>(trunc_ln203_fu_1124_p1.read(), ap_const_lv2_2)) {
            ap_phi_mux_phi_ln203_8_phi_fu_768_p8 = kernel_data_V_1_25.read();
        } else if (esl_seteq<1,2,2>(trunc_ln203_fu_1124_p1.read(), ap_const_lv2_1)) {
            ap_phi_mux_phi_ln203_8_phi_fu_768_p8 = kernel_data_V_1_17.read();
        } else if (esl_seteq<1,2,2>(trunc_ln203_fu_1124_p1.read(), ap_const_lv2_0)) {
            ap_phi_mux_phi_ln203_8_phi_fu_768_p8 = kernel_data_V_1_9.read();
        } else {
            ap_phi_mux_phi_ln203_8_phi_fu_768_p8 = "XXXXXXXXXXXXXXXXXXXXXXXX";
        }
    } else {
        ap_phi_mux_phi_ln203_8_phi_fu_768_p8 = "XXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_ap_phi_mux_phi_ln203_9_phi_fu_781_p8() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state3.read()) && esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln166_fu_1112_p2.read()))) {
        if (esl_seteq<1,2,2>(trunc_ln203_fu_1124_p1.read(), ap_const_lv2_3)) {
            ap_phi_mux_phi_ln203_9_phi_fu_781_p8 = kernel_data_V_1_34_load_reg_24018.read();
        } else if (esl_seteq<1,2,2>(trunc_ln203_fu_1124_p1.read(), ap_const_lv2_2)) {
            ap_phi_mux_phi_ln203_9_phi_fu_781_p8 = kernel_data_V_1_26.read();
        } else if (esl_seteq<1,2,2>(trunc_ln203_fu_1124_p1.read(), ap_const_lv2_1)) {
            ap_phi_mux_phi_ln203_9_phi_fu_781_p8 = kernel_data_V_1_18.read();
        } else if (esl_seteq<1,2,2>(trunc_ln203_fu_1124_p1.read(), ap_const_lv2_0)) {
            ap_phi_mux_phi_ln203_9_phi_fu_781_p8 = kernel_data_V_1_10.read();
        } else {
            ap_phi_mux_phi_ln203_9_phi_fu_781_p8 = "XXXXXXXXXXXXXXXXXXXXXXXX";
        }
    } else {
        ap_phi_mux_phi_ln203_9_phi_fu_781_p8 = "XXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_ap_phi_mux_phi_ln203_phi_fu_755_p8() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state3.read()) && esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln166_fu_1112_p2.read()))) {
        if (esl_seteq<1,2,2>(trunc_ln203_fu_1124_p1.read(), ap_const_lv2_3)) {
            ap_phi_mux_phi_ln203_phi_fu_755_p8 = kernel_data_V_1_32_load_reg_24008.read();
        } else if (esl_seteq<1,2,2>(trunc_ln203_fu_1124_p1.read(), ap_const_lv2_2)) {
            ap_phi_mux_phi_ln203_phi_fu_755_p8 = kernel_data_V_1_24.read();
        } else if (esl_seteq<1,2,2>(trunc_ln203_fu_1124_p1.read(), ap_const_lv2_1)) {
            ap_phi_mux_phi_ln203_phi_fu_755_p8 = kernel_data_V_1_16.read();
        } else if (esl_seteq<1,2,2>(trunc_ln203_fu_1124_p1.read(), ap_const_lv2_0)) {
            ap_phi_mux_phi_ln203_phi_fu_755_p8 = kernel_data_V_1_8.read();
        } else {
            ap_phi_mux_phi_ln203_phi_fu_755_p8 = "XXXXXXXXXXXXXXXXXXXXXXXX";
        }
    } else {
        ap_phi_mux_phi_ln203_phi_fu_755_p8 = "XXXXXXXXXXXXXXXXXXXXXXXX";
    }
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_ap_phi_mux_storemerge_i_i_phi_fu_915_p4() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state8.read())) {
        if (esl_seteq<1,1,1>(ap_const_lv1_1, icmp_ln384_fu_23121_p2.read())) {
            ap_phi_mux_storemerge_i_i_phi_fu_915_p4 = ap_const_lv32_0;
        } else if (esl_seteq<1,1,1>(ap_const_lv1_0, icmp_ln384_fu_23121_p2.read())) {
            ap_phi_mux_storemerge_i_i_phi_fu_915_p4 = select_ln391_fu_23142_p3.read();
        } else {
            ap_phi_mux_storemerge_i_i_phi_fu_915_p4 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        }
    } else {
        ap_phi_mux_storemerge_i_i_phi_fu_915_p4 =  (sc_lv<32>) ("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
    }
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_ap_ready() {
    ap_ready = internal_ap_ready.read();
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_data_V_data_0_V_blk_n() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read())) {
        data_V_data_0_V_blk_n = data_V_data_0_V_empty_n.read();
    } else {
        data_V_data_0_V_blk_n = ap_const_logic_1;
    }
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_data_V_data_0_V_read() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read()) && 
         esl_seteq<1,1,1>(io_acc_block_signal_op26.read(), ap_const_logic_1))) {
        data_V_data_0_V_read = ap_const_logic_1;
    } else {
        data_V_data_0_V_read = ap_const_logic_0;
    }
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_data_V_data_1_V_blk_n() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read())) {
        data_V_data_1_V_blk_n = data_V_data_1_V_empty_n.read();
    } else {
        data_V_data_1_V_blk_n = ap_const_logic_1;
    }
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_data_V_data_1_V_read() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read()) && 
         esl_seteq<1,1,1>(io_acc_block_signal_op26.read(), ap_const_logic_1))) {
        data_V_data_1_V_read = ap_const_logic_1;
    } else {
        data_V_data_1_V_read = ap_const_logic_0;
    }
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_data_V_data_2_V_blk_n() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read())) {
        data_V_data_2_V_blk_n = data_V_data_2_V_empty_n.read();
    } else {
        data_V_data_2_V_blk_n = ap_const_logic_1;
    }
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_data_V_data_2_V_read() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read()) && 
         esl_seteq<1,1,1>(io_acc_block_signal_op26.read(), ap_const_logic_1))) {
        data_V_data_2_V_read = ap_const_logic_1;
    } else {
        data_V_data_2_V_read = ap_const_logic_0;
    }
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_data_V_data_3_V_blk_n() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read())) {
        data_V_data_3_V_blk_n = data_V_data_3_V_empty_n.read();
    } else {
        data_V_data_3_V_blk_n = ap_const_logic_1;
    }
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_data_V_data_3_V_read() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read()) && 
         esl_seteq<1,1,1>(io_acc_block_signal_op26.read(), ap_const_logic_1))) {
        data_V_data_3_V_read = ap_const_logic_1;
    } else {
        data_V_data_3_V_read = ap_const_logic_0;
    }
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_data_V_data_4_V_blk_n() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read())) {
        data_V_data_4_V_blk_n = data_V_data_4_V_empty_n.read();
    } else {
        data_V_data_4_V_blk_n = ap_const_logic_1;
    }
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_data_V_data_4_V_read() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read()) && 
         esl_seteq<1,1,1>(io_acc_block_signal_op26.read(), ap_const_logic_1))) {
        data_V_data_4_V_read = ap_const_logic_1;
    } else {
        data_V_data_4_V_read = ap_const_logic_0;
    }
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_data_V_data_5_V_blk_n() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read())) {
        data_V_data_5_V_blk_n = data_V_data_5_V_empty_n.read();
    } else {
        data_V_data_5_V_blk_n = ap_const_logic_1;
    }
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_data_V_data_5_V_read() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read()) && 
         esl_seteq<1,1,1>(io_acc_block_signal_op26.read(), ap_const_logic_1))) {
        data_V_data_5_V_read = ap_const_logic_1;
    } else {
        data_V_data_5_V_read = ap_const_logic_0;
    }
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_data_V_data_6_V_blk_n() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read())) {
        data_V_data_6_V_blk_n = data_V_data_6_V_empty_n.read();
    } else {
        data_V_data_6_V_blk_n = ap_const_logic_1;
    }
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_data_V_data_6_V_read() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read()) && 
         esl_seteq<1,1,1>(io_acc_block_signal_op26.read(), ap_const_logic_1))) {
        data_V_data_6_V_read = ap_const_logic_1;
    } else {
        data_V_data_6_V_read = ap_const_logic_0;
    }
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_data_V_data_7_V_blk_n() {
    if (esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read())) {
        data_V_data_7_V_blk_n = data_V_data_7_V_empty_n.read();
    } else {
        data_V_data_7_V_blk_n = ap_const_logic_1;
    }
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_data_V_data_7_V_read() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state2.read()) && 
         esl_seteq<1,1,1>(io_acc_block_signal_op26.read(), ap_const_logic_1))) {
        data_V_data_7_V_read = ap_const_logic_1;
    } else {
        data_V_data_7_V_read = ap_const_logic_0;
    }
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_i_iw_3_fu_1118_p2() {
    i_iw_3_fu_1118_p2 = (!i_iw_0_i_i_i_reg_741.read().is_01() || !ap_const_lv3_1.is_01())? sc_lv<3>(): (sc_biguint<3>(i_iw_0_i_i_i_reg_741.read()) + sc_biguint<3>(ap_const_lv3_1));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_i_iw_fu_1106_p2() {
    i_iw_fu_1106_p2 = (!i_iw_0_i14_reg_729.read().is_01() || !ap_const_lv7_1.is_01())? sc_lv<7>(): (sc_biguint<7>(i_iw_0_i14_reg_729.read()) + sc_biguint<7>(ap_const_lv7_1));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_icmp_ln166_fu_1112_p2() {
    icmp_ln166_fu_1112_p2 = (!i_iw_0_i_i_i_reg_741.read().is_01() || !ap_const_lv3_4.is_01())? sc_lv<1>(): sc_lv<1>(i_iw_0_i_i_i_reg_741.read() == ap_const_lv3_4);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_icmp_ln360_3_fu_1384_p2() {
    icmp_ln360_3_fu_1384_p2 = (!tmp_5338_fu_1374_p4.read().is_01() || !ap_const_lv30_0.is_01())? sc_lv<1>(): (sc_bigint<30>(tmp_5338_fu_1374_p4.read()) > sc_bigint<30>(ap_const_lv30_0));
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_icmp_ln360_fu_1364_p2() {
    icmp_ln360_fu_1364_p2 = (!sX_2.read().is_01() || !ap_const_lv32_4.is_01())? sc_lv<1>(): sc_lv<1>(sX_2.read() == ap_const_lv32_4);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_icmp_ln384_fu_23121_p2() {
    icmp_ln384_fu_23121_p2 = (!pX_2_load_reg_24074.read().is_01() || !ap_const_lv32_42.is_01())? sc_lv<1>(): sc_lv<1>(pX_2_load_reg_24074.read() == ap_const_lv32_42);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_icmp_ln64_fu_23162_p2() {
    icmp_ln64_fu_23162_p2 = (!i_iw_0_i14_reg_729.read().is_01() || !ap_const_lv7_42.is_01())? sc_lv<1>(): sc_lv<1>(i_iw_0_i14_reg_729.read() == ap_const_lv7_42);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_in_index_fu_1401_p2() {
    in_index_fu_1401_p2 = (ap_phi_mux_in_index13_phi_fu_860_p4.read() ^ ap_const_lv1_1);
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_internal_ap_ready() {
    if ((esl_seteq<1,1,1>(ap_const_logic_1, ap_CS_fsm_state8.read()) && 
         !(esl_seteq<1,1,1>(and_ln360_reg_24080.read(), ap_const_lv1_1) && esl_seteq<1,1,1>(ap_const_logic_0, io_acc_block_signal_op3666.read())) && 
         esl_seteq<1,1,1>(ap_const_lv1_1, icmp_ln64_fu_23162_p2.read()))) {
        internal_ap_ready = ap_const_logic_1;
    } else {
        internal_ap_ready = ap_const_logic_0;
    }
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_io_acc_block_signal_op26() {
    io_acc_block_signal_op26 = (data_V_data_0_V_empty_n.read() & data_V_data_1_V_empty_n.read() & data_V_data_2_V_empty_n.read() & data_V_data_3_V_empty_n.read() & data_V_data_4_V_empty_n.read() & data_V_data_5_V_empty_n.read() & data_V_data_6_V_empty_n.read() & data_V_data_7_V_empty_n.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_io_acc_block_signal_op3666() {
    io_acc_block_signal_op3666 = (res_V_data_0_V_full_n.read() & res_V_data_1_V_full_n.read() & res_V_data_2_V_full_n.read() & res_V_data_3_V_full_n.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_mul_ln1118_681_fu_23178_p0() {
    mul_ln1118_681_fu_23178_p0 =  (sc_lv<24>) (sext_ln1116_53_fu_1627_p1.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_mul_ln1118_682_fu_23188_p0() {
    mul_ln1118_682_fu_23188_p0 =  (sc_lv<24>) (sext_ln1116_54_fu_1827_p1.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_mul_ln1118_683_fu_23198_p0() {
    mul_ln1118_683_fu_23198_p0 =  (sc_lv<24>) (sext_ln1116_55_fu_2027_p1.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_mul_ln1118_684_fu_23208_p0() {
    mul_ln1118_684_fu_23208_p0 =  (sc_lv<24>) (sext_ln1116_56_fu_2219_p1.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_mul_ln1118_685_fu_23218_p0() {
    mul_ln1118_685_fu_23218_p0 =  (sc_lv<24>) (sext_ln1116_57_fu_2411_p1.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_mul_ln1118_686_fu_23228_p0() {
    mul_ln1118_686_fu_23228_p0 =  (sc_lv<24>) (sext_ln1116_58_fu_2603_p1.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_mul_ln1118_687_fu_23238_p0() {
    mul_ln1118_687_fu_23238_p0 =  (sc_lv<24>) (sext_ln1116_59_fu_2795_p1.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_mul_ln1118_688_fu_23248_p0() {
    mul_ln1118_688_fu_23248_p0 =  (sc_lv<24>) (sext_ln1116_60_fu_2987_p1.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_mul_ln1118_689_fu_23258_p0() {
    mul_ln1118_689_fu_23258_p0 =  (sc_lv<24>) (sext_ln1116_61_fu_3179_p1.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_mul_ln1118_690_fu_23268_p0() {
    mul_ln1118_690_fu_23268_p0 =  (sc_lv<24>) (sext_ln1116_62_fu_3371_p1.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_mul_ln1118_691_fu_23278_p0() {
    mul_ln1118_691_fu_23278_p0 =  (sc_lv<24>) (sext_ln1116_63_fu_3563_p1.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_mul_ln1118_692_fu_23288_p0() {
    mul_ln1118_692_fu_23288_p0 =  (sc_lv<24>) (sext_ln1116_64_fu_3755_p1.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_mul_ln1118_693_fu_23298_p0() {
    mul_ln1118_693_fu_23298_p0 =  (sc_lv<24>) (sext_ln1116_65_fu_3947_p1.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_mul_ln1118_694_fu_23308_p0() {
    mul_ln1118_694_fu_23308_p0 =  (sc_lv<24>) (sext_ln1116_66_fu_4139_p1.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_mul_ln1118_695_fu_23318_p0() {
    mul_ln1118_695_fu_23318_p0 =  (sc_lv<24>) (sext_ln1116_67_fu_4331_p1.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_mul_ln1118_696_fu_23328_p0() {
    mul_ln1118_696_fu_23328_p0 =  (sc_lv<24>) (sext_ln1116_68_fu_4523_p1.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_mul_ln1118_697_fu_23338_p0() {
    mul_ln1118_697_fu_23338_p0 =  (sc_lv<24>) (sext_ln1116_69_fu_4715_p1.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_mul_ln1118_698_fu_23348_p0() {
    mul_ln1118_698_fu_23348_p0 =  (sc_lv<24>) (sext_ln1116_70_fu_4907_p1.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_mul_ln1118_699_fu_23928_p0() {
    mul_ln1118_699_fu_23928_p0 =  (sc_lv<24>) (sext_ln1116_71_fu_17061_p1.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_mul_ln1118_700_fu_23358_p0() {
    mul_ln1118_700_fu_23358_p0 =  (sc_lv<24>) (sext_ln1116_fu_1427_p1.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_mul_ln1118_701_fu_23368_p0() {
    mul_ln1118_701_fu_23368_p0 =  (sc_lv<24>) (sext_ln1116_53_fu_1627_p1.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_mul_ln1118_702_fu_23378_p0() {
    mul_ln1118_702_fu_23378_p0 =  (sc_lv<24>) (sext_ln1116_54_fu_1827_p1.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_mul_ln1118_703_fu_23388_p0() {
    mul_ln1118_703_fu_23388_p0 =  (sc_lv<24>) (sext_ln1116_55_fu_2027_p1.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_mul_ln1118_704_fu_23398_p0() {
    mul_ln1118_704_fu_23398_p0 =  (sc_lv<24>) (sext_ln1116_56_fu_2219_p1.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_mul_ln1118_705_fu_23408_p0() {
    mul_ln1118_705_fu_23408_p0 =  (sc_lv<24>) (sext_ln1116_57_fu_2411_p1.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_mul_ln1118_706_fu_23418_p0() {
    mul_ln1118_706_fu_23418_p0 =  (sc_lv<24>) (sext_ln1116_58_fu_2603_p1.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_mul_ln1118_707_fu_23428_p0() {
    mul_ln1118_707_fu_23428_p0 =  (sc_lv<24>) (sext_ln1116_59_fu_2795_p1.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_mul_ln1118_708_fu_23438_p0() {
    mul_ln1118_708_fu_23438_p0 =  (sc_lv<24>) (sext_ln1116_60_fu_2987_p1.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_mul_ln1118_709_fu_23448_p0() {
    mul_ln1118_709_fu_23448_p0 =  (sc_lv<24>) (sext_ln1116_61_fu_3179_p1.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_mul_ln1118_710_fu_23458_p0() {
    mul_ln1118_710_fu_23458_p0 =  (sc_lv<24>) (sext_ln1116_62_fu_3371_p1.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_mul_ln1118_711_fu_23468_p0() {
    mul_ln1118_711_fu_23468_p0 =  (sc_lv<24>) (sext_ln1116_63_fu_3563_p1.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_mul_ln1118_712_fu_23478_p0() {
    mul_ln1118_712_fu_23478_p0 =  (sc_lv<24>) (sext_ln1116_64_fu_3755_p1.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_mul_ln1118_713_fu_23488_p0() {
    mul_ln1118_713_fu_23488_p0 =  (sc_lv<24>) (sext_ln1116_65_fu_3947_p1.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_mul_ln1118_714_fu_23498_p0() {
    mul_ln1118_714_fu_23498_p0 =  (sc_lv<24>) (sext_ln1116_66_fu_4139_p1.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_mul_ln1118_715_fu_23508_p0() {
    mul_ln1118_715_fu_23508_p0 =  (sc_lv<24>) (sext_ln1116_67_fu_4331_p1.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_mul_ln1118_716_fu_23518_p0() {
    mul_ln1118_716_fu_23518_p0 =  (sc_lv<24>) (sext_ln1116_68_fu_4523_p1.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_mul_ln1118_717_fu_23528_p0() {
    mul_ln1118_717_fu_23528_p0 =  (sc_lv<24>) (sext_ln1116_69_fu_4715_p1.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_mul_ln1118_718_fu_23538_p0() {
    mul_ln1118_718_fu_23538_p0 =  (sc_lv<24>) (sext_ln1116_70_fu_4907_p1.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_mul_ln1118_719_fu_23938_p0() {
    mul_ln1118_719_fu_23938_p0 =  (sc_lv<24>) (sext_ln1116_71_fu_17061_p1.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_mul_ln1118_720_fu_23548_p0() {
    mul_ln1118_720_fu_23548_p0 =  (sc_lv<24>) (sext_ln1116_fu_1427_p1.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_mul_ln1118_721_fu_23558_p0() {
    mul_ln1118_721_fu_23558_p0 =  (sc_lv<24>) (sext_ln1116_53_fu_1627_p1.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_mul_ln1118_722_fu_23568_p0() {
    mul_ln1118_722_fu_23568_p0 =  (sc_lv<24>) (sext_ln1116_54_fu_1827_p1.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_mul_ln1118_723_fu_23578_p0() {
    mul_ln1118_723_fu_23578_p0 =  (sc_lv<24>) (sext_ln1116_55_fu_2027_p1.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_mul_ln1118_724_fu_23588_p0() {
    mul_ln1118_724_fu_23588_p0 =  (sc_lv<24>) (sext_ln1116_56_fu_2219_p1.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_mul_ln1118_725_fu_23598_p0() {
    mul_ln1118_725_fu_23598_p0 =  (sc_lv<24>) (sext_ln1116_57_fu_2411_p1.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_mul_ln1118_726_fu_23608_p0() {
    mul_ln1118_726_fu_23608_p0 =  (sc_lv<24>) (sext_ln1116_58_fu_2603_p1.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_mul_ln1118_727_fu_23618_p0() {
    mul_ln1118_727_fu_23618_p0 =  (sc_lv<24>) (sext_ln1116_59_fu_2795_p1.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_mul_ln1118_728_fu_23628_p0() {
    mul_ln1118_728_fu_23628_p0 =  (sc_lv<24>) (sext_ln1116_60_fu_2987_p1.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_mul_ln1118_729_fu_23638_p0() {
    mul_ln1118_729_fu_23638_p0 =  (sc_lv<24>) (sext_ln1116_61_fu_3179_p1.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_mul_ln1118_730_fu_23648_p0() {
    mul_ln1118_730_fu_23648_p0 =  (sc_lv<24>) (sext_ln1116_62_fu_3371_p1.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_mul_ln1118_731_fu_23658_p0() {
    mul_ln1118_731_fu_23658_p0 =  (sc_lv<24>) (sext_ln1116_63_fu_3563_p1.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_mul_ln1118_732_fu_23668_p0() {
    mul_ln1118_732_fu_23668_p0 =  (sc_lv<24>) (sext_ln1116_64_fu_3755_p1.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_mul_ln1118_733_fu_23678_p0() {
    mul_ln1118_733_fu_23678_p0 =  (sc_lv<24>) (sext_ln1116_65_fu_3947_p1.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_mul_ln1118_734_fu_23688_p0() {
    mul_ln1118_734_fu_23688_p0 =  (sc_lv<24>) (sext_ln1116_66_fu_4139_p1.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_mul_ln1118_735_fu_23698_p0() {
    mul_ln1118_735_fu_23698_p0 =  (sc_lv<24>) (sext_ln1116_67_fu_4331_p1.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_mul_ln1118_736_fu_23708_p0() {
    mul_ln1118_736_fu_23708_p0 =  (sc_lv<24>) (sext_ln1116_68_fu_4523_p1.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_mul_ln1118_737_fu_23718_p0() {
    mul_ln1118_737_fu_23718_p0 =  (sc_lv<24>) (sext_ln1116_69_fu_4715_p1.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_mul_ln1118_738_fu_23728_p0() {
    mul_ln1118_738_fu_23728_p0 =  (sc_lv<24>) (sext_ln1116_70_fu_4907_p1.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_mul_ln1118_739_fu_23948_p0() {
    mul_ln1118_739_fu_23948_p0 =  (sc_lv<24>) (sext_ln1116_71_fu_17061_p1.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_mul_ln1118_740_fu_23738_p0() {
    mul_ln1118_740_fu_23738_p0 =  (sc_lv<24>) (sext_ln1116_fu_1427_p1.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_mul_ln1118_741_fu_23748_p0() {
    mul_ln1118_741_fu_23748_p0 =  (sc_lv<24>) (sext_ln1116_53_fu_1627_p1.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_mul_ln1118_742_fu_23758_p0() {
    mul_ln1118_742_fu_23758_p0 =  (sc_lv<24>) (sext_ln1116_54_fu_1827_p1.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_mul_ln1118_743_fu_23768_p0() {
    mul_ln1118_743_fu_23768_p0 =  (sc_lv<24>) (sext_ln1116_55_fu_2027_p1.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_mul_ln1118_744_fu_23778_p0() {
    mul_ln1118_744_fu_23778_p0 =  (sc_lv<24>) (sext_ln1116_56_fu_2219_p1.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_mul_ln1118_745_fu_23788_p0() {
    mul_ln1118_745_fu_23788_p0 =  (sc_lv<24>) (sext_ln1116_57_fu_2411_p1.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_mul_ln1118_746_fu_23798_p0() {
    mul_ln1118_746_fu_23798_p0 =  (sc_lv<24>) (sext_ln1116_58_fu_2603_p1.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_mul_ln1118_747_fu_23808_p0() {
    mul_ln1118_747_fu_23808_p0 =  (sc_lv<24>) (sext_ln1116_59_fu_2795_p1.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_mul_ln1118_748_fu_23818_p0() {
    mul_ln1118_748_fu_23818_p0 =  (sc_lv<24>) (sext_ln1116_60_fu_2987_p1.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_mul_ln1118_749_fu_23828_p0() {
    mul_ln1118_749_fu_23828_p0 =  (sc_lv<24>) (sext_ln1116_61_fu_3179_p1.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_mul_ln1118_750_fu_23838_p0() {
    mul_ln1118_750_fu_23838_p0 =  (sc_lv<24>) (sext_ln1116_62_fu_3371_p1.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_mul_ln1118_751_fu_23848_p0() {
    mul_ln1118_751_fu_23848_p0 =  (sc_lv<24>) (sext_ln1116_63_fu_3563_p1.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_mul_ln1118_752_fu_23858_p0() {
    mul_ln1118_752_fu_23858_p0 =  (sc_lv<24>) (sext_ln1116_64_fu_3755_p1.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_mul_ln1118_753_fu_23868_p0() {
    mul_ln1118_753_fu_23868_p0 =  (sc_lv<24>) (sext_ln1116_65_fu_3947_p1.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_mul_ln1118_754_fu_23878_p0() {
    mul_ln1118_754_fu_23878_p0 =  (sc_lv<24>) (sext_ln1116_66_fu_4139_p1.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_mul_ln1118_755_fu_23888_p0() {
    mul_ln1118_755_fu_23888_p0 =  (sc_lv<24>) (sext_ln1116_67_fu_4331_p1.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_mul_ln1118_756_fu_23898_p0() {
    mul_ln1118_756_fu_23898_p0 =  (sc_lv<24>) (sext_ln1116_68_fu_4523_p1.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_mul_ln1118_757_fu_23908_p0() {
    mul_ln1118_757_fu_23908_p0 =  (sc_lv<24>) (sext_ln1116_69_fu_4715_p1.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_mul_ln1118_758_fu_23918_p0() {
    mul_ln1118_758_fu_23918_p0 =  (sc_lv<24>) (sext_ln1116_70_fu_4907_p1.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_mul_ln1118_fu_23168_p0() {
    mul_ln1118_fu_23168_p0 =  (sc_lv<24>) (sext_ln1116_fu_1427_p1.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_10_fu_3503_p2() {
    or_ln340_10_fu_3503_p2 = (and_ln786_1947_fu_3497_p2.read() | and_ln785_680_fu_3473_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_1126_fu_3695_p2() {
    or_ln340_1126_fu_3695_p2 = (and_ln786_1949_fu_3689_p2.read() | and_ln785_681_fu_3665_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_12_fu_3887_p2() {
    or_ln340_12_fu_3887_p2 = (and_ln786_1951_fu_3881_p2.read() | and_ln785_682_fu_3857_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_13_fu_4079_p2() {
    or_ln340_13_fu_4079_p2 = (and_ln786_1953_fu_4073_p2.read() | and_ln785_683_fu_4049_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_14_fu_4271_p2() {
    or_ln340_14_fu_4271_p2 = (and_ln786_1955_fu_4265_p2.read() | and_ln785_684_fu_4241_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_15_fu_4463_p2() {
    or_ln340_15_fu_4463_p2 = (and_ln786_1957_fu_4457_p2.read() | and_ln785_685_fu_4433_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_16_fu_4655_p2() {
    or_ln340_16_fu_4655_p2 = (and_ln786_1959_fu_4649_p2.read() | and_ln785_686_fu_4625_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_17_fu_4847_p2() {
    or_ln340_17_fu_4847_p2 = (and_ln786_1961_fu_4841_p2.read() | and_ln785_687_fu_4817_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_18_fu_5039_p2() {
    or_ln340_18_fu_5039_p2 = (and_ln786_1963_fu_5033_p2.read() | and_ln785_688_fu_5009_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_19_fu_17196_p2() {
    or_ln340_19_fu_17196_p2 = (and_ln786_1965_fu_17190_p2.read() | and_ln785_689_fu_17166_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_1_fu_1759_p2() {
    or_ln340_1_fu_1759_p2 = (and_ln786_1929_fu_1753_p2.read() | and_ln785_671_fu_1729_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_20_fu_5229_p2() {
    or_ln340_20_fu_5229_p2 = (and_ln786_1967_fu_5223_p2.read() | and_ln785_690_fu_5199_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_21_fu_5409_p2() {
    or_ln340_21_fu_5409_p2 = (and_ln786_1969_fu_5403_p2.read() | and_ln785_691_fu_5379_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_22_fu_5589_p2() {
    or_ln340_22_fu_5589_p2 = (and_ln786_1971_fu_5583_p2.read() | and_ln785_692_fu_5559_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_23_fu_5769_p2() {
    or_ln340_23_fu_5769_p2 = (and_ln786_1973_fu_5763_p2.read() | and_ln785_693_fu_5739_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_24_fu_5949_p2() {
    or_ln340_24_fu_5949_p2 = (and_ln786_1975_fu_5943_p2.read() | and_ln785_694_fu_5919_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_2599_fu_1565_p2() {
    or_ln340_2599_fu_1565_p2 = (and_ln786_fu_1535_p2.read() | xor_ln779_fu_1503_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_25_fu_6129_p2() {
    or_ln340_25_fu_6129_p2 = (and_ln786_1977_fu_6123_p2.read() | and_ln785_695_fu_6099_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_2600_fu_1571_p2() {
    or_ln340_2600_fu_1571_p2 = (or_ln340_2599_fu_1565_p2.read() | and_ln416_fu_1489_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_2601_fu_15439_p2() {
    or_ln340_2601_fu_15439_p2 = (tmp_5345_fu_15407_p3.read() | xor_ln340_fu_15433_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_2602_fu_1765_p2() {
    or_ln340_2602_fu_1765_p2 = (and_ln786_1_fu_1735_p2.read() | xor_ln779_1_fu_1703_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_2603_fu_1771_p2() {
    or_ln340_2603_fu_1771_p2 = (or_ln340_2602_fu_1765_p2.read() | and_ln416_671_fu_1689_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_2604_fu_15527_p2() {
    or_ln340_2604_fu_15527_p2 = (tmp_5352_fu_15495_p3.read() | xor_ln340_718_fu_15521_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_2605_fu_1965_p2() {
    or_ln340_2605_fu_1965_p2 = (and_ln786_2_fu_1935_p2.read() | xor_ln779_2_fu_1903_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_2606_fu_1971_p2() {
    or_ln340_2606_fu_1971_p2 = (or_ln340_2605_fu_1965_p2.read() | and_ln416_672_fu_1889_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_2607_fu_15615_p2() {
    or_ln340_2607_fu_15615_p2 = (tmp_5359_fu_15583_p3.read() | xor_ln340_719_fu_15609_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_2608_fu_2165_p2() {
    or_ln340_2608_fu_2165_p2 = (and_ln786_3_fu_2135_p2.read() | xor_ln779_3_fu_2103_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_2609_fu_2171_p2() {
    or_ln340_2609_fu_2171_p2 = (or_ln340_2608_fu_2165_p2.read() | and_ln416_673_fu_2089_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_2610_fu_15703_p2() {
    or_ln340_2610_fu_15703_p2 = (tmp_5366_fu_15671_p3.read() | xor_ln340_720_fu_15697_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_2611_fu_2357_p2() {
    or_ln340_2611_fu_2357_p2 = (and_ln786_4_fu_2327_p2.read() | xor_ln779_4_fu_2295_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_2612_fu_2363_p2() {
    or_ln340_2612_fu_2363_p2 = (or_ln340_2611_fu_2357_p2.read() | and_ln416_674_fu_2281_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_2613_fu_15791_p2() {
    or_ln340_2613_fu_15791_p2 = (tmp_5373_fu_15759_p3.read() | xor_ln340_721_fu_15785_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_2614_fu_2549_p2() {
    or_ln340_2614_fu_2549_p2 = (and_ln786_5_fu_2519_p2.read() | xor_ln779_5_fu_2487_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_2615_fu_2555_p2() {
    or_ln340_2615_fu_2555_p2 = (or_ln340_2614_fu_2549_p2.read() | and_ln416_675_fu_2473_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_2616_fu_15879_p2() {
    or_ln340_2616_fu_15879_p2 = (tmp_5380_fu_15847_p3.read() | xor_ln340_722_fu_15873_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_2617_fu_2741_p2() {
    or_ln340_2617_fu_2741_p2 = (and_ln786_6_fu_2711_p2.read() | xor_ln779_6_fu_2679_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_2618_fu_2747_p2() {
    or_ln340_2618_fu_2747_p2 = (or_ln340_2617_fu_2741_p2.read() | and_ln416_676_fu_2665_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_2619_fu_15967_p2() {
    or_ln340_2619_fu_15967_p2 = (tmp_5387_fu_15935_p3.read() | xor_ln340_723_fu_15961_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_2620_fu_2933_p2() {
    or_ln340_2620_fu_2933_p2 = (and_ln786_7_fu_2903_p2.read() | xor_ln779_7_fu_2871_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_2621_fu_2939_p2() {
    or_ln340_2621_fu_2939_p2 = (or_ln340_2620_fu_2933_p2.read() | and_ln416_677_fu_2857_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_2622_fu_16055_p2() {
    or_ln340_2622_fu_16055_p2 = (tmp_5394_fu_16023_p3.read() | xor_ln340_724_fu_16049_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_2623_fu_3125_p2() {
    or_ln340_2623_fu_3125_p2 = (and_ln786_8_fu_3095_p2.read() | xor_ln779_8_fu_3063_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_2624_fu_3131_p2() {
    or_ln340_2624_fu_3131_p2 = (or_ln340_2623_fu_3125_p2.read() | and_ln416_678_fu_3049_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_2625_fu_16143_p2() {
    or_ln340_2625_fu_16143_p2 = (tmp_5401_fu_16111_p3.read() | xor_ln340_725_fu_16137_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_2626_fu_3317_p2() {
    or_ln340_2626_fu_3317_p2 = (and_ln786_9_fu_3287_p2.read() | xor_ln779_9_fu_3255_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_2627_fu_3323_p2() {
    or_ln340_2627_fu_3323_p2 = (or_ln340_2626_fu_3317_p2.read() | and_ln416_679_fu_3241_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_2628_fu_16231_p2() {
    or_ln340_2628_fu_16231_p2 = (tmp_5408_fu_16199_p3.read() | xor_ln340_726_fu_16225_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_2629_fu_3509_p2() {
    or_ln340_2629_fu_3509_p2 = (and_ln786_10_fu_3479_p2.read() | xor_ln779_10_fu_3447_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_2630_fu_3515_p2() {
    or_ln340_2630_fu_3515_p2 = (or_ln340_2629_fu_3509_p2.read() | and_ln416_680_fu_3433_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_2631_fu_16319_p2() {
    or_ln340_2631_fu_16319_p2 = (tmp_5415_fu_16287_p3.read() | xor_ln340_727_fu_16313_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_2632_fu_3701_p2() {
    or_ln340_2632_fu_3701_p2 = (and_ln786_11_fu_3671_p2.read() | xor_ln779_11_fu_3639_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_2633_fu_3707_p2() {
    or_ln340_2633_fu_3707_p2 = (or_ln340_2632_fu_3701_p2.read() | and_ln416_681_fu_3625_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_2634_fu_16407_p2() {
    or_ln340_2634_fu_16407_p2 = (tmp_5422_fu_16375_p3.read() | xor_ln340_728_fu_16401_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_2635_fu_3893_p2() {
    or_ln340_2635_fu_3893_p2 = (and_ln786_12_fu_3863_p2.read() | xor_ln779_12_fu_3831_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_2636_fu_3899_p2() {
    or_ln340_2636_fu_3899_p2 = (or_ln340_2635_fu_3893_p2.read() | and_ln416_682_fu_3817_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_2637_fu_16495_p2() {
    or_ln340_2637_fu_16495_p2 = (tmp_5429_fu_16463_p3.read() | xor_ln340_729_fu_16489_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_2638_fu_4085_p2() {
    or_ln340_2638_fu_4085_p2 = (and_ln786_13_fu_4055_p2.read() | xor_ln779_13_fu_4023_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_2639_fu_4091_p2() {
    or_ln340_2639_fu_4091_p2 = (or_ln340_2638_fu_4085_p2.read() | and_ln416_683_fu_4009_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_2640_fu_16583_p2() {
    or_ln340_2640_fu_16583_p2 = (tmp_5436_fu_16551_p3.read() | xor_ln340_730_fu_16577_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_2641_fu_4277_p2() {
    or_ln340_2641_fu_4277_p2 = (and_ln786_14_fu_4247_p2.read() | xor_ln779_14_fu_4215_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_2642_fu_4283_p2() {
    or_ln340_2642_fu_4283_p2 = (or_ln340_2641_fu_4277_p2.read() | and_ln416_684_fu_4201_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_2643_fu_16671_p2() {
    or_ln340_2643_fu_16671_p2 = (tmp_5443_fu_16639_p3.read() | xor_ln340_731_fu_16665_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_2644_fu_4469_p2() {
    or_ln340_2644_fu_4469_p2 = (and_ln786_15_fu_4439_p2.read() | xor_ln779_15_fu_4407_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_2645_fu_4475_p2() {
    or_ln340_2645_fu_4475_p2 = (or_ln340_2644_fu_4469_p2.read() | and_ln416_685_fu_4393_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_2646_fu_16759_p2() {
    or_ln340_2646_fu_16759_p2 = (tmp_5450_fu_16727_p3.read() | xor_ln340_732_fu_16753_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_2647_fu_4661_p2() {
    or_ln340_2647_fu_4661_p2 = (and_ln786_16_fu_4631_p2.read() | xor_ln779_16_fu_4599_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_2648_fu_4667_p2() {
    or_ln340_2648_fu_4667_p2 = (or_ln340_2647_fu_4661_p2.read() | and_ln416_686_fu_4585_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_2649_fu_16847_p2() {
    or_ln340_2649_fu_16847_p2 = (tmp_5457_fu_16815_p3.read() | xor_ln340_733_fu_16841_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_2650_fu_4853_p2() {
    or_ln340_2650_fu_4853_p2 = (and_ln786_17_fu_4823_p2.read() | xor_ln779_17_fu_4791_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_2651_fu_4859_p2() {
    or_ln340_2651_fu_4859_p2 = (or_ln340_2650_fu_4853_p2.read() | and_ln416_687_fu_4777_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_2652_fu_16935_p2() {
    or_ln340_2652_fu_16935_p2 = (tmp_5464_fu_16903_p3.read() | xor_ln340_734_fu_16929_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_2653_fu_5045_p2() {
    or_ln340_2653_fu_5045_p2 = (and_ln786_18_fu_5015_p2.read() | xor_ln779_18_fu_4983_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_2654_fu_5051_p2() {
    or_ln340_2654_fu_5051_p2 = (or_ln340_2653_fu_5045_p2.read() | and_ln416_688_fu_4969_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_2655_fu_17023_p2() {
    or_ln340_2655_fu_17023_p2 = (tmp_5471_fu_16991_p3.read() | xor_ln340_735_fu_17017_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_2656_fu_17202_p2() {
    or_ln340_2656_fu_17202_p2 = (and_ln786_19_fu_17172_p2.read() | xor_ln779_19_fu_17140_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_2657_fu_17208_p2() {
    or_ln340_2657_fu_17208_p2 = (or_ln340_2656_fu_17202_p2.read() | and_ln416_689_fu_17126_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_2658_fu_17298_p2() {
    or_ln340_2658_fu_17298_p2 = (tmp_5478_fu_17266_p3.read() | xor_ln340_736_fu_17292_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_2659_fu_5235_p2() {
    or_ln340_2659_fu_5235_p2 = (and_ln786_20_fu_5205_p2.read() | xor_ln779_20_fu_5173_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_2660_fu_5241_p2() {
    or_ln340_2660_fu_5241_p2 = (or_ln340_2659_fu_5235_p2.read() | and_ln416_690_fu_5159_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_2661_fu_17386_p2() {
    or_ln340_2661_fu_17386_p2 = (tmp_5485_fu_17354_p3.read() | xor_ln340_737_fu_17380_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_2662_fu_5415_p2() {
    or_ln340_2662_fu_5415_p2 = (and_ln786_21_fu_5385_p2.read() | xor_ln779_21_fu_5353_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_2663_fu_5421_p2() {
    or_ln340_2663_fu_5421_p2 = (or_ln340_2662_fu_5415_p2.read() | and_ln416_691_fu_5339_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_2664_fu_17474_p2() {
    or_ln340_2664_fu_17474_p2 = (tmp_5492_fu_17442_p3.read() | xor_ln340_738_fu_17468_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_2665_fu_5595_p2() {
    or_ln340_2665_fu_5595_p2 = (and_ln786_22_fu_5565_p2.read() | xor_ln779_22_fu_5533_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_2666_fu_5601_p2() {
    or_ln340_2666_fu_5601_p2 = (or_ln340_2665_fu_5595_p2.read() | and_ln416_692_fu_5519_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_2667_fu_17562_p2() {
    or_ln340_2667_fu_17562_p2 = (tmp_5499_fu_17530_p3.read() | xor_ln340_739_fu_17556_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_2668_fu_5775_p2() {
    or_ln340_2668_fu_5775_p2 = (and_ln786_23_fu_5745_p2.read() | xor_ln779_23_fu_5713_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_2669_fu_5781_p2() {
    or_ln340_2669_fu_5781_p2 = (or_ln340_2668_fu_5775_p2.read() | and_ln416_693_fu_5699_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_2670_fu_17650_p2() {
    or_ln340_2670_fu_17650_p2 = (tmp_5506_fu_17618_p3.read() | xor_ln340_740_fu_17644_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_2671_fu_5955_p2() {
    or_ln340_2671_fu_5955_p2 = (and_ln786_24_fu_5925_p2.read() | xor_ln779_24_fu_5893_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_2672_fu_5961_p2() {
    or_ln340_2672_fu_5961_p2 = (or_ln340_2671_fu_5955_p2.read() | and_ln416_694_fu_5879_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_2673_fu_17738_p2() {
    or_ln340_2673_fu_17738_p2 = (tmp_5513_fu_17706_p3.read() | xor_ln340_741_fu_17732_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_2674_fu_6135_p2() {
    or_ln340_2674_fu_6135_p2 = (and_ln786_25_fu_6105_p2.read() | xor_ln779_25_fu_6073_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_2675_fu_6141_p2() {
    or_ln340_2675_fu_6141_p2 = (or_ln340_2674_fu_6135_p2.read() | and_ln416_695_fu_6059_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_2676_fu_17826_p2() {
    or_ln340_2676_fu_17826_p2 = (tmp_5520_fu_17794_p3.read() | xor_ln340_742_fu_17820_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_2677_fu_6315_p2() {
    or_ln340_2677_fu_6315_p2 = (and_ln786_26_fu_6285_p2.read() | xor_ln779_26_fu_6253_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_2678_fu_6321_p2() {
    or_ln340_2678_fu_6321_p2 = (or_ln340_2677_fu_6315_p2.read() | and_ln416_696_fu_6239_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_2679_fu_17914_p2() {
    or_ln340_2679_fu_17914_p2 = (tmp_5527_fu_17882_p3.read() | xor_ln340_743_fu_17908_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_2680_fu_6495_p2() {
    or_ln340_2680_fu_6495_p2 = (and_ln786_27_fu_6465_p2.read() | xor_ln779_27_fu_6433_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_2681_fu_6501_p2() {
    or_ln340_2681_fu_6501_p2 = (or_ln340_2680_fu_6495_p2.read() | and_ln416_697_fu_6419_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_2682_fu_18002_p2() {
    or_ln340_2682_fu_18002_p2 = (tmp_5534_fu_17970_p3.read() | xor_ln340_744_fu_17996_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_2683_fu_6675_p2() {
    or_ln340_2683_fu_6675_p2 = (and_ln786_28_fu_6645_p2.read() | xor_ln779_28_fu_6613_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_2684_fu_6681_p2() {
    or_ln340_2684_fu_6681_p2 = (or_ln340_2683_fu_6675_p2.read() | and_ln416_698_fu_6599_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_2685_fu_18090_p2() {
    or_ln340_2685_fu_18090_p2 = (tmp_5541_fu_18058_p3.read() | xor_ln340_745_fu_18084_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_2686_fu_6855_p2() {
    or_ln340_2686_fu_6855_p2 = (and_ln786_29_fu_6825_p2.read() | xor_ln779_29_fu_6793_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_2687_fu_6861_p2() {
    or_ln340_2687_fu_6861_p2 = (or_ln340_2686_fu_6855_p2.read() | and_ln416_699_fu_6779_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_2688_fu_18178_p2() {
    or_ln340_2688_fu_18178_p2 = (tmp_5548_fu_18146_p3.read() | xor_ln340_746_fu_18172_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_2689_fu_7035_p2() {
    or_ln340_2689_fu_7035_p2 = (and_ln786_30_fu_7005_p2.read() | xor_ln779_30_fu_6973_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_2690_fu_7041_p2() {
    or_ln340_2690_fu_7041_p2 = (or_ln340_2689_fu_7035_p2.read() | and_ln416_700_fu_6959_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_2691_fu_18266_p2() {
    or_ln340_2691_fu_18266_p2 = (tmp_5555_fu_18234_p3.read() | xor_ln340_747_fu_18260_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_2692_fu_7215_p2() {
    or_ln340_2692_fu_7215_p2 = (and_ln786_31_fu_7185_p2.read() | xor_ln779_31_fu_7153_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_2693_fu_7221_p2() {
    or_ln340_2693_fu_7221_p2 = (or_ln340_2692_fu_7215_p2.read() | and_ln416_701_fu_7139_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_2694_fu_18354_p2() {
    or_ln340_2694_fu_18354_p2 = (tmp_5562_fu_18322_p3.read() | xor_ln340_748_fu_18348_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_2695_fu_7395_p2() {
    or_ln340_2695_fu_7395_p2 = (and_ln786_32_fu_7365_p2.read() | xor_ln779_32_fu_7333_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_2696_fu_7401_p2() {
    or_ln340_2696_fu_7401_p2 = (or_ln340_2695_fu_7395_p2.read() | and_ln416_702_fu_7319_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_2697_fu_18442_p2() {
    or_ln340_2697_fu_18442_p2 = (tmp_5569_fu_18410_p3.read() | xor_ln340_749_fu_18436_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_2698_fu_7575_p2() {
    or_ln340_2698_fu_7575_p2 = (and_ln786_33_fu_7545_p2.read() | xor_ln779_33_fu_7513_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_2699_fu_7581_p2() {
    or_ln340_2699_fu_7581_p2 = (or_ln340_2698_fu_7575_p2.read() | and_ln416_703_fu_7499_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_26_fu_6309_p2() {
    or_ln340_26_fu_6309_p2 = (and_ln786_1979_fu_6303_p2.read() | and_ln785_696_fu_6279_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_2700_fu_18530_p2() {
    or_ln340_2700_fu_18530_p2 = (tmp_5576_fu_18498_p3.read() | xor_ln340_750_fu_18524_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_2701_fu_7755_p2() {
    or_ln340_2701_fu_7755_p2 = (and_ln786_34_fu_7725_p2.read() | xor_ln779_34_fu_7693_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_2702_fu_7761_p2() {
    or_ln340_2702_fu_7761_p2 = (or_ln340_2701_fu_7755_p2.read() | and_ln416_704_fu_7679_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_2703_fu_18618_p2() {
    or_ln340_2703_fu_18618_p2 = (tmp_5583_fu_18586_p3.read() | xor_ln340_751_fu_18612_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_2704_fu_7935_p2() {
    or_ln340_2704_fu_7935_p2 = (and_ln786_35_fu_7905_p2.read() | xor_ln779_35_fu_7873_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_2705_fu_7941_p2() {
    or_ln340_2705_fu_7941_p2 = (or_ln340_2704_fu_7935_p2.read() | and_ln416_705_fu_7859_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_2706_fu_18706_p2() {
    or_ln340_2706_fu_18706_p2 = (tmp_5590_fu_18674_p3.read() | xor_ln340_752_fu_18700_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_2707_fu_8115_p2() {
    or_ln340_2707_fu_8115_p2 = (and_ln786_36_fu_8085_p2.read() | xor_ln779_36_fu_8053_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_2708_fu_8121_p2() {
    or_ln340_2708_fu_8121_p2 = (or_ln340_2707_fu_8115_p2.read() | and_ln416_706_fu_8039_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_2709_fu_18794_p2() {
    or_ln340_2709_fu_18794_p2 = (tmp_5597_fu_18762_p3.read() | xor_ln340_753_fu_18788_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_2710_fu_8295_p2() {
    or_ln340_2710_fu_8295_p2 = (and_ln786_37_fu_8265_p2.read() | xor_ln779_37_fu_8233_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_2711_fu_8301_p2() {
    or_ln340_2711_fu_8301_p2 = (or_ln340_2710_fu_8295_p2.read() | and_ln416_707_fu_8219_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_2712_fu_18882_p2() {
    or_ln340_2712_fu_18882_p2 = (tmp_5604_fu_18850_p3.read() | xor_ln340_754_fu_18876_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_2713_fu_8475_p2() {
    or_ln340_2713_fu_8475_p2 = (and_ln786_38_fu_8445_p2.read() | xor_ln779_38_fu_8413_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_2714_fu_8481_p2() {
    or_ln340_2714_fu_8481_p2 = (or_ln340_2713_fu_8475_p2.read() | and_ln416_708_fu_8399_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_2715_fu_18970_p2() {
    or_ln340_2715_fu_18970_p2 = (tmp_5611_fu_18938_p3.read() | xor_ln340_755_fu_18964_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_2716_fu_19133_p2() {
    or_ln340_2716_fu_19133_p2 = (and_ln786_39_fu_19103_p2.read() | xor_ln779_39_fu_19071_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_2717_fu_19139_p2() {
    or_ln340_2717_fu_19139_p2 = (or_ln340_2716_fu_19133_p2.read() | and_ln416_709_fu_19057_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_2718_fu_19229_p2() {
    or_ln340_2718_fu_19229_p2 = (tmp_5618_fu_19197_p3.read() | xor_ln340_756_fu_19223_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_2719_fu_8665_p2() {
    or_ln340_2719_fu_8665_p2 = (and_ln786_40_fu_8635_p2.read() | xor_ln779_40_fu_8603_p2.read());
}

void conv_1d_cl_array_ap_fixed_8u_array_ap_fixed_24_16_0_0_0_4u_config8_s::thread_or_ln340_2720_fu_8671_p2() {
    or_ln340_2720_fu_8671_p2 = (or_ln340_2719_fu_8665_p2.read() | and_ln416_710_fu_8589_p2.read());
}

}

