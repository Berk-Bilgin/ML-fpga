#include "dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s.h"
#include "AESL_pkg.h"

using namespace std;

namespace ap_rtl {

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_357_fu_67437_p2() {
    xor_ln779_357_fu_67437_p2 = (tmp_3011_fu_67369_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_358_fu_67617_p2() {
    xor_ln779_358_fu_67617_p2 = (tmp_3018_fu_67549_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_359_fu_67797_p2() {
    xor_ln779_359_fu_67797_p2 = (tmp_3025_fu_67729_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_35_fu_11177_p2() {
    xor_ln779_35_fu_11177_p2 = (tmp_757_fu_11109_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_360_fu_67977_p2() {
    xor_ln779_360_fu_67977_p2 = (tmp_3032_fu_67909_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_361_fu_68157_p2() {
    xor_ln779_361_fu_68157_p2 = (tmp_3039_fu_68089_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_362_fu_68337_p2() {
    xor_ln779_362_fu_68337_p2 = (tmp_3046_fu_68269_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_363_fu_68517_p2() {
    xor_ln779_363_fu_68517_p2 = (tmp_3053_fu_68449_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_364_fu_68697_p2() {
    xor_ln779_364_fu_68697_p2 = (tmp_3060_fu_68629_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_365_fu_68877_p2() {
    xor_ln779_365_fu_68877_p2 = (tmp_3067_fu_68809_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_366_fu_69057_p2() {
    xor_ln779_366_fu_69057_p2 = (tmp_3074_fu_68989_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_367_fu_69237_p2() {
    xor_ln779_367_fu_69237_p2 = (tmp_3081_fu_69169_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_368_fu_69417_p2() {
    xor_ln779_368_fu_69417_p2 = (tmp_3088_fu_69349_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_369_fu_69597_p2() {
    xor_ln779_369_fu_69597_p2 = (tmp_3095_fu_69529_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_36_fu_11357_p2() {
    xor_ln779_36_fu_11357_p2 = (tmp_764_fu_11289_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_370_fu_69777_p2() {
    xor_ln779_370_fu_69777_p2 = (tmp_3102_fu_69709_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_371_fu_69957_p2() {
    xor_ln779_371_fu_69957_p2 = (tmp_3109_fu_69889_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_372_fu_70137_p2() {
    xor_ln779_372_fu_70137_p2 = (tmp_3116_fu_70069_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_373_fu_70317_p2() {
    xor_ln779_373_fu_70317_p2 = (tmp_3123_fu_70249_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_374_fu_70497_p2() {
    xor_ln779_374_fu_70497_p2 = (tmp_3130_fu_70429_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_375_fu_70677_p2() {
    xor_ln779_375_fu_70677_p2 = (tmp_3137_fu_70609_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_376_fu_70857_p2() {
    xor_ln779_376_fu_70857_p2 = (tmp_3144_fu_70789_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_377_fu_71037_p2() {
    xor_ln779_377_fu_71037_p2 = (tmp_3151_fu_70969_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_378_fu_71217_p2() {
    xor_ln779_378_fu_71217_p2 = (tmp_3158_fu_71149_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_379_fu_71397_p2() {
    xor_ln779_379_fu_71397_p2 = (tmp_3165_fu_71329_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_37_fu_11537_p2() {
    xor_ln779_37_fu_11537_p2 = (tmp_771_fu_11469_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_380_fu_71577_p2() {
    xor_ln779_380_fu_71577_p2 = (tmp_3172_fu_71509_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_381_fu_71757_p2() {
    xor_ln779_381_fu_71757_p2 = (tmp_3179_fu_71689_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_382_fu_71937_p2() {
    xor_ln779_382_fu_71937_p2 = (tmp_3186_fu_71869_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_383_fu_130067_p2() {
    xor_ln779_383_fu_130067_p2 = (tmp_3193_fu_129999_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_384_fu_72127_p2() {
    xor_ln779_384_fu_72127_p2 = (tmp_3200_fu_72059_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_385_fu_72307_p2() {
    xor_ln779_385_fu_72307_p2 = (tmp_3207_fu_72239_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_386_fu_72487_p2() {
    xor_ln779_386_fu_72487_p2 = (tmp_3214_fu_72419_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_387_fu_72667_p2() {
    xor_ln779_387_fu_72667_p2 = (tmp_3221_fu_72599_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_388_fu_72847_p2() {
    xor_ln779_388_fu_72847_p2 = (tmp_3228_fu_72779_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_389_fu_73027_p2() {
    xor_ln779_389_fu_73027_p2 = (tmp_3235_fu_72959_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_38_fu_11717_p2() {
    xor_ln779_38_fu_11717_p2 = (tmp_778_fu_11649_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_390_fu_73207_p2() {
    xor_ln779_390_fu_73207_p2 = (tmp_3242_fu_73139_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_391_fu_73387_p2() {
    xor_ln779_391_fu_73387_p2 = (tmp_3249_fu_73319_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_392_fu_73567_p2() {
    xor_ln779_392_fu_73567_p2 = (tmp_3256_fu_73499_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_393_fu_73747_p2() {
    xor_ln779_393_fu_73747_p2 = (tmp_3263_fu_73679_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_394_fu_73927_p2() {
    xor_ln779_394_fu_73927_p2 = (tmp_3270_fu_73859_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_395_fu_74107_p2() {
    xor_ln779_395_fu_74107_p2 = (tmp_3277_fu_74039_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_396_fu_74287_p2() {
    xor_ln779_396_fu_74287_p2 = (tmp_3284_fu_74219_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_397_fu_74467_p2() {
    xor_ln779_397_fu_74467_p2 = (tmp_3291_fu_74399_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_398_fu_74647_p2() {
    xor_ln779_398_fu_74647_p2 = (tmp_3298_fu_74579_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_399_fu_74827_p2() {
    xor_ln779_399_fu_74827_p2 = (tmp_3305_fu_74759_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_39_fu_11897_p2() {
    xor_ln779_39_fu_11897_p2 = (tmp_785_fu_11829_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_3_fu_5255_p2() {
    xor_ln779_3_fu_5255_p2 = (tmp_533_fu_5187_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_400_fu_75007_p2() {
    xor_ln779_400_fu_75007_p2 = (tmp_3312_fu_74939_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_401_fu_75187_p2() {
    xor_ln779_401_fu_75187_p2 = (tmp_3319_fu_75119_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_402_fu_75367_p2() {
    xor_ln779_402_fu_75367_p2 = (tmp_3326_fu_75299_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_403_fu_75547_p2() {
    xor_ln779_403_fu_75547_p2 = (tmp_3333_fu_75479_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_404_fu_75727_p2() {
    xor_ln779_404_fu_75727_p2 = (tmp_3340_fu_75659_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_405_fu_75907_p2() {
    xor_ln779_405_fu_75907_p2 = (tmp_3347_fu_75839_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_406_fu_76087_p2() {
    xor_ln779_406_fu_76087_p2 = (tmp_3354_fu_76019_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_407_fu_76267_p2() {
    xor_ln779_407_fu_76267_p2 = (tmp_3361_fu_76199_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_408_fu_76447_p2() {
    xor_ln779_408_fu_76447_p2 = (tmp_3368_fu_76379_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_409_fu_76627_p2() {
    xor_ln779_409_fu_76627_p2 = (tmp_3375_fu_76559_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_40_fu_12077_p2() {
    xor_ln779_40_fu_12077_p2 = (tmp_792_fu_12009_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_410_fu_76807_p2() {
    xor_ln779_410_fu_76807_p2 = (tmp_3382_fu_76739_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_411_fu_76987_p2() {
    xor_ln779_411_fu_76987_p2 = (tmp_3389_fu_76919_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_412_fu_77167_p2() {
    xor_ln779_412_fu_77167_p2 = (tmp_3396_fu_77099_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_413_fu_77347_p2() {
    xor_ln779_413_fu_77347_p2 = (tmp_3403_fu_77279_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_414_fu_77527_p2() {
    xor_ln779_414_fu_77527_p2 = (tmp_3410_fu_77459_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_415_fu_133054_p2() {
    xor_ln779_415_fu_133054_p2 = (tmp_3417_fu_132986_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_416_fu_77717_p2() {
    xor_ln779_416_fu_77717_p2 = (tmp_3424_fu_77649_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_417_fu_77897_p2() {
    xor_ln779_417_fu_77897_p2 = (tmp_3431_fu_77829_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_418_fu_78077_p2() {
    xor_ln779_418_fu_78077_p2 = (tmp_3438_fu_78009_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_419_fu_78257_p2() {
    xor_ln779_419_fu_78257_p2 = (tmp_3445_fu_78189_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_41_fu_12257_p2() {
    xor_ln779_41_fu_12257_p2 = (tmp_799_fu_12189_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_420_fu_78437_p2() {
    xor_ln779_420_fu_78437_p2 = (tmp_3452_fu_78369_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_421_fu_78617_p2() {
    xor_ln779_421_fu_78617_p2 = (tmp_3459_fu_78549_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_422_fu_78797_p2() {
    xor_ln779_422_fu_78797_p2 = (tmp_3466_fu_78729_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_423_fu_78977_p2() {
    xor_ln779_423_fu_78977_p2 = (tmp_3473_fu_78909_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_424_fu_79157_p2() {
    xor_ln779_424_fu_79157_p2 = (tmp_3480_fu_79089_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_425_fu_79337_p2() {
    xor_ln779_425_fu_79337_p2 = (tmp_3487_fu_79269_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_426_fu_79517_p2() {
    xor_ln779_426_fu_79517_p2 = (tmp_3494_fu_79449_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_427_fu_79697_p2() {
    xor_ln779_427_fu_79697_p2 = (tmp_3501_fu_79629_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_428_fu_79877_p2() {
    xor_ln779_428_fu_79877_p2 = (tmp_3508_fu_79809_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_429_fu_80057_p2() {
    xor_ln779_429_fu_80057_p2 = (tmp_3515_fu_79989_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_42_fu_12437_p2() {
    xor_ln779_42_fu_12437_p2 = (tmp_806_fu_12369_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_430_fu_80237_p2() {
    xor_ln779_430_fu_80237_p2 = (tmp_3522_fu_80169_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_431_fu_80417_p2() {
    xor_ln779_431_fu_80417_p2 = (tmp_3529_fu_80349_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_432_fu_80597_p2() {
    xor_ln779_432_fu_80597_p2 = (tmp_3536_fu_80529_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_433_fu_80777_p2() {
    xor_ln779_433_fu_80777_p2 = (tmp_3543_fu_80709_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_434_fu_80957_p2() {
    xor_ln779_434_fu_80957_p2 = (tmp_3550_fu_80889_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_435_fu_81137_p2() {
    xor_ln779_435_fu_81137_p2 = (tmp_3557_fu_81069_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_436_fu_81317_p2() {
    xor_ln779_436_fu_81317_p2 = (tmp_3564_fu_81249_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_437_fu_81497_p2() {
    xor_ln779_437_fu_81497_p2 = (tmp_3571_fu_81429_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_438_fu_81677_p2() {
    xor_ln779_438_fu_81677_p2 = (tmp_3578_fu_81609_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_439_fu_81857_p2() {
    xor_ln779_439_fu_81857_p2 = (tmp_3585_fu_81789_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_43_fu_12617_p2() {
    xor_ln779_43_fu_12617_p2 = (tmp_813_fu_12549_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_440_fu_82037_p2() {
    xor_ln779_440_fu_82037_p2 = (tmp_3592_fu_81969_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_441_fu_82217_p2() {
    xor_ln779_441_fu_82217_p2 = (tmp_3599_fu_82149_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_442_fu_82397_p2() {
    xor_ln779_442_fu_82397_p2 = (tmp_3606_fu_82329_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_443_fu_82577_p2() {
    xor_ln779_443_fu_82577_p2 = (tmp_3613_fu_82509_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_444_fu_82757_p2() {
    xor_ln779_444_fu_82757_p2 = (tmp_3620_fu_82689_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_445_fu_82937_p2() {
    xor_ln779_445_fu_82937_p2 = (tmp_3627_fu_82869_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_446_fu_83117_p2() {
    xor_ln779_446_fu_83117_p2 = (tmp_3634_fu_83049_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_447_fu_136041_p2() {
    xor_ln779_447_fu_136041_p2 = (tmp_3641_fu_135973_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_448_fu_83307_p2() {
    xor_ln779_448_fu_83307_p2 = (tmp_3648_fu_83239_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_449_fu_83487_p2() {
    xor_ln779_449_fu_83487_p2 = (tmp_3655_fu_83419_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_44_fu_12797_p2() {
    xor_ln779_44_fu_12797_p2 = (tmp_820_fu_12729_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_450_fu_83667_p2() {
    xor_ln779_450_fu_83667_p2 = (tmp_3662_fu_83599_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_451_fu_83847_p2() {
    xor_ln779_451_fu_83847_p2 = (tmp_3669_fu_83779_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_452_fu_84027_p2() {
    xor_ln779_452_fu_84027_p2 = (tmp_3676_fu_83959_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_453_fu_84207_p2() {
    xor_ln779_453_fu_84207_p2 = (tmp_3683_fu_84139_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_454_fu_84387_p2() {
    xor_ln779_454_fu_84387_p2 = (tmp_3690_fu_84319_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_455_fu_84567_p2() {
    xor_ln779_455_fu_84567_p2 = (tmp_3697_fu_84499_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_456_fu_84747_p2() {
    xor_ln779_456_fu_84747_p2 = (tmp_3704_fu_84679_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_457_fu_84927_p2() {
    xor_ln779_457_fu_84927_p2 = (tmp_3711_fu_84859_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_458_fu_85107_p2() {
    xor_ln779_458_fu_85107_p2 = (tmp_3718_fu_85039_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_459_fu_85287_p2() {
    xor_ln779_459_fu_85287_p2 = (tmp_3725_fu_85219_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_45_fu_12977_p2() {
    xor_ln779_45_fu_12977_p2 = (tmp_827_fu_12909_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_460_fu_85467_p2() {
    xor_ln779_460_fu_85467_p2 = (tmp_3732_fu_85399_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_461_fu_85647_p2() {
    xor_ln779_461_fu_85647_p2 = (tmp_3739_fu_85579_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_462_fu_85827_p2() {
    xor_ln779_462_fu_85827_p2 = (tmp_3746_fu_85759_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_463_fu_86007_p2() {
    xor_ln779_463_fu_86007_p2 = (tmp_3753_fu_85939_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_464_fu_86187_p2() {
    xor_ln779_464_fu_86187_p2 = (tmp_3760_fu_86119_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_465_fu_86367_p2() {
    xor_ln779_465_fu_86367_p2 = (tmp_3767_fu_86299_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_466_fu_86547_p2() {
    xor_ln779_466_fu_86547_p2 = (tmp_3774_fu_86479_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_467_fu_86727_p2() {
    xor_ln779_467_fu_86727_p2 = (tmp_3781_fu_86659_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_468_fu_86907_p2() {
    xor_ln779_468_fu_86907_p2 = (tmp_3788_fu_86839_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_469_fu_87087_p2() {
    xor_ln779_469_fu_87087_p2 = (tmp_3795_fu_87019_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_46_fu_13157_p2() {
    xor_ln779_46_fu_13157_p2 = (tmp_834_fu_13089_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_470_fu_87267_p2() {
    xor_ln779_470_fu_87267_p2 = (tmp_3802_fu_87199_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_471_fu_87447_p2() {
    xor_ln779_471_fu_87447_p2 = (tmp_3809_fu_87379_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_472_fu_87627_p2() {
    xor_ln779_472_fu_87627_p2 = (tmp_3816_fu_87559_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_473_fu_87807_p2() {
    xor_ln779_473_fu_87807_p2 = (tmp_3823_fu_87739_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_474_fu_87987_p2() {
    xor_ln779_474_fu_87987_p2 = (tmp_3830_fu_87919_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_475_fu_88167_p2() {
    xor_ln779_475_fu_88167_p2 = (tmp_3837_fu_88099_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_476_fu_88347_p2() {
    xor_ln779_476_fu_88347_p2 = (tmp_3844_fu_88279_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_477_fu_88527_p2() {
    xor_ln779_477_fu_88527_p2 = (tmp_3851_fu_88459_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_478_fu_88707_p2() {
    xor_ln779_478_fu_88707_p2 = (tmp_3858_fu_88639_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_479_fu_139028_p2() {
    xor_ln779_479_fu_139028_p2 = (tmp_3865_fu_138960_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_47_fu_13337_p2() {
    xor_ln779_47_fu_13337_p2 = (tmp_841_fu_13269_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_480_fu_88897_p2() {
    xor_ln779_480_fu_88897_p2 = (tmp_3872_fu_88829_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_481_fu_89077_p2() {
    xor_ln779_481_fu_89077_p2 = (tmp_3879_fu_89009_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_482_fu_89257_p2() {
    xor_ln779_482_fu_89257_p2 = (tmp_3886_fu_89189_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_483_fu_89437_p2() {
    xor_ln779_483_fu_89437_p2 = (tmp_3893_fu_89369_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_484_fu_89617_p2() {
    xor_ln779_484_fu_89617_p2 = (tmp_3900_fu_89549_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_485_fu_89797_p2() {
    xor_ln779_485_fu_89797_p2 = (tmp_3907_fu_89729_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_486_fu_89977_p2() {
    xor_ln779_486_fu_89977_p2 = (tmp_3914_fu_89909_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_487_fu_90157_p2() {
    xor_ln779_487_fu_90157_p2 = (tmp_3921_fu_90089_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_488_fu_90337_p2() {
    xor_ln779_488_fu_90337_p2 = (tmp_3928_fu_90269_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_489_fu_90517_p2() {
    xor_ln779_489_fu_90517_p2 = (tmp_3935_fu_90449_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_48_fu_13517_p2() {
    xor_ln779_48_fu_13517_p2 = (tmp_848_fu_13449_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_490_fu_90697_p2() {
    xor_ln779_490_fu_90697_p2 = (tmp_3942_fu_90629_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_491_fu_90877_p2() {
    xor_ln779_491_fu_90877_p2 = (tmp_3949_fu_90809_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_492_fu_91057_p2() {
    xor_ln779_492_fu_91057_p2 = (tmp_3956_fu_90989_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_493_fu_91237_p2() {
    xor_ln779_493_fu_91237_p2 = (tmp_3963_fu_91169_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_494_fu_91417_p2() {
    xor_ln779_494_fu_91417_p2 = (tmp_3970_fu_91349_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_495_fu_91597_p2() {
    xor_ln779_495_fu_91597_p2 = (tmp_3977_fu_91529_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_496_fu_91777_p2() {
    xor_ln779_496_fu_91777_p2 = (tmp_3984_fu_91709_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_497_fu_91957_p2() {
    xor_ln779_497_fu_91957_p2 = (tmp_3991_fu_91889_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_498_fu_92137_p2() {
    xor_ln779_498_fu_92137_p2 = (tmp_3998_fu_92069_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_499_fu_92317_p2() {
    xor_ln779_499_fu_92317_p2 = (tmp_4005_fu_92249_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_49_fu_13697_p2() {
    xor_ln779_49_fu_13697_p2 = (tmp_855_fu_13629_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_4_fu_5447_p2() {
    xor_ln779_4_fu_5447_p2 = (tmp_540_fu_5379_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_500_fu_92497_p2() {
    xor_ln779_500_fu_92497_p2 = (tmp_4012_fu_92429_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_501_fu_92677_p2() {
    xor_ln779_501_fu_92677_p2 = (tmp_4019_fu_92609_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_502_fu_92857_p2() {
    xor_ln779_502_fu_92857_p2 = (tmp_4026_fu_92789_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_503_fu_93037_p2() {
    xor_ln779_503_fu_93037_p2 = (tmp_4033_fu_92969_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_504_fu_93217_p2() {
    xor_ln779_504_fu_93217_p2 = (tmp_4040_fu_93149_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_505_fu_93397_p2() {
    xor_ln779_505_fu_93397_p2 = (tmp_4047_fu_93329_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_506_fu_93577_p2() {
    xor_ln779_506_fu_93577_p2 = (tmp_4054_fu_93509_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_507_fu_93757_p2() {
    xor_ln779_507_fu_93757_p2 = (tmp_4061_fu_93689_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_508_fu_93937_p2() {
    xor_ln779_508_fu_93937_p2 = (tmp_4068_fu_93869_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_509_fu_94117_p2() {
    xor_ln779_509_fu_94117_p2 = (tmp_4075_fu_94049_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_50_fu_13877_p2() {
    xor_ln779_50_fu_13877_p2 = (tmp_862_fu_13809_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_510_fu_94297_p2() {
    xor_ln779_510_fu_94297_p2 = (tmp_4082_fu_94229_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_511_fu_142033_p2() {
    xor_ln779_511_fu_142033_p2 = (tmp_4089_fu_141953_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_51_fu_14057_p2() {
    xor_ln779_51_fu_14057_p2 = (tmp_869_fu_13989_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_52_fu_14237_p2() {
    xor_ln779_52_fu_14237_p2 = (tmp_876_fu_14169_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_53_fu_14417_p2() {
    xor_ln779_53_fu_14417_p2 = (tmp_883_fu_14349_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_54_fu_14597_p2() {
    xor_ln779_54_fu_14597_p2 = (tmp_890_fu_14529_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_55_fu_14777_p2() {
    xor_ln779_55_fu_14777_p2 = (tmp_897_fu_14709_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_56_fu_14957_p2() {
    xor_ln779_56_fu_14957_p2 = (tmp_904_fu_14889_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_57_fu_15137_p2() {
    xor_ln779_57_fu_15137_p2 = (tmp_911_fu_15069_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_58_fu_15317_p2() {
    xor_ln779_58_fu_15317_p2 = (tmp_918_fu_15249_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_59_fu_15497_p2() {
    xor_ln779_59_fu_15497_p2 = (tmp_925_fu_15429_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_5_fu_5639_p2() {
    xor_ln779_5_fu_5639_p2 = (tmp_547_fu_5571_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_60_fu_15677_p2() {
    xor_ln779_60_fu_15677_p2 = (tmp_932_fu_15609_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_61_fu_15857_p2() {
    xor_ln779_61_fu_15857_p2 = (tmp_939_fu_15789_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_62_fu_16037_p2() {
    xor_ln779_62_fu_16037_p2 = (tmp_946_fu_15969_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_63_fu_100197_p2() {
    xor_ln779_63_fu_100197_p2 = (tmp_953_fu_100129_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_64_fu_16227_p2() {
    xor_ln779_64_fu_16227_p2 = (tmp_960_fu_16159_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_65_fu_16407_p2() {
    xor_ln779_65_fu_16407_p2 = (tmp_967_fu_16339_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_66_fu_16587_p2() {
    xor_ln779_66_fu_16587_p2 = (tmp_974_fu_16519_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_67_fu_16767_p2() {
    xor_ln779_67_fu_16767_p2 = (tmp_981_fu_16699_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_68_fu_16947_p2() {
    xor_ln779_68_fu_16947_p2 = (tmp_988_fu_16879_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_69_fu_17127_p2() {
    xor_ln779_69_fu_17127_p2 = (tmp_995_fu_17059_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_6_fu_5831_p2() {
    xor_ln779_6_fu_5831_p2 = (tmp_554_fu_5763_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_70_fu_17307_p2() {
    xor_ln779_70_fu_17307_p2 = (tmp_1002_fu_17239_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_71_fu_17487_p2() {
    xor_ln779_71_fu_17487_p2 = (tmp_1009_fu_17419_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_72_fu_17667_p2() {
    xor_ln779_72_fu_17667_p2 = (tmp_1016_fu_17599_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_73_fu_17847_p2() {
    xor_ln779_73_fu_17847_p2 = (tmp_1023_fu_17779_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_74_fu_18027_p2() {
    xor_ln779_74_fu_18027_p2 = (tmp_1030_fu_17959_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_75_fu_18207_p2() {
    xor_ln779_75_fu_18207_p2 = (tmp_1037_fu_18139_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_76_fu_18387_p2() {
    xor_ln779_76_fu_18387_p2 = (tmp_1044_fu_18319_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_77_fu_18567_p2() {
    xor_ln779_77_fu_18567_p2 = (tmp_1051_fu_18499_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_78_fu_18747_p2() {
    xor_ln779_78_fu_18747_p2 = (tmp_1058_fu_18679_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_79_fu_18927_p2() {
    xor_ln779_79_fu_18927_p2 = (tmp_1065_fu_18859_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_7_fu_6023_p2() {
    xor_ln779_7_fu_6023_p2 = (tmp_561_fu_5955_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_80_fu_19107_p2() {
    xor_ln779_80_fu_19107_p2 = (tmp_1072_fu_19039_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_81_fu_19287_p2() {
    xor_ln779_81_fu_19287_p2 = (tmp_1079_fu_19219_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_82_fu_19467_p2() {
    xor_ln779_82_fu_19467_p2 = (tmp_1086_fu_19399_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_83_fu_19647_p2() {
    xor_ln779_83_fu_19647_p2 = (tmp_1093_fu_19579_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_84_fu_19827_p2() {
    xor_ln779_84_fu_19827_p2 = (tmp_1100_fu_19759_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_85_fu_20007_p2() {
    xor_ln779_85_fu_20007_p2 = (tmp_1107_fu_19939_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_86_fu_20187_p2() {
    xor_ln779_86_fu_20187_p2 = (tmp_1114_fu_20119_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_87_fu_20367_p2() {
    xor_ln779_87_fu_20367_p2 = (tmp_1121_fu_20299_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_88_fu_20547_p2() {
    xor_ln779_88_fu_20547_p2 = (tmp_1128_fu_20479_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_89_fu_20727_p2() {
    xor_ln779_89_fu_20727_p2 = (tmp_1135_fu_20659_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_8_fu_6215_p2() {
    xor_ln779_8_fu_6215_p2 = (tmp_568_fu_6147_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_90_fu_20907_p2() {
    xor_ln779_90_fu_20907_p2 = (tmp_1142_fu_20839_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_91_fu_21087_p2() {
    xor_ln779_91_fu_21087_p2 = (tmp_1149_fu_21019_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_92_fu_21267_p2() {
    xor_ln779_92_fu_21267_p2 = (tmp_1156_fu_21199_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_93_fu_21447_p2() {
    xor_ln779_93_fu_21447_p2 = (tmp_1163_fu_21379_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_94_fu_21627_p2() {
    xor_ln779_94_fu_21627_p2 = (tmp_1170_fu_21559_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_95_fu_103184_p2() {
    xor_ln779_95_fu_103184_p2 = (tmp_1177_fu_103116_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_96_fu_21817_p2() {
    xor_ln779_96_fu_21817_p2 = (tmp_1184_fu_21749_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_97_fu_21997_p2() {
    xor_ln779_97_fu_21997_p2 = (tmp_1191_fu_21929_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_98_fu_22177_p2() {
    xor_ln779_98_fu_22177_p2 = (tmp_1198_fu_22109_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_99_fu_22357_p2() {
    xor_ln779_99_fu_22357_p2 = (tmp_1205_fu_22289_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_9_fu_6407_p2() {
    xor_ln779_9_fu_6407_p2 = (tmp_575_fu_6339_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln779_fu_4679_p2() {
    xor_ln779_fu_4679_p2 = (tmp_512_fu_4611_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_100_fu_22551_p2() {
    xor_ln785_100_fu_22551_p2 = (tmp_1212_fu_22469_p3.read() ^ and_ln416_100_fu_22523_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_101_fu_22731_p2() {
    xor_ln785_101_fu_22731_p2 = (tmp_1219_fu_22649_p3.read() ^ and_ln416_101_fu_22703_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_102_fu_22911_p2() {
    xor_ln785_102_fu_22911_p2 = (tmp_1226_fu_22829_p3.read() ^ and_ln416_102_fu_22883_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_103_fu_23091_p2() {
    xor_ln785_103_fu_23091_p2 = (tmp_1233_fu_23009_p3.read() ^ and_ln416_103_fu_23063_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_104_fu_23271_p2() {
    xor_ln785_104_fu_23271_p2 = (tmp_1240_fu_23189_p3.read() ^ and_ln416_104_fu_23243_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_105_fu_23451_p2() {
    xor_ln785_105_fu_23451_p2 = (tmp_1247_fu_23369_p3.read() ^ and_ln416_105_fu_23423_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_106_fu_23631_p2() {
    xor_ln785_106_fu_23631_p2 = (tmp_1254_fu_23549_p3.read() ^ and_ln416_106_fu_23603_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_107_fu_23811_p2() {
    xor_ln785_107_fu_23811_p2 = (tmp_1261_fu_23729_p3.read() ^ and_ln416_107_fu_23783_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_108_fu_23991_p2() {
    xor_ln785_108_fu_23991_p2 = (tmp_1268_fu_23909_p3.read() ^ and_ln416_108_fu_23963_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_109_fu_24171_p2() {
    xor_ln785_109_fu_24171_p2 = (tmp_1275_fu_24089_p3.read() ^ and_ln416_109_fu_24143_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_10_fu_6613_p2() {
    xor_ln785_10_fu_6613_p2 = (tmp_582_fu_6531_p3.read() ^ and_ln416_10_fu_6585_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_110_fu_24351_p2() {
    xor_ln785_110_fu_24351_p2 = (tmp_1282_fu_24269_p3.read() ^ and_ln416_110_fu_24323_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_111_fu_24531_p2() {
    xor_ln785_111_fu_24531_p2 = (tmp_1289_fu_24449_p3.read() ^ and_ln416_111_fu_24503_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_112_fu_24711_p2() {
    xor_ln785_112_fu_24711_p2 = (tmp_1296_fu_24629_p3.read() ^ and_ln416_112_fu_24683_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_113_fu_24891_p2() {
    xor_ln785_113_fu_24891_p2 = (tmp_1303_fu_24809_p3.read() ^ and_ln416_113_fu_24863_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_114_fu_25071_p2() {
    xor_ln785_114_fu_25071_p2 = (tmp_1310_fu_24989_p3.read() ^ and_ln416_114_fu_25043_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_115_fu_25251_p2() {
    xor_ln785_115_fu_25251_p2 = (tmp_1317_fu_25169_p3.read() ^ and_ln416_115_fu_25223_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_116_fu_25431_p2() {
    xor_ln785_116_fu_25431_p2 = (tmp_1324_fu_25349_p3.read() ^ and_ln416_116_fu_25403_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_117_fu_25611_p2() {
    xor_ln785_117_fu_25611_p2 = (tmp_1331_fu_25529_p3.read() ^ and_ln416_117_fu_25583_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_118_fu_25791_p2() {
    xor_ln785_118_fu_25791_p2 = (tmp_1338_fu_25709_p3.read() ^ and_ln416_118_fu_25763_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_119_fu_25971_p2() {
    xor_ln785_119_fu_25971_p2 = (tmp_1345_fu_25889_p3.read() ^ and_ln416_119_fu_25943_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_11_fu_6805_p2() {
    xor_ln785_11_fu_6805_p2 = (tmp_589_fu_6723_p3.read() ^ and_ln416_11_fu_6777_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_120_fu_26151_p2() {
    xor_ln785_120_fu_26151_p2 = (tmp_1352_fu_26069_p3.read() ^ and_ln416_120_fu_26123_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_121_fu_26331_p2() {
    xor_ln785_121_fu_26331_p2 = (tmp_1359_fu_26249_p3.read() ^ and_ln416_121_fu_26303_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_122_fu_26511_p2() {
    xor_ln785_122_fu_26511_p2 = (tmp_1366_fu_26429_p3.read() ^ and_ln416_122_fu_26483_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_123_fu_26691_p2() {
    xor_ln785_123_fu_26691_p2 = (tmp_1373_fu_26609_p3.read() ^ and_ln416_123_fu_26663_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_124_fu_26871_p2() {
    xor_ln785_124_fu_26871_p2 = (tmp_1380_fu_26789_p3.read() ^ and_ln416_124_fu_26843_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_125_fu_27051_p2() {
    xor_ln785_125_fu_27051_p2 = (tmp_1387_fu_26969_p3.read() ^ and_ln416_125_fu_27023_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_126_fu_27231_p2() {
    xor_ln785_126_fu_27231_p2 = (tmp_1394_fu_27149_p3.read() ^ and_ln416_126_fu_27203_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_127_fu_106185_p2() {
    xor_ln785_127_fu_106185_p2 = (tmp_1401_fu_106103_p3.read() ^ and_ln416_127_fu_106157_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_128_fu_27421_p2() {
    xor_ln785_128_fu_27421_p2 = (tmp_1408_fu_27339_p3.read() ^ and_ln416_128_fu_27393_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_129_fu_27601_p2() {
    xor_ln785_129_fu_27601_p2 = (tmp_1415_fu_27519_p3.read() ^ and_ln416_129_fu_27573_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_12_fu_6997_p2() {
    xor_ln785_12_fu_6997_p2 = (tmp_596_fu_6915_p3.read() ^ and_ln416_12_fu_6969_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_130_fu_27781_p2() {
    xor_ln785_130_fu_27781_p2 = (tmp_1422_fu_27699_p3.read() ^ and_ln416_130_fu_27753_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_131_fu_27961_p2() {
    xor_ln785_131_fu_27961_p2 = (tmp_1429_fu_27879_p3.read() ^ and_ln416_131_fu_27933_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_132_fu_28141_p2() {
    xor_ln785_132_fu_28141_p2 = (tmp_1436_fu_28059_p3.read() ^ and_ln416_132_fu_28113_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_133_fu_28321_p2() {
    xor_ln785_133_fu_28321_p2 = (tmp_1443_fu_28239_p3.read() ^ and_ln416_133_fu_28293_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_134_fu_28501_p2() {
    xor_ln785_134_fu_28501_p2 = (tmp_1450_fu_28419_p3.read() ^ and_ln416_134_fu_28473_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_135_fu_28681_p2() {
    xor_ln785_135_fu_28681_p2 = (tmp_1457_fu_28599_p3.read() ^ and_ln416_135_fu_28653_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_136_fu_28861_p2() {
    xor_ln785_136_fu_28861_p2 = (tmp_1464_fu_28779_p3.read() ^ and_ln416_136_fu_28833_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_137_fu_29041_p2() {
    xor_ln785_137_fu_29041_p2 = (tmp_1471_fu_28959_p3.read() ^ and_ln416_137_fu_29013_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_138_fu_29221_p2() {
    xor_ln785_138_fu_29221_p2 = (tmp_1478_fu_29139_p3.read() ^ and_ln416_138_fu_29193_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_139_fu_29401_p2() {
    xor_ln785_139_fu_29401_p2 = (tmp_1485_fu_29319_p3.read() ^ and_ln416_139_fu_29373_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_13_fu_7189_p2() {
    xor_ln785_13_fu_7189_p2 = (tmp_603_fu_7107_p3.read() ^ and_ln416_13_fu_7161_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_140_fu_29581_p2() {
    xor_ln785_140_fu_29581_p2 = (tmp_1492_fu_29499_p3.read() ^ and_ln416_140_fu_29553_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_141_fu_29761_p2() {
    xor_ln785_141_fu_29761_p2 = (tmp_1499_fu_29679_p3.read() ^ and_ln416_141_fu_29733_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_142_fu_29941_p2() {
    xor_ln785_142_fu_29941_p2 = (tmp_1506_fu_29859_p3.read() ^ and_ln416_142_fu_29913_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_143_fu_30121_p2() {
    xor_ln785_143_fu_30121_p2 = (tmp_1513_fu_30039_p3.read() ^ and_ln416_143_fu_30093_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_144_fu_30301_p2() {
    xor_ln785_144_fu_30301_p2 = (tmp_1520_fu_30219_p3.read() ^ and_ln416_144_fu_30273_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_145_fu_30481_p2() {
    xor_ln785_145_fu_30481_p2 = (tmp_1527_fu_30399_p3.read() ^ and_ln416_145_fu_30453_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_146_fu_30661_p2() {
    xor_ln785_146_fu_30661_p2 = (tmp_1534_fu_30579_p3.read() ^ and_ln416_146_fu_30633_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_147_fu_30841_p2() {
    xor_ln785_147_fu_30841_p2 = (tmp_1541_fu_30759_p3.read() ^ and_ln416_147_fu_30813_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_148_fu_31021_p2() {
    xor_ln785_148_fu_31021_p2 = (tmp_1548_fu_30939_p3.read() ^ and_ln416_148_fu_30993_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_149_fu_31201_p2() {
    xor_ln785_149_fu_31201_p2 = (tmp_1555_fu_31119_p3.read() ^ and_ln416_149_fu_31173_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_14_fu_7381_p2() {
    xor_ln785_14_fu_7381_p2 = (tmp_610_fu_7299_p3.read() ^ and_ln416_14_fu_7353_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_150_fu_31381_p2() {
    xor_ln785_150_fu_31381_p2 = (tmp_1562_fu_31299_p3.read() ^ and_ln416_150_fu_31353_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_151_fu_31561_p2() {
    xor_ln785_151_fu_31561_p2 = (tmp_1569_fu_31479_p3.read() ^ and_ln416_151_fu_31533_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_152_fu_31741_p2() {
    xor_ln785_152_fu_31741_p2 = (tmp_1576_fu_31659_p3.read() ^ and_ln416_152_fu_31713_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_153_fu_31921_p2() {
    xor_ln785_153_fu_31921_p2 = (tmp_1583_fu_31839_p3.read() ^ and_ln416_153_fu_31893_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_154_fu_32101_p2() {
    xor_ln785_154_fu_32101_p2 = (tmp_1590_fu_32019_p3.read() ^ and_ln416_154_fu_32073_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_155_fu_32281_p2() {
    xor_ln785_155_fu_32281_p2 = (tmp_1597_fu_32199_p3.read() ^ and_ln416_155_fu_32253_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_156_fu_32461_p2() {
    xor_ln785_156_fu_32461_p2 = (tmp_1604_fu_32379_p3.read() ^ and_ln416_156_fu_32433_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_157_fu_32641_p2() {
    xor_ln785_157_fu_32641_p2 = (tmp_1611_fu_32559_p3.read() ^ and_ln416_157_fu_32613_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_158_fu_32821_p2() {
    xor_ln785_158_fu_32821_p2 = (tmp_1618_fu_32739_p3.read() ^ and_ln416_158_fu_32793_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_159_fu_109172_p2() {
    xor_ln785_159_fu_109172_p2 = (tmp_1625_fu_109090_p3.read() ^ and_ln416_159_fu_109144_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_15_fu_7573_p2() {
    xor_ln785_15_fu_7573_p2 = (tmp_617_fu_7491_p3.read() ^ and_ln416_15_fu_7545_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_160_fu_33011_p2() {
    xor_ln785_160_fu_33011_p2 = (tmp_1632_fu_32929_p3.read() ^ and_ln416_160_fu_32983_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_161_fu_33191_p2() {
    xor_ln785_161_fu_33191_p2 = (tmp_1639_fu_33109_p3.read() ^ and_ln416_161_fu_33163_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_162_fu_33371_p2() {
    xor_ln785_162_fu_33371_p2 = (tmp_1646_fu_33289_p3.read() ^ and_ln416_162_fu_33343_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_163_fu_33551_p2() {
    xor_ln785_163_fu_33551_p2 = (tmp_1653_fu_33469_p3.read() ^ and_ln416_163_fu_33523_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_164_fu_33731_p2() {
    xor_ln785_164_fu_33731_p2 = (tmp_1660_fu_33649_p3.read() ^ and_ln416_164_fu_33703_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_165_fu_33911_p2() {
    xor_ln785_165_fu_33911_p2 = (tmp_1667_fu_33829_p3.read() ^ and_ln416_165_fu_33883_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_166_fu_34091_p2() {
    xor_ln785_166_fu_34091_p2 = (tmp_1674_fu_34009_p3.read() ^ and_ln416_166_fu_34063_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_167_fu_34271_p2() {
    xor_ln785_167_fu_34271_p2 = (tmp_1681_fu_34189_p3.read() ^ and_ln416_167_fu_34243_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_168_fu_34451_p2() {
    xor_ln785_168_fu_34451_p2 = (tmp_1688_fu_34369_p3.read() ^ and_ln416_168_fu_34423_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_169_fu_34631_p2() {
    xor_ln785_169_fu_34631_p2 = (tmp_1695_fu_34549_p3.read() ^ and_ln416_169_fu_34603_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_16_fu_7765_p2() {
    xor_ln785_16_fu_7765_p2 = (tmp_624_fu_7683_p3.read() ^ and_ln416_16_fu_7737_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_170_fu_34811_p2() {
    xor_ln785_170_fu_34811_p2 = (tmp_1702_fu_34729_p3.read() ^ and_ln416_170_fu_34783_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_171_fu_34991_p2() {
    xor_ln785_171_fu_34991_p2 = (tmp_1709_fu_34909_p3.read() ^ and_ln416_171_fu_34963_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_172_fu_35171_p2() {
    xor_ln785_172_fu_35171_p2 = (tmp_1716_fu_35089_p3.read() ^ and_ln416_172_fu_35143_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_173_fu_35351_p2() {
    xor_ln785_173_fu_35351_p2 = (tmp_1723_fu_35269_p3.read() ^ and_ln416_173_fu_35323_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_174_fu_35531_p2() {
    xor_ln785_174_fu_35531_p2 = (tmp_1730_fu_35449_p3.read() ^ and_ln416_174_fu_35503_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_175_fu_35711_p2() {
    xor_ln785_175_fu_35711_p2 = (tmp_1737_fu_35629_p3.read() ^ and_ln416_175_fu_35683_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_176_fu_35891_p2() {
    xor_ln785_176_fu_35891_p2 = (tmp_1744_fu_35809_p3.read() ^ and_ln416_176_fu_35863_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_177_fu_36071_p2() {
    xor_ln785_177_fu_36071_p2 = (tmp_1751_fu_35989_p3.read() ^ and_ln416_177_fu_36043_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_178_fu_36251_p2() {
    xor_ln785_178_fu_36251_p2 = (tmp_1758_fu_36169_p3.read() ^ and_ln416_178_fu_36223_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_179_fu_36431_p2() {
    xor_ln785_179_fu_36431_p2 = (tmp_1765_fu_36349_p3.read() ^ and_ln416_179_fu_36403_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_17_fu_7957_p2() {
    xor_ln785_17_fu_7957_p2 = (tmp_631_fu_7875_p3.read() ^ and_ln416_17_fu_7929_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_180_fu_36611_p2() {
    xor_ln785_180_fu_36611_p2 = (tmp_1772_fu_36529_p3.read() ^ and_ln416_180_fu_36583_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_181_fu_36791_p2() {
    xor_ln785_181_fu_36791_p2 = (tmp_1779_fu_36709_p3.read() ^ and_ln416_181_fu_36763_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_182_fu_36971_p2() {
    xor_ln785_182_fu_36971_p2 = (tmp_1786_fu_36889_p3.read() ^ and_ln416_182_fu_36943_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_183_fu_37151_p2() {
    xor_ln785_183_fu_37151_p2 = (tmp_1793_fu_37069_p3.read() ^ and_ln416_183_fu_37123_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_184_fu_37331_p2() {
    xor_ln785_184_fu_37331_p2 = (tmp_1800_fu_37249_p3.read() ^ and_ln416_184_fu_37303_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_185_fu_37511_p2() {
    xor_ln785_185_fu_37511_p2 = (tmp_1807_fu_37429_p3.read() ^ and_ln416_185_fu_37483_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_186_fu_37691_p2() {
    xor_ln785_186_fu_37691_p2 = (tmp_1814_fu_37609_p3.read() ^ and_ln416_186_fu_37663_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_187_fu_37871_p2() {
    xor_ln785_187_fu_37871_p2 = (tmp_1821_fu_37789_p3.read() ^ and_ln416_187_fu_37843_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_188_fu_38051_p2() {
    xor_ln785_188_fu_38051_p2 = (tmp_1828_fu_37969_p3.read() ^ and_ln416_188_fu_38023_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_189_fu_38231_p2() {
    xor_ln785_189_fu_38231_p2 = (tmp_1835_fu_38149_p3.read() ^ and_ln416_189_fu_38203_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_18_fu_8149_p2() {
    xor_ln785_18_fu_8149_p2 = (tmp_638_fu_8067_p3.read() ^ and_ln416_18_fu_8121_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_190_fu_38411_p2() {
    xor_ln785_190_fu_38411_p2 = (tmp_1842_fu_38329_p3.read() ^ and_ln416_190_fu_38383_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_191_fu_112159_p2() {
    xor_ln785_191_fu_112159_p2 = (tmp_1849_fu_112077_p3.read() ^ and_ln416_191_fu_112131_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_192_fu_38601_p2() {
    xor_ln785_192_fu_38601_p2 = (tmp_1856_fu_38519_p3.read() ^ and_ln416_192_fu_38573_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_193_fu_38781_p2() {
    xor_ln785_193_fu_38781_p2 = (tmp_1863_fu_38699_p3.read() ^ and_ln416_193_fu_38753_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_194_fu_38961_p2() {
    xor_ln785_194_fu_38961_p2 = (tmp_1870_fu_38879_p3.read() ^ and_ln416_194_fu_38933_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_195_fu_39141_p2() {
    xor_ln785_195_fu_39141_p2 = (tmp_1877_fu_39059_p3.read() ^ and_ln416_195_fu_39113_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_196_fu_39321_p2() {
    xor_ln785_196_fu_39321_p2 = (tmp_1884_fu_39239_p3.read() ^ and_ln416_196_fu_39293_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_197_fu_39501_p2() {
    xor_ln785_197_fu_39501_p2 = (tmp_1891_fu_39419_p3.read() ^ and_ln416_197_fu_39473_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_198_fu_39681_p2() {
    xor_ln785_198_fu_39681_p2 = (tmp_1898_fu_39599_p3.read() ^ and_ln416_198_fu_39653_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_199_fu_39861_p2() {
    xor_ln785_199_fu_39861_p2 = (tmp_1905_fu_39779_p3.read() ^ and_ln416_199_fu_39833_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_19_fu_8341_p2() {
    xor_ln785_19_fu_8341_p2 = (tmp_645_fu_8259_p3.read() ^ and_ln416_19_fu_8313_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_1_fu_4885_p2() {
    xor_ln785_1_fu_4885_p2 = (tmp_519_fu_4803_p3.read() ^ and_ln416_1_fu_4857_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_200_fu_40041_p2() {
    xor_ln785_200_fu_40041_p2 = (tmp_1912_fu_39959_p3.read() ^ and_ln416_200_fu_40013_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_201_fu_40221_p2() {
    xor_ln785_201_fu_40221_p2 = (tmp_1919_fu_40139_p3.read() ^ and_ln416_201_fu_40193_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_202_fu_40401_p2() {
    xor_ln785_202_fu_40401_p2 = (tmp_1926_fu_40319_p3.read() ^ and_ln416_202_fu_40373_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_203_fu_40581_p2() {
    xor_ln785_203_fu_40581_p2 = (tmp_1933_fu_40499_p3.read() ^ and_ln416_203_fu_40553_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_204_fu_40761_p2() {
    xor_ln785_204_fu_40761_p2 = (tmp_1940_fu_40679_p3.read() ^ and_ln416_204_fu_40733_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_205_fu_40941_p2() {
    xor_ln785_205_fu_40941_p2 = (tmp_1947_fu_40859_p3.read() ^ and_ln416_205_fu_40913_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_206_fu_41121_p2() {
    xor_ln785_206_fu_41121_p2 = (tmp_1954_fu_41039_p3.read() ^ and_ln416_206_fu_41093_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_207_fu_41301_p2() {
    xor_ln785_207_fu_41301_p2 = (tmp_1961_fu_41219_p3.read() ^ and_ln416_207_fu_41273_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_208_fu_41481_p2() {
    xor_ln785_208_fu_41481_p2 = (tmp_1968_fu_41399_p3.read() ^ and_ln416_208_fu_41453_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_209_fu_41661_p2() {
    xor_ln785_209_fu_41661_p2 = (tmp_1975_fu_41579_p3.read() ^ and_ln416_209_fu_41633_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_20_fu_8533_p2() {
    xor_ln785_20_fu_8533_p2 = (tmp_652_fu_8451_p3.read() ^ and_ln416_20_fu_8505_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_210_fu_41841_p2() {
    xor_ln785_210_fu_41841_p2 = (tmp_1982_fu_41759_p3.read() ^ and_ln416_210_fu_41813_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_211_fu_42021_p2() {
    xor_ln785_211_fu_42021_p2 = (tmp_1989_fu_41939_p3.read() ^ and_ln416_211_fu_41993_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_212_fu_42201_p2() {
    xor_ln785_212_fu_42201_p2 = (tmp_1996_fu_42119_p3.read() ^ and_ln416_212_fu_42173_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_213_fu_42381_p2() {
    xor_ln785_213_fu_42381_p2 = (tmp_2003_fu_42299_p3.read() ^ and_ln416_213_fu_42353_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_214_fu_42561_p2() {
    xor_ln785_214_fu_42561_p2 = (tmp_2010_fu_42479_p3.read() ^ and_ln416_214_fu_42533_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_215_fu_42741_p2() {
    xor_ln785_215_fu_42741_p2 = (tmp_2017_fu_42659_p3.read() ^ and_ln416_215_fu_42713_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_216_fu_42921_p2() {
    xor_ln785_216_fu_42921_p2 = (tmp_2024_fu_42839_p3.read() ^ and_ln416_216_fu_42893_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_217_fu_43101_p2() {
    xor_ln785_217_fu_43101_p2 = (tmp_2031_fu_43019_p3.read() ^ and_ln416_217_fu_43073_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_218_fu_43281_p2() {
    xor_ln785_218_fu_43281_p2 = (tmp_2038_fu_43199_p3.read() ^ and_ln416_218_fu_43253_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_219_fu_43461_p2() {
    xor_ln785_219_fu_43461_p2 = (tmp_2045_fu_43379_p3.read() ^ and_ln416_219_fu_43433_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_21_fu_8725_p2() {
    xor_ln785_21_fu_8725_p2 = (tmp_659_fu_8643_p3.read() ^ and_ln416_21_fu_8697_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_220_fu_43641_p2() {
    xor_ln785_220_fu_43641_p2 = (tmp_2052_fu_43559_p3.read() ^ and_ln416_220_fu_43613_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_221_fu_43821_p2() {
    xor_ln785_221_fu_43821_p2 = (tmp_2059_fu_43739_p3.read() ^ and_ln416_221_fu_43793_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_222_fu_44001_p2() {
    xor_ln785_222_fu_44001_p2 = (tmp_2066_fu_43919_p3.read() ^ and_ln416_222_fu_43973_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_223_fu_115146_p2() {
    xor_ln785_223_fu_115146_p2 = (tmp_2073_fu_115064_p3.read() ^ and_ln416_223_fu_115118_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_224_fu_44191_p2() {
    xor_ln785_224_fu_44191_p2 = (tmp_2080_fu_44109_p3.read() ^ and_ln416_224_fu_44163_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_225_fu_44371_p2() {
    xor_ln785_225_fu_44371_p2 = (tmp_2087_fu_44289_p3.read() ^ and_ln416_225_fu_44343_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_226_fu_44551_p2() {
    xor_ln785_226_fu_44551_p2 = (tmp_2094_fu_44469_p3.read() ^ and_ln416_226_fu_44523_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_227_fu_44731_p2() {
    xor_ln785_227_fu_44731_p2 = (tmp_2101_fu_44649_p3.read() ^ and_ln416_227_fu_44703_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_228_fu_44911_p2() {
    xor_ln785_228_fu_44911_p2 = (tmp_2108_fu_44829_p3.read() ^ and_ln416_228_fu_44883_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_229_fu_45091_p2() {
    xor_ln785_229_fu_45091_p2 = (tmp_2115_fu_45009_p3.read() ^ and_ln416_229_fu_45063_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_22_fu_8917_p2() {
    xor_ln785_22_fu_8917_p2 = (tmp_666_fu_8835_p3.read() ^ and_ln416_22_fu_8889_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_230_fu_45271_p2() {
    xor_ln785_230_fu_45271_p2 = (tmp_2122_fu_45189_p3.read() ^ and_ln416_230_fu_45243_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_231_fu_45451_p2() {
    xor_ln785_231_fu_45451_p2 = (tmp_2129_fu_45369_p3.read() ^ and_ln416_231_fu_45423_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_232_fu_45631_p2() {
    xor_ln785_232_fu_45631_p2 = (tmp_2136_fu_45549_p3.read() ^ and_ln416_232_fu_45603_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_233_fu_45811_p2() {
    xor_ln785_233_fu_45811_p2 = (tmp_2143_fu_45729_p3.read() ^ and_ln416_233_fu_45783_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_234_fu_45991_p2() {
    xor_ln785_234_fu_45991_p2 = (tmp_2150_fu_45909_p3.read() ^ and_ln416_234_fu_45963_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_235_fu_46171_p2() {
    xor_ln785_235_fu_46171_p2 = (tmp_2157_fu_46089_p3.read() ^ and_ln416_235_fu_46143_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_236_fu_46351_p2() {
    xor_ln785_236_fu_46351_p2 = (tmp_2164_fu_46269_p3.read() ^ and_ln416_236_fu_46323_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_237_fu_46531_p2() {
    xor_ln785_237_fu_46531_p2 = (tmp_2171_fu_46449_p3.read() ^ and_ln416_237_fu_46503_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_238_fu_46711_p2() {
    xor_ln785_238_fu_46711_p2 = (tmp_2178_fu_46629_p3.read() ^ and_ln416_238_fu_46683_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_239_fu_46891_p2() {
    xor_ln785_239_fu_46891_p2 = (tmp_2185_fu_46809_p3.read() ^ and_ln416_239_fu_46863_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_23_fu_9109_p2() {
    xor_ln785_23_fu_9109_p2 = (tmp_673_fu_9027_p3.read() ^ and_ln416_23_fu_9081_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_240_fu_47071_p2() {
    xor_ln785_240_fu_47071_p2 = (tmp_2192_fu_46989_p3.read() ^ and_ln416_240_fu_47043_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_241_fu_47251_p2() {
    xor_ln785_241_fu_47251_p2 = (tmp_2199_fu_47169_p3.read() ^ and_ln416_241_fu_47223_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_242_fu_47431_p2() {
    xor_ln785_242_fu_47431_p2 = (tmp_2206_fu_47349_p3.read() ^ and_ln416_242_fu_47403_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_243_fu_47611_p2() {
    xor_ln785_243_fu_47611_p2 = (tmp_2213_fu_47529_p3.read() ^ and_ln416_243_fu_47583_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_244_fu_47791_p2() {
    xor_ln785_244_fu_47791_p2 = (tmp_2220_fu_47709_p3.read() ^ and_ln416_244_fu_47763_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_245_fu_47971_p2() {
    xor_ln785_245_fu_47971_p2 = (tmp_2227_fu_47889_p3.read() ^ and_ln416_245_fu_47943_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_246_fu_48151_p2() {
    xor_ln785_246_fu_48151_p2 = (tmp_2234_fu_48069_p3.read() ^ and_ln416_246_fu_48123_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_247_fu_48331_p2() {
    xor_ln785_247_fu_48331_p2 = (tmp_2241_fu_48249_p3.read() ^ and_ln416_247_fu_48303_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_248_fu_48511_p2() {
    xor_ln785_248_fu_48511_p2 = (tmp_2248_fu_48429_p3.read() ^ and_ln416_248_fu_48483_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_249_fu_48691_p2() {
    xor_ln785_249_fu_48691_p2 = (tmp_2255_fu_48609_p3.read() ^ and_ln416_249_fu_48663_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_24_fu_9301_p2() {
    xor_ln785_24_fu_9301_p2 = (tmp_680_fu_9219_p3.read() ^ and_ln416_24_fu_9273_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_250_fu_48871_p2() {
    xor_ln785_250_fu_48871_p2 = (tmp_2262_fu_48789_p3.read() ^ and_ln416_250_fu_48843_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_251_fu_49051_p2() {
    xor_ln785_251_fu_49051_p2 = (tmp_2269_fu_48969_p3.read() ^ and_ln416_251_fu_49023_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_252_fu_49231_p2() {
    xor_ln785_252_fu_49231_p2 = (tmp_2276_fu_49149_p3.read() ^ and_ln416_252_fu_49203_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_253_fu_49411_p2() {
    xor_ln785_253_fu_49411_p2 = (tmp_2283_fu_49329_p3.read() ^ and_ln416_253_fu_49383_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_254_fu_49591_p2() {
    xor_ln785_254_fu_49591_p2 = (tmp_2290_fu_49509_p3.read() ^ and_ln416_254_fu_49563_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_255_fu_118133_p2() {
    xor_ln785_255_fu_118133_p2 = (tmp_2297_fu_118051_p3.read() ^ and_ln416_255_fu_118105_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_256_fu_49781_p2() {
    xor_ln785_256_fu_49781_p2 = (tmp_2304_fu_49699_p3.read() ^ and_ln416_256_fu_49753_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_257_fu_49961_p2() {
    xor_ln785_257_fu_49961_p2 = (tmp_2311_fu_49879_p3.read() ^ and_ln416_257_fu_49933_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_258_fu_50141_p2() {
    xor_ln785_258_fu_50141_p2 = (tmp_2318_fu_50059_p3.read() ^ and_ln416_258_fu_50113_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_259_fu_50321_p2() {
    xor_ln785_259_fu_50321_p2 = (tmp_2325_fu_50239_p3.read() ^ and_ln416_259_fu_50293_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_25_fu_9493_p2() {
    xor_ln785_25_fu_9493_p2 = (tmp_687_fu_9411_p3.read() ^ and_ln416_25_fu_9465_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_260_fu_50501_p2() {
    xor_ln785_260_fu_50501_p2 = (tmp_2332_fu_50419_p3.read() ^ and_ln416_260_fu_50473_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_261_fu_50681_p2() {
    xor_ln785_261_fu_50681_p2 = (tmp_2339_fu_50599_p3.read() ^ and_ln416_261_fu_50653_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_262_fu_50861_p2() {
    xor_ln785_262_fu_50861_p2 = (tmp_2346_fu_50779_p3.read() ^ and_ln416_262_fu_50833_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_263_fu_51041_p2() {
    xor_ln785_263_fu_51041_p2 = (tmp_2353_fu_50959_p3.read() ^ and_ln416_263_fu_51013_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_264_fu_51221_p2() {
    xor_ln785_264_fu_51221_p2 = (tmp_2360_fu_51139_p3.read() ^ and_ln416_264_fu_51193_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_265_fu_51401_p2() {
    xor_ln785_265_fu_51401_p2 = (tmp_2367_fu_51319_p3.read() ^ and_ln416_265_fu_51373_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_266_fu_51581_p2() {
    xor_ln785_266_fu_51581_p2 = (tmp_2374_fu_51499_p3.read() ^ and_ln416_266_fu_51553_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_267_fu_51761_p2() {
    xor_ln785_267_fu_51761_p2 = (tmp_2381_fu_51679_p3.read() ^ and_ln416_267_fu_51733_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_268_fu_51941_p2() {
    xor_ln785_268_fu_51941_p2 = (tmp_2388_fu_51859_p3.read() ^ and_ln416_268_fu_51913_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_269_fu_52121_p2() {
    xor_ln785_269_fu_52121_p2 = (tmp_2395_fu_52039_p3.read() ^ and_ln416_269_fu_52093_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_26_fu_9685_p2() {
    xor_ln785_26_fu_9685_p2 = (tmp_694_fu_9603_p3.read() ^ and_ln416_26_fu_9657_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_270_fu_52301_p2() {
    xor_ln785_270_fu_52301_p2 = (tmp_2402_fu_52219_p3.read() ^ and_ln416_270_fu_52273_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_271_fu_52481_p2() {
    xor_ln785_271_fu_52481_p2 = (tmp_2409_fu_52399_p3.read() ^ and_ln416_271_fu_52453_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_272_fu_52661_p2() {
    xor_ln785_272_fu_52661_p2 = (tmp_2416_fu_52579_p3.read() ^ and_ln416_272_fu_52633_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_273_fu_52841_p2() {
    xor_ln785_273_fu_52841_p2 = (tmp_2423_fu_52759_p3.read() ^ and_ln416_273_fu_52813_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_274_fu_53021_p2() {
    xor_ln785_274_fu_53021_p2 = (tmp_2430_fu_52939_p3.read() ^ and_ln416_274_fu_52993_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_275_fu_53201_p2() {
    xor_ln785_275_fu_53201_p2 = (tmp_2437_fu_53119_p3.read() ^ and_ln416_275_fu_53173_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_276_fu_53381_p2() {
    xor_ln785_276_fu_53381_p2 = (tmp_2444_fu_53299_p3.read() ^ and_ln416_276_fu_53353_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_277_fu_53561_p2() {
    xor_ln785_277_fu_53561_p2 = (tmp_2451_fu_53479_p3.read() ^ and_ln416_277_fu_53533_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_278_fu_53741_p2() {
    xor_ln785_278_fu_53741_p2 = (tmp_2458_fu_53659_p3.read() ^ and_ln416_278_fu_53713_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_279_fu_53921_p2() {
    xor_ln785_279_fu_53921_p2 = (tmp_2465_fu_53839_p3.read() ^ and_ln416_279_fu_53893_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_27_fu_9877_p2() {
    xor_ln785_27_fu_9877_p2 = (tmp_701_fu_9795_p3.read() ^ and_ln416_27_fu_9849_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_280_fu_54101_p2() {
    xor_ln785_280_fu_54101_p2 = (tmp_2472_fu_54019_p3.read() ^ and_ln416_280_fu_54073_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_281_fu_54281_p2() {
    xor_ln785_281_fu_54281_p2 = (tmp_2479_fu_54199_p3.read() ^ and_ln416_281_fu_54253_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_282_fu_54461_p2() {
    xor_ln785_282_fu_54461_p2 = (tmp_2486_fu_54379_p3.read() ^ and_ln416_282_fu_54433_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_283_fu_54641_p2() {
    xor_ln785_283_fu_54641_p2 = (tmp_2493_fu_54559_p3.read() ^ and_ln416_283_fu_54613_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_284_fu_54821_p2() {
    xor_ln785_284_fu_54821_p2 = (tmp_2500_fu_54739_p3.read() ^ and_ln416_284_fu_54793_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_285_fu_55001_p2() {
    xor_ln785_285_fu_55001_p2 = (tmp_2507_fu_54919_p3.read() ^ and_ln416_285_fu_54973_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_286_fu_55181_p2() {
    xor_ln785_286_fu_55181_p2 = (tmp_2514_fu_55099_p3.read() ^ and_ln416_286_fu_55153_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_287_fu_121120_p2() {
    xor_ln785_287_fu_121120_p2 = (tmp_2521_fu_121038_p3.read() ^ and_ln416_287_fu_121092_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_288_fu_55371_p2() {
    xor_ln785_288_fu_55371_p2 = (tmp_2528_fu_55289_p3.read() ^ and_ln416_288_fu_55343_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_289_fu_55551_p2() {
    xor_ln785_289_fu_55551_p2 = (tmp_2535_fu_55469_p3.read() ^ and_ln416_289_fu_55523_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_28_fu_10069_p2() {
    xor_ln785_28_fu_10069_p2 = (tmp_708_fu_9987_p3.read() ^ and_ln416_28_fu_10041_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_290_fu_55731_p2() {
    xor_ln785_290_fu_55731_p2 = (tmp_2542_fu_55649_p3.read() ^ and_ln416_290_fu_55703_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_291_fu_55911_p2() {
    xor_ln785_291_fu_55911_p2 = (tmp_2549_fu_55829_p3.read() ^ and_ln416_291_fu_55883_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_292_fu_56091_p2() {
    xor_ln785_292_fu_56091_p2 = (tmp_2556_fu_56009_p3.read() ^ and_ln416_292_fu_56063_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_293_fu_56271_p2() {
    xor_ln785_293_fu_56271_p2 = (tmp_2563_fu_56189_p3.read() ^ and_ln416_293_fu_56243_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_294_fu_56451_p2() {
    xor_ln785_294_fu_56451_p2 = (tmp_2570_fu_56369_p3.read() ^ and_ln416_294_fu_56423_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_295_fu_56631_p2() {
    xor_ln785_295_fu_56631_p2 = (tmp_2577_fu_56549_p3.read() ^ and_ln416_295_fu_56603_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_296_fu_56811_p2() {
    xor_ln785_296_fu_56811_p2 = (tmp_2584_fu_56729_p3.read() ^ and_ln416_296_fu_56783_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_297_fu_56991_p2() {
    xor_ln785_297_fu_56991_p2 = (tmp_2591_fu_56909_p3.read() ^ and_ln416_297_fu_56963_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_298_fu_57171_p2() {
    xor_ln785_298_fu_57171_p2 = (tmp_2598_fu_57089_p3.read() ^ and_ln416_298_fu_57143_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_299_fu_57351_p2() {
    xor_ln785_299_fu_57351_p2 = (tmp_2605_fu_57269_p3.read() ^ and_ln416_299_fu_57323_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_29_fu_10261_p2() {
    xor_ln785_29_fu_10261_p2 = (tmp_715_fu_10179_p3.read() ^ and_ln416_29_fu_10233_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_2_fu_5077_p2() {
    xor_ln785_2_fu_5077_p2 = (tmp_526_fu_4995_p3.read() ^ and_ln416_2_fu_5049_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_300_fu_57531_p2() {
    xor_ln785_300_fu_57531_p2 = (tmp_2612_fu_57449_p3.read() ^ and_ln416_300_fu_57503_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_301_fu_57711_p2() {
    xor_ln785_301_fu_57711_p2 = (tmp_2619_fu_57629_p3.read() ^ and_ln416_301_fu_57683_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_302_fu_57891_p2() {
    xor_ln785_302_fu_57891_p2 = (tmp_2626_fu_57809_p3.read() ^ and_ln416_302_fu_57863_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_303_fu_58071_p2() {
    xor_ln785_303_fu_58071_p2 = (tmp_2633_fu_57989_p3.read() ^ and_ln416_303_fu_58043_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_304_fu_58251_p2() {
    xor_ln785_304_fu_58251_p2 = (tmp_2640_fu_58169_p3.read() ^ and_ln416_304_fu_58223_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_305_fu_58431_p2() {
    xor_ln785_305_fu_58431_p2 = (tmp_2647_fu_58349_p3.read() ^ and_ln416_305_fu_58403_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_306_fu_58611_p2() {
    xor_ln785_306_fu_58611_p2 = (tmp_2654_fu_58529_p3.read() ^ and_ln416_306_fu_58583_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_307_fu_58791_p2() {
    xor_ln785_307_fu_58791_p2 = (tmp_2661_fu_58709_p3.read() ^ and_ln416_307_fu_58763_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_308_fu_58971_p2() {
    xor_ln785_308_fu_58971_p2 = (tmp_2668_fu_58889_p3.read() ^ and_ln416_308_fu_58943_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_309_fu_59151_p2() {
    xor_ln785_309_fu_59151_p2 = (tmp_2675_fu_59069_p3.read() ^ and_ln416_309_fu_59123_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_30_fu_10453_p2() {
    xor_ln785_30_fu_10453_p2 = (tmp_722_fu_10371_p3.read() ^ and_ln416_30_fu_10425_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_310_fu_59331_p2() {
    xor_ln785_310_fu_59331_p2 = (tmp_2682_fu_59249_p3.read() ^ and_ln416_310_fu_59303_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_311_fu_59511_p2() {
    xor_ln785_311_fu_59511_p2 = (tmp_2689_fu_59429_p3.read() ^ and_ln416_311_fu_59483_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_312_fu_59691_p2() {
    xor_ln785_312_fu_59691_p2 = (tmp_2696_fu_59609_p3.read() ^ and_ln416_312_fu_59663_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_313_fu_59871_p2() {
    xor_ln785_313_fu_59871_p2 = (tmp_2703_fu_59789_p3.read() ^ and_ln416_313_fu_59843_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_314_fu_60051_p2() {
    xor_ln785_314_fu_60051_p2 = (tmp_2710_fu_59969_p3.read() ^ and_ln416_314_fu_60023_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_315_fu_60231_p2() {
    xor_ln785_315_fu_60231_p2 = (tmp_2717_fu_60149_p3.read() ^ and_ln416_315_fu_60203_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_316_fu_60411_p2() {
    xor_ln785_316_fu_60411_p2 = (tmp_2724_fu_60329_p3.read() ^ and_ln416_316_fu_60383_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_317_fu_60591_p2() {
    xor_ln785_317_fu_60591_p2 = (tmp_2731_fu_60509_p3.read() ^ and_ln416_317_fu_60563_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_318_fu_60771_p2() {
    xor_ln785_318_fu_60771_p2 = (tmp_2738_fu_60689_p3.read() ^ and_ln416_318_fu_60743_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_319_fu_124107_p2() {
    xor_ln785_319_fu_124107_p2 = (tmp_2745_fu_124025_p3.read() ^ and_ln416_319_fu_124079_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_31_fu_97224_p2() {
    xor_ln785_31_fu_97224_p2 = (tmp_729_fu_97142_p3.read() ^ and_ln416_31_fu_97196_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_320_fu_60961_p2() {
    xor_ln785_320_fu_60961_p2 = (tmp_2752_fu_60879_p3.read() ^ and_ln416_320_fu_60933_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_321_fu_61141_p2() {
    xor_ln785_321_fu_61141_p2 = (tmp_2759_fu_61059_p3.read() ^ and_ln416_321_fu_61113_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_322_fu_61321_p2() {
    xor_ln785_322_fu_61321_p2 = (tmp_2766_fu_61239_p3.read() ^ and_ln416_322_fu_61293_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_323_fu_61501_p2() {
    xor_ln785_323_fu_61501_p2 = (tmp_2773_fu_61419_p3.read() ^ and_ln416_323_fu_61473_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_324_fu_61681_p2() {
    xor_ln785_324_fu_61681_p2 = (tmp_2780_fu_61599_p3.read() ^ and_ln416_324_fu_61653_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_325_fu_61861_p2() {
    xor_ln785_325_fu_61861_p2 = (tmp_2787_fu_61779_p3.read() ^ and_ln416_325_fu_61833_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_326_fu_62041_p2() {
    xor_ln785_326_fu_62041_p2 = (tmp_2794_fu_61959_p3.read() ^ and_ln416_326_fu_62013_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_327_fu_62221_p2() {
    xor_ln785_327_fu_62221_p2 = (tmp_2801_fu_62139_p3.read() ^ and_ln416_327_fu_62193_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_328_fu_62401_p2() {
    xor_ln785_328_fu_62401_p2 = (tmp_2808_fu_62319_p3.read() ^ and_ln416_328_fu_62373_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_329_fu_62581_p2() {
    xor_ln785_329_fu_62581_p2 = (tmp_2815_fu_62499_p3.read() ^ and_ln416_329_fu_62553_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_32_fu_10651_p2() {
    xor_ln785_32_fu_10651_p2 = (tmp_736_fu_10569_p3.read() ^ and_ln416_32_fu_10623_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_330_fu_62761_p2() {
    xor_ln785_330_fu_62761_p2 = (tmp_2822_fu_62679_p3.read() ^ and_ln416_330_fu_62733_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_331_fu_62941_p2() {
    xor_ln785_331_fu_62941_p2 = (tmp_2829_fu_62859_p3.read() ^ and_ln416_331_fu_62913_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_332_fu_63121_p2() {
    xor_ln785_332_fu_63121_p2 = (tmp_2836_fu_63039_p3.read() ^ and_ln416_332_fu_63093_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_333_fu_63301_p2() {
    xor_ln785_333_fu_63301_p2 = (tmp_2843_fu_63219_p3.read() ^ and_ln416_333_fu_63273_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_334_fu_63481_p2() {
    xor_ln785_334_fu_63481_p2 = (tmp_2850_fu_63399_p3.read() ^ and_ln416_334_fu_63453_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_335_fu_63661_p2() {
    xor_ln785_335_fu_63661_p2 = (tmp_2857_fu_63579_p3.read() ^ and_ln416_335_fu_63633_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_336_fu_63841_p2() {
    xor_ln785_336_fu_63841_p2 = (tmp_2864_fu_63759_p3.read() ^ and_ln416_336_fu_63813_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_337_fu_64021_p2() {
    xor_ln785_337_fu_64021_p2 = (tmp_2871_fu_63939_p3.read() ^ and_ln416_337_fu_63993_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_338_fu_64201_p2() {
    xor_ln785_338_fu_64201_p2 = (tmp_2878_fu_64119_p3.read() ^ and_ln416_338_fu_64173_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_339_fu_64381_p2() {
    xor_ln785_339_fu_64381_p2 = (tmp_2885_fu_64299_p3.read() ^ and_ln416_339_fu_64353_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_33_fu_10831_p2() {
    xor_ln785_33_fu_10831_p2 = (tmp_743_fu_10749_p3.read() ^ and_ln416_33_fu_10803_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_340_fu_64561_p2() {
    xor_ln785_340_fu_64561_p2 = (tmp_2892_fu_64479_p3.read() ^ and_ln416_340_fu_64533_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_341_fu_64741_p2() {
    xor_ln785_341_fu_64741_p2 = (tmp_2899_fu_64659_p3.read() ^ and_ln416_341_fu_64713_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_342_fu_64921_p2() {
    xor_ln785_342_fu_64921_p2 = (tmp_2906_fu_64839_p3.read() ^ and_ln416_342_fu_64893_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_343_fu_65101_p2() {
    xor_ln785_343_fu_65101_p2 = (tmp_2913_fu_65019_p3.read() ^ and_ln416_343_fu_65073_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_344_fu_65281_p2() {
    xor_ln785_344_fu_65281_p2 = (tmp_2920_fu_65199_p3.read() ^ and_ln416_344_fu_65253_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_345_fu_65461_p2() {
    xor_ln785_345_fu_65461_p2 = (tmp_2927_fu_65379_p3.read() ^ and_ln416_345_fu_65433_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_346_fu_65641_p2() {
    xor_ln785_346_fu_65641_p2 = (tmp_2934_fu_65559_p3.read() ^ and_ln416_346_fu_65613_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_347_fu_65821_p2() {
    xor_ln785_347_fu_65821_p2 = (tmp_2941_fu_65739_p3.read() ^ and_ln416_347_fu_65793_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_348_fu_66001_p2() {
    xor_ln785_348_fu_66001_p2 = (tmp_2948_fu_65919_p3.read() ^ and_ln416_348_fu_65973_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_349_fu_66181_p2() {
    xor_ln785_349_fu_66181_p2 = (tmp_2955_fu_66099_p3.read() ^ and_ln416_349_fu_66153_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_34_fu_11011_p2() {
    xor_ln785_34_fu_11011_p2 = (tmp_750_fu_10929_p3.read() ^ and_ln416_34_fu_10983_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_350_fu_66361_p2() {
    xor_ln785_350_fu_66361_p2 = (tmp_2962_fu_66279_p3.read() ^ and_ln416_350_fu_66333_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_351_fu_127094_p2() {
    xor_ln785_351_fu_127094_p2 = (tmp_2969_fu_127012_p3.read() ^ and_ln416_351_fu_127066_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_352_fu_66551_p2() {
    xor_ln785_352_fu_66551_p2 = (tmp_2976_fu_66469_p3.read() ^ and_ln416_352_fu_66523_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_353_fu_66731_p2() {
    xor_ln785_353_fu_66731_p2 = (tmp_2983_fu_66649_p3.read() ^ and_ln416_353_fu_66703_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_354_fu_66911_p2() {
    xor_ln785_354_fu_66911_p2 = (tmp_2990_fu_66829_p3.read() ^ and_ln416_354_fu_66883_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_355_fu_67091_p2() {
    xor_ln785_355_fu_67091_p2 = (tmp_2997_fu_67009_p3.read() ^ and_ln416_355_fu_67063_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_356_fu_67271_p2() {
    xor_ln785_356_fu_67271_p2 = (tmp_3004_fu_67189_p3.read() ^ and_ln416_356_fu_67243_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_357_fu_67451_p2() {
    xor_ln785_357_fu_67451_p2 = (tmp_3011_fu_67369_p3.read() ^ and_ln416_357_fu_67423_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_358_fu_67631_p2() {
    xor_ln785_358_fu_67631_p2 = (tmp_3018_fu_67549_p3.read() ^ and_ln416_358_fu_67603_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_359_fu_67811_p2() {
    xor_ln785_359_fu_67811_p2 = (tmp_3025_fu_67729_p3.read() ^ and_ln416_359_fu_67783_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_35_fu_11191_p2() {
    xor_ln785_35_fu_11191_p2 = (tmp_757_fu_11109_p3.read() ^ and_ln416_35_fu_11163_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_360_fu_67991_p2() {
    xor_ln785_360_fu_67991_p2 = (tmp_3032_fu_67909_p3.read() ^ and_ln416_360_fu_67963_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_361_fu_68171_p2() {
    xor_ln785_361_fu_68171_p2 = (tmp_3039_fu_68089_p3.read() ^ and_ln416_361_fu_68143_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_362_fu_68351_p2() {
    xor_ln785_362_fu_68351_p2 = (tmp_3046_fu_68269_p3.read() ^ and_ln416_362_fu_68323_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_363_fu_68531_p2() {
    xor_ln785_363_fu_68531_p2 = (tmp_3053_fu_68449_p3.read() ^ and_ln416_363_fu_68503_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_364_fu_68711_p2() {
    xor_ln785_364_fu_68711_p2 = (tmp_3060_fu_68629_p3.read() ^ and_ln416_364_fu_68683_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_365_fu_68891_p2() {
    xor_ln785_365_fu_68891_p2 = (tmp_3067_fu_68809_p3.read() ^ and_ln416_365_fu_68863_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_366_fu_69071_p2() {
    xor_ln785_366_fu_69071_p2 = (tmp_3074_fu_68989_p3.read() ^ and_ln416_366_fu_69043_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_367_fu_69251_p2() {
    xor_ln785_367_fu_69251_p2 = (tmp_3081_fu_69169_p3.read() ^ and_ln416_367_fu_69223_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_368_fu_69431_p2() {
    xor_ln785_368_fu_69431_p2 = (tmp_3088_fu_69349_p3.read() ^ and_ln416_368_fu_69403_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_369_fu_69611_p2() {
    xor_ln785_369_fu_69611_p2 = (tmp_3095_fu_69529_p3.read() ^ and_ln416_369_fu_69583_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_36_fu_11371_p2() {
    xor_ln785_36_fu_11371_p2 = (tmp_764_fu_11289_p3.read() ^ and_ln416_36_fu_11343_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_370_fu_69791_p2() {
    xor_ln785_370_fu_69791_p2 = (tmp_3102_fu_69709_p3.read() ^ and_ln416_370_fu_69763_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_371_fu_69971_p2() {
    xor_ln785_371_fu_69971_p2 = (tmp_3109_fu_69889_p3.read() ^ and_ln416_371_fu_69943_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_372_fu_70151_p2() {
    xor_ln785_372_fu_70151_p2 = (tmp_3116_fu_70069_p3.read() ^ and_ln416_372_fu_70123_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_373_fu_70331_p2() {
    xor_ln785_373_fu_70331_p2 = (tmp_3123_fu_70249_p3.read() ^ and_ln416_373_fu_70303_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_374_fu_70511_p2() {
    xor_ln785_374_fu_70511_p2 = (tmp_3130_fu_70429_p3.read() ^ and_ln416_374_fu_70483_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_375_fu_70691_p2() {
    xor_ln785_375_fu_70691_p2 = (tmp_3137_fu_70609_p3.read() ^ and_ln416_375_fu_70663_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_376_fu_70871_p2() {
    xor_ln785_376_fu_70871_p2 = (tmp_3144_fu_70789_p3.read() ^ and_ln416_376_fu_70843_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_377_fu_71051_p2() {
    xor_ln785_377_fu_71051_p2 = (tmp_3151_fu_70969_p3.read() ^ and_ln416_377_fu_71023_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_378_fu_71231_p2() {
    xor_ln785_378_fu_71231_p2 = (tmp_3158_fu_71149_p3.read() ^ and_ln416_378_fu_71203_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_379_fu_71411_p2() {
    xor_ln785_379_fu_71411_p2 = (tmp_3165_fu_71329_p3.read() ^ and_ln416_379_fu_71383_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_37_fu_11551_p2() {
    xor_ln785_37_fu_11551_p2 = (tmp_771_fu_11469_p3.read() ^ and_ln416_37_fu_11523_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_380_fu_71591_p2() {
    xor_ln785_380_fu_71591_p2 = (tmp_3172_fu_71509_p3.read() ^ and_ln416_380_fu_71563_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_381_fu_71771_p2() {
    xor_ln785_381_fu_71771_p2 = (tmp_3179_fu_71689_p3.read() ^ and_ln416_381_fu_71743_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_382_fu_71951_p2() {
    xor_ln785_382_fu_71951_p2 = (tmp_3186_fu_71869_p3.read() ^ and_ln416_382_fu_71923_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_383_fu_130081_p2() {
    xor_ln785_383_fu_130081_p2 = (tmp_3193_fu_129999_p3.read() ^ and_ln416_383_fu_130053_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_384_fu_72141_p2() {
    xor_ln785_384_fu_72141_p2 = (tmp_3200_fu_72059_p3.read() ^ and_ln416_384_fu_72113_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_385_fu_72321_p2() {
    xor_ln785_385_fu_72321_p2 = (tmp_3207_fu_72239_p3.read() ^ and_ln416_385_fu_72293_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_386_fu_72501_p2() {
    xor_ln785_386_fu_72501_p2 = (tmp_3214_fu_72419_p3.read() ^ and_ln416_386_fu_72473_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_387_fu_72681_p2() {
    xor_ln785_387_fu_72681_p2 = (tmp_3221_fu_72599_p3.read() ^ and_ln416_387_fu_72653_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_388_fu_72861_p2() {
    xor_ln785_388_fu_72861_p2 = (tmp_3228_fu_72779_p3.read() ^ and_ln416_388_fu_72833_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_389_fu_73041_p2() {
    xor_ln785_389_fu_73041_p2 = (tmp_3235_fu_72959_p3.read() ^ and_ln416_389_fu_73013_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_38_fu_11731_p2() {
    xor_ln785_38_fu_11731_p2 = (tmp_778_fu_11649_p3.read() ^ and_ln416_38_fu_11703_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_390_fu_73221_p2() {
    xor_ln785_390_fu_73221_p2 = (tmp_3242_fu_73139_p3.read() ^ and_ln416_390_fu_73193_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_391_fu_73401_p2() {
    xor_ln785_391_fu_73401_p2 = (tmp_3249_fu_73319_p3.read() ^ and_ln416_391_fu_73373_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_392_fu_73581_p2() {
    xor_ln785_392_fu_73581_p2 = (tmp_3256_fu_73499_p3.read() ^ and_ln416_392_fu_73553_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_393_fu_73761_p2() {
    xor_ln785_393_fu_73761_p2 = (tmp_3263_fu_73679_p3.read() ^ and_ln416_393_fu_73733_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_394_fu_73941_p2() {
    xor_ln785_394_fu_73941_p2 = (tmp_3270_fu_73859_p3.read() ^ and_ln416_394_fu_73913_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_395_fu_74121_p2() {
    xor_ln785_395_fu_74121_p2 = (tmp_3277_fu_74039_p3.read() ^ and_ln416_395_fu_74093_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_396_fu_74301_p2() {
    xor_ln785_396_fu_74301_p2 = (tmp_3284_fu_74219_p3.read() ^ and_ln416_396_fu_74273_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_397_fu_74481_p2() {
    xor_ln785_397_fu_74481_p2 = (tmp_3291_fu_74399_p3.read() ^ and_ln416_397_fu_74453_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_398_fu_74661_p2() {
    xor_ln785_398_fu_74661_p2 = (tmp_3298_fu_74579_p3.read() ^ and_ln416_398_fu_74633_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_399_fu_74841_p2() {
    xor_ln785_399_fu_74841_p2 = (tmp_3305_fu_74759_p3.read() ^ and_ln416_399_fu_74813_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_39_fu_11911_p2() {
    xor_ln785_39_fu_11911_p2 = (tmp_785_fu_11829_p3.read() ^ and_ln416_39_fu_11883_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_3_fu_5269_p2() {
    xor_ln785_3_fu_5269_p2 = (tmp_533_fu_5187_p3.read() ^ and_ln416_3_fu_5241_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_400_fu_75021_p2() {
    xor_ln785_400_fu_75021_p2 = (tmp_3312_fu_74939_p3.read() ^ and_ln416_400_fu_74993_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_401_fu_75201_p2() {
    xor_ln785_401_fu_75201_p2 = (tmp_3319_fu_75119_p3.read() ^ and_ln416_401_fu_75173_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_402_fu_75381_p2() {
    xor_ln785_402_fu_75381_p2 = (tmp_3326_fu_75299_p3.read() ^ and_ln416_402_fu_75353_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_403_fu_75561_p2() {
    xor_ln785_403_fu_75561_p2 = (tmp_3333_fu_75479_p3.read() ^ and_ln416_403_fu_75533_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_404_fu_75741_p2() {
    xor_ln785_404_fu_75741_p2 = (tmp_3340_fu_75659_p3.read() ^ and_ln416_404_fu_75713_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_405_fu_75921_p2() {
    xor_ln785_405_fu_75921_p2 = (tmp_3347_fu_75839_p3.read() ^ and_ln416_405_fu_75893_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_406_fu_76101_p2() {
    xor_ln785_406_fu_76101_p2 = (tmp_3354_fu_76019_p3.read() ^ and_ln416_406_fu_76073_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_407_fu_76281_p2() {
    xor_ln785_407_fu_76281_p2 = (tmp_3361_fu_76199_p3.read() ^ and_ln416_407_fu_76253_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_408_fu_76461_p2() {
    xor_ln785_408_fu_76461_p2 = (tmp_3368_fu_76379_p3.read() ^ and_ln416_408_fu_76433_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_409_fu_76641_p2() {
    xor_ln785_409_fu_76641_p2 = (tmp_3375_fu_76559_p3.read() ^ and_ln416_409_fu_76613_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_40_fu_12091_p2() {
    xor_ln785_40_fu_12091_p2 = (tmp_792_fu_12009_p3.read() ^ and_ln416_40_fu_12063_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_410_fu_76821_p2() {
    xor_ln785_410_fu_76821_p2 = (tmp_3382_fu_76739_p3.read() ^ and_ln416_410_fu_76793_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_411_fu_77001_p2() {
    xor_ln785_411_fu_77001_p2 = (tmp_3389_fu_76919_p3.read() ^ and_ln416_411_fu_76973_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_412_fu_77181_p2() {
    xor_ln785_412_fu_77181_p2 = (tmp_3396_fu_77099_p3.read() ^ and_ln416_412_fu_77153_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_413_fu_77361_p2() {
    xor_ln785_413_fu_77361_p2 = (tmp_3403_fu_77279_p3.read() ^ and_ln416_413_fu_77333_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_414_fu_77541_p2() {
    xor_ln785_414_fu_77541_p2 = (tmp_3410_fu_77459_p3.read() ^ and_ln416_414_fu_77513_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_415_fu_133068_p2() {
    xor_ln785_415_fu_133068_p2 = (tmp_3417_fu_132986_p3.read() ^ and_ln416_415_fu_133040_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_416_fu_77731_p2() {
    xor_ln785_416_fu_77731_p2 = (tmp_3424_fu_77649_p3.read() ^ and_ln416_416_fu_77703_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_417_fu_77911_p2() {
    xor_ln785_417_fu_77911_p2 = (tmp_3431_fu_77829_p3.read() ^ and_ln416_417_fu_77883_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_418_fu_78091_p2() {
    xor_ln785_418_fu_78091_p2 = (tmp_3438_fu_78009_p3.read() ^ and_ln416_418_fu_78063_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_419_fu_78271_p2() {
    xor_ln785_419_fu_78271_p2 = (tmp_3445_fu_78189_p3.read() ^ and_ln416_419_fu_78243_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_41_fu_12271_p2() {
    xor_ln785_41_fu_12271_p2 = (tmp_799_fu_12189_p3.read() ^ and_ln416_41_fu_12243_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_420_fu_78451_p2() {
    xor_ln785_420_fu_78451_p2 = (tmp_3452_fu_78369_p3.read() ^ and_ln416_420_fu_78423_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_421_fu_78631_p2() {
    xor_ln785_421_fu_78631_p2 = (tmp_3459_fu_78549_p3.read() ^ and_ln416_421_fu_78603_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_422_fu_78811_p2() {
    xor_ln785_422_fu_78811_p2 = (tmp_3466_fu_78729_p3.read() ^ and_ln416_422_fu_78783_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_423_fu_78991_p2() {
    xor_ln785_423_fu_78991_p2 = (tmp_3473_fu_78909_p3.read() ^ and_ln416_423_fu_78963_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_424_fu_79171_p2() {
    xor_ln785_424_fu_79171_p2 = (tmp_3480_fu_79089_p3.read() ^ and_ln416_424_fu_79143_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_425_fu_79351_p2() {
    xor_ln785_425_fu_79351_p2 = (tmp_3487_fu_79269_p3.read() ^ and_ln416_425_fu_79323_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_426_fu_79531_p2() {
    xor_ln785_426_fu_79531_p2 = (tmp_3494_fu_79449_p3.read() ^ and_ln416_426_fu_79503_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_427_fu_79711_p2() {
    xor_ln785_427_fu_79711_p2 = (tmp_3501_fu_79629_p3.read() ^ and_ln416_427_fu_79683_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_428_fu_79891_p2() {
    xor_ln785_428_fu_79891_p2 = (tmp_3508_fu_79809_p3.read() ^ and_ln416_428_fu_79863_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_429_fu_80071_p2() {
    xor_ln785_429_fu_80071_p2 = (tmp_3515_fu_79989_p3.read() ^ and_ln416_429_fu_80043_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_42_fu_12451_p2() {
    xor_ln785_42_fu_12451_p2 = (tmp_806_fu_12369_p3.read() ^ and_ln416_42_fu_12423_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_430_fu_80251_p2() {
    xor_ln785_430_fu_80251_p2 = (tmp_3522_fu_80169_p3.read() ^ and_ln416_430_fu_80223_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_431_fu_80431_p2() {
    xor_ln785_431_fu_80431_p2 = (tmp_3529_fu_80349_p3.read() ^ and_ln416_431_fu_80403_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_432_fu_80611_p2() {
    xor_ln785_432_fu_80611_p2 = (tmp_3536_fu_80529_p3.read() ^ and_ln416_432_fu_80583_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_433_fu_80791_p2() {
    xor_ln785_433_fu_80791_p2 = (tmp_3543_fu_80709_p3.read() ^ and_ln416_433_fu_80763_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_434_fu_80971_p2() {
    xor_ln785_434_fu_80971_p2 = (tmp_3550_fu_80889_p3.read() ^ and_ln416_434_fu_80943_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_435_fu_81151_p2() {
    xor_ln785_435_fu_81151_p2 = (tmp_3557_fu_81069_p3.read() ^ and_ln416_435_fu_81123_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_436_fu_81331_p2() {
    xor_ln785_436_fu_81331_p2 = (tmp_3564_fu_81249_p3.read() ^ and_ln416_436_fu_81303_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_437_fu_81511_p2() {
    xor_ln785_437_fu_81511_p2 = (tmp_3571_fu_81429_p3.read() ^ and_ln416_437_fu_81483_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_438_fu_81691_p2() {
    xor_ln785_438_fu_81691_p2 = (tmp_3578_fu_81609_p3.read() ^ and_ln416_438_fu_81663_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_439_fu_81871_p2() {
    xor_ln785_439_fu_81871_p2 = (tmp_3585_fu_81789_p3.read() ^ and_ln416_439_fu_81843_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_43_fu_12631_p2() {
    xor_ln785_43_fu_12631_p2 = (tmp_813_fu_12549_p3.read() ^ and_ln416_43_fu_12603_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_440_fu_82051_p2() {
    xor_ln785_440_fu_82051_p2 = (tmp_3592_fu_81969_p3.read() ^ and_ln416_440_fu_82023_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_441_fu_82231_p2() {
    xor_ln785_441_fu_82231_p2 = (tmp_3599_fu_82149_p3.read() ^ and_ln416_441_fu_82203_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_442_fu_82411_p2() {
    xor_ln785_442_fu_82411_p2 = (tmp_3606_fu_82329_p3.read() ^ and_ln416_442_fu_82383_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_443_fu_82591_p2() {
    xor_ln785_443_fu_82591_p2 = (tmp_3613_fu_82509_p3.read() ^ and_ln416_443_fu_82563_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_444_fu_82771_p2() {
    xor_ln785_444_fu_82771_p2 = (tmp_3620_fu_82689_p3.read() ^ and_ln416_444_fu_82743_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_445_fu_82951_p2() {
    xor_ln785_445_fu_82951_p2 = (tmp_3627_fu_82869_p3.read() ^ and_ln416_445_fu_82923_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_446_fu_83131_p2() {
    xor_ln785_446_fu_83131_p2 = (tmp_3634_fu_83049_p3.read() ^ and_ln416_446_fu_83103_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_447_fu_136055_p2() {
    xor_ln785_447_fu_136055_p2 = (tmp_3641_fu_135973_p3.read() ^ and_ln416_447_fu_136027_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_448_fu_83321_p2() {
    xor_ln785_448_fu_83321_p2 = (tmp_3648_fu_83239_p3.read() ^ and_ln416_448_fu_83293_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_449_fu_83501_p2() {
    xor_ln785_449_fu_83501_p2 = (tmp_3655_fu_83419_p3.read() ^ and_ln416_449_fu_83473_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_44_fu_12811_p2() {
    xor_ln785_44_fu_12811_p2 = (tmp_820_fu_12729_p3.read() ^ and_ln416_44_fu_12783_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_450_fu_83681_p2() {
    xor_ln785_450_fu_83681_p2 = (tmp_3662_fu_83599_p3.read() ^ and_ln416_450_fu_83653_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_451_fu_83861_p2() {
    xor_ln785_451_fu_83861_p2 = (tmp_3669_fu_83779_p3.read() ^ and_ln416_451_fu_83833_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_452_fu_84041_p2() {
    xor_ln785_452_fu_84041_p2 = (tmp_3676_fu_83959_p3.read() ^ and_ln416_452_fu_84013_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_453_fu_84221_p2() {
    xor_ln785_453_fu_84221_p2 = (tmp_3683_fu_84139_p3.read() ^ and_ln416_453_fu_84193_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_454_fu_84401_p2() {
    xor_ln785_454_fu_84401_p2 = (tmp_3690_fu_84319_p3.read() ^ and_ln416_454_fu_84373_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_455_fu_84581_p2() {
    xor_ln785_455_fu_84581_p2 = (tmp_3697_fu_84499_p3.read() ^ and_ln416_455_fu_84553_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_456_fu_84761_p2() {
    xor_ln785_456_fu_84761_p2 = (tmp_3704_fu_84679_p3.read() ^ and_ln416_456_fu_84733_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_457_fu_84941_p2() {
    xor_ln785_457_fu_84941_p2 = (tmp_3711_fu_84859_p3.read() ^ and_ln416_457_fu_84913_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_458_fu_85121_p2() {
    xor_ln785_458_fu_85121_p2 = (tmp_3718_fu_85039_p3.read() ^ and_ln416_458_fu_85093_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_459_fu_85301_p2() {
    xor_ln785_459_fu_85301_p2 = (tmp_3725_fu_85219_p3.read() ^ and_ln416_459_fu_85273_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_45_fu_12991_p2() {
    xor_ln785_45_fu_12991_p2 = (tmp_827_fu_12909_p3.read() ^ and_ln416_45_fu_12963_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_460_fu_85481_p2() {
    xor_ln785_460_fu_85481_p2 = (tmp_3732_fu_85399_p3.read() ^ and_ln416_460_fu_85453_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_461_fu_85661_p2() {
    xor_ln785_461_fu_85661_p2 = (tmp_3739_fu_85579_p3.read() ^ and_ln416_461_fu_85633_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_462_fu_85841_p2() {
    xor_ln785_462_fu_85841_p2 = (tmp_3746_fu_85759_p3.read() ^ and_ln416_462_fu_85813_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_463_fu_86021_p2() {
    xor_ln785_463_fu_86021_p2 = (tmp_3753_fu_85939_p3.read() ^ and_ln416_463_fu_85993_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_464_fu_86201_p2() {
    xor_ln785_464_fu_86201_p2 = (tmp_3760_fu_86119_p3.read() ^ and_ln416_464_fu_86173_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_465_fu_86381_p2() {
    xor_ln785_465_fu_86381_p2 = (tmp_3767_fu_86299_p3.read() ^ and_ln416_465_fu_86353_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_466_fu_86561_p2() {
    xor_ln785_466_fu_86561_p2 = (tmp_3774_fu_86479_p3.read() ^ and_ln416_466_fu_86533_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_467_fu_86741_p2() {
    xor_ln785_467_fu_86741_p2 = (tmp_3781_fu_86659_p3.read() ^ and_ln416_467_fu_86713_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_468_fu_86921_p2() {
    xor_ln785_468_fu_86921_p2 = (tmp_3788_fu_86839_p3.read() ^ and_ln416_468_fu_86893_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_469_fu_87101_p2() {
    xor_ln785_469_fu_87101_p2 = (tmp_3795_fu_87019_p3.read() ^ and_ln416_469_fu_87073_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_46_fu_13171_p2() {
    xor_ln785_46_fu_13171_p2 = (tmp_834_fu_13089_p3.read() ^ and_ln416_46_fu_13143_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_470_fu_87281_p2() {
    xor_ln785_470_fu_87281_p2 = (tmp_3802_fu_87199_p3.read() ^ and_ln416_470_fu_87253_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_471_fu_87461_p2() {
    xor_ln785_471_fu_87461_p2 = (tmp_3809_fu_87379_p3.read() ^ and_ln416_471_fu_87433_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_472_fu_87641_p2() {
    xor_ln785_472_fu_87641_p2 = (tmp_3816_fu_87559_p3.read() ^ and_ln416_472_fu_87613_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_473_fu_87821_p2() {
    xor_ln785_473_fu_87821_p2 = (tmp_3823_fu_87739_p3.read() ^ and_ln416_473_fu_87793_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_474_fu_88001_p2() {
    xor_ln785_474_fu_88001_p2 = (tmp_3830_fu_87919_p3.read() ^ and_ln416_474_fu_87973_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_475_fu_88181_p2() {
    xor_ln785_475_fu_88181_p2 = (tmp_3837_fu_88099_p3.read() ^ and_ln416_475_fu_88153_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_476_fu_88361_p2() {
    xor_ln785_476_fu_88361_p2 = (tmp_3844_fu_88279_p3.read() ^ and_ln416_476_fu_88333_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_477_fu_88541_p2() {
    xor_ln785_477_fu_88541_p2 = (tmp_3851_fu_88459_p3.read() ^ and_ln416_477_fu_88513_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_478_fu_88721_p2() {
    xor_ln785_478_fu_88721_p2 = (tmp_3858_fu_88639_p3.read() ^ and_ln416_478_fu_88693_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_479_fu_139042_p2() {
    xor_ln785_479_fu_139042_p2 = (tmp_3865_fu_138960_p3.read() ^ and_ln416_479_fu_139014_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_47_fu_13351_p2() {
    xor_ln785_47_fu_13351_p2 = (tmp_841_fu_13269_p3.read() ^ and_ln416_47_fu_13323_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_480_fu_88911_p2() {
    xor_ln785_480_fu_88911_p2 = (tmp_3872_fu_88829_p3.read() ^ and_ln416_480_fu_88883_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_481_fu_89091_p2() {
    xor_ln785_481_fu_89091_p2 = (tmp_3879_fu_89009_p3.read() ^ and_ln416_481_fu_89063_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_482_fu_89271_p2() {
    xor_ln785_482_fu_89271_p2 = (tmp_3886_fu_89189_p3.read() ^ and_ln416_482_fu_89243_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_483_fu_89451_p2() {
    xor_ln785_483_fu_89451_p2 = (tmp_3893_fu_89369_p3.read() ^ and_ln416_483_fu_89423_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_484_fu_89631_p2() {
    xor_ln785_484_fu_89631_p2 = (tmp_3900_fu_89549_p3.read() ^ and_ln416_484_fu_89603_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_485_fu_89811_p2() {
    xor_ln785_485_fu_89811_p2 = (tmp_3907_fu_89729_p3.read() ^ and_ln416_485_fu_89783_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_486_fu_89991_p2() {
    xor_ln785_486_fu_89991_p2 = (tmp_3914_fu_89909_p3.read() ^ and_ln416_486_fu_89963_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_487_fu_90171_p2() {
    xor_ln785_487_fu_90171_p2 = (tmp_3921_fu_90089_p3.read() ^ and_ln416_487_fu_90143_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_488_fu_90351_p2() {
    xor_ln785_488_fu_90351_p2 = (tmp_3928_fu_90269_p3.read() ^ and_ln416_488_fu_90323_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_489_fu_90531_p2() {
    xor_ln785_489_fu_90531_p2 = (tmp_3935_fu_90449_p3.read() ^ and_ln416_489_fu_90503_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_48_fu_13531_p2() {
    xor_ln785_48_fu_13531_p2 = (tmp_848_fu_13449_p3.read() ^ and_ln416_48_fu_13503_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_490_fu_90711_p2() {
    xor_ln785_490_fu_90711_p2 = (tmp_3942_fu_90629_p3.read() ^ and_ln416_490_fu_90683_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_491_fu_90891_p2() {
    xor_ln785_491_fu_90891_p2 = (tmp_3949_fu_90809_p3.read() ^ and_ln416_491_fu_90863_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_492_fu_91071_p2() {
    xor_ln785_492_fu_91071_p2 = (tmp_3956_fu_90989_p3.read() ^ and_ln416_492_fu_91043_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_493_fu_91251_p2() {
    xor_ln785_493_fu_91251_p2 = (tmp_3963_fu_91169_p3.read() ^ and_ln416_493_fu_91223_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_494_fu_91431_p2() {
    xor_ln785_494_fu_91431_p2 = (tmp_3970_fu_91349_p3.read() ^ and_ln416_494_fu_91403_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_495_fu_91611_p2() {
    xor_ln785_495_fu_91611_p2 = (tmp_3977_fu_91529_p3.read() ^ and_ln416_495_fu_91583_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_496_fu_91791_p2() {
    xor_ln785_496_fu_91791_p2 = (tmp_3984_fu_91709_p3.read() ^ and_ln416_496_fu_91763_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_497_fu_91971_p2() {
    xor_ln785_497_fu_91971_p2 = (tmp_3991_fu_91889_p3.read() ^ and_ln416_497_fu_91943_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_498_fu_92151_p2() {
    xor_ln785_498_fu_92151_p2 = (tmp_3998_fu_92069_p3.read() ^ and_ln416_498_fu_92123_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_499_fu_92331_p2() {
    xor_ln785_499_fu_92331_p2 = (tmp_4005_fu_92249_p3.read() ^ and_ln416_499_fu_92303_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_49_fu_13711_p2() {
    xor_ln785_49_fu_13711_p2 = (tmp_855_fu_13629_p3.read() ^ and_ln416_49_fu_13683_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_4_fu_5461_p2() {
    xor_ln785_4_fu_5461_p2 = (tmp_540_fu_5379_p3.read() ^ and_ln416_4_fu_5433_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_500_fu_92511_p2() {
    xor_ln785_500_fu_92511_p2 = (tmp_4012_fu_92429_p3.read() ^ and_ln416_500_fu_92483_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_501_fu_92691_p2() {
    xor_ln785_501_fu_92691_p2 = (tmp_4019_fu_92609_p3.read() ^ and_ln416_501_fu_92663_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_502_fu_92871_p2() {
    xor_ln785_502_fu_92871_p2 = (tmp_4026_fu_92789_p3.read() ^ and_ln416_502_fu_92843_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_503_fu_93051_p2() {
    xor_ln785_503_fu_93051_p2 = (tmp_4033_fu_92969_p3.read() ^ and_ln416_503_fu_93023_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_504_fu_93231_p2() {
    xor_ln785_504_fu_93231_p2 = (tmp_4040_fu_93149_p3.read() ^ and_ln416_504_fu_93203_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_505_fu_93411_p2() {
    xor_ln785_505_fu_93411_p2 = (tmp_4047_fu_93329_p3.read() ^ and_ln416_505_fu_93383_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_506_fu_93591_p2() {
    xor_ln785_506_fu_93591_p2 = (tmp_4054_fu_93509_p3.read() ^ and_ln416_506_fu_93563_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_507_fu_93771_p2() {
    xor_ln785_507_fu_93771_p2 = (tmp_4061_fu_93689_p3.read() ^ and_ln416_507_fu_93743_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_508_fu_93951_p2() {
    xor_ln785_508_fu_93951_p2 = (tmp_4068_fu_93869_p3.read() ^ and_ln416_508_fu_93923_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_509_fu_94131_p2() {
    xor_ln785_509_fu_94131_p2 = (tmp_4075_fu_94049_p3.read() ^ and_ln416_509_fu_94103_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_50_fu_13891_p2() {
    xor_ln785_50_fu_13891_p2 = (tmp_862_fu_13809_p3.read() ^ and_ln416_50_fu_13863_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_510_fu_94311_p2() {
    xor_ln785_510_fu_94311_p2 = (tmp_4082_fu_94229_p3.read() ^ and_ln416_510_fu_94283_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_511_fu_142047_p2() {
    xor_ln785_511_fu_142047_p2 = (tmp_4089_fu_141953_p3.read() ^ and_ln416_511_fu_142019_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_51_fu_14071_p2() {
    xor_ln785_51_fu_14071_p2 = (tmp_869_fu_13989_p3.read() ^ and_ln416_51_fu_14043_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_52_fu_14251_p2() {
    xor_ln785_52_fu_14251_p2 = (tmp_876_fu_14169_p3.read() ^ and_ln416_52_fu_14223_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_53_fu_14431_p2() {
    xor_ln785_53_fu_14431_p2 = (tmp_883_fu_14349_p3.read() ^ and_ln416_53_fu_14403_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_54_fu_14611_p2() {
    xor_ln785_54_fu_14611_p2 = (tmp_890_fu_14529_p3.read() ^ and_ln416_54_fu_14583_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_55_fu_14791_p2() {
    xor_ln785_55_fu_14791_p2 = (tmp_897_fu_14709_p3.read() ^ and_ln416_55_fu_14763_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_56_fu_14971_p2() {
    xor_ln785_56_fu_14971_p2 = (tmp_904_fu_14889_p3.read() ^ and_ln416_56_fu_14943_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_57_fu_15151_p2() {
    xor_ln785_57_fu_15151_p2 = (tmp_911_fu_15069_p3.read() ^ and_ln416_57_fu_15123_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_58_fu_15331_p2() {
    xor_ln785_58_fu_15331_p2 = (tmp_918_fu_15249_p3.read() ^ and_ln416_58_fu_15303_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_59_fu_15511_p2() {
    xor_ln785_59_fu_15511_p2 = (tmp_925_fu_15429_p3.read() ^ and_ln416_59_fu_15483_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_5_fu_5653_p2() {
    xor_ln785_5_fu_5653_p2 = (tmp_547_fu_5571_p3.read() ^ and_ln416_5_fu_5625_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_60_fu_15691_p2() {
    xor_ln785_60_fu_15691_p2 = (tmp_932_fu_15609_p3.read() ^ and_ln416_60_fu_15663_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_61_fu_15871_p2() {
    xor_ln785_61_fu_15871_p2 = (tmp_939_fu_15789_p3.read() ^ and_ln416_61_fu_15843_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_62_fu_16051_p2() {
    xor_ln785_62_fu_16051_p2 = (tmp_946_fu_15969_p3.read() ^ and_ln416_62_fu_16023_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_63_fu_100211_p2() {
    xor_ln785_63_fu_100211_p2 = (tmp_953_fu_100129_p3.read() ^ and_ln416_63_fu_100183_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_64_fu_16241_p2() {
    xor_ln785_64_fu_16241_p2 = (tmp_960_fu_16159_p3.read() ^ and_ln416_64_fu_16213_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_65_fu_16421_p2() {
    xor_ln785_65_fu_16421_p2 = (tmp_967_fu_16339_p3.read() ^ and_ln416_65_fu_16393_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_66_fu_16601_p2() {
    xor_ln785_66_fu_16601_p2 = (tmp_974_fu_16519_p3.read() ^ and_ln416_66_fu_16573_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_67_fu_16781_p2() {
    xor_ln785_67_fu_16781_p2 = (tmp_981_fu_16699_p3.read() ^ and_ln416_67_fu_16753_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_68_fu_16961_p2() {
    xor_ln785_68_fu_16961_p2 = (tmp_988_fu_16879_p3.read() ^ and_ln416_68_fu_16933_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_69_fu_17141_p2() {
    xor_ln785_69_fu_17141_p2 = (tmp_995_fu_17059_p3.read() ^ and_ln416_69_fu_17113_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_6_fu_5845_p2() {
    xor_ln785_6_fu_5845_p2 = (tmp_554_fu_5763_p3.read() ^ and_ln416_6_fu_5817_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_70_fu_17321_p2() {
    xor_ln785_70_fu_17321_p2 = (tmp_1002_fu_17239_p3.read() ^ and_ln416_70_fu_17293_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_71_fu_17501_p2() {
    xor_ln785_71_fu_17501_p2 = (tmp_1009_fu_17419_p3.read() ^ and_ln416_71_fu_17473_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_72_fu_17681_p2() {
    xor_ln785_72_fu_17681_p2 = (tmp_1016_fu_17599_p3.read() ^ and_ln416_72_fu_17653_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_73_fu_17861_p2() {
    xor_ln785_73_fu_17861_p2 = (tmp_1023_fu_17779_p3.read() ^ and_ln416_73_fu_17833_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_74_fu_18041_p2() {
    xor_ln785_74_fu_18041_p2 = (tmp_1030_fu_17959_p3.read() ^ and_ln416_74_fu_18013_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_75_fu_18221_p2() {
    xor_ln785_75_fu_18221_p2 = (tmp_1037_fu_18139_p3.read() ^ and_ln416_75_fu_18193_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_76_fu_18401_p2() {
    xor_ln785_76_fu_18401_p2 = (tmp_1044_fu_18319_p3.read() ^ and_ln416_76_fu_18373_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_77_fu_18581_p2() {
    xor_ln785_77_fu_18581_p2 = (tmp_1051_fu_18499_p3.read() ^ and_ln416_77_fu_18553_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_78_fu_18761_p2() {
    xor_ln785_78_fu_18761_p2 = (tmp_1058_fu_18679_p3.read() ^ and_ln416_78_fu_18733_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_79_fu_18941_p2() {
    xor_ln785_79_fu_18941_p2 = (tmp_1065_fu_18859_p3.read() ^ and_ln416_79_fu_18913_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_7_fu_6037_p2() {
    xor_ln785_7_fu_6037_p2 = (tmp_561_fu_5955_p3.read() ^ and_ln416_7_fu_6009_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_80_fu_19121_p2() {
    xor_ln785_80_fu_19121_p2 = (tmp_1072_fu_19039_p3.read() ^ and_ln416_80_fu_19093_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_81_fu_19301_p2() {
    xor_ln785_81_fu_19301_p2 = (tmp_1079_fu_19219_p3.read() ^ and_ln416_81_fu_19273_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_82_fu_19481_p2() {
    xor_ln785_82_fu_19481_p2 = (tmp_1086_fu_19399_p3.read() ^ and_ln416_82_fu_19453_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_83_fu_19661_p2() {
    xor_ln785_83_fu_19661_p2 = (tmp_1093_fu_19579_p3.read() ^ and_ln416_83_fu_19633_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_84_fu_19841_p2() {
    xor_ln785_84_fu_19841_p2 = (tmp_1100_fu_19759_p3.read() ^ and_ln416_84_fu_19813_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_85_fu_20021_p2() {
    xor_ln785_85_fu_20021_p2 = (tmp_1107_fu_19939_p3.read() ^ and_ln416_85_fu_19993_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_86_fu_20201_p2() {
    xor_ln785_86_fu_20201_p2 = (tmp_1114_fu_20119_p3.read() ^ and_ln416_86_fu_20173_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_87_fu_20381_p2() {
    xor_ln785_87_fu_20381_p2 = (tmp_1121_fu_20299_p3.read() ^ and_ln416_87_fu_20353_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_88_fu_20561_p2() {
    xor_ln785_88_fu_20561_p2 = (tmp_1128_fu_20479_p3.read() ^ and_ln416_88_fu_20533_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_89_fu_20741_p2() {
    xor_ln785_89_fu_20741_p2 = (tmp_1135_fu_20659_p3.read() ^ and_ln416_89_fu_20713_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_8_fu_6229_p2() {
    xor_ln785_8_fu_6229_p2 = (tmp_568_fu_6147_p3.read() ^ and_ln416_8_fu_6201_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_90_fu_20921_p2() {
    xor_ln785_90_fu_20921_p2 = (tmp_1142_fu_20839_p3.read() ^ and_ln416_90_fu_20893_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_91_fu_21101_p2() {
    xor_ln785_91_fu_21101_p2 = (tmp_1149_fu_21019_p3.read() ^ and_ln416_91_fu_21073_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_92_fu_21281_p2() {
    xor_ln785_92_fu_21281_p2 = (tmp_1156_fu_21199_p3.read() ^ and_ln416_92_fu_21253_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_93_fu_21461_p2() {
    xor_ln785_93_fu_21461_p2 = (tmp_1163_fu_21379_p3.read() ^ and_ln416_93_fu_21433_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_94_fu_21641_p2() {
    xor_ln785_94_fu_21641_p2 = (tmp_1170_fu_21559_p3.read() ^ and_ln416_94_fu_21613_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_95_fu_103198_p2() {
    xor_ln785_95_fu_103198_p2 = (tmp_1177_fu_103116_p3.read() ^ and_ln416_95_fu_103170_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_96_fu_21831_p2() {
    xor_ln785_96_fu_21831_p2 = (tmp_1184_fu_21749_p3.read() ^ and_ln416_96_fu_21803_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_97_fu_22011_p2() {
    xor_ln785_97_fu_22011_p2 = (tmp_1191_fu_21929_p3.read() ^ and_ln416_97_fu_21983_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_98_fu_22191_p2() {
    xor_ln785_98_fu_22191_p2 = (tmp_1198_fu_22109_p3.read() ^ and_ln416_98_fu_22163_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_99_fu_22371_p2() {
    xor_ln785_99_fu_22371_p2 = (tmp_1205_fu_22289_p3.read() ^ and_ln416_99_fu_22343_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_9_fu_6421_p2() {
    xor_ln785_9_fu_6421_p2 = (tmp_575_fu_6339_p3.read() ^ and_ln416_9_fu_6393_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln785_fu_4693_p2() {
    xor_ln785_fu_4693_p2 = (tmp_512_fu_4611_p3.read() ^ and_ln416_fu_4665_p2.read());
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_1000_fu_92541_p2() {
    xor_ln786_1000_fu_92541_p2 = (or_ln786_500_fu_92535_p2.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_1001_fu_141010_p2() {
    xor_ln786_1001_fu_141010_p2 = (tmp_4018_fu_141002_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_1002_fu_92721_p2() {
    xor_ln786_1002_fu_92721_p2 = (or_ln786_501_fu_92715_p2.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_1003_fu_141098_p2() {
    xor_ln786_1003_fu_141098_p2 = (tmp_4025_fu_141090_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_1004_fu_92901_p2() {
    xor_ln786_1004_fu_92901_p2 = (or_ln786_502_fu_92895_p2.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_1005_fu_141186_p2() {
    xor_ln786_1005_fu_141186_p2 = (tmp_4032_fu_141178_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_1006_fu_93081_p2() {
    xor_ln786_1006_fu_93081_p2 = (or_ln786_503_fu_93075_p2.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_1007_fu_141274_p2() {
    xor_ln786_1007_fu_141274_p2 = (tmp_4039_fu_141266_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_1008_fu_93261_p2() {
    xor_ln786_1008_fu_93261_p2 = (or_ln786_504_fu_93255_p2.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_1009_fu_141362_p2() {
    xor_ln786_1009_fu_141362_p2 = (tmp_4046_fu_141354_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_100_fu_13921_p2() {
    xor_ln786_100_fu_13921_p2 = (or_ln786_50_fu_13915_p2.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_1010_fu_93441_p2() {
    xor_ln786_1010_fu_93441_p2 = (or_ln786_505_fu_93435_p2.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_1011_fu_141450_p2() {
    xor_ln786_1011_fu_141450_p2 = (tmp_4053_fu_141442_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_1012_fu_93621_p2() {
    xor_ln786_1012_fu_93621_p2 = (or_ln786_506_fu_93615_p2.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_1013_fu_141538_p2() {
    xor_ln786_1013_fu_141538_p2 = (tmp_4060_fu_141530_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_1014_fu_93801_p2() {
    xor_ln786_1014_fu_93801_p2 = (or_ln786_507_fu_93795_p2.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_1015_fu_141626_p2() {
    xor_ln786_1015_fu_141626_p2 = (tmp_4067_fu_141618_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_1016_fu_93981_p2() {
    xor_ln786_1016_fu_93981_p2 = (or_ln786_508_fu_93975_p2.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_1017_fu_141714_p2() {
    xor_ln786_1017_fu_141714_p2 = (tmp_4074_fu_141706_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_1018_fu_94161_p2() {
    xor_ln786_1018_fu_94161_p2 = (or_ln786_509_fu_94155_p2.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_1019_fu_141802_p2() {
    xor_ln786_1019_fu_141802_p2 = (tmp_4081_fu_141794_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_101_fu_99016_p2() {
    xor_ln786_101_fu_99016_p2 = (tmp_868_fu_99008_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_1020_fu_94341_p2() {
    xor_ln786_1020_fu_94341_p2 = (or_ln786_510_fu_94335_p2.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_1021_fu_141890_p2() {
    xor_ln786_1021_fu_141890_p2 = (tmp_4088_fu_141882_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_1022_fu_142077_p2() {
    xor_ln786_1022_fu_142077_p2 = (or_ln786_511_fu_142071_p2.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_1023_fu_142167_p2() {
    xor_ln786_1023_fu_142167_p2 = (tmp_4095_fu_142159_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_102_fu_14101_p2() {
    xor_ln786_102_fu_14101_p2 = (or_ln786_51_fu_14095_p2.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_103_fu_99104_p2() {
    xor_ln786_103_fu_99104_p2 = (tmp_875_fu_99096_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_104_fu_14281_p2() {
    xor_ln786_104_fu_14281_p2 = (or_ln786_52_fu_14275_p2.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_105_fu_99192_p2() {
    xor_ln786_105_fu_99192_p2 = (tmp_882_fu_99184_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_106_fu_14461_p2() {
    xor_ln786_106_fu_14461_p2 = (or_ln786_53_fu_14455_p2.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_107_fu_99280_p2() {
    xor_ln786_107_fu_99280_p2 = (tmp_889_fu_99272_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_108_fu_14641_p2() {
    xor_ln786_108_fu_14641_p2 = (or_ln786_54_fu_14635_p2.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_109_fu_99368_p2() {
    xor_ln786_109_fu_99368_p2 = (tmp_896_fu_99360_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_10_fu_5683_p2() {
    xor_ln786_10_fu_5683_p2 = (or_ln786_5_fu_5677_p2.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_110_fu_14821_p2() {
    xor_ln786_110_fu_14821_p2 = (or_ln786_55_fu_14815_p2.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_111_fu_99456_p2() {
    xor_ln786_111_fu_99456_p2 = (tmp_903_fu_99448_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_112_fu_15001_p2() {
    xor_ln786_112_fu_15001_p2 = (or_ln786_56_fu_14995_p2.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_113_fu_99544_p2() {
    xor_ln786_113_fu_99544_p2 = (tmp_910_fu_99536_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_114_fu_15181_p2() {
    xor_ln786_114_fu_15181_p2 = (or_ln786_57_fu_15175_p2.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_115_fu_99632_p2() {
    xor_ln786_115_fu_99632_p2 = (tmp_917_fu_99624_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_116_fu_15361_p2() {
    xor_ln786_116_fu_15361_p2 = (or_ln786_58_fu_15355_p2.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_117_fu_99720_p2() {
    xor_ln786_117_fu_99720_p2 = (tmp_924_fu_99712_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_118_fu_15541_p2() {
    xor_ln786_118_fu_15541_p2 = (or_ln786_59_fu_15535_p2.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_119_fu_99808_p2() {
    xor_ln786_119_fu_99808_p2 = (tmp_931_fu_99800_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_11_fu_94879_p2() {
    xor_ln786_11_fu_94879_p2 = (tmp_553_fu_94871_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_120_fu_15721_p2() {
    xor_ln786_120_fu_15721_p2 = (or_ln786_60_fu_15715_p2.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_121_fu_99896_p2() {
    xor_ln786_121_fu_99896_p2 = (tmp_938_fu_99888_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_122_fu_15901_p2() {
    xor_ln786_122_fu_15901_p2 = (or_ln786_61_fu_15895_p2.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_123_fu_99984_p2() {
    xor_ln786_123_fu_99984_p2 = (tmp_945_fu_99976_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_124_fu_16081_p2() {
    xor_ln786_124_fu_16081_p2 = (or_ln786_62_fu_16075_p2.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_125_fu_100072_p2() {
    xor_ln786_125_fu_100072_p2 = (tmp_952_fu_100064_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_126_fu_100241_p2() {
    xor_ln786_126_fu_100241_p2 = (or_ln786_63_fu_100235_p2.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_127_fu_100331_p2() {
    xor_ln786_127_fu_100331_p2 = (tmp_959_fu_100323_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_128_fu_16271_p2() {
    xor_ln786_128_fu_16271_p2 = (or_ln786_64_fu_16265_p2.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_129_fu_100419_p2() {
    xor_ln786_129_fu_100419_p2 = (tmp_966_fu_100411_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_12_fu_5875_p2() {
    xor_ln786_12_fu_5875_p2 = (or_ln786_6_fu_5869_p2.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_130_fu_16451_p2() {
    xor_ln786_130_fu_16451_p2 = (or_ln786_65_fu_16445_p2.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_131_fu_100507_p2() {
    xor_ln786_131_fu_100507_p2 = (tmp_973_fu_100499_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_132_fu_16631_p2() {
    xor_ln786_132_fu_16631_p2 = (or_ln786_66_fu_16625_p2.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_133_fu_100595_p2() {
    xor_ln786_133_fu_100595_p2 = (tmp_980_fu_100587_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_134_fu_16811_p2() {
    xor_ln786_134_fu_16811_p2 = (or_ln786_67_fu_16805_p2.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_135_fu_100683_p2() {
    xor_ln786_135_fu_100683_p2 = (tmp_987_fu_100675_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_136_fu_16991_p2() {
    xor_ln786_136_fu_16991_p2 = (or_ln786_68_fu_16985_p2.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_137_fu_100771_p2() {
    xor_ln786_137_fu_100771_p2 = (tmp_994_fu_100763_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_138_fu_17171_p2() {
    xor_ln786_138_fu_17171_p2 = (or_ln786_69_fu_17165_p2.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_139_fu_100859_p2() {
    xor_ln786_139_fu_100859_p2 = (tmp_1001_fu_100851_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_13_fu_94967_p2() {
    xor_ln786_13_fu_94967_p2 = (tmp_560_fu_94959_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_140_fu_17351_p2() {
    xor_ln786_140_fu_17351_p2 = (or_ln786_70_fu_17345_p2.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_141_fu_100947_p2() {
    xor_ln786_141_fu_100947_p2 = (tmp_1008_fu_100939_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_142_fu_17531_p2() {
    xor_ln786_142_fu_17531_p2 = (or_ln786_71_fu_17525_p2.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_143_fu_101035_p2() {
    xor_ln786_143_fu_101035_p2 = (tmp_1015_fu_101027_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_144_fu_17711_p2() {
    xor_ln786_144_fu_17711_p2 = (or_ln786_72_fu_17705_p2.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_145_fu_101123_p2() {
    xor_ln786_145_fu_101123_p2 = (tmp_1022_fu_101115_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_146_fu_17891_p2() {
    xor_ln786_146_fu_17891_p2 = (or_ln786_73_fu_17885_p2.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_147_fu_101211_p2() {
    xor_ln786_147_fu_101211_p2 = (tmp_1029_fu_101203_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_148_fu_18071_p2() {
    xor_ln786_148_fu_18071_p2 = (or_ln786_74_fu_18065_p2.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_149_fu_101299_p2() {
    xor_ln786_149_fu_101299_p2 = (tmp_1036_fu_101291_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_14_fu_6067_p2() {
    xor_ln786_14_fu_6067_p2 = (or_ln786_7_fu_6061_p2.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_150_fu_18251_p2() {
    xor_ln786_150_fu_18251_p2 = (or_ln786_75_fu_18245_p2.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_151_fu_101387_p2() {
    xor_ln786_151_fu_101387_p2 = (tmp_1043_fu_101379_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_152_fu_18431_p2() {
    xor_ln786_152_fu_18431_p2 = (or_ln786_76_fu_18425_p2.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_153_fu_101475_p2() {
    xor_ln786_153_fu_101475_p2 = (tmp_1050_fu_101467_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_154_fu_18611_p2() {
    xor_ln786_154_fu_18611_p2 = (or_ln786_77_fu_18605_p2.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_155_fu_101563_p2() {
    xor_ln786_155_fu_101563_p2 = (tmp_1057_fu_101555_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_156_fu_18791_p2() {
    xor_ln786_156_fu_18791_p2 = (or_ln786_78_fu_18785_p2.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_157_fu_101651_p2() {
    xor_ln786_157_fu_101651_p2 = (tmp_1064_fu_101643_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_158_fu_18971_p2() {
    xor_ln786_158_fu_18971_p2 = (or_ln786_79_fu_18965_p2.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_159_fu_101739_p2() {
    xor_ln786_159_fu_101739_p2 = (tmp_1071_fu_101731_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_15_fu_95055_p2() {
    xor_ln786_15_fu_95055_p2 = (tmp_567_fu_95047_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_160_fu_19151_p2() {
    xor_ln786_160_fu_19151_p2 = (or_ln786_80_fu_19145_p2.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_161_fu_101827_p2() {
    xor_ln786_161_fu_101827_p2 = (tmp_1078_fu_101819_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_162_fu_19331_p2() {
    xor_ln786_162_fu_19331_p2 = (or_ln786_81_fu_19325_p2.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_163_fu_101915_p2() {
    xor_ln786_163_fu_101915_p2 = (tmp_1085_fu_101907_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_164_fu_19511_p2() {
    xor_ln786_164_fu_19511_p2 = (or_ln786_82_fu_19505_p2.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_165_fu_102003_p2() {
    xor_ln786_165_fu_102003_p2 = (tmp_1092_fu_101995_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_166_fu_19691_p2() {
    xor_ln786_166_fu_19691_p2 = (or_ln786_83_fu_19685_p2.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_167_fu_102091_p2() {
    xor_ln786_167_fu_102091_p2 = (tmp_1099_fu_102083_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_168_fu_19871_p2() {
    xor_ln786_168_fu_19871_p2 = (or_ln786_84_fu_19865_p2.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_169_fu_102179_p2() {
    xor_ln786_169_fu_102179_p2 = (tmp_1106_fu_102171_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_16_fu_6259_p2() {
    xor_ln786_16_fu_6259_p2 = (or_ln786_8_fu_6253_p2.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_170_fu_20051_p2() {
    xor_ln786_170_fu_20051_p2 = (or_ln786_85_fu_20045_p2.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_171_fu_102267_p2() {
    xor_ln786_171_fu_102267_p2 = (tmp_1113_fu_102259_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_172_fu_20231_p2() {
    xor_ln786_172_fu_20231_p2 = (or_ln786_86_fu_20225_p2.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_173_fu_102355_p2() {
    xor_ln786_173_fu_102355_p2 = (tmp_1120_fu_102347_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_174_fu_20411_p2() {
    xor_ln786_174_fu_20411_p2 = (or_ln786_87_fu_20405_p2.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_175_fu_102443_p2() {
    xor_ln786_175_fu_102443_p2 = (tmp_1127_fu_102435_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_176_fu_20591_p2() {
    xor_ln786_176_fu_20591_p2 = (or_ln786_88_fu_20585_p2.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_177_fu_102531_p2() {
    xor_ln786_177_fu_102531_p2 = (tmp_1134_fu_102523_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_178_fu_20771_p2() {
    xor_ln786_178_fu_20771_p2 = (or_ln786_89_fu_20765_p2.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_179_fu_102619_p2() {
    xor_ln786_179_fu_102619_p2 = (tmp_1141_fu_102611_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_17_fu_95143_p2() {
    xor_ln786_17_fu_95143_p2 = (tmp_574_fu_95135_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_180_fu_20951_p2() {
    xor_ln786_180_fu_20951_p2 = (or_ln786_90_fu_20945_p2.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_181_fu_102707_p2() {
    xor_ln786_181_fu_102707_p2 = (tmp_1148_fu_102699_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_182_fu_21131_p2() {
    xor_ln786_182_fu_21131_p2 = (or_ln786_91_fu_21125_p2.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_183_fu_102795_p2() {
    xor_ln786_183_fu_102795_p2 = (tmp_1155_fu_102787_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_184_fu_21311_p2() {
    xor_ln786_184_fu_21311_p2 = (or_ln786_92_fu_21305_p2.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_185_fu_102883_p2() {
    xor_ln786_185_fu_102883_p2 = (tmp_1162_fu_102875_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_186_fu_21491_p2() {
    xor_ln786_186_fu_21491_p2 = (or_ln786_93_fu_21485_p2.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_187_fu_102971_p2() {
    xor_ln786_187_fu_102971_p2 = (tmp_1169_fu_102963_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_188_fu_21671_p2() {
    xor_ln786_188_fu_21671_p2 = (or_ln786_94_fu_21665_p2.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_189_fu_103059_p2() {
    xor_ln786_189_fu_103059_p2 = (tmp_1176_fu_103051_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_18_fu_6451_p2() {
    xor_ln786_18_fu_6451_p2 = (or_ln786_9_fu_6445_p2.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_190_fu_103228_p2() {
    xor_ln786_190_fu_103228_p2 = (or_ln786_95_fu_103222_p2.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_191_fu_103318_p2() {
    xor_ln786_191_fu_103318_p2 = (tmp_1183_fu_103310_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_192_fu_21861_p2() {
    xor_ln786_192_fu_21861_p2 = (or_ln786_96_fu_21855_p2.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_193_fu_103406_p2() {
    xor_ln786_193_fu_103406_p2 = (tmp_1190_fu_103398_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_194_fu_22041_p2() {
    xor_ln786_194_fu_22041_p2 = (or_ln786_97_fu_22035_p2.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_195_fu_103494_p2() {
    xor_ln786_195_fu_103494_p2 = (tmp_1197_fu_103486_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_196_fu_22221_p2() {
    xor_ln786_196_fu_22221_p2 = (or_ln786_98_fu_22215_p2.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_197_fu_103582_p2() {
    xor_ln786_197_fu_103582_p2 = (tmp_1204_fu_103574_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_198_fu_22401_p2() {
    xor_ln786_198_fu_22401_p2 = (or_ln786_99_fu_22395_p2.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_199_fu_103670_p2() {
    xor_ln786_199_fu_103670_p2 = (tmp_1211_fu_103662_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_19_fu_95231_p2() {
    xor_ln786_19_fu_95231_p2 = (tmp_581_fu_95223_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_1_fu_94439_p2() {
    xor_ln786_1_fu_94439_p2 = (tmp_518_fu_94431_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_200_fu_22581_p2() {
    xor_ln786_200_fu_22581_p2 = (or_ln786_100_fu_22575_p2.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_201_fu_103758_p2() {
    xor_ln786_201_fu_103758_p2 = (tmp_1218_fu_103750_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_202_fu_22761_p2() {
    xor_ln786_202_fu_22761_p2 = (or_ln786_101_fu_22755_p2.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_203_fu_103846_p2() {
    xor_ln786_203_fu_103846_p2 = (tmp_1225_fu_103838_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_204_fu_22941_p2() {
    xor_ln786_204_fu_22941_p2 = (or_ln786_102_fu_22935_p2.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_205_fu_103934_p2() {
    xor_ln786_205_fu_103934_p2 = (tmp_1232_fu_103926_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_206_fu_23121_p2() {
    xor_ln786_206_fu_23121_p2 = (or_ln786_103_fu_23115_p2.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_207_fu_104022_p2() {
    xor_ln786_207_fu_104022_p2 = (tmp_1239_fu_104014_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_208_fu_23301_p2() {
    xor_ln786_208_fu_23301_p2 = (or_ln786_104_fu_23295_p2.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_209_fu_104110_p2() {
    xor_ln786_209_fu_104110_p2 = (tmp_1246_fu_104102_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_20_fu_6643_p2() {
    xor_ln786_20_fu_6643_p2 = (or_ln786_10_fu_6637_p2.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_210_fu_23481_p2() {
    xor_ln786_210_fu_23481_p2 = (or_ln786_105_fu_23475_p2.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_211_fu_104198_p2() {
    xor_ln786_211_fu_104198_p2 = (tmp_1253_fu_104190_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_212_fu_23661_p2() {
    xor_ln786_212_fu_23661_p2 = (or_ln786_106_fu_23655_p2.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_213_fu_104286_p2() {
    xor_ln786_213_fu_104286_p2 = (tmp_1260_fu_104278_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_214_fu_23841_p2() {
    xor_ln786_214_fu_23841_p2 = (or_ln786_107_fu_23835_p2.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_215_fu_104374_p2() {
    xor_ln786_215_fu_104374_p2 = (tmp_1267_fu_104366_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_216_fu_24021_p2() {
    xor_ln786_216_fu_24021_p2 = (or_ln786_108_fu_24015_p2.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_217_fu_104462_p2() {
    xor_ln786_217_fu_104462_p2 = (tmp_1274_fu_104454_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_218_fu_24201_p2() {
    xor_ln786_218_fu_24201_p2 = (or_ln786_109_fu_24195_p2.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_219_fu_104550_p2() {
    xor_ln786_219_fu_104550_p2 = (tmp_1281_fu_104542_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_21_fu_95319_p2() {
    xor_ln786_21_fu_95319_p2 = (tmp_588_fu_95311_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_220_fu_24381_p2() {
    xor_ln786_220_fu_24381_p2 = (or_ln786_110_fu_24375_p2.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_221_fu_104638_p2() {
    xor_ln786_221_fu_104638_p2 = (tmp_1288_fu_104630_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_222_fu_24561_p2() {
    xor_ln786_222_fu_24561_p2 = (or_ln786_111_fu_24555_p2.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_223_fu_104726_p2() {
    xor_ln786_223_fu_104726_p2 = (tmp_1295_fu_104718_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_224_fu_24741_p2() {
    xor_ln786_224_fu_24741_p2 = (or_ln786_112_fu_24735_p2.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_225_fu_104814_p2() {
    xor_ln786_225_fu_104814_p2 = (tmp_1302_fu_104806_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_226_fu_24921_p2() {
    xor_ln786_226_fu_24921_p2 = (or_ln786_113_fu_24915_p2.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_227_fu_104902_p2() {
    xor_ln786_227_fu_104902_p2 = (tmp_1309_fu_104894_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_228_fu_25101_p2() {
    xor_ln786_228_fu_25101_p2 = (or_ln786_114_fu_25095_p2.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_229_fu_104990_p2() {
    xor_ln786_229_fu_104990_p2 = (tmp_1316_fu_104982_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_22_fu_6835_p2() {
    xor_ln786_22_fu_6835_p2 = (or_ln786_11_fu_6829_p2.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_230_fu_25281_p2() {
    xor_ln786_230_fu_25281_p2 = (or_ln786_115_fu_25275_p2.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_231_fu_105078_p2() {
    xor_ln786_231_fu_105078_p2 = (tmp_1323_fu_105070_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_232_fu_25461_p2() {
    xor_ln786_232_fu_25461_p2 = (or_ln786_116_fu_25455_p2.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_233_fu_105166_p2() {
    xor_ln786_233_fu_105166_p2 = (tmp_1330_fu_105158_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_234_fu_25641_p2() {
    xor_ln786_234_fu_25641_p2 = (or_ln786_117_fu_25635_p2.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_235_fu_105254_p2() {
    xor_ln786_235_fu_105254_p2 = (tmp_1337_fu_105246_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_236_fu_25821_p2() {
    xor_ln786_236_fu_25821_p2 = (or_ln786_118_fu_25815_p2.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_237_fu_105342_p2() {
    xor_ln786_237_fu_105342_p2 = (tmp_1344_fu_105334_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_238_fu_26001_p2() {
    xor_ln786_238_fu_26001_p2 = (or_ln786_119_fu_25995_p2.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_239_fu_105430_p2() {
    xor_ln786_239_fu_105430_p2 = (tmp_1351_fu_105422_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_23_fu_95407_p2() {
    xor_ln786_23_fu_95407_p2 = (tmp_595_fu_95399_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_240_fu_26181_p2() {
    xor_ln786_240_fu_26181_p2 = (or_ln786_120_fu_26175_p2.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_241_fu_105518_p2() {
    xor_ln786_241_fu_105518_p2 = (tmp_1358_fu_105510_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_242_fu_26361_p2() {
    xor_ln786_242_fu_26361_p2 = (or_ln786_121_fu_26355_p2.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_243_fu_105606_p2() {
    xor_ln786_243_fu_105606_p2 = (tmp_1365_fu_105598_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_244_fu_26541_p2() {
    xor_ln786_244_fu_26541_p2 = (or_ln786_122_fu_26535_p2.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_245_fu_105694_p2() {
    xor_ln786_245_fu_105694_p2 = (tmp_1372_fu_105686_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_246_fu_26721_p2() {
    xor_ln786_246_fu_26721_p2 = (or_ln786_123_fu_26715_p2.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_247_fu_105782_p2() {
    xor_ln786_247_fu_105782_p2 = (tmp_1379_fu_105774_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_248_fu_26901_p2() {
    xor_ln786_248_fu_26901_p2 = (or_ln786_124_fu_26895_p2.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_249_fu_105870_p2() {
    xor_ln786_249_fu_105870_p2 = (tmp_1386_fu_105862_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_24_fu_7027_p2() {
    xor_ln786_24_fu_7027_p2 = (or_ln786_12_fu_7021_p2.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_250_fu_27081_p2() {
    xor_ln786_250_fu_27081_p2 = (or_ln786_125_fu_27075_p2.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_251_fu_105958_p2() {
    xor_ln786_251_fu_105958_p2 = (tmp_1393_fu_105950_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_252_fu_27261_p2() {
    xor_ln786_252_fu_27261_p2 = (or_ln786_126_fu_27255_p2.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_253_fu_106046_p2() {
    xor_ln786_253_fu_106046_p2 = (tmp_1400_fu_106038_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_254_fu_106215_p2() {
    xor_ln786_254_fu_106215_p2 = (or_ln786_127_fu_106209_p2.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_255_fu_106305_p2() {
    xor_ln786_255_fu_106305_p2 = (tmp_1407_fu_106297_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_256_fu_27451_p2() {
    xor_ln786_256_fu_27451_p2 = (or_ln786_128_fu_27445_p2.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_257_fu_106393_p2() {
    xor_ln786_257_fu_106393_p2 = (tmp_1414_fu_106385_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_258_fu_27631_p2() {
    xor_ln786_258_fu_27631_p2 = (or_ln786_129_fu_27625_p2.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_259_fu_106481_p2() {
    xor_ln786_259_fu_106481_p2 = (tmp_1421_fu_106473_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_25_fu_95495_p2() {
    xor_ln786_25_fu_95495_p2 = (tmp_602_fu_95487_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_260_fu_27811_p2() {
    xor_ln786_260_fu_27811_p2 = (or_ln786_130_fu_27805_p2.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_261_fu_106569_p2() {
    xor_ln786_261_fu_106569_p2 = (tmp_1428_fu_106561_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_262_fu_27991_p2() {
    xor_ln786_262_fu_27991_p2 = (or_ln786_131_fu_27985_p2.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_263_fu_106657_p2() {
    xor_ln786_263_fu_106657_p2 = (tmp_1435_fu_106649_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_264_fu_28171_p2() {
    xor_ln786_264_fu_28171_p2 = (or_ln786_132_fu_28165_p2.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_265_fu_106745_p2() {
    xor_ln786_265_fu_106745_p2 = (tmp_1442_fu_106737_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_266_fu_28351_p2() {
    xor_ln786_266_fu_28351_p2 = (or_ln786_133_fu_28345_p2.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_267_fu_106833_p2() {
    xor_ln786_267_fu_106833_p2 = (tmp_1449_fu_106825_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_268_fu_28531_p2() {
    xor_ln786_268_fu_28531_p2 = (or_ln786_134_fu_28525_p2.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_269_fu_106921_p2() {
    xor_ln786_269_fu_106921_p2 = (tmp_1456_fu_106913_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_26_fu_7219_p2() {
    xor_ln786_26_fu_7219_p2 = (or_ln786_13_fu_7213_p2.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_270_fu_28711_p2() {
    xor_ln786_270_fu_28711_p2 = (or_ln786_135_fu_28705_p2.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_271_fu_107009_p2() {
    xor_ln786_271_fu_107009_p2 = (tmp_1463_fu_107001_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_272_fu_28891_p2() {
    xor_ln786_272_fu_28891_p2 = (or_ln786_136_fu_28885_p2.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_273_fu_107097_p2() {
    xor_ln786_273_fu_107097_p2 = (tmp_1470_fu_107089_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_274_fu_29071_p2() {
    xor_ln786_274_fu_29071_p2 = (or_ln786_137_fu_29065_p2.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_275_fu_107185_p2() {
    xor_ln786_275_fu_107185_p2 = (tmp_1477_fu_107177_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_276_fu_29251_p2() {
    xor_ln786_276_fu_29251_p2 = (or_ln786_138_fu_29245_p2.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_277_fu_107273_p2() {
    xor_ln786_277_fu_107273_p2 = (tmp_1484_fu_107265_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_278_fu_29431_p2() {
    xor_ln786_278_fu_29431_p2 = (or_ln786_139_fu_29425_p2.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_279_fu_107361_p2() {
    xor_ln786_279_fu_107361_p2 = (tmp_1491_fu_107353_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_27_fu_95583_p2() {
    xor_ln786_27_fu_95583_p2 = (tmp_609_fu_95575_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_280_fu_29611_p2() {
    xor_ln786_280_fu_29611_p2 = (or_ln786_140_fu_29605_p2.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_281_fu_107449_p2() {
    xor_ln786_281_fu_107449_p2 = (tmp_1498_fu_107441_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_282_fu_29791_p2() {
    xor_ln786_282_fu_29791_p2 = (or_ln786_141_fu_29785_p2.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_283_fu_107537_p2() {
    xor_ln786_283_fu_107537_p2 = (tmp_1505_fu_107529_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_284_fu_29971_p2() {
    xor_ln786_284_fu_29971_p2 = (or_ln786_142_fu_29965_p2.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_285_fu_107625_p2() {
    xor_ln786_285_fu_107625_p2 = (tmp_1512_fu_107617_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_286_fu_30151_p2() {
    xor_ln786_286_fu_30151_p2 = (or_ln786_143_fu_30145_p2.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_287_fu_107713_p2() {
    xor_ln786_287_fu_107713_p2 = (tmp_1519_fu_107705_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_288_fu_30331_p2() {
    xor_ln786_288_fu_30331_p2 = (or_ln786_144_fu_30325_p2.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_289_fu_107801_p2() {
    xor_ln786_289_fu_107801_p2 = (tmp_1526_fu_107793_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_28_fu_7411_p2() {
    xor_ln786_28_fu_7411_p2 = (or_ln786_14_fu_7405_p2.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_290_fu_30511_p2() {
    xor_ln786_290_fu_30511_p2 = (or_ln786_145_fu_30505_p2.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_291_fu_107889_p2() {
    xor_ln786_291_fu_107889_p2 = (tmp_1533_fu_107881_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_292_fu_30691_p2() {
    xor_ln786_292_fu_30691_p2 = (or_ln786_146_fu_30685_p2.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_293_fu_107977_p2() {
    xor_ln786_293_fu_107977_p2 = (tmp_1540_fu_107969_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_294_fu_30871_p2() {
    xor_ln786_294_fu_30871_p2 = (or_ln786_147_fu_30865_p2.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_295_fu_108065_p2() {
    xor_ln786_295_fu_108065_p2 = (tmp_1547_fu_108057_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_296_fu_31051_p2() {
    xor_ln786_296_fu_31051_p2 = (or_ln786_148_fu_31045_p2.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_297_fu_108153_p2() {
    xor_ln786_297_fu_108153_p2 = (tmp_1554_fu_108145_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_298_fu_31231_p2() {
    xor_ln786_298_fu_31231_p2 = (or_ln786_149_fu_31225_p2.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_299_fu_108241_p2() {
    xor_ln786_299_fu_108241_p2 = (tmp_1561_fu_108233_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_29_fu_95671_p2() {
    xor_ln786_29_fu_95671_p2 = (tmp_616_fu_95663_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_2_fu_4915_p2() {
    xor_ln786_2_fu_4915_p2 = (or_ln786_1_fu_4909_p2.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_300_fu_31411_p2() {
    xor_ln786_300_fu_31411_p2 = (or_ln786_150_fu_31405_p2.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_301_fu_108329_p2() {
    xor_ln786_301_fu_108329_p2 = (tmp_1568_fu_108321_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_302_fu_31591_p2() {
    xor_ln786_302_fu_31591_p2 = (or_ln786_151_fu_31585_p2.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_303_fu_108417_p2() {
    xor_ln786_303_fu_108417_p2 = (tmp_1575_fu_108409_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_304_fu_31771_p2() {
    xor_ln786_304_fu_31771_p2 = (or_ln786_152_fu_31765_p2.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_305_fu_108505_p2() {
    xor_ln786_305_fu_108505_p2 = (tmp_1582_fu_108497_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_306_fu_31951_p2() {
    xor_ln786_306_fu_31951_p2 = (or_ln786_153_fu_31945_p2.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_307_fu_108593_p2() {
    xor_ln786_307_fu_108593_p2 = (tmp_1589_fu_108585_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_308_fu_32131_p2() {
    xor_ln786_308_fu_32131_p2 = (or_ln786_154_fu_32125_p2.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_309_fu_108681_p2() {
    xor_ln786_309_fu_108681_p2 = (tmp_1596_fu_108673_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_30_fu_7603_p2() {
    xor_ln786_30_fu_7603_p2 = (or_ln786_15_fu_7597_p2.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_310_fu_32311_p2() {
    xor_ln786_310_fu_32311_p2 = (or_ln786_155_fu_32305_p2.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_311_fu_108769_p2() {
    xor_ln786_311_fu_108769_p2 = (tmp_1603_fu_108761_p3.read() ^ ap_const_lv1_1);
}

void dense_wrapper_ap_fixed_24_16_0_0_0_ap_fixed_24_16_0_0_0_config15_s::thread_xor_ln786_312_fu_32491_p2() {
    xor_ln786_312_fu_32491_p2 = (or_ln786_156_fu_32485_p2.read() ^ ap_const_lv1_1);
}

}

